﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Preference.Agreement.Command;
using PARSNextGen.Application.Preference.Agreement.Queries;
using PARSNextGen.Application.Preference.IcInstructions.Command;
using PARSNextGen.Application.Preference.IcInstructions.Query;
using PARSNextGen.Application.Preference.Preference.Command;
using PARSNextGen.Application.Preference.Preference.Queries;
using PARSNextGen.Application.Preference.RuleEditor.Queries;
using PARSNextGen.Application.Preference.StateInspection.Command;
using PARSNextGen.Application.Preference.StateInspection.Queries;
using PARSNextGen.Application.QueuePreferenceRule;
using PARSNextGen.Application.Service;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class PreferenceController : Controller
    {
        private readonly ILogger<AccountController> _logger;
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;
        // private readonly IHostingEnvironment _hostingEnvironment;

        public PreferenceController(ILogger<AccountController> logger, IMediator mediator, ICustomMessageService customMsgSvc)//IHostingEnvironment hostingEnvironment)
        {
            _logger = logger;
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
            //  _hostingEnvironment = hostingEnvironment;
        }

        #region API CONTROLLER METHODS

        /// <summary>
        /// API get details of Vehicle Master
        /// </summary>
        /// <returns> List of all master Data </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<AgreementMasterDataDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAgreementMasterData()
        {
            ResponseBase<AgreementMasterDataDto> response = new ResponseBase<AgreementMasterDataDto>();
            var agreementMasters = await _mediator.Send(new GetAgreementMasterDataQuery { });
            if (agreementMasters != null)
            {

                response.Data = agreementMasters;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }



        /// <summary>
        /// API to get agreements
        /// </summary>
        /// <returns> List of all agreements. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<AllAgreementsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllAgreements()
        {
            ResponseBase<List<AllAgreementsDto>> response = new ResponseBase<List<AllAgreementsDto>>();

            var agreementDetails = await _mediator.Send(new GetAllAgreementsQuery { });
            if (agreementDetails != null && agreementDetails.Count > 0)
            {
                response.Data = agreementDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to get agreement by id
        /// </summary>
        /// <param name="id"> Agreement Id</param>
        /// <returns> Get Agreement. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<AgreementDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAgreementById(long id)
        {
            ResponseBase<AgreementDto> response = new ResponseBase<AgreementDto>();

            var agreementDetails = await _mediator.Send(new GetAgreementByIdQuery { id = id });
            if (agreementDetails != null)
            {
                response.Data = agreementDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to create agreements
        /// </summary>
        /// <param name="createAgreementReq"> CreateAgreementReq</param>
        /// <returns> Create Agreements. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateAgreement(CreateAgreementReq createAgreementReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            //#region Get related agreement
            //var agreement_id = await _mediator.Send(new GetAgreementQuery { fmc_id = createAgreementReq.fmc_id, fleet_id = createAgreementReq.fleet_id });
            //if (agreement_id == null)
            //    throw new BusinessException("PARS_AGREEMENT_NOT_FOUND");
            //#endregion End

            //CreateAgreementReq agreementReq = new CreateAgreementReq();

            //agreementReq.name = createAgreementReq.name;
            //agreementReq.fmc_id = createAgreementReq.fmc_id;
            //agreementReq.fleet_id = createAgreementReq.fleet_id;
            //agreementReq.start_date = createAgreementReq.start_date;
            //agreementReq.end_date = createAgreementReq.end_date;
            //agreementReq.currency_id = (long)createAgreementReq.currency_id;
            //agreementReq.default_bill_to_id = (long)createAgreementReq.default_bill_to_id;
            //agreementReq.parent_agreement_id = createAgreementReq.parent_agreement_id;
            //agreementReq.transportation_preference_type_id = (long)createAgreementReq.transportation_preference_type_id;
            //agreementReq.agreement_status_id = (long)createAgreementReq.agreement_status_id;
            //agreementReq.pars_perform_inspection = createAgreementReq.pars_perform_inspection;


            bool newAgreement = await _mediator.Send(new CreateAgreementCommand
            {
                createAgreementReqs = createAgreementReq

            });
            if (newAgreement)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        /// <summary>
        /// API to update agreements
        /// </summary>
        /// <param name="updateAgreementReq"> UpdateAgreementReq</param>
        /// <returns> Update Agreements. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateAgreement(UpdateAgreementReq updateAgreementReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            bool newAgreement = await _mediator.Send(new UpdateAgreementCommand
            {
                updateAgreementReq = updateAgreementReq

            });
            if (newAgreement)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// API to Get Rule Editor Settings
        /// </summary>
        /// <param name="preferenceType"> Preference Type</param>
        /// <param name="ruleType"> Rule Type</param>
        /// <param name="editorId"> Editor Id</param>
        /// <returns> ClientSettingsDto </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<ClientSettingsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEditorSettings(long? preferenceType, long? ruleType, string editorId)
        {
            ResponseBase<ClientSettingsDto> response = new ResponseBase<ClientSettingsDto>();

            var clientSettingsDto = await _mediator.Send(new GetRuleEditorSettingQuery { editorId = editorId, preferenceType = preferenceType, ruleType = ruleType });
            if (clientSettingsDto != null)
            {
                response.Data = clientSettingsDto;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }




        /// <summary>
        /// API to Get Get Preference Master Data
        /// </summary>
        /// <returns> List of Preference Master Data   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<PreferenceMasterDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPreferenceMasterData()
        {
            ResponseBase<List<PreferenceMasterDto>> response = new ResponseBase<List<PreferenceMasterDto>>();
            var preferenceMaster = await _mediator.Send(new GetPreferenceMasterQuery { });
            if (preferenceMaster != null)
            {
                List<PreferenceMasterDto> resp = new List<PreferenceMasterDto>();
                resp.Add(preferenceMaster);
                response.Data = resp;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to create Preference
        /// </summary>
        /// <param name="createAgreementReq"> CreatePreferenceReq</param>
        /// <returns> Create Preference. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreatePreference(CreatePreferenceReq createPreferenceReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            string result = await _mediator.Send(new CreatePreferenceCommand
            {
                createPreferenceReq = createPreferenceReq

            });
            if (!string.IsNullOrEmpty(result))
            {
                if (result == "PARS_RECORD_CREATE_SUCCESS")
                    response.IsSuccessful = true;
                else
                    response.IsSuccessful = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode(result);
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        /// <summary>
        /// API to update agreements
        /// </summary>
        /// <param name="updateAgreementReq"> UpdateAgreementReq</param>
        /// <returns> Update Agreements. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdatePreference(UpdatePreferenceReq updatePreferenceReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            bool newAgreement = await _mediator.Send(new UpdatePreferenceCommand
            {
                updatePreferenceReq = updatePreferenceReq

            });
            if (newAgreement)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// API to Get Preferences By Agreement Id
        /// </summary>
        /// <param name="agreementId"> Agreement Id</param>
        /// <returns> Preference List </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<PreferenceDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPreferenceByAgreementId(long agreementId, long? eventTypeId)
        {
            ResponseBase<List<PreferenceDto>> response = new ResponseBase<List<PreferenceDto>>();

            List<PreferenceDto> preferencesList = await _mediator.Send(new GetPreferencesByAgreementIdQuery
            {
                agreementId = agreementId,
                eventTypeId = eventTypeId

            });

            if (preferencesList != null && preferencesList.Count > 0)
            {
                string json = JsonConvert.SerializeObject(preferencesList);
                json = json.Replace("\\r\\n", "");
                preferencesList = JsonConvert.DeserializeObject<List<PreferenceDto>>(json);
                response.Data = preferencesList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            }
            else
            {
                response.Data = preferencesList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
            }

            return new OkObjectResult(response);

        }

        /// <summary>
        /// API to get preference by id
        /// </summary>
        /// <param name="id"> Preference Id</param>
        /// <returns>Preference Data </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<PreferenceDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPreferenceById(long id)
        {
            ResponseBase<PreferenceDto> response = new ResponseBase<PreferenceDto>();

            var preferenceDetails = await _mediator.Send(new GetPreferenceByIdQuery { preferenceId = id });
            if (preferenceDetails != null)
            {
                response.Data = preferenceDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to update preference status
        /// </summary>
        /// <param name="updatePreferenceStatusReq"> UpdatePreferenceStatusReq</param>
        /// <returns> Update Preference Status. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdatePreferenceStatus(UpdatePreferenceStatusReq updatePreferenceStatusReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            bool updStatus = await _mediator.Send(new UpdatePreferenceStatusCommand { updatePreferenceStatusReq = updatePreferenceStatusReq });

            if (updStatus)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        ///// <summary>
        ///// API to Evaluation and Execution Of Rule
        ///// </summary>
        ///// <param name="listEvaluateRulesDto"> listEvaluateRulesDto</param>
        ///// <returns> List Of Evaluated Json Result. </returns>
        ///// <exception cref="BusinessException"></exception>
        //[HttpPost]
        //[ProducesResponseType(typeof(ResponseBase<List<JsonResultData>>), StatusCodes.Status200OK)]
        //public async Task<IActionResult> EvaluateRule(List<EvaluateRulesDto> listEvaluateRulesDto)
        //{
        //    ResponseBase<List<JsonResultData>> response = new ResponseBase<List<JsonResultData>>();

        //    var JsonResultDataList = await _mediator.Send(new EvaluateRulesQuery { listEvaluateRulesDto = listEvaluateRulesDto });

        //    if (JsonResultDataList != null && JsonResultDataList.Count > 0)
        //    {
        //        response.Data = JsonResultDataList;
        //        response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
        //        return new OkObjectResult(response);
        //    }
        //    else
        //    {
        //        throw new BusinessException("PARS_RECORD_NOT_FOUND");
        //    }
        //}

        /// <summary>
        /// API to Activate or inactivate agreement
        /// </summary>
        /// <param name="updateAgreementStatusReq"> updateAgreementStatusReq</param>
        /// <returns> List Of Evaluated Json Result. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateAgreementStatus(UpdateAgreementStatusReq updateAgreementStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool isAgreementDuplicate = false;
            if (updateAgreementStatusReq != null)
            {
                if (updateAgreementStatusReq.agreement_status_id == 1)
                {
                    isAgreementDuplicate = await _mediator.Send(new CheckDuplicateAgreementQuery
                    {
                        fleet_id = updateAgreementStatusReq.fleet_id,
                        fmc_id = updateAgreementStatusReq.fmc_id,
                        start_date = updateAgreementStatusReq.start_date,
                        end_date = updateAgreementStatusReq.end_date,
                        currency_id = updateAgreementStatusReq.currency_id,
                    });
                }
            }

            if (isAgreementDuplicate)
            {
                throw new BusinessException("PARS_DUPLICATE_AGREEMENT");
            }

            var updStatus = await _mediator.Send(new UpdateAgreementStatusCommand { updateAgreementStatusReq = updateAgreementStatusReq });

            if (updStatus)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// API to get preference by id
        /// </summary>
        /// <param name="id"> Preference Id</param>
        /// <returns>Preference Data </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<PrefrenceServiceDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPrefrenceServiceList(long currencyId)
        {
            ResponseBase<List<PrefrenceServiceDto>> response = new ResponseBase<List<PrefrenceServiceDto>>();

            var preferenceDetails = await _mediator.Send(new GetPrefrenceServiceListQuery { currency_id = currencyId });
            if (preferenceDetails != null)
            {
                response.Data = preferenceDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        /// <summary>
        /// API to Delete agreements
        /// </summary>
        /// <param name="id"> Agreement Id</param>
        /// <returns>Deletion Stats(Bool) </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> DeleteAgreement(long id)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            #region Get agreement
            var agreement = await _mediator.Send(new GetAgreementByIdQuery { id = id });
            if (agreement == null)
                throw new BusinessException("PARS_AGREEMENT_NOT_FOUND");
            #endregion End

            #region Delete Agreement
            else
            {

                bool status = await _mediator.Send(new DeleteAgreementCommand
                {
                    Id = id

                });
                if (status)
                {
                    response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_DELETE_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                {
                    throw new BusinessException("PARS_DELETION_FAILURE");
                }
            }
            #endregion Delete Agreement
        }


        /// <summary>
        /// API to get agreements by Currency ID
        /// </summary>
        /// <returns> List of all agreements. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<AgreementsByCurrencyDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetActiveAgreementListByCurrencyId(long currencyId)
        {
            ResponseBase<List<AgreementsByCurrencyDto>> response = new ResponseBase<List<AgreementsByCurrencyDto>>();

            var agreementDetails = await _mediator.Send(new GetActiveAgreementListByCurrencyIdQuery
            { currencyId = currencyId });
            if (agreementDetails != null && agreementDetails.Count > 0)
            {
                response.Data = agreementDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// Method to Get applicable agreement
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<ApplicableAgreementDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetApplicableAgreement(ApplicableAgreementReq applicableAgreementReq)
        {
            ResponseBase<ApplicableAgreementDto> response = new ResponseBase<ApplicableAgreementDto>();
            #region Get related agreement and price list
            var agreementDetails = await _mediator.Send(new GetApplicableAgreementQuery
            {
                fmc_id = applicableAgreementReq.fmc_id,
                fleet_id = applicableAgreementReq.fleet_id,
                customer_account_id = applicableAgreementReq.customer_account_id
            });
            if (agreementDetails == null)
                throw new BusinessException("PARS_AGREEMENT_NOT_FOUND");

            if (agreementDetails != null)
            {

                response.Data = agreementDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_AGREEMENT_NOT_FOUND");
            }
            #endregion End Get related agreement
        }

        /// <summary>
        /// Method to Get Agreement List To Clone
        /// </summary>
        /// <returns>Agreement List</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<GetAgreementListToCloneDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAgreementListToClone(long currencyId)
        {

            ResponseBase<List<GetAgreementListToCloneDto>> response = new ResponseBase<List<GetAgreementListToCloneDto>>();
            #region Get related agreement and price list
            var agreementDetails = await _mediator.Send(new GetAgreementListToCloneQuery { currency_id = currencyId });
            if (agreementDetails == null)
                throw new BusinessException("PARS_AGREEMENT_NOT_FOUND");

            if (agreementDetails != null)
            {

                response.Data = agreementDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
            #endregion End Get related agreement
        }
        #endregion

        #region API_Clone_Agreement

        /// <summary>
        /// API to Clone agreement
        /// </summary>
        /// <param name="id"> id</param>
        /// <returns> Agreement Id </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CloneAgreement(CloneAgreementReq cloneAgreementReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            var cloneid = await _mediator.Send(new CloneAgreementCommand { cloneAgreementReq = cloneAgreementReq });

            if (cloneid > 0)
            {
                response.Data = cloneid;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CLONE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CLONE_FAILURE");
            }
        }

        /// <summary>
        /// Clone Agreement For Customer Parameter Set
        /// </summary>
        /// <param name="cloneAgreementReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CloneAgreementForCustomerParameterSet(long agreementId, string name, Guid parameter_set_id)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            var cloneid = await _mediator.Send(new CloneAgreementForCustomerParameterSetCommand { agreement_id = agreementId, name = name, parameter_set_id = parameter_set_id });
            if (cloneid > 0)
            {
                response.Data = cloneid;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CLONE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CLONE_FAILURE");
            }
        }


        /// <summary>
        /// API to get Currency using Account ID
        /// </summary>

        /// <returns>Currency </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<CurrencyByAccountIdDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCurrencyByAccountId(long fmcId, long fleetId)
        {
            ResponseBase<CurrencyByAccountIdDto> response = new ResponseBase<CurrencyByAccountIdDto>();

            var agreementDetails = await _mediator.Send(new GetCurrencyByAccountIdQuery { fmc_id = fmcId, fleet_id = fleetId });
            if (agreementDetails != null)
            {


                response.Data = agreementDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);

            }
            else
            {
                throw new BusinessException("PARS_ACCOUNT_CURRENCY_NOT_FOUND");
            }
        }

        #endregion

        #region  API_CONTROLLER_FOR_IC_PREFERENCE_RULE_METHODS

        /// <summary>
        /// 
        /// </summary>
        /// <param name="createIcInstructionsReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateICPreferenceRule(CreateIcPreferenceRuleReq createIcPreferenceRuleReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool createRecord = await _mediator.Send(new CreateIcPreferenceRulesCommand { createIcPreferenceRuleReq = createIcPreferenceRuleReq });

            if (createRecord)
            {

                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        /// <summary>
        /// This api is used to update record..
        /// </summary>
        /// <param name="updateIcPreferenceRuleReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateICPreferenceRule(UpdateIcPreferenceRuleReq updateIcPreferenceRuleReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            bool updateRecord = await _mediator.Send(new UpdateIcPreferenceRulesCommand { updateIcPreferenceRuleReq = updateIcPreferenceRuleReq });

            if (updateRecord)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        /// <summary>
        /// this api ix used to update record by id..
        /// </summary>
        /// <param name="updateIcPreferenceRuleStatusReq"></param>
        /// <returns>  </returns>
        /// <exception cref="BusinessException"></exception>      
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateICPreferenceRuleStatus(UpdateIcPreferenceRuleStatusReq updateIcPreferenceRuleStatusReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            bool updStatus = await _mediator.Send(new UpdateIcPreferenceRuleStatusCommand { id = updateIcPreferenceRuleStatusReq.id, is_active = updateIcPreferenceRuleStatusReq.is_active });

            if (updStatus)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// we get IC Preference rule based on the agreement_id and agreement_type_id, 
        /// if agreement is default agreement then we get IC Preference Rule based on the agreement_type_id, otherwise get record based on the agreement id and agreement_type_id
        /// </summary>
        /// <returns>  Return all record from ic_instruction_master table.. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<GetAllICPreferenceRuleDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetICPreferenceRuleByAgreementId(GetICPreferenceRuleListReq preferenceRuleListReq)
        {
            ResponseBase<List<GetAllICPreferenceRuleDto>> response = new ResponseBase<List<GetAllICPreferenceRuleDto>>();

            var results = await _mediator.Send(new GetAllICPreferenceRuleQuery { preferenceRuleListReq = preferenceRuleListReq });
            if (results.Count > 0)
            {

                string json = JsonConvert.SerializeObject(results);
                json = json.Replace("\\r\\n", "");
                results = JsonConvert.DeserializeObject<List<GetAllICPreferenceRuleDto>>(json);
                response.Data = results;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        /// <summary>
        /// Get a IC Preference Rule record based on the id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>  Return record by id..  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<GetICPreferenceRuleDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetICPreferenceRuleById(long id)
        {
            ResponseBase<GetICPreferenceRuleDto> response = new ResponseBase<GetICPreferenceRuleDto>();

            var result = await _mediator.Send(new GetICPreferenceRuleQuery { id = id });
            if (result != null)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        #endregion END_API_CONTROLLER_FOR_IC_PREFERENCE_RULE_METHODS

        #region API CONTRACT MODEL AND VALIDATORS
        public class CreatePreferenceReqValidator : AbstractValidator<CreatePreferenceReq>
        {
            public CreatePreferenceReqValidator()
            {
                RuleFor(p => p.agreement_id).NotNull();
                RuleFor(p => p.category_id).NotNull();
                //RuleFor(p => p.subcategory_id).NotNull();
                // RuleFor(p => p.service_id).NotNull();
                RuleFor(p => p.inclusion_type_id).NotNull();
            }
        }


        public class UpdatePreferenceReqValidator : AbstractValidator<UpdatePreferenceReq>
        {
            public UpdatePreferenceReqValidator()
            {
                RuleFor(p => p.id).NotNull();
                RuleFor(p => p.agreement_id).NotNull();
                RuleFor(p => p.category_id).NotNull();
                //RuleFor(p => p.subcategory_id).NotNull();
                //RuleFor(p => p.service_id).NotNull();
                RuleFor(p => p.inclusion_type_id).NotNull();
            }
        }

        public class UpdateAgreementStatusReqValidator : AbstractValidator<UpdateAgreementStatusReq>
        {
            public UpdateAgreementStatusReqValidator()
            {
                RuleFor(p => p.id).NotNull();
                RuleFor(p => p.start_date).NotNull();
                // RuleFor(p => p.end_date).NotNull();
                RuleFor(p => p.agreement_status_id).NotNull();
                RuleFor(p => p.currency_id).NotNull();
            }
        }


        public class CreateAgreementReqValidator : AbstractValidator<CreateAgreementReq>
        {
            public CreateAgreementReqValidator()
            {
                RuleFor(p => p.start_date).NotNull();
                //RuleFor(p => p.end_date).NotNull();
                RuleFor(p => p.currency_id).NotNull();
            }
        }

        public class GetICPreferenceRuleListReqValidator : AbstractValidator<GetICPreferenceRuleListReq>
        {
            public GetICPreferenceRuleListReqValidator()
            {
                RuleFor(p => p.agreement_type_id).NotNull();
                RuleFor(p => p.currency_id).NotNull();
            }
        }



        #endregion

        #region API_CONTROLLER_FOR_IC_PREFERENCE_RULE_METHODS_VALIDATORS

        public class CreateIcPreferenceRuleReqValidator : AbstractValidator<CreateIcPreferenceRuleReq>
        {
            public CreateIcPreferenceRuleReqValidator()
            {
                RuleFor(p => p.agreement_type_id).NotNull();
            }
        }

        public class UpdateIcPreferenceRuleReqValidator : AbstractValidator<UpdateIcPreferenceRuleReq>
        {
            public UpdateIcPreferenceRuleReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }

        public class UpdateIcPreferenceRuleStatusReqValidator : AbstractValidator<UpdateIcPreferenceRuleStatusReq>
        {
            public UpdateIcPreferenceRuleStatusReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }

        #endregion END_API_CONTROLLER_FOR_IC_PREFERENCE_RULE_METHODS_VALIDATORS

        #region Execute Queue Related Rule Prefrence 'Json Based Rule Engine'
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> QueueRuleEngine(QueuePreferenceRuleReq queuePreferenceRuleReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            // var rootPath = _hostingEnvironment.ContentRootPath; //get the root path

            var fullPath = Path.Combine("rootPath", "queuerules.json"); //combine the root path with that of our json file inside mydata directory

            var queueRule = System.IO.File.ReadAllText(fullPath); //read all the content inside the file

            var result = await _mediator.Send(new ExecuteQueuePreferenceRule { queuePreferenceRuleReq = queuePreferenceRuleReq, queueRule = queueRule });

            return new OkObjectResult(result);

        }
        #endregion

        #region State Inspection Rules
        /// <summary>
        /// API to create Preference
        /// </summary>
        /// <param name="createAgreementReq"> CreatePreferenceReq</param>
        /// <returns> Create Preference. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateStateInspectionPreference(CreateStateInspectionPreferenceReq createPreferenceReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            Tuple<bool, bool> result = await _mediator.Send(new CreateStateInspectionPreferenceCommand { createPreferenceReq = createPreferenceReq });

            if (result.Item2)
            {
                response.IsSuccessful = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_DUPLICATE_ENTRY");
                return new OkObjectResult(response);
            }
            if (result.Item1)
            {
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");

        }

        /// <summary>
        /// Update State Inspection Preference
        /// </summary>
        /// <param name="updatePreferenceReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateStateInspectionPreference(UpdateStateInspectionPreferenceReq updatePreferenceReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            bool Is_updated = await _mediator.Send(new UpdateStateInspectionPreferenceCommand { updatePreferenceReq = updatePreferenceReq });
            if (Is_updated)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        /// <summary>
        /// API to update preference status
        /// </summary>
        /// <param name="updatePreferenceStatusReq"> UpdatePreferenceStatusReq</param>
        /// <returns> Update Preference Status. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateStateInspectionStatus(UpdateStateInspectionStatusReq updatePreferenceStatusReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            bool updStatus = await _mediator.Send(new UpdateStateInspectionStatusCommand { updatePreferenceStatusReq = updatePreferenceStatusReq });

            if (updStatus)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        /// <summary>
        /// Get State Inspection List
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<StateInspectionListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetStateInspectionList()
        {
            ResponseBase<List<StateInspectionListDto>> response = new ResponseBase<List<StateInspectionListDto>>();
            List<StateInspectionListDto> preferencesList = await _mediator.Send(new GetStateInspectionPreferencesQuery { });
            if (preferencesList != null && preferencesList.Count > 0)
            {
                response.Data = preferencesList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            }
            else
            {
                response.Data = preferencesList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
            }
            return new OkObjectResult(response);
        }

        /// <summary>
        /// API to get State Inspection preference by id
        /// </summary>
        /// <param name="id"> Preference Id</param>
        /// <returns>Preference Data </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<StateInspectionDetailDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetStateInspectionPreferenceById(long id, long? inspection_type_id)
        {
            ResponseBase<StateInspectionDetailDto> response = new ResponseBase<StateInspectionDetailDto>();

            var preferenceDetails = await _mediator.Send(new GetStateInspectionPreferenceByIdQuery { preferenceId = id, inspectionTypeId = inspection_type_id });
            if (preferenceDetails != null)
            {
                response.Data = preferenceDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }
        #endregion END


        #region Set agreement to account
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SetAgreementToAccount(SetAgreementReq setAgreementReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            bool result = await _mediator.Send(new SetAgreementToAccountCommand { req = setAgreementReq });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        #endregion

    }
}
