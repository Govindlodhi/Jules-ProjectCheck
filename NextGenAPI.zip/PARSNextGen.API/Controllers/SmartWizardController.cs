﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PARSNextGen.Application.Service;
using System.Threading.Tasks;
using PARSNextGen.API.DataModel;
using PARSNextGen.Application.SmartWizard.MasterData.Query;
using PARSNextGen.API.Extensions.Exceptions;
using System.Collections.Generic;
using PARSNextGen.Application.SmartWizard.MasterData.Command;
using System.Linq;
using PARSNextGen.Application.SmartWizard.QuestionSetup.Command;
using PARSNextGen.Application.SmartWizard.QuestionSetup.Query;
using System;
using System.Diagnostics;
using Newtonsoft.Json;
using System.Net.Http;
using Microsoft.Extensions.Configuration;
using static PARSNextGen.Domain.Common.EnumTypes;
using Scriban;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class SmartWizardController : ControllerBase
    {
        private readonly ILogger<SmartWizardController> _logger;
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClient;
        public SmartWizardController(ILogger<SmartWizardController> logger, IMediator mediator, ICustomMessageService customMsgSvc, IConfiguration configuration, IHttpClientFactory httpClient)
        {
            _logger = logger;
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
            _configuration = configuration;
            _httpClient = httpClient;
        }

        #region API METHODS


        #region Smart Wizard Master Data
        /// <summary>
        /// This method used for get smart wizard master data.
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(GetSmartWizardMasterDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSmartWizardMasterData()
        {
            ResponseBase<GetSmartWizardMasterDto> response = new ResponseBase<GetSmartWizardMasterDto>();
            var result = await _mediator.Send(new GetSmartWizardMasterDataQuery { });
            if (result != null)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }

        }
        #endregion

        #region Get Questions List 
        /// <summary>
        /// This method used for get smart wizard question list
        /// </summary>
        /// <param name="event_type"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(List<GetQuestionListDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetQuestionList()
        {
            ResponseBase<List<GetQuestionListDto>> response = new ResponseBase<List<GetQuestionListDto>>();
            var result = await _mediator.Send(new GetQuestionListQuery { });
            if (result.Count() > 0)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }

        }

        #endregion

        #region Insert Question And Options
        /// <summary>
        /// This method used for insert questions and options
        /// </summary>
        /// <param name="que"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(long), StatusCodes.Status201Created)]
        public async Task<IActionResult> InsertQuestionAndOption(InsertQuestionDto questions)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            var result = await _mediator.Send(new InsertQuestionAndOptionCommand { questions = questions });
            if (result > 0)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        #endregion

        #region Update Question And Options
        /// <summary>
        /// This method used for update questions and options
        /// </summary>
        /// <param name="que"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(long), StatusCodes.Status201Created)]
        public async Task<IActionResult> UpdateQuestionAndOption(UpdateQuestionDto questions)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            var result = await _mediator.Send(new UpdateQuestionAndOptionCommand { questions = questions });
            if (result > 0)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }

        }

        #endregion

        #region Get Question By Id
        /// <summary> 
        /// This method used for get smart wizard question details by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(GetQuestionDetailsDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetQuestionDetailsById(long id)
        {
            ResponseBase<GetQuestionDetailsDto> response = new ResponseBase<GetQuestionDetailsDto>();
            var result = await _mediator.Send(new GetQuestionDetailsByIdQuery { id = id });
            if (result != null)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }
        #endregion

        #region Update Active/Inactive Status
        /// <summary> 
        /// This method used for update active or Inactive status
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(GetQuestionDetailsDto), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> ChangeQuestionStatus(ChangeQuestionStatusCommand request)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            var result = await _mediator.Send(request);
            if (result > 0)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }
        #endregion

        #region Question Setup

        /// <summary>
        /// This method used for question setup
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status201Created)]
        public async Task<IActionResult> QuestionSetup(List<QuestionSetupDto> question_setup)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new QuestionSetupCommand { question_setup = question_setup });
            if (result)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        /// <summary>
        /// This method used for get smart wizard questions by event type inbound or outbound
        /// </summary>
        /// <param name="event_type_id"></param>
        /// <param name="pickup_id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(EventQuestionList), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetQuestionListByEvent(long event_type_id, Guid pickup_id, long? address_type, string? user_type)
        {
            EventQuestionList result = new EventQuestionList();
            result.pickup_information = new PickupInformation();
            result.delivery_information = new DeliveryInformation();
            result.question_list = new List<QuestionList>();
            result.wizard_response = new GetSmartWizardResponseDto();

            ResponseBase<EventQuestionList> response = new ResponseBase<EventQuestionList>();

            GetOrderInfomation getOrderInfoObj = new GetOrderInfomation();

            //Getting the pickup and delivery information by using parallel api/method calling.
            var pickupTask = address_type == (long?)address_point.pickup || address_type == (long?)address_point.dealership ? getOrderInfoObj.GetInformationAsync<PickupAddress>(pickup_id, "/api/GetPickupConfirmInformation?id=", _configuration, _httpClient) : Task.FromResult<PickupAddress>(null);
            var deliveryTask = address_type == (long?)address_point.delivery ? getOrderInfoObj.GetInformationAsync<DeliveryAddress>(pickup_id, "/api/GetDeliveryConfirmInformation?id=", _configuration, _httpClient) : Task.FromResult<DeliveryAddress>(null);

            // For _mediator.Send, if asynchronous
            var questionListTask = Task.Run(() => _mediator.Send(new GetQuestionListByEventQuery { event_type_id = event_type_id, pickup_id = pickup_id, address_type = address_type }));

            await Task.WhenAll(questionListTask, pickupTask, deliveryTask);

            // Here assigned return data from api in pickup and delivery information.
            result.pickup_information = address_type == (long?)address_point.pickup || address_type == (long?)address_point.dealership ? pickupTask.Result.data : null;
            result.delivery_information = address_type == (long?)address_point.delivery ? deliveryTask.Result.data : null;
            result.question_list = questionListTask.Result.question_list;
            result.event_message = questionListTask.Result.event_message;
            result.wizard_response = questionListTask.Result.wizard_response;

            //wizard only open in ASSIGNED Stage, and (HOLD stage does not contain linkExpired flag true)
            if (result.pickup_information != null)
            {
                if (result.pickup_information.stageName.Contains("ASSIGNED"))
                {
                    if (user_type == "PARS")
                        result.pickup_information.linkExpired = false;
                    else
                    {
                        if (user_type == "CUSTOMER" && !result.pickup_information.linkExpired)
                            result.pickup_information.linkExpired = false;
                        else
                            result.pickup_information.linkExpired = true;
                    }
                }
                else if (result.pickup_information.stageName.Contains("HOLD"))
                {
                    if (!result.pickup_information.linkExpired && user_type == "PARS")
                        result.pickup_information.linkExpired = false;
                    else
                        result.pickup_information.linkExpired = true;
                }
                else
                    result.pickup_information.linkExpired = true;
            }

            if (result.delivery_information != null)
            {
                if (result.delivery_information.stageName.Contains("ASSIGNED"))
                {
                    if (user_type == "PARS")
                        result.delivery_information.linkExpired = false;
                    else
                    {
                        if (user_type == "CUSTOMER" && !result.delivery_information.linkExpired)
                            result.delivery_information.linkExpired = false;
                        else
                            result.delivery_information.linkExpired = true;
                    }
                }
                else if (result.delivery_information.stageName.Contains("HOLD"))
                {
                    if (!result.delivery_information.linkExpired && user_type == "PARS")
                        result.delivery_information.linkExpired = false;
                    else
                        result.delivery_information.linkExpired = true;
                }
                else
                    result.delivery_information.linkExpired = true;
            }

            switch (address_type)
            {
                case (long?)address_point.pickup:

                    //Check that the pickup information is not null and the link has not expired.
                    if (result.pickup_information != null && result.pickup_information.linkExpired == false)
                    {
                        var data = new MergeDataCollection
                        {
                            customer_account_name = result.pickup_information?.customerAccountName ?? string.Empty,
                            addressed = "pickup",
                            model = result.pickup_information?.model ?? string.Empty,
                            make = result.pickup_information?.make ?? string.Empty,
                            year = result.pickup_information?.year ?? string.Empty,
                            vin = result.pickup_information?.vin ?? string.Empty,
                        };

                        //Here Merge the event message with the order information.
                        result.event_message = getOrderInfoObj.MergeMessage(result.event_message, data);

                        //Check if the parent question, 'Will there be any work-related items left in the vehicle?' includes the sub-question, 'I understand this is an electric vehicle.
                        var electricParentQuestion = result.question_list.Where(p => p.id == 282).FirstOrDefault();
                        if (electricParentQuestion != null)
                        {
                            //Check if the vehicle is electric based on its primary fuel type.
                            if (result.pickup_information.primaryFuelType == "Electric")
                            {
                                //Remove the question, 'I understand this is an electric vehicle,' and display the next question, 'Will the charging cord and any adapters be in the vehicle at pickup?
                                var dependentElectricQuestion = electricParentQuestion.dependent_question.FirstOrDefault(p => p.dependent_question_id == 230 && p.parent_question_answer == "Yes");
                                var index1 = electricParentQuestion.dependent_question.IndexOf(dependentElectricQuestion);
                                if (index1 != -1)
                                    dependentElectricQuestion.dependent_question_id = 231;

                                var dependentElectricQuestion1 = electricParentQuestion.dependent_question.FirstOrDefault(p => p.dependent_question_id == 230 && p.parent_question_answer == "No");
                                var index = electricParentQuestion.dependent_question.IndexOf(dependentElectricQuestion1);
                                if (index != -1)
                                    dependentElectricQuestion1.dependent_question_id = 231;
                            }
                            else
                            {
                                // When the vehicle is not electric, hide the electric question and display the last question from the 'Other Information' wizard tab.
                                var dependentElectricQuestion = electricParentQuestion.dependent_question.FirstOrDefault(p => p.dependent_question_id == 230 && p.parent_question_answer == "Yes");
                                var index1 = electricParentQuestion.dependent_question.IndexOf(dependentElectricQuestion);
                                if (index1 != -1)
                                {
                                    dependentElectricQuestion.dependent_question_id = 237;
                                    dependentElectricQuestion.next_response_type = "Other Information";
                                }

                                var dependentElectricQuestion1 = electricParentQuestion.dependent_question.FirstOrDefault(p => p.dependent_question_id == 230 && p.parent_question_answer == "No");
                                var index = electricParentQuestion.dependent_question.IndexOf(dependentElectricQuestion1);
                                if (index != -1)
                                {
                                    dependentElectricQuestion1.dependent_question_id = 237;
                                    dependentElectricQuestion1.next_response_type = "Other Information";
                                }
                            }
                        }
                    }

                    break;

                case (long)address_point.delivery:

                    //Check that the delivery information is not null and the link has not expired.
                    if (result.delivery_information != null && result.delivery_information.linkExpired == false)
                    {
                        var data = new MergeDataCollection
                        {
                            customer_account_name = result.delivery_information?.customerAccountName ?? string.Empty,
                            addressed = "deliver",
                            model = result.delivery_information?.model ?? string.Empty,
                            make = result.delivery_information?.make ?? string.Empty,
                            year = result.delivery_information?.year ?? string.Empty,
                            vin = result.delivery_information?.vin ?? string.Empty,
                        };

                        //Here Merge the event message with the order information.
                        result.event_message = getOrderInfoObj.MergeMessage(result.event_message, data);
                    }
                    break;

                case (long)address_point.dealership:
                    result.event_message = null;

                    //Check that the pickup information is not null and the link has not expired.
                    if (result.pickup_information != null && result.pickup_information.linkExpired == false)
                    {
                        //Retrieve specific questions based on their unique question codes to hide or show them dynamically, depending on the inbound or outbound event type.
                        var imbound_question = result.question_list.FirstOrDefault(p => p.question_code == "q0");
                        var imbound_question1 = result.question_list.FirstOrDefault(p => p.question_code == "q3");
                        int imbound_index1 = imbound_question1 != null ? result.question_list.IndexOf(imbound_question1) : -1;
                        var outbound_question = result.question_list.FirstOrDefault(p => p.question_code == "q1");
                        var outbound_question1 = result.question_list.FirstOrDefault(p => p.question_code == "q4");
                        var outbound_question2 = result.question_list.FirstOrDefault(p => p.question_code == "q2");
                        int outbound_index = outbound_question != null ? result.question_list.IndexOf(outbound_question) : -1;
                        int outbound_index1 = outbound_question1 != null ? result.question_list.IndexOf(outbound_question1) : -1;
                        int outbound_index2 = outbound_question2 != null ? result.question_list.IndexOf(outbound_question2) : -1;

                        var fmc_question = result.question_list.FirstOrDefault(p => p.question_code == "q5");
                        int fmc_question_index = fmc_question != null ? result.question_list.IndexOf(fmc_question) : -1;

                        if (imbound_index1 != -1 && outbound_index != -1 && result.pickup_information != null)
                        {
                            var data = new MergeDataCollection
                            {
                                fmc_name = result.pickup_information.fmcName,
                                fleet_name = result.pickup_information.customerAccountName, //result.pickup_information.transportationModeType == "Driveaway" ? result.pickup_information.fleetName : result.pickup_information.customerAccountName,
                                vin = result.pickup_information.vin.Substring(result.pickup_information.vin.Length - 6),
                                year = result.pickup_information.year,
                                make = result.pickup_information.make,
                                model = result.pickup_information.model,
                                caller_name = result.pickup_information.customerName
                            };

                            switch (event_type_id)
                            {
                                case (long)confirmation_call_type.imbound:

                                    //Merge the specific questions with the order details based on the inbound event type.
                                    imbound_question1.question = getOrderInfoObj.MergeMessage(imbound_question1.question, data);
                                    imbound_question1.label = getOrderInfoObj.MergeMessage(imbound_question1.label, data);

                                    fmc_question.question = getOrderInfoObj.MergeMessage(fmc_question.question, data);
                                    fmc_question.label = getOrderInfoObj.MergeMessage(fmc_question.label, data);
                                    result.question_list[fmc_question_index] = fmc_question;
                                    result.question_list[imbound_index1] = imbound_question1;

                                    // Check order line details for 
                                    if (result.pickup_information.orderLines == null)
                                    {
                                        //Check state infection parent question from question list.
                                        var stateInpection = result.question_list.Where(p => p.id == 271).FirstOrDefault();
                                        if (stateInpection != null)
                                        {
                                            //Check the state infection question in the dependent question list when the answer is 'No,' and display the question 'Is there a bracket to mount a front plate?'.
                                            var dependentInsp = stateInpection.dependent_question.FirstOrDefault(p => p.dependent_question_id == 272 && p.parent_question_answer == "No");
                                            var ind = stateInpection.dependent_question.IndexOf(dependentInsp);
                                            if (ind != -1)
                                                dependentInsp.dependent_question_id = 284;
                                        }
                                    }

                                    //Remove the outbound question from the question list and insert the inbound question at the first index.
                                    result.question_list.Remove(imbound_question);
                                    result.question_list.Insert(0, imbound_question);
                                    result.question_list.Remove(outbound_question);
                                    result.question_list.Remove(outbound_question1);
                                    result.question_list.Remove(outbound_question2);

                                    break;

                                case (long)confirmation_call_type.outbound:

                                    //Merge the specific questions with the order details based on the outbound event type.
                                    outbound_question1.question = getOrderInfoObj.MergeMessage(outbound_question1.question, data);
                                    outbound_question1.label = getOrderInfoObj.MergeMessage(outbound_question1.label, data);
                                    outbound_question2.question = getOrderInfoObj.MergeMessage(outbound_question2.question, data);
                                    outbound_question2.label = getOrderInfoObj.MergeMessage(outbound_question2.label, data);
                                    fmc_question.question = getOrderInfoObj.MergeMessage(fmc_question.question, data);
                                    fmc_question.label = getOrderInfoObj.MergeMessage(fmc_question.label, data);
                                    result.question_list[fmc_question_index] = fmc_question;
                                    result.question_list[outbound_index1] = outbound_question1;
                                    result.question_list[outbound_index2] = outbound_question2;
                                    if (result.pickup_information.orderLines == null)
                                    {
                                        // Check state infection parent question from question list.
                                        var stateInpection = result.question_list.Where(p => p.id == 271).FirstOrDefault();
                                        if (stateInpection != null)
                                        {
                                            // Check the state infection question in the dependent question list when the answer is 'No,' and display the question 'Is there a bracket to mount a front plate?'.
                                            var dependentInsp = stateInpection.dependent_question.FirstOrDefault(p => p.dependent_question_id == 272 && p.parent_question_answer == "No");
                                            var ind = stateInpection.dependent_question.IndexOf(dependentInsp);
                                            if (ind != -1)
                                                dependentInsp.dependent_question_id = 284;
                                        }
                                    }

                                    // Remove the inbound question from the question list and insert the outbound question at the first index.
                                    result.question_list.Remove(outbound_question);
                                    result.question_list.Insert(0, outbound_question);
                                    result.question_list.Remove(imbound_question);
                                    result.question_list.Remove(imbound_question1);

                                    break;

                                default:
                                    result.pickup_information = null;
                                    break;
                            }
                        }
                        else
                            result.pickup_information = null;
                    }
                    break;
            }

            if (result != null)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }



        /// <summary>
        /// This method used for submit all questions
        /// </summary>
        /// <param name="submit_question"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(long), StatusCodes.Status201Created)]
        public async Task<IActionResult> SubmitQuestion(SubmitQuestionDto submit_question)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            var result = await _mediator.Send(new SubmitQuestionCommand { submitQuestion = submit_question });
            if (result > 0)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_SMART_WIZARD_SUBMITTED");
                return new OkObjectResult(response);
            }
            else
            {
                if (result == -1)
                    throw new BusinessException("PARS_DUPLICATE_ENTRY");
                if (result == -2)
                    throw new BusinessException("PARS_UPDATION_FAILURE");
                else
                    throw new BusinessException("PARS_SMART_WIZARD_SUBMITTED_FAILURE");
            }
        }

        /// <summary>
        /// This method used for get smart wizard response by event type id.
        /// </summary>
        /// <param name="event_type_id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(GetSmartWizardResponseDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSmartWizardResponseByEventId(Guid order_id, long address_type)
        {
            ResponseBase<GetSmartWizardResponseDto> response = new ResponseBase<GetSmartWizardResponseDto>();
            var result = await _mediator.Send(new GetSmartWizardResponseQuery { address_type = address_type, order_id = order_id });
            if (result != null)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            }
            else
            {
                response.Data = result;
                response.IsSuccessful = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
            }
            return new OkObjectResult(response);

        }
        #endregion

        #endregion
    }
    public class MergeDataCollection
    {
        public string customer_account_name { get; set; }
        public string caller_name { get; set; }
        public string year { get; set; }
        public string make { get; set; }
        public string model { get; set; }
        public string addressed { get; set; }
        public string vin { get; set; }
        public string fmc_name { get; set; }
        public string fleet_name { get; set; }
    }
    public class PickupAddress
    {
        public PickupInformation data { get; set; }
        public bool isSuccessful { get; set; }
    }
    public class DeliveryAddress
    {
        public DeliveryInformation data { get; set; }
        public bool isSuccessful { get; set; }
    }
    public class GetOrderInfomation
    {
        /// <summary>
        /// This method used for get pickup and delivery information.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="pickup_id"></param>
        /// <param name="api_method"></param>
        /// <returns></returns>
        public async Task<T> GetInformationAsync<T>(Guid pickup_id, string api_method, IConfiguration _configuration, IHttpClientFactory _httpClient)
        {
            string api_url = _configuration["appSettings:DmGatewayUrl"];

            //PickupAddress pickupAddress = new PickupAddress();
            using (var client = _httpClient.CreateClient())
            {
                string strUrl = api_url + api_method + pickup_id.ToString();
                try
                {
                    HttpResponseMessage response = await client.GetAsync(strUrl);
                    if (response.IsSuccessStatusCode)
                    {
                        var responseData = await response.Content.ReadAsStringAsync();
                        return string.IsNullOrEmpty(responseData) ? default : JsonConvert.DeserializeObject<T>(responseData);
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
            return default;
        }

        /// <summary>
        /// This method used for merge specific questions/message with order details.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public string MergeMessage(string message, MergeDataCollection data)
        {
            string mergeData = string.Empty;
            var newMessage = Template.Parse(message);

            mergeData = newMessage.Render(data);

            return mergeData;
        }

    }

}
