﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Document.AttachmentList.Command;
using PARSNextGen.Application.Document.AttachmentList.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.Vehicle.AttachmentList.Queries;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class DocumentController : Controller
    {
        private readonly ILogger<DocumentController> _logger;
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMessageService;
        private readonly IAzureDocumentService _azureService;
        public DocumentController(IMediator mediator, ILogger<DocumentController> logger, ICustomMessageService customMessageService, IAzureDocumentService azureService)
        {
            _logger = logger;
            _mediator = mediator;
            _customMessageService = customMessageService;
            _azureService = azureService;
        }

        #region API CONTROLLER METHODS

        /// <summary>
        /// API to get vehicle attachment list
        /// </summary>
        /// <returns> VehicleAttachmentListDto</returns>
        /// <exception cref="Exception"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<VehicleDocumentDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehicleDocuments(long vehicleId)
        {
            ResponseBase<List<VehicleDocumentDto>> response = new ResponseBase<List<VehicleDocumentDto>>();
            var docAttachment = await _mediator.Send(new GetVehicleDocumentQuery { vehicle_id = vehicleId });
            if (docAttachment != null)
            {
                response.Data = docAttachment;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }



        /// <summary>
        /// API to Get Document Master Data
        /// </summary>
        /// <returns> List of Document Master Data   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<DocumentMasterDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetDocumentMasterData()
        {
            ResponseBase<List<DocumentMasterDto>> response = new ResponseBase<List<DocumentMasterDto>>();
            var documentDetails = await _mediator.Send(new GetDocumentMasterQuery { });
            if (documentDetails != null)
            {
                List<DocumentMasterDto> resp = new List<DocumentMasterDto>();
                resp.Add(documentDetails);
                response.Data = resp;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }



        /// <summary>
        /// API to create document 
        /// </summary>
        /// <returns> AttachmentListDto</returns>
        /// <exception cref="Exception"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UploadDocument(UploadDocumentReq uploadDocumentReq)
        {
            var response = new ResponseBase<long>();

            var docAttachment = await _mediator.Send(new InsertDocumentCommand
            {
                vehicle_id = uploadDocumentReq.vehicle_id,
                vehicle_condition_id = uploadDocumentReq.vehicle_condition_id,
                contact_id = uploadDocumentReq.contact_id,
                account_id = uploadDocumentReq.account_id,
                client_id = uploadDocumentReq.client_id,
                document_name = uploadDocumentReq.document_name,
                document_type_id = uploadDocumentReq.document_type_id,
                base64String = uploadDocumentReq.base64String,
            });

            if (docAttachment > 0)
            {
                response.Data = docAttachment;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                var fileurl = _azureService.UploadDocuments(uploadDocumentReq.base64String);
                if (fileurl.Result != null)
                {
                    bool updateUrl = await _mediator.Send(new UpdateDocumentURL
                    {
                        id = docAttachment,
                        base64String = null,
                        document_uri = fileurl.Result,
                    });
                    if (updateUrl)
                    {
                        response.Data = docAttachment;
                        response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_DOCUMENT_UPLOAD_SUCCESS");
                    }
                    else
                    {
                        throw new BusinessException("PARS_UPLOAD_FAILURE");
                    }
                }
                else
                {
                    throw new BusinessException("PARS_URL_NULL");
                }

                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }





        /// <summary>
        /// API to update document 
        /// </summary>
        /// <returns> UpdateDocumentReq</returns>
        /// <exception cref="Exception"></exception>

        //[HttpPost]
        //[ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        //public async Task<IActionResult> UpdateDocument(UpdateDocumentReq updateDocumentReq)
        //{
        //    ResponseBase<bool> response = new ResponseBase<bool>();
        //    bool docAttachment = await _mediator.Send(new UpdateDocumentCommand
        //    {
        //        id = updateDocumentReq.id,
        //        vehicle_id = updateDocumentReq.vehicle_id,
        //        vehicle_condition_id = updateDocumentReq.vehicle_condition_id,
        //        contact_id = updateDocumentReq.contact_id,
        //        account_id = updateDocumentReq.account_id,
        //        client_id = updateDocumentReq.client_id,
        //        document_id = updateDocumentReq.document_id,
        //        base64String = updateDocumentReq.base64String,
        //        document_uri = updateDocumentReq.document_uri,
        //        is_active = updateDocumentReq.is_active,
        //        is_deleted = updateDocumentReq.is_deleted,
        //        created_on = updateDocumentReq.created_on,
        //        created_by = updateDocumentReq.created_by,
        //        updated_on = updateDocumentReq.updated_on,
        //        updated_by = updateDocumentReq.updated_by

        //    });
        //    if (docAttachment)
        //    {
        //        response.Data = docAttachment;
        //        response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
        //        return new OkObjectResult(response);
        //    }
        //    else
        //    {
        //        throw new BusinessException("PARS_UPDATION_FAILURE");
        //    }
        //}




        /// <summary>
        /// API to delete document at azure.
        /// </summary>
        /// <param name="id"> id </param>
        /// <exception cref="Exception"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> DeleteDocument(DeleteDocumentReq deleteDocumentReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var docAttachment = await _mediator.Send(new GetDocumentUrlQuery { id = deleteDocumentReq.id });

            // Check If document_uri field doesn't contains data it means that the document has been deleted to the cloud 
            if (docAttachment.document_uri != null)
            {
                var deleteUri = await _azureService.DeleteDocuments(docAttachment.document_uri);
                if (deleteUri)
                {
                    response.Data = deleteUri;

                    bool deleteUrl = await _mediator.Send(new DeleteDocumentCommand { id = deleteDocumentReq.id });
                    if (deleteUrl)
                    {
                        response.Data = deleteUrl;
                        response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_DOCUMENT_DELETE_SUCCESS");
                        return new OkObjectResult(response);
                    }
                    else
                    {
                        throw new BusinessException("PARS_DOCUMENT_DELETE_FAILURE");
                    }
                }
                else
                {
                    throw new BusinessException("PARS_DOCUMENT_DELETE_FAILURE");
                }
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }



        /// <summary>
        /// API to download document.
        /// </summary>
        /// <param name="id"> id </param>
        /// <exception cref="Exception"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<DownloadDocumentDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> DownloadDocument(DownloadDocumentReq downloadDocumentReq)
        {
            ResponseBase<DownloadDocumentDto> response = new ResponseBase<DownloadDocumentDto>();
            var doc = await _mediator.Send(new DownloadDocumentByIdQuery { id = downloadDocumentReq.id });
            if (!string.IsNullOrEmpty(doc.base64string))
            {
                response.Data = doc;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                var downloadDoc = await _azureService.DownloadDocuments(doc.document_uri, doc.document_name);
                if (downloadDoc != null)
                {
                    response.Data = downloadDoc;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_DOCUMENT_DOWNLOAD_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                {
                    throw new BusinessException("PARS_DOCUMENT_DOWNLOAD_FAILURE");
                }

                throw new BusinessException("PARS_DOCUMENT_DOWNLOAD_FAILURE");
            }

        }

        #region Batch Template API

        /// <summary>
        /// API to Create Batch Template
        /// </summary>
        /// <param name="CreateBatchTemplateReq"> CreateBatchTemplateReq </param>
        /// <exception cref="Exception"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<DownloadDocumentDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateBatchTemplate(CreateBatchTemplateReq req)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            Tuple<bool, bool> doc = await _mediator.Send(new CreateBatchemplateCommand {TemplateReq = req  });
            if (doc.Item1)
            {
                response.Data = doc.Item1;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_CSV_TEMPLATE_ALREADY_EXIST");
                return new OkObjectResult(response);
            }
            if (doc.Item2)
            {
                response.Data = doc.Item2;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }

        }

        /// <summary>
        /// API to get Batch Template list
        /// </summary>
        /// <returns> BatchTemplateListDto</returns>
        /// <exception cref="Exception"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<BatchTemplateListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetBatchTemplateList()
        {
            ResponseBase<List<BatchTemplateListDto>> response = new ResponseBase<List<BatchTemplateListDto>>();
            var docAttachment = await _mediator.Send(new GetBatchTemplateListQuery { });
            if (docAttachment != null)
            {
                response.Data = docAttachment;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to get Batch Template list
        /// </summary>
        /// <returns> BatchTemplateListDto</returns>
        /// <exception cref="Exception"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<BatchTemplateDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetBatchTemplateDetailsById(long id)
        {
            ResponseBase<BatchTemplateDetailsDto> response = new ResponseBase<BatchTemplateDetailsDto>();
            var docAttachment = await _mediator.Send(new GetBatchTemplateByIdQuery {id = id });
            if (docAttachment != null)
            {
                response.Data = docAttachment;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to Download Batch Template
        /// </summary>
        /// <param name="CreateBatchTemplateReq"> CreateBatchTemplateReq </param>
        /// <exception cref="Exception"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<DownloadBatchTemplateDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> DownloadBatchTemplate(DownloadDocumentReq downloadDocumentReq)
        {
            ResponseBase<DownloadBatchTemplateDto> response = new ResponseBase<DownloadBatchTemplateDto>();
            var doc = await _mediator.Send(new DownloadBatchTemplateQuery { id = downloadDocumentReq.id });
            if (!string.IsNullOrEmpty(doc.base64string))
            {
                response.Data = doc;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                var downloadDoc = await _azureService.DownloadBatchTemplate(doc.document_uri, doc.document_name);
                if (downloadDoc != null)
                {
                    response.Data = downloadDoc;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_DOCUMENT_DOWNLOAD_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                {
                    throw new BusinessException("PARS_DOCUMENT_DOWNLOAD_FAILURE");
                }

                throw new BusinessException("PARS_DOCUMENT_DOWNLOAD_FAILURE");
            }

        }

        /// <summary>
        /// API to Create Batch Template
        /// </summary>
        /// <param name="CreateBatchTemplateReq"> CreateBatchTemplateReq </param>
        /// <exception cref="Exception"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateBatchTemplateStatus(UpdateBatchTemplateStatusReq req)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool doc = await _mediator.Send(new UpdateBatchTemplateStatusCommand { id = req.id, status = req.is_active });
            if (doc)
            {
                response.Data = doc;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }

        }

        /// <summary>
        /// API to delete document at azure and DB.
        /// </summary>
        /// <param name="id"> id </param>
        /// <exception cref="Exception"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> DeleteBatchTemplate(DeleteDocumentReq deleteDocumentReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var docAttachment = await _mediator.Send(new DeleteBatchTemplateCommand { id = deleteDocumentReq.id });

            if (docAttachment)
            {
                response.Data = docAttachment;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_DOCUMENT_DELETE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_DOCUMENT_DELETE_FAILURE");
            }
        }
        
        /// <summary>
        /// API to Update document.
        /// </summary>
        /// <param name="id"> id </param>
        /// <exception cref="Exception"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateBatchTemplate(UpdateBatchTemplateReq updateCSVTemplate)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var docAttachment = await _mediator.Send(new UpdateBatchTemplateCommand { TemplateReq = updateCSVTemplate });

            if (docAttachment)
            {
                response.Data = docAttachment;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        #endregion


        #endregion


        #region API CONTRACT MODELS AND VALIDATORS
        public class UploadDocumentReq
        {
            public long? vehicle_id { get; set; }
            public long? vehicle_condition_id { get; set; }
            public long? contact_id { get; set; }
            public long? account_id { get; set; }
            public long? client_id { get; set; }
            public string? document_name { get; set; }
            public long document_type_id { get; set; }
            public string base64String { get; set; }
        }



        public class UpdateDocumentReq
        {
            public long id { get; set; }
            public long? vehicle_id { get; set; }
            public long? vehicle_condition_id { get; set; }
            public long? contact_id { get; set; }
            public long? account_id { get; set; }
            public long? client_id { get; set; }
            public long document_id { get; set; }
            public string base64String { get; set; }
            public string document_uri { get; set; }
            public bool is_active { get; set; }
            public bool is_deleted { get; set; }
            public DateTime created_on { get; set; }
            public long created_by { get; set; }
            public DateTime? updated_on { get; set; }
            public long? updated_by { get; set; }
        }

        public class UpdateDocumentReqValidator : AbstractValidator<UpdateDocumentReq>
        {
            public UpdateDocumentReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
            }
        }

        public class DeleteDocumentReq
        {
            public long id { get; set; }
        }

        public class DownloadDocumentReq
        {
            public long id { get; set; }
        }


        #endregion

    }
}
