﻿using FluentValidation;
using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Nancy.Json;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Master.Roles.Command.UpdateUserPhoto;
using PARSNextGen.Application.Preference.Agreement.Command.UpdateAGServicesAndICFromCRM;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.User.UserProfile.Queries;
using PARSNextGen.Application.User.UserQueue.Command.cs;
using PARSNextGen.Application.User.UserQueue.Queries;
using PARSNextGen.Application.User.UserRole.Command;
using PARSNextGen.Application.User.Users.Command;
using PARSNextGen.Application.User.Users.Queries.AllUsers;
using PARSNextGen.Application.User.Users.Queries.GetUsersDetails;
using PARSNextGen.Application.User.Users.Queries.UserByAccountId;
using PARSNextGen.Application.User.Users.Queries.UserById;
using PARSNextGen.Application.User.Users.Queries.UserEmailReminders;
using PARSNextGen.Application.User.UserStatus.Command;
using PARSNextGen.Application.User.UserStatus.Queries;
using PARSNextGen.Contracts;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static PARSNextGen.API.Controllers.AuthController;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ILogger<UserController> _logger;
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;
        private readonly IBus _bus;
        private readonly ITemplateMapper _templateMapper;
        private readonly IConfiguration _config;
        private readonly ICurrentUserService _currentUserService;

        public UserController(IMediator mediator, ILogger<UserController> logger, ICustomMessageService customMsgSvc,
            IBus bus, ITemplateMapper templateMapper, IConfiguration config, ICurrentUserService currentUserService)
        {
            _logger = logger;
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
            _bus = bus;
            _templateMapper = templateMapper;
            _config = config;
            _currentUserService = currentUserService;
        }

        #region API CONTROLLER METHODS

        /// <summary>
        /// API  sets user status to active or in-active    
        /// </summary>
        /// <param name="UserStatusDto"> This Dto takes user_id and status</param>
        /// <returns></returns>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateUserStatus(UpdateUserStatusReq updateUserStatusReq)
        {
            if (_currentUserService.LoggedInUserId == updateUserStatusReq.id && updateUserStatusReq.user_status == (long)EnumTypes.user_status.Inactive)
                throw new BusinessException("PARS_USER_CANNOT_DEACTIVATED");

            ResponseBase<long> updResponse = new ResponseBase<long>();

            Tuple<bool, bool, string, string> isUpdSuccessful = await _mediator.Send(new UpdateUserStatusCommand
            {
                id = updateUserStatusReq.id,
                user_status = updateUserStatusReq.user_status,
                account_id = updateUserStatusReq.account_id
            });
            if (isUpdSuccessful.Item1)
            {
                #region SEND WELCOME EMAIL TO USER
                //Item2 if Email verify 'True' and user status 'Active' then send Email
                if (isUpdSuccessful.Item2 && (updateUserStatusReq.user_status == (long)EnumTypes.user_status.Active || updateUserStatusReq.user_status == (long)EnumTypes.user_status.Declined))
                {
                    CustomerNotificationEmail newUserReq = new CustomerNotificationEmail();
                    newUserReq.email = isUpdSuccessful.Item3;
                    newUserReq.full_name = isUpdSuccessful.Item4;
                    newUserReq.base_url = _config["appSettings:WebAppBaseURI"];
                    MergedContent emailTemplateContent = null;
                    if (updateUserStatusReq.user_status == (long)EnumTypes.user_status.Active)
                        emailTemplateContent = await _templateMapper.MergeTemplateByCode<CustomerNotificationEmail>("ACTIVATE_USER_ACCOUNT_EMAIL_TEMPLATE", newUserReq);
                    if (updateUserStatusReq.user_status == (long)EnumTypes.user_status.Declined)
                        emailTemplateContent = await _templateMapper.MergeTemplateByCode<CustomerNotificationEmail>("DECLINED_USER_ACCOUNT", newUserReq);

                    //Publish send email event for sending reset password link to user.
                    SendEmail emailMessage = new SendEmail
                    {
                        ToPartyEmails = new List<string>(new[] { newUserReq.email }),
                        Subject = emailTemplateContent.subject,
                        MessageBody = emailTemplateContent.body_text,
                        IsMessageHTML = emailTemplateContent.body_text.EndsWith("</html>", StringComparison.OrdinalIgnoreCase)
                    };
                    await _bus.Publish(emailMessage);
                }
                #endregion
                updResponse.Data = updateUserStatusReq.id;
                updResponse.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(updResponse);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API gets details of all users
        /// </summary>
        /// <returns> List of all users </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<AccountUsersDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountUsers(AccountUserReq accountUserReq)
        {
            ResponseBase<List<AccountUsersDto>> response = new ResponseBase<List<AccountUsersDto>>();
            var user = await _mediator.Send(new GetAccountUsersQuery
            {
                accountId = accountUserReq.account_id,
                statusId = accountUserReq.status_id,
                isPARSUsers = accountUserReq.is_PARS_users,
                is_email_verify = accountUserReq.is_email_verify,
                is_other_users = accountUserReq.is_other_users,
            });
            if (user?.Count != 0)
            {
                response.Data = user;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = user;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to get role by user id.
        /// </summary>
        /// <param name="userId"> user id </param>
        /// <returns> User Roles dto </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<UserRolesDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllRolesByUserId(int userId, long accountId)
        {
            var userRoles = await _mediator.Send(new GetAllRolesByUserIdQuery { user_id = userId, account_id = accountId });
            if (userRoles.Count > 0)
            {
                ResponseBase<List<UserRolesDto>> response = new ResponseBase<List<UserRolesDto>>();
                response.Data = userRoles;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API gets user by user id
        /// </summary>
        /// /// <param name="id">user id</param>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<UserByIdDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetUserById(long id)
        {
            var userById = await _mediator.Send(new GetUserByIdQuery { id = id });
            if (userById != null)
            {
                ResponseBase<UserByIdDto> response = new ResponseBase<UserByIdDto>();
                response.Data = userById;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API used to update user photo.
        /// </summary>
        /// <param name="UpdateUserPhotoReq"> Dto takes user id and the user image url </param>
        /// <returns> Updated user id </returns>
        /// <exception cref="Exception"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateUserPhoto(UpdateUserPhotoReq updateUserPhotoReq)
        {
            ResponseBase<long> updResponse = new ResponseBase<long>();
            bool isUpdSuccessful = await _mediator.Send(new UpdateUserPhotoCommand { user_id = updateUserPhotoReq.user_id, image_url = updateUserPhotoReq.image_url });
            if (isUpdSuccessful)
            {
                updResponse.Data = updateUserPhotoReq.user_id;
                updResponse.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(updResponse);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        ///  API is For add user roles
        /// </summary>
        /// <param name="UserRolesAddDto"> This dto is used to Add Role for user</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> AssignRoleToUser(UserRolesAddReq userRoles)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool isUpdateSuccessful = await _mediator.Send(new AddUserRoleCommand { user_id = userRoles.user_id, role_ids = userRoles.role_ids });
            if (isUpdateSuccessful)
            {
                response.Data = isUpdateSuccessful;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API gets user profile information    
        /// </summary>
        /// <param name="UserStatusDto"> This Dto takes user_id and status</param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<UsersDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetUserProfile(long id)
        {
            ResponseBase<UsersDetailsDto> response = new ResponseBase<UsersDetailsDto>();
            var user = await _mediator.Send(new GetuserDetailQuery { id = id });
            if (user != null)
            {
                response.Data = user;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API to get users through account.
        /// </summary>
        /// <param name="accountId"> account id </param>
        /// <returns> User dto </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<UserByAccountIdDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetUserByAccountId(int accountId)
        {
            var accountUser = await _mediator.Send(new GetUserByAccountIdQuery { account_id = accountId });
            if (accountUser.Count > 0)
            {
                ResponseBase<List<UserByAccountIdDto>> response = new ResponseBase<List<UserByAccountIdDto>>();
                response.Data = accountUser;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        ///  API is For Add user 
        /// </summary>
        /// <param name="CreateUserReq"> This dto is used to Add new user</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> AddNewUser(CreateUserReq createUserReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var isUpdateSuccessful = await _mediator.Send(new CreateUserCommand { createUserContactReq = createUserReq });

            if (isUpdateSuccessful.Item2)
                throw new BusinessException("PARS_DUPLICATE_EMAIL_ENTRY");
            else if (isUpdateSuccessful.Item1)
            {
                CustomerNotificationEmail newUserReq = new CustomerNotificationEmail();
                newUserReq.email = createUserReq.primary_email;
                newUserReq.full_name = createUserReq.first_name + " " + createUserReq.last_name;
                newUserReq.reset_password_token = isUpdateSuccessful.Item3;
                newUserReq.base_url = _config["appSettings:WebAppBaseURI"];
                MergedContent emailTemplateContent = await _templateMapper.MergeTemplateByCode<CustomerNotificationEmail>("SET_NEW_PASSWORD", newUserReq);

                SendEmail emailMessage = new SendEmail
                {
                    ToPartyEmails = new List<string>(new[] { newUserReq.email }),
                    Subject = emailTemplateContent.subject,
                    MessageBody = emailTemplateContent.body_text,
                    IsMessageHTML = emailTemplateContent.body_text.EndsWith("</html>", StringComparison.OrdinalIgnoreCase)
                };
                await _bus.Publish(emailMessage);
                response.Data = isUpdateSuccessful.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");
        }


        /// <summary>
        ///  API is For Update user 
        /// </summary>
        /// <param name="UpdateUserReq"> This dto is used to Update Role for user</param>
        /// <returns></returns>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateUser(UpdateUserReq userUserReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            #region Parameter detail for exception detail
            // Assign a value to HttpContext.Items
            HttpContext.Items["CurrentObject"] = null;
            var requestParameter = userUserReq;
            ExceptionDetail exceptionDetail = new ExceptionDetail();
            exceptionDetail.controller_name = "UserController";
            exceptionDetail.method_name = "UpdateUser";
            exceptionDetail.request_parameter = requestParameter;
            var exceptionDetailJson = new JavaScriptSerializer().Serialize(exceptionDetail);
            HttpContext.Items["CurrentObject"] = exceptionDetailJson;
            #endregion END

            bool isUpdateSuccessful = await _mediator.Send(new UpdateUserCommand { updateUserReq = userUserReq });
            if (isUpdateSuccessful)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
        }



        /// <summary>
        ///  API is For Add user without login
        /// </summary>
        /// <param name="CreateUserByDomainReq"> This dto is used to Add new user with portal</param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> AddNewUserWithoutLogin(CreateUserByDomainReq createUserReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            var isUpdateSuccessful = await _mediator.Send(new CreateUserByDomainCommand { createUserByDomainReq = createUserReq });


            if (isUpdateSuccessful.Item1)
            {
                throw new BusinessException("PARS_DUPLICATE_EMAIL_ENTRY");
            }
            else if (isUpdateSuccessful.Item2.Item1)
            {
                #region SEND WELCOME EMAIL TO USER
                string queueName = _config["RabbitMQSettings:QueueName"];
                CustomerNotificationEmail newUserReq = new CustomerNotificationEmail();
                newUserReq.reset_password_token = isUpdateSuccessful.Item2.Item2;
                newUserReq.full_name = string.IsNullOrEmpty(createUserReq.middle_name) ? createUserReq.first_name + " " + createUserReq.last_name : createUserReq.first_name + " " + createUserReq.middle_name + " " + createUserReq.last_name;
                newUserReq.email = createUserReq.primary_email;
                newUserReq.base_url = _config["appSettings:WebAppBaseURI"];

                MergedContent emailTemplateContent = await _templateMapper.MergeTemplateByCode<CustomerNotificationEmail>("VERIFIE_USER_EMAIL_TEMPLATE", newUserReq);

                //Publish send email event for sending reset password link to user.
                SendEmail emailMessage = new SendEmail
                {
                    ToPartyEmails = new List<string>(new[] { newUserReq.email }),
                    Subject = emailTemplateContent.subject,
                    MessageBody = emailTemplateContent.body_text,
                    IsMessageHTML = emailTemplateContent.body_text.EndsWith("</html>", StringComparison.OrdinalIgnoreCase)
                };
                await _bus.Publish(emailMessage);
                //var endpoint = await _bus.GetSendEndpoint(new Uri("queue:" + queueName));
                //await endpoint.Send(emailMessage);
                #endregion

                #region SEND EMAIL TO ACCOUNT ADMIN USER FOR ACTIVATE THE USER ACCOUNT

                CustomerNotificationEmail newUserReq1 = new CustomerNotificationEmail();

                newUserReq1.full_name = string.IsNullOrEmpty(createUserReq.middle_name) ? createUserReq.first_name + " " + createUserReq.last_name : createUserReq.first_name + " " + createUserReq.middle_name + " " + createUserReq.last_name;
                newUserReq1.email = createUserReq.primary_email;
                newUserReq1.base_url = _config["appSettings:WebAppBaseURI"];
                newUserReq1.phone_number = createUserReq.contact_phone_types[0].phone_number;
                newUserReq1.company = createUserReq.organization;
                if (createUserReq.country_id == (long)EnumTypes.Country.United_States)
                    newUserReq1.country = EnumTypes.Country.United_States.ToString();
                else if (createUserReq.country_id == (long)EnumTypes.Country.Canada)
                    newUserReq1.country = EnumTypes.Country.Canada.ToString();
                else if (createUserReq.country_id == (long)EnumTypes.Country.Puerto_Rico)
                    newUserReq1.country = EnumTypes.Country.Puerto_Rico.ToString();
                MergedContent emailTemplateContent1 = await _templateMapper.MergeTemplateByCode<CustomerNotificationEmail>("PENDING_APPROVAL_TEMPLATE", newUserReq1);

                //Publish send email event for sending reset password link to user.
                SendEmail emailMessage1 = new SendEmail
                {
                    ToPartyEmails = new List<string>(isUpdateSuccessful.Item3),
                    Subject = emailTemplateContent1.subject,
                    MessageBody = emailTemplateContent1.body_text,
                    IsMessageHTML = emailTemplateContent1.body_text.EndsWith("</html>", StringComparison.OrdinalIgnoreCase)
                };


                var endpoint1 = await _bus.GetSendEndpoint(new Uri("queue:" + queueName));
                await endpoint1.Send(emailMessage1);
                #endregion


                response.Data = isUpdateSuccessful.Item2.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }


        /// <summary>
        /// API CONTROLLER FOR UPDATE IS_EMAIL_VERIFY FIELD IN CONTACT
        /// </summary>
        /// <param name="updateReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>        

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<int>), StatusCodes.Status200OK)]
        public async Task<IActionResult> VerifyEmail(VerifyEmailReq updateReq)
        {
            ResponseBase<int> response = new ResponseBase<int>();
            Tuple<bool, int> result = await _mediator.Send(new VerifyEmailCommand { verifyToken = updateReq.verifyToken });
            if (result.Item2 != 0)
            {
                response.Data = result.Item2;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// Resend Verify Email To User
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ResendVerifyEmail(resendEmailReq userobj)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            Tuple<bool, string, string, string> result = await _mediator.Send(new ResendVerificationEmailCommand { id = userobj.userId });
            if (result.Item1)
            {
                #region SEND WELCOME EMAIL TO USER
                //string queueName = _config["RabbitMQSettings:QueueName"];
                CustomerNotificationEmail newUserReq = new CustomerNotificationEmail();
                newUserReq.reset_password_token = result.Item4;
                newUserReq.full_name = result.Item2;
                newUserReq.email = result.Item3;
                newUserReq.base_url = _config["appSettings:WebAppBaseURI"];
                MergedContent emailTemplateContent = await _templateMapper.MergeTemplateByCode<CustomerNotificationEmail>("VERIFIE_USER_EMAIL_TEMPLATE", newUserReq);

                //Publish send email event for sending reset password link to user.
                SendEmail emailMessage = new SendEmail
                {
                    ToPartyEmails = new List<string>(new[] { newUserReq.email }),
                    Subject = emailTemplateContent.subject,
                    MessageBody = emailTemplateContent.body_text,
                    IsMessageHTML = emailTemplateContent.body_text.EndsWith("</html>", StringComparison.OrdinalIgnoreCase)
                };
                await _bus.Publish(emailMessage);
                //var endpoint = await _bus.GetSendEndpoint(new Uri("queue:" + queueName));
                //await endpoint.Send(emailMessage);
                #endregion
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_VERIFY_EMAIL_SEND_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        /// <summary>
        /// This API USE in Time trigger function App. 
        /// this method send Email to account admin after two days if user account not approved.
        /// </summary>
        /// <returns></returns>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<bool> UserAccountPendingForApprovalNotification()
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            List<UserDetailsforEmailDto> result = await _mediator.Send(new GetUserAccountAdminsQuery { });
            if (result.Count > 0)
            {
                #region SEND EMAIL TO ACCOUNT ADMIN USER FOR ACTIVATE THE USER ACCOUNT
                foreach (var item in result)
                {
                    CustomerNotificationEmail newUserReq = new CustomerNotificationEmail();

                    newUserReq.full_name = string.IsNullOrEmpty(item.middle_name) ? item.first_name + " " + item.last_name : item.first_name + " " + item.middle_name + " " + item.last_name;
                    newUserReq.email = item.primary_email;
                    newUserReq.base_url = _config["appSettings:WebAppBaseURI"];
                    string queueName = _config["RabbitMQSettings:QueueName"];
                    newUserReq.phone_number = item.phone_1;
                    newUserReq.company = item.organization;

                    if (item.country_id == (long)EnumTypes.Country.United_States)
                        newUserReq.country = EnumTypes.Country.United_States.ToString();
                    else if (item.country_id == (long)EnumTypes.Country.Canada)
                        newUserReq.country = EnumTypes.Country.Canada.ToString();
                    else if (item.country_id == (long)EnumTypes.Country.Puerto_Rico)
                        newUserReq.country = EnumTypes.Country.Puerto_Rico.ToString();

                    MergedContent emailTemplateContent1 = await _templateMapper.MergeTemplateByCode<CustomerNotificationEmail>("PENDING_APPROVAL_TEMPLATE", newUserReq);

                    //Publish send email event for sending reset password link to user.
                    SendEmail emailMessage = new SendEmail
                    {
                        ToPartyEmails = new List<string>(item.adminEmails),
                        Subject = emailTemplateContent1.subject,
                        MessageBody = emailTemplateContent1.body_text,
                        IsMessageHTML = emailTemplateContent1.body_text.EndsWith("</html>", StringComparison.OrdinalIgnoreCase)
                    };
                    //var endpoint = await _bus.GetSendEndpoint(new Uri("queue:" + queueName));
                    //await endpoint.Send(emailMessage);
                    await _bus.Publish(emailMessage);
                }
                #endregion
            }
            return true;
        }
        #endregion

        #region API CONTROLLER FOR ASSIGN QUEUE TO USER
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        public async Task<IActionResult> AssignQueueToUser(CreateUserQueueReq createUserQueueReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool userQueue = await _mediator.Send(new CreateUserQueueCommand { user_id = createUserQueueReq.user_id, queue_ids = createUserQueueReq.queue_ids });
            if (userQueue)
            {
                response.Data = userQueue;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns> queue record </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAllQueueByUserIdReq>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllQueueByUserId(long userId)
        {
            var userQueue = await _mediator.Send(new GetAllQueueByUserIdQuery { userId = userId });
            if (userQueue.Count > 0)
            {
                ResponseBase<List<GetAllQueueByUserIdReq>> response = new ResponseBase<List<GetAllQueueByUserIdReq>>();
                response.Data = userQueue;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }
        #endregion


        #region API CONTRACT MODEL AND VALIDATORS

        public class UserRolesAddReq
        {
            public int user_id { get; set; }
            public List<int> role_ids { get; set; }

        }

        //Add validator here for UserRolesAddReqValidator.

        public class UpdateUserPhotoReq
        {
            public int user_id { get; set; }
            public string image_url { get; set; }
        }

        public class UpdateUserPhotoReqValidator : AbstractValidator<UpdateUserPhotoReq>
        {
            public UpdateUserPhotoReqValidator()
            {
                RuleFor(p => p.user_id).NotEmpty();
                RuleFor(p => p.image_url).NotEmpty();
            }
        }


        public class UpdateUserStatusReq
        {
            public long id { get; set; }
            public long? user_status { get; set; }
            public long account_id { get; set; }
        }

        public class AccountUserReq
        {
            public long? account_id { get; set; }
            public long? status_id { get; set; }
            public bool is_email_verify { get; set; }
            public bool is_PARS_users { get; set; }
            public bool is_other_users { get; set; }

        }


        public class UpdateUserStatusReqValidator : AbstractValidator<UpdateUserStatusReq>
        {
            public UpdateUserStatusReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
                RuleFor(p => p.account_id).NotEmpty();
            }
        }

        public class UpdateUserReqValidator : AbstractValidator<UpdateUserReq>
        {
            public UpdateUserReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }

        public class CreateUserReqValidator : AbstractValidator<CreateUserReq>
        {
            public CreateUserReqValidator()
            {
                RuleFor(p => p.primary_email).NotEmpty();
            }
        }
        public class VerifyEmailReqValidator : AbstractValidator<VerifyEmailReq>
        {
            public VerifyEmailReqValidator()
            {
                RuleFor(p => p.verifyToken).NotNull().NotEmpty().WithMessage("Please provide verify token.");
            }
        }
        public class CreateUserQueueReqValidator : AbstractValidator<CreateUserQueueReq>
        {
            public CreateUserQueueReqValidator()
            {
                RuleFor(p => p.user_id).NotNull();
                RuleFor(p => p.queue_ids).NotEmpty();
            }
        }

        public class GetAllQueueByUserIdReqValidator : AbstractValidator<GetAllQueueByUserIdReq>
        {
            public GetAllQueueByUserIdReqValidator()
            {
                RuleFor(p => p.userId).NotNull();
            }
        }
        #endregion


    }
    public class resendEmailReq
    {
        public long userId { get; set; }
    }
}
