﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.DistanceCalculate.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.Storage.GetStorage.GetStorageDetails.Queries;
using System.Globalization;
using System.Threading.Tasks;
using static PARSNextGen.Domain.Common.EnumTypes;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class MapController : Controller
    {
        private readonly ILogger<QuoteController> _logger;
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;
        private readonly IConfiguration _config;
        private readonly IAzureMapService _azureMapService;
        public MapController(IMediator mediator, ILogger<QuoteController> logger, ICustomMessageService customMsgSvc, IConfiguration config, IAzureMapService azureMapService)
        {
            _logger = logger;
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
            _config = config;
            _azureMapService = azureMapService;
        }


        #region API CONTROLLER METHODS

        /// <summary>
        /// API get address by  postal Code   
        /// <param> postal_code </param>
        /// </summary>
        /// <returns> city,state,postal_code </returns>
        /// <exception cref="BusinessException"></exception>
        ///   
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<PostalAddressDTO>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAddressByZipCode(ZipCodeAddressReq zipCodeAddressReq)
        {
            ResponseBase<PostalAddressDTO> responseBase = new ResponseBase<PostalAddressDTO>();
            var address = await _azureMapService.GetByZipCodeAddress(zipCodeAddressReq);
            if (address is not null)
            {
                if (address.is_verify_postal_code)
                {
                    responseBase.Data = address;
                    responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                    return new OkObjectResult(responseBase);
                }
                else
                {
                    responseBase.Data = null;
                    responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                    return new OkObjectResult(responseBase);
                }
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }
        /// <summary>
        /// Api verify address
        /// <param>postal Address DTO</param>
        /// <return>verify address</return>
        /// <exception cref="BusinessException"></exception>
        /// </summary>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<PostalAddressVerifyDTO>), StatusCodes.Status200OK)]
        public async Task<IActionResult> VerifyAddress(VerifyAddressReq postalAddressDTO)
        {
            ResponseBase<PostalAddressVerifyDTO> responseBase = new ResponseBase<PostalAddressVerifyDTO>();
            var address = await _azureMapService.VerifyAddress(postalAddressDTO);
            if (address is not null)
            {
                if (address.verification_status == (long)Verification_Status.Not_Verified)
                {
                    responseBase.Data = address;
                    responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                    return new OkObjectResult(responseBase);
                }
                else
                {
                    responseBase.Data = address;
                    responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                    return new OkObjectResult(responseBase);
                }

            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to calculate distance between pickup and delivery by latitude and longitude   
        /// <param> latitude and longitude </param>
        /// </summary>
        /// <returns> distance,duration time </returns>
        /// <exception cref="BusinessException"></exception>
        ///  

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<RouteLengthResponseDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ReRouteLength(RouteLenthReq routeLenthReq)
        {
            ResponseBase<RouteLengthResponseDto> response = new ResponseBase<RouteLengthResponseDto>();
            string pick_lat = string.Empty;
            string pick_lon = string.Empty;
            string del_lat = string.Empty;
            string del_lon = string.Empty;

            #region Get Latitude and Longitude For Pickup and Delivery Address
            ZipCodeAddressReq pickZipCodeAddress = new ZipCodeAddressReq();
            pickZipCodeAddress.postalCode = routeLenthReq.pick_postal_code;
            //Get latitude and longitude for Pickup address
            var addressRes = await _azureMapService.GetByZipCodeAddress(pickZipCodeAddress);
            if (addressRes != null)
            {
                if (addressRes.lat != null || addressRes.lon != null)
                {
                    pick_lat = addressRes.lat;
                    pick_lon = addressRes.lon;
                }
                else
                {
                    throw new BusinessException("PARS_PICKUP_COORDINATE_NOT_FOUND");
                }
            }
            else
            {
                throw new BusinessException("PARS_PICKUP_COORDINATE_NOT_FOUND");
            }

            //Get latitude and longitude for Delivery address
            if (routeLenthReq.storage_id == null)
            {
                ZipCodeAddressReq delZipCodeAddress = new ZipCodeAddressReq();
                delZipCodeAddress.postalCode = routeLenthReq.del_postal_code;
                var addressRes1 = await _azureMapService.GetByZipCodeAddress(delZipCodeAddress);
                if (addressRes1 != null)
                {
                    if (addressRes1.lat != null || addressRes1.lon != null)
                    {
                        del_lat = addressRes1.lat;
                        del_lon = addressRes1.lon;
                    }
                    else
                    {
                        throw new BusinessException("PARS_DELIVERY_COORDINATE_NOT_FOUND");
                    }
                }
                else
                {
                    throw new BusinessException("PARS_DELIVERY_COORDINATE_NOT_FOUND");
                }
            }
            else
            {
                //long parsStorageId = 7;
                var storagedetail = await _mediator.Send(new GetStorageDetailQuery { id = (long)routeLenthReq.storage_id });
                if (storagedetail != null)
                {
                    del_lat = storagedetail.latitude.ToString();
                    del_lon = storagedetail.longitude.ToString();
                }
                else
                {
                    throw new BusinessException("PARS_DELIVERY_COORDINATE_NOT_FOUND");

                }
            }

            #endregion End To Get Latitude and Longitude For Pickup and Delivery Address

            //long parsStorageId = 7;
            //var storagedetail = await _mediator.Send(new GetStorageDetailQuery { id = (long)routeLenthReq.storage_id });
            //if (storagedetail != null)
            //{
            //    del_lat = storagedetail.latitude.ToString();
            //    del_lon = storagedetail.longitude.ToString();
            //}
            //else
            //{
            //    //Get latitude and longitude for Delivery address
            //    var addressRes1 = await _azureMapService.GetByZipCodeAddress(routeLenthReq.del_postal_code);
            //    if(addressRes1!= null)
            //    {
            //        if (addressRes1.lat!= null || addressRes1.lon!= null)
            //        {
            //            del_lat = addressRes1.lat;
            //            del_lon = addressRes1.lon;
            //        }
            //        else
            //        {
            //            throw new BusinessException("PARS_DELIVERY_COORDINATE_NOT_FOUND");

            //        }
            //    }
            //    else
            //    {
            //        throw new BusinessException("PARS_DELIVERY_COORDINATE_NOT_FOUND");

            //    }


            //}

            ////Get latitude and longitude for Delivery address
            //var addressRes1 = await _azureMapService.GetByZipCodeAddress(routeLenthReq.del_postal_code);
            //if (addressRes1.lat == null || addressRes1.lon == null)
            //{
            //    throw new BusinessException("PARS_DELIVERY_COORDINATE_NOT_FOUND");
            //}

            // pick_lat = addressRes.lat;
            // pick_lon = addressRes.lon;

            string coordinate = string.Format("{0},{1}:{2},{3}", pick_lat.ToString(CultureInfo.InvariantCulture), pick_lon.ToString(CultureInfo.InvariantCulture), del_lat.ToString(CultureInfo.InvariantCulture), del_lon.ToString(CultureInfo.InvariantCulture));

            var routeLengthResponse = await _azureMapService.CalculateDistanceBetweenCoordinates(coordinate);
            if (routeLengthResponse != null)
            {
                response.Data = routeLengthResponse;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }

        }

        #endregion


        #region API CONTRACT MODEL AND VALIDATORS

        public class RouteLenthReq
        {
            public string pick_postal_code { get; set; }
            public string del_postal_code { get; set; }
            public long? storage_id { get; set; }
        }

        public class RouteLenthReqValidator : AbstractValidator<RouteLenthReq>
        {
            public RouteLenthReqValidator()
            {
                RuleFor(p => p.pick_postal_code).NotEmpty();
                // RuleFor(p => p.del_postal_code).NotEmpty();
            }
        }

        public class VerifyAddressReqValidator : AbstractValidator<VerifyAddressReq>
        {
            public VerifyAddressReqValidator()
            {

                RuleFor(x => x.City).NotEmpty();
                RuleFor(x => x.PostalCode).NotEmpty();
                RuleFor(x => x.CountryCode).NotEmpty();


            }
        }

        #endregion
    }
}
