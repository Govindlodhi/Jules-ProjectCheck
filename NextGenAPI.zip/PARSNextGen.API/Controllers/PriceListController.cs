﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Preference.PriceList.Command;
using PARSNextGen.Application.Preference.PriceList.Queries;
using PARSNextGen.Application.Preference.PriceListItem.Command;
using PARSNextGen.Application.Preference.PriceListItem.Queries;
using PARSNextGen.Application.Service;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]

    public class PriceListController : Controller
    {
        private readonly ILogger<AccountController> _logger;
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;

        public PriceListController(ILogger<AccountController> logger, IMediator mediator, ICustomMessageService customMsgSvc)
        {
            _logger = logger;
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
        }
        #region PRICE LIST API METHODS


        /// <summary>
        /// API to Get PriceList Master Data
        /// </summary>
        /// <returns> List of PriceList Master Data   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<PriceListMasterDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPriceListMasterData()
        {
            ResponseBase<List<PriceListMasterDto>> response = new ResponseBase<List<PriceListMasterDto>>();
            var masterDetails = await _mediator.Send(new GetPriceListMasterQuery { });
            if (masterDetails != null)
            {
                List<PriceListMasterDto> resp = new List<PriceListMasterDto>();
                resp.Add(masterDetails);
                response.Data = resp;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to get Pricelists by Id
        /// <returns> Pricelists details by Id </returns>
        /// <exception cref="BusinessException"></exception>
        /// </summary>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<PriceListDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPricelistById(long Id)
        {
            ResponseBase<PriceListDto> response = new ResponseBase<PriceListDto>();

            var pricelistDetails = await _mediator.Send(new GetPriceListByIdQuery
            { id = Id });
            if (pricelistDetails != null && pricelistDetails.id > 0)
            {
                response.Data = pricelistDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to get Pricelists by AgreementId
        /// <returns> List of all Pricelists related to Agreement. </returns>
        /// <exception cref="BusinessException"></exception>
        /// </summary>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<PriceListDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPricelist(priceListReq priceListReq)
        {
            ResponseBase<List<PriceListDto>> response = new ResponseBase<List<PriceListDto>>();

            var pricelistDetails = await _mediator.Send(new GetPriceListQuery { currencyId = priceListReq.currencyId });
            if (pricelistDetails != null && pricelistDetails.Count > 0)
            {
                response.Data = pricelistDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to create PriceLists
        /// </summary>
        /// <param name="createPriceListReq"> CreatePriceListReq</param>
        /// <returns> Create PriceLists. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreatePriceList(CreatePriceListReq createPriceListReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new CreatePriceListCommand
            {
                createPriceListReqs = createPriceListReq

            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }

        }

        /// <summary>
        /// API to update PriceLists
        /// </summary>
        /// <param name="updatePriceListReq"> UpdatePriceListReq</param>
        /// <returns> Update PriceLists. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdatePriceList(UpdatePriceListReq updatePriceListReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdatePriceListCommand
            {
                updatePriceListReqs = updatePriceListReq

            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        /// <summary>
        /// API to update PriceList status
        /// </summary>
        /// <param name="updatePriceListStatusReq"> UpdatePriceListStatusReq</param>
        /// <returns> Update PriceList Status. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdatePriceListStatus(UpdatePriceListStatusReq updatePriceListStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var updStatus = await _mediator.Send(new UpdatePriceListStatusCommand { updatePriceListStatusReq = updatePriceListStatusReq });

            if (updStatus.Item2)
            {
                response.Data = updStatus.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_PRICE_LIST_CAN_NOT_DEACTIVATE");
                return new OkObjectResult(response);
            }
            else if (updStatus.Item1)
            {
                response.Data = updStatus.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }

        }



        /// <summary>
        /// API to Clone Price List
        /// </summary>
        /// <param name="priceListId"> priceListId</param>
        /// <returns> Price List Id </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long?>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ClonePriceList(ClonePriceListReq clonePriceListReq)
        {
            ResponseBase<long?> response = new ResponseBase<long?>();
            var cloneid = await _mediator.Send(new ClonePriceListCommand { clonePriceListReq = clonePriceListReq });
            if (cloneid > 0 && cloneid != null)
            {
                response.Data = cloneid;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CLONE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CLONE_FAILURE");
            }
        }


        #endregion

        #region PRICE LIST ITEMS API METHODS

        /// <summary>
        /// API to get PriceListItems by Id
        /// <returns> PriceListItems details by Id </returns>
        /// <exception cref="BusinessException"></exception>
        /// </summary>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<PriceListItemDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPriceListItemById(long Id)
        {
            ResponseBase<PriceListItemDto> response = new ResponseBase<PriceListItemDto>();

            var priceListItemDetails = await _mediator.Send(new GetPriceListItemByIdQuery
            { id = Id });
            if (priceListItemDetails != null && priceListItemDetails.id > 0)
            {
                response.Data = priceListItemDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        /// <summary>
        /// API to Get PriceListItemItem Master Data
        /// </summary>
        /// <returns> List of PriceListItem Master Data   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<PriceListItemMasterDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPriceListItemMasterData()
        {
            ResponseBase<List<PriceListItemMasterDto>> response = new ResponseBase<List<PriceListItemMasterDto>>();
            var masterDetails = await _mediator.Send(new GetPriceListItemMasterQuery { });
            if (masterDetails != null)
            {
                List<PriceListItemMasterDto> resp = new List<PriceListItemMasterDto>();
                resp.Add(masterDetails);
                response.Data = resp;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to get PricelistItem by PriceListId
        /// <returns> List of all PricelistItems related to PriceListId. </returns>
        /// <exception cref="BusinessException"></exception>
        /// </summary>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<PriceListItemDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPricelistItemsByPriceListId(long priceListId)
        {
            ResponseBase<List<PriceListItemDto>> response = new ResponseBase<List<PriceListItemDto>>();

            var pricelistItemDetails = await _mediator.Send(new GetPriceListItemByPriceListIdQuery
            {
                priceListId = priceListId
            });
            if (pricelistItemDetails != null && pricelistItemDetails.Count > 0)
            {
                response.Data = pricelistItemDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        /// <summary>
        /// API to create PriceListItems
        /// </summary>
        /// <param name="createPriceListItemReq"> CreatePriceListItemReq</param>
        /// <returns> Create PriceListItems. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreatePriceListItem(CreatePriceListItemReq createPriceListItemReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            #region Check Duplicate Service In Price List Item 
            bool isExist = await _mediator.Send(new CheckDuplicateServiceInPriceListItemQuery
            {
                service_id = createPriceListItemReq.service_id,
                price_list_id = createPriceListItemReq.price_list_id

            });
            if (isExist)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            #endregion
            bool result = await _mediator.Send(new CreatePriceListItemCommand
            {
                createPriceListItemReqs = createPriceListItemReq

            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }

        }


        /// <summary>
        /// API to update PriceListItems
        /// </summary>
        /// <param name="updatePriceListItemReq"> UpdatePriceListItemReq</param>
        /// <returns> Update PriceListItems. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdatePriceListItem(UpdatePriceListItemReq updatePriceListItemReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            #region Check Duplicate Service In Price List Item 
            bool isExist = await _mediator.Send(new CheckDuplicateServiceInPriceListItemQuery
            {
                id = updatePriceListItemReq.id,
                service_id = updatePriceListItemReq.service_id,
                price_list_id = updatePriceListItemReq.price_list_id

            });
            if (isExist)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            #endregion

            bool result = await _mediator.Send(new UpdatePriceListItemCommand
            {
                updatePriceListItemReqs = updatePriceListItemReq

            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// API to update PriceListItem status
        /// </summary>
        /// <param name="updatePriceListItemStatusReq"> UpdatePriceListItemStatusReq</param>
        /// <returns> Update PriceListItem Status. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdatePriceListItemStatus(UpdatePriceListItemStatusReq updatePriceListItemStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool updStatus = await _mediator.Send(new UpdatePriceListItemStatusCommand { updatePriceListItemStatusReq = updatePriceListItemStatusReq });

            if (updStatus)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        /// <summary>
        /// API to get Service Details by priceListId and Service Id
        /// <returns> PriceListItems details by Id </returns>
        /// <exception cref="BusinessException"></exception>
        /// </summary>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<GetServiceDetailsByPriceListIdDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServiceDetailsByPriceListId(GetServiceDetailsByPriceListIdReq getServiceDetailsByPriceListIdReq)
        {
            ResponseBase<GetServiceDetailsByPriceListIdDto> response = new ResponseBase<GetServiceDetailsByPriceListIdDto>();

            var serviceDetails = await _mediator.Send(new GetServiceDetailsByPriceListIdQuery
            { getServiceDetailsByPriceListIdReq = getServiceDetailsByPriceListIdReq });
            if (serviceDetails != null)
            {
                response.Data = serviceDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        #endregion 

        #region PRICE LIST API MODELS AND VALIDATIONS
        /// <summary>
        /// validator for CreatePreferenceReq
        /// </summary>
        public class CreatePriceListReqValidator : AbstractValidator<CreatePriceListReq>
        {
            public CreatePriceListReqValidator()
            {
                RuleFor(p => p.price_list_name).NotNull().NotEmpty();
                RuleFor(p => p.price_list_type_id).NotNull().NotEmpty().NotEqual(0);
            }
        }
        public class UpdatePriceListReqValidator : AbstractValidator<UpdatePriceListReq>
        {
            public UpdatePriceListReqValidator()
            {
                RuleFor(p => p.price_list_name).NotNull().NotEmpty();
                RuleFor(p => p.price_list_type_id).NotNull().NotEmpty().NotEqual(0);
                RuleFor(p => p.id).NotEmpty().NotEmpty().NotEqual(0);
            }
        }

        public class ClonePriceListReqValidator : AbstractValidator<ClonePriceListReq>
        {
            public ClonePriceListReqValidator()
            {

                RuleFor(p => p.price_list_name).NotNull().NotEmpty();
                RuleFor(p => p.price_list_type_id).NotNull().NotEmpty().NotEqual(0);
                RuleFor(p => p.id).NotEmpty().NotEmpty().NotEqual(0);
            }
        }

        #endregion

        #region PRICE LIST ITEM API MODELS AND VALIDATIONS


        public class CreatePriceListItemReqValidator : AbstractValidator<CreatePriceListItemReq>
        {
            public CreatePriceListItemReqValidator()
            {
                RuleFor(p => p.price_list_id).NotNull().NotEmpty();
                RuleFor(p => p.service_id).NotNull().NotEmpty();
                RuleFor(p => p.rate_type).NotNull().NotEmpty();


            }
        }
        public class UpdatePriceListItemReqValidator : AbstractValidator<UpdatePriceListItemReq>
        {
            public UpdatePriceListItemReqValidator()
            {
                RuleFor(p => p.price_list_id).NotNull().NotEmpty();
                RuleFor(p => p.service_id).NotNull().NotEmpty();
                RuleFor(p => p.rate_type).NotNull().NotEmpty();


            }
        }


        public class priceListReq
        {
            public long? currencyId { get; set; }
        }
        #endregion 
    }

}
