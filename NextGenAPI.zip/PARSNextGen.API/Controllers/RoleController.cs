﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Master.Permission.Command;
using PARSNextGen.Application.Master.Permission.Queries;
using PARSNextGen.Application.Master.Roles.Command.CreateRole;
using PARSNextGen.Application.Master.Roles.Command.DeleteRole;
using PARSNextGen.Application.Master.Roles.Command.UpdateRole;
using PARSNextGen.Application.Master.Roles.Command.UpdateRoleStatus;
using PARSNextGen.Application.Master.Roles.Queries.AccountRoles;
using PARSNextGen.Application.Master.Roles.Queries.RoleDetail;
using PARSNextGen.Application.Service;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static PARSNextGen.API.Controllers.RoleController;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class RoleController : Controller
    {
        private readonly ILogger<RoleController> _logger;
        private readonly IMediator _mediator;
        private readonly ICurrentUserService _currentUserContext;
        private readonly ICustomMessageService _customMessageService;

        public RoleController(IMediator mediator, ILogger<RoleController> logger, ICurrentUserService currentUserContext, ICustomMessageService customMessageService)
        {
            _logger = logger;
            _mediator = mediator;
            _currentUserContext = currentUserContext;
            _customMessageService = customMessageService;
        }

        #region API CONTROLLER METHODS


        /// <summary>
        ///  API to get all account roles.
        /// </summary>
        /// <returns> List of all roles. </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<RolesDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountRoles(long accountId)
        {
            ResponseBase<List<RolesDto>> response = new ResponseBase<List<RolesDto>>();
            var userRoles = await _mediator.Send(new GetAccountRolesQuery { accountId = accountId });
            if (userRoles?.Count != 0)
            {
                response.Data = userRoles;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }



        /// <summary>
        /// API to create role.
        /// </summary>
        /// <param name="createRoleReq"> Dto takes role name and role description. </param>
        /// <returns> Created new role id. </returns>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateRole(CreateRoleReq createRoleReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            bool newRoleId = await _mediator.Send(new CreateRoleCommand { role_name = createRoleReq.role_name, role_description = createRoleReq.role_description });
            if (newRoleId)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
        }



        /// <summary>
        /// API to update role status.
        /// </summary>
        /// <param name="updateRoleStatus"> Dto takes role id and role status. </param>
        /// <returns> 204 No Content Status Code. </returns>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateRoleStatus(UpdateRoleStatusReq updateRoleStatusReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            if (updateRoleStatusReq.role_id == (long)EnumTypes.Role.Super_Administrator && _currentUserContext.LoggedInUserId != (long)EnumTypes.Super_Admin_User.SuperAdminUser)
                throw new BusinessException("PARS_SUPER_ADMINISTRATOR_CAN_MODIFY_THEIR_PERMISSIONS");
            else
            {
                bool isUpdateSuccessful = await _mediator.Send(new UpdateRoleStatusCommand { role_id = updateRoleStatusReq.role_id, role_status = updateRoleStatusReq.role_status });
                if (isUpdateSuccessful)
                {
                    response.Data = updateRoleStatusReq.role_id;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                {
                    throw new BusinessException("PARS_UPDATION_FAILURE");
                }
            }          

        }



        /// <summary>
        /// API to change role.
        /// </summary>
        /// <param name="updateRoleDto"> Dto takes role id and role name. </param>
        /// <returns> 204 No content Status Code. </returns>
        /// <exception cref="Exception"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateRole(UpdateRoleReq updateRoleReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            bool isUpdateSuccessful = await _mediator.Send(new UpdateRoleCommand { role_id = updateRoleReq.role_id, role_name = updateRoleReq.role_name, role_description = updateRoleReq.role_description });
            if (isUpdateSuccessful)
            {
                response.Data = updateRoleReq.role_id;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
        }



        /// <summary>
        /// API to delete role.
        /// </summary>
        /// <param name="roleId"> Role Id </param>
        /// <returns> 204 No Content Status Code. </returns>
        /// <exception cref="Exception"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> DeleteRole(DeleteRoleReq deleteRoleReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            if (deleteRoleReq.role_id == (long)EnumTypes.Role.Super_Administrator && _currentUserContext.LoggedInUserId != (long)EnumTypes.Super_Admin_User.SuperAdminUser)
                throw new BusinessException("PARS_SUPER_ADMINISTRATOR_CAN_MODIFY_THEIR_PERMISSIONS");
            else
            {
                Tuple<bool, bool> isDeleteSuccessful = await _mediator.Send(new DeleteRoleCommand { role_id = deleteRoleReq.role_id });
                if (isDeleteSuccessful.Item1)
                {
                    response.Data = false;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_ROLE_ASSIGNED");
                    return new OkObjectResult(response);
                }
                else if (isDeleteSuccessful.Item2)
                {
                    response.Data = true;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_DELETE_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                    throw new BusinessException("PARS_DELETION_FAILURE");
            }           
        }



        /// <summary>
        /// API to get role for id.
        /// </summary>
        /// <param name="roleId"> Role Id </param>
        /// <returns> Roles Dto </returns>
        /// <exception cref="Exception"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<RoleDetailDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetRoleById(int roleId)
        {
            ResponseBase<RoleDetailDto> response = new ResponseBase<RoleDetailDto>();
            var roleById = await _mediator.Send(new RoleDetailQuery { role_id = roleId });
            if (roleById != null)
            {
                response.Data = roleById;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        /// <summary>
        /// API to get all permissions assigned for a role.
        /// </summary>
        /// <param name="id"> </param>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<PermissionDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetRolePermission(long id, long account_type_id)
        {
            ResponseBase<PermissionDto> response = new ResponseBase<PermissionDto>();
            var permissionById = await _mediator.Send(new GetRolePermissionQuery { id = id, account_type_id = account_type_id });
            if (permissionById != null)
            {
                response.Data = permissionById;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        /// <summary>
        ///  API is used to Add Permission for Role
        /// </summary>
        /// <param name="CreateRolePermissionDto"> This dto contains role_id,permission_id and created_by</param>
        /// <returns></returns>

        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        public async Task<IActionResult> AssignPermissionToRole(CreateRolePermissionReq createRolePermissionReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            if (createRolePermissionReq.role_id == (long)EnumTypes.Role.Super_Administrator && _currentUserContext.LoggedInUserId != (long)EnumTypes.Super_Admin_User.SuperAdminUser)
                throw new BusinessException("PARS_SUPER_ADMINISTRATOR_CAN_MODIFY_THEIR_PERMISSIONS");
            else
            {
                bool rolePermission = await _mediator.Send(new CreateRolePermissionsCommand { role_id = createRolePermissionReq.role_id, permission_ids = createRolePermissionReq.permission_ids });
                if (rolePermission)
                {
                    response.Data = rolePermission;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                {
                    throw new BusinessException("PARS_UPDATION_FAILURE");
                }
            }
        }

        #endregion

        #region API CONTRACT MODELS AND VALIDATORS
        ///Model Definition And Validators


        ///Create RolePermission Dto and Validator
        public class CreateRolePermissionReq
        {
            public long role_id { get; set; }
            public List<long> permission_ids { get; set; }
        }

        public class CreateRolePermissionReqValidator : AbstractValidator<CreateRolePermissionReq>
        {
            public CreateRolePermissionReqValidator()
            {
                RuleFor(p => p.role_id).NotEmpty();
                RuleFor(p => p.permission_ids).NotEmpty().WithMessage("Assign the user a minimum of one permission.");
            }
        }


        ///Create Role Dto and Validator
        public class CreateRoleReq
        {
            //  public long id { get; set; }
            public string role_name { get; set; }
            public string role_description { get; set; }
        }
        //public class CreateRoleReqValidator : AbstractValidator<CreateRoleReq>
        //{
        //    public CreateRoleReqValidator()
        //    {
        //        //RuleFor(p => p.role_name).NotEmpty().MinimumLength(5);
        //        RuleFor(p => p.role_description).NotEmpty().NotNull().MinimumLength(500);
        //    }
        //}

        ///Delete Role Dto and Validator
        public class DeleteRoleReq
        {
            public int role_id { get; set; }
        }
        public class DeleteRoleReqValidator : AbstractValidator<DeleteRoleReq>
        {
            public DeleteRoleReqValidator()
            {
                RuleFor(p => p.role_id).NotEqual(0);
            }
        }

        ///Update Role Dto and Validator
        public class UpdateRoleReq
        {
            public int role_id { get; set; }
            public string role_name { get; set; }
            public string role_description { get; set; }
        }
        public class UpdateRoleReqValidator : AbstractValidator<UpdateRoleReq>
        {
            public UpdateRoleReqValidator()
            {
                RuleFor(p => p.role_id).NotEmpty().NotEqual(0);
                RuleFor(p => p.role_name).NotEmpty().NotNull();
                RuleFor(p => p.role_description).NotEmpty().NotNull().MinimumLength(5);
            }
        }

        //Update Role status Dto and Validator
        public class UpdateRoleStatusReq
        {
            public int role_id { get; set; }
            public bool role_status { get; set; }
        }
        public class UpdateRoleStatusReqValidator : AbstractValidator<UpdateRoleStatusReq>
        {
            public UpdateRoleStatusReqValidator()
            {
                RuleFor(p => p.role_id).NotEqual(0);
            }
        }
        #endregion

    }
}
