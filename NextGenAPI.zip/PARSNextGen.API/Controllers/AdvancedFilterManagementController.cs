﻿using MassTransit.Futures.Contracts;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Account.Accounts.Queries;
using PARSNextGen.Application.AdvancedFilterManagement.Command;
using PARSNextGen.Application.AdvancedFilterManagements.Command;
using PARSNextGen.Application.AdvancedFilterManagements.Query;
using PARSNextGen.Application.Service;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static PARSNextGen.Domain.Common.EnumTypes;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class AdvancedFilterManagementController : Controller
    {
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;
        public AdvancedFilterManagementController(IMediator mediator, ICustomMessageService customMsgSvc)
        {
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
        }

        /// <summary>
        /// API for Save and Update Advanced Filter.
        /// </summary>
        /// <param name="advancedFilterRequest"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateAdvancedFilter(AdvancedFilterRequest advancedFilterRequest)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool data = await _mediator.Send(new CreateFilterCommand { requestParam = advancedFilterRequest });
            if (data)
            {
                response.Data = data;
                response.MessageDetail = advancedFilterRequest.id == null ? _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS") :
                  _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                string sortMessage = advancedFilterRequest.id == null ? throw new BusinessException("PARS_CREATION_FAILURE")
                    : throw new BusinessException("PARS_UPDATION_FAILURE");
                throw new BusinessException(sortMessage);
            }
        }

        /// <summary>
        /// API for All Advanced Filter List.
        /// </summary>
        /// <param name="entity_name"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<AdvancedFilterListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAdvancedFilterList(string entity_name)
        {
            ResponseBase<List<AdvancedFilterListDto>> response = new ResponseBase<List<AdvancedFilterListDto>>();
            var data = await _mediator.Send(new GetAdvancedFilterListQuery { entity_name = entity_name });
            if (data.Count > 0)
            {
                response.Data = data;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");

            }
            else
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            return new OkObjectResult(response);
        }

        /// <summary>
        /// API for Deleting Advanced Filter.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpDelete]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> DeleteAdvancedFilter(long id)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var data = await _mediator.Send(new DeleteAdvancedFilterCommand { id = id });
            if (data)
            {
                response.Data = data;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_DELETE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_DELETION_FAILURE");
        }

        /// <summary>
        /// API for Set And Remove Default Advanced Filter.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="is_set_default"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPatch]
        [ProducesResponseType(typeof(ResponseBase<AccountMasterDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateSetDefaultAdvancedFilter(long id, bool is_set_default)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var data = await _mediator.Send(new UpdateSetDefaultAdvancedFilter { id = id, is_set_default = is_set_default });
            if (data)
            {
                response.Data = data;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

    }
}
