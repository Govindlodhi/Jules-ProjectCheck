﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.User.GridPreference.Command;
using PARSNextGen.Application.User.UserViewPreference.Queries;
using System.Threading.Tasks;


namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class GridPreferenceController : Controller
    {
        // private readonly ILogger<UserController> _logger;
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;

        public GridPreferenceController(IMediator mediator, ICustomMessageService customMsgSvc)
        {
            //_logger = logger;
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
        }
        /// <summary>
        /// API get View setting by Entity Name
        /// </summary>
        /// /// <param name="id">user id</param>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<GridPreferenceDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetGridViewPreference(string entityName)
        {
            var user_view = await _mediator.Send(new GetGridViewPreferenceQuery { entity_name = entityName });
            if (user_view != null)
            {
                ResponseBase<GridPreferenceDto> response = new ResponseBase<GridPreferenceDto>();
                response.Data = user_view;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }
        /// <summary>
        ///  API is For set Default Grid column Preference
        /// </summary>
        /// <param name="DefaultGridColumnSetReq">  Parameter for set Default grid column for entity</param>
        /// <returns></returns>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SetDefaultGridColumnPreference(DefaultGridColumnSetReq DefaultGridColumn)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool isUpdateSuccessful = await _mediator.Send(new SetDefaultGridPreferenceCommand { entity_name = DefaultGridColumn.entityName, view_column_json = DefaultGridColumn.viewColumnJson });
            if (isUpdateSuccessful)
            {
                response.Data = isUpdateSuccessful;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_SET_DEFAULT_COLUMN_SUCCESSFULLY");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_SET_DEFUALT_COLUMN_FAILURE");
            }
        }
        /// <summary>
        ///  API is For set Default Grid column Preference
        /// </summary>
        /// <param name="DefaultGridColumnFilterSetReq"> Parameter for set column filter for entity</param>
        /// <returns></returns>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SetDefaultGridFilterPreference(DefaultGridFilterSetReq DefaultGridFilter)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool isUpdateSuccessful = await _mediator.Send(new SetDefaultGridFilterPreferenceCommand { entity_name = DefaultGridFilter.entityName, view_column_json = DefaultGridFilter.viewColumnJson });
            if (isUpdateSuccessful)
            {
                response.Data = isUpdateSuccessful;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }
        #region API CONTRACT MODEL AND VALIDATORS
        public class DefaultGridColumnSetReq
        {
            public string entityName { get; set; }
            public string viewColumnJson { get; set; }

        }
        public class DefaultGridFilterSetReq
        {
            public string entityName { get; set; }
            public string viewColumnJson { get; set; }

        }
        public class DefaultGridColumnSetReqValidator : AbstractValidator<DefaultGridColumnSetReq>
        {
            public DefaultGridColumnSetReqValidator()
            {
                RuleFor(p => p.entityName).NotEmpty();
                RuleFor(p => p.viewColumnJson).NotEmpty();
            }
        }
        public class DefaultGridFilterSetReqValidator : AbstractValidator<DefaultGridColumnSetReq>
        {
            public DefaultGridFilterSetReqValidator()
            {
                RuleFor(p => p.entityName).NotEmpty();
                RuleFor(p => p.viewColumnJson).NotEmpty();
            }
        }
        #endregion

    }
}
