﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.EmailTemplate.Command;
using PARSNextGen.Application.EmailTemplate.Queries;
using PARSNextGen.Application.Service;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class EmailTemplateController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMessageService;

        public EmailTemplateController(IMediator mediator, ICustomMessageService customMessageService)
        {
            _mediator = mediator;
            _customMessageService = customMessageService;
        }
        #region API CONTROLLER METHODS

        #region API CONTROLLER FOR EMAIL-TEMPLATE

        /// <summary>
        /// 
        /// </summary>
        /// <returns> list of records..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<EmailTemplateListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEmailTemplateList()
        {
            ResponseBase<List<EmailTemplateListDto>> response = new ResponseBase<List<EmailTemplateListDto>>();
            var emailTemplateList = await _mediator.Send(new GetEmailTemplateListQuery { });
            if (emailTemplateList?.Count > 0)
            {
                response.Data = emailTemplateList;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// GetEmailTemplateDetails By id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Email Template Details</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<EmailTemplateDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEmailTemplateDetails(long id)
        {
            ResponseBase<EmailTemplateDetailsDto> response = new ResponseBase<EmailTemplateDetailsDto>();
            var emailTemplateDetails = await _mediator.Send(new GetEmailTemplateDetailsQuery { id = id });
            if (emailTemplateDetails != null)
            {
                response.Data = emailTemplateDetails;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns> list of records..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<TemplateTypeMasterListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetTemplateTypeMasterList()
        {
            ResponseBase<List<TemplateTypeMasterListDto>> response = new ResponseBase<List<TemplateTypeMasterListDto>>();
            var templateTypeList = await _mediator.Send(new TemplateTypeMasterListQuery { });
            if (templateTypeList != null)
            {
                List<TemplateTypeMasterListDto> list = new List<TemplateTypeMasterListDto>();
                list.Add(templateTypeList);
                response.Data = list;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// Create Email Template
        /// </summary>
        /// <returns> recorded created or not..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateEmailTemplate(CreateEmailTemplateReq createEmailTemplateReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new CreateEmailTemplateCommand { createEmailTemplateReq = createEmailTemplateReq });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        /// <summary>
        /// Update Email Template
        /// </summary>
        /// <returns> recorded update or not..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateEmailTemplate(UpdateEmailTemplateReq updateEmailTemplateReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateEmailTemplateCommand { updateEmailTemplateReq = updateEmailTemplateReq });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// Update Email Template
        /// </summary>
        /// <returns> recorded update or not..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateEmailTemplateStatus(UpdateEmailTemplateStatusReq updateEmailTemplateStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateEmailTemplateStatusCommand { id = updateEmailTemplateStatusReq.id, status = updateEmailTemplateStatusReq.status });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }



        #endregion END EMAIL-TEMPLATE API CONTROLLER

        #endregion API CONTROLLER METHODS

        #region API CONTRACT MODEL AND VALIDATORS

        public class UpdateEmailTemplateReqValidator : AbstractValidator<UpdateEmailTemplateReq>
        {
            public UpdateEmailTemplateReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }

        public class UpdateEmailTemplateStatusReq
        {
            public long id { get; set; }
            public bool status { get; set; }
        }
        public class UpdateEmailTemplateStatusReqValidator : AbstractValidator<UpdateEmailTemplateStatusReq>
        {
            public UpdateEmailTemplateStatusReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }
        #endregion
    }
}
