﻿using FluentValidation;
using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Account.Accounts.Command;
using PARSNextGen.Application.Account.Accounts.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.Vehicle.Vehicles.Queries;
using PARSNextGen.Application.VINValidation.Queries;
using PARSNextGen.Contracts;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static PARSNextGen.API.Controllers.AuthController;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class AccountController : Controller
    {
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;
        private readonly IConfiguration _config;
        private readonly ITemplateMapper _templateMapper;
        private readonly IBus _bus;
        public AccountController(IMediator mediator, ICustomMessageService customMsgSvc, IConfiguration configuration, ITemplateMapper templateMapper, IBus bus)
        {
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
            _config = configuration;
            _templateMapper = templateMapper;
            _bus = bus;
        }

        #region  API METHODS
        /// <summary>
        /// API to Get Account Master Data
        /// </summary>
        /// <returns> List of Account Master Data   </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<AccountMasterDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountMasterData(AccountMasterDataReq accountMasterDataReq)
        {
            ResponseBase<List<AccountMasterDto>> response = new ResponseBase<List<AccountMasterDto>>();
            var accountDetails = await _mediator.Send(new GetAccountMasterQuery { fmc_id = accountMasterDataReq.fmc_id });
            if (accountDetails != null)
            {
                List<AccountMasterDto> resp = new List<AccountMasterDto>();
                resp.Add(accountDetails);
                response.Data = resp;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// Get Account List
        /// <param name="accountTypeId, id"> id </param>
        /// </summary>
        /// <returns>GetAccountListDto</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAccountListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountsForParentAssignment(long accountTypeId, long id)
        {
            ResponseBase<List<GetAccountListDto>> response = new ResponseBase<List<GetAccountListDto>>();
            if (accountTypeId == (long)EnumTypes.AccountTypes.PARS)
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            var accountDetails = await _mediator.Send(new GetAccountListQuery { accountTypeId = accountTypeId, id = id });
            if (accountDetails != null)
            {
                response.Data = accountDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// Get Account User List For Switch Account.
        /// <param name="account_id"> account_id </param>
        /// </summary>
        /// <returns>GetAccountUserListForSwitchAccountDto</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAccountUserListForSwitchAccountDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountUserListForSwitchAccount(long account_id)
        {
            ResponseBase<List<GetAccountUserListForSwitchAccountDto>> response = new ResponseBase<List<GetAccountUserListForSwitchAccountDto>>();
            var UserList = await _mediator.Send(new GetAccountUserListForSwitchAccountQuery { account_id = account_id });
            if (UserList != null)
            {
                List<GetAccountUserListForSwitchAccountDto> resp = new List<GetAccountUserListForSwitchAccountDto>();
                response.Data = UserList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API get list of fmc regarding fleet
        /// <param name="accountId"> accountId </param>
        /// </summary>
        /// <returns> List of Fmc regarding fleet </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<FmcByFleetMasterDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFmcByFleetMaster(long accountId)
        {
            ResponseBase<List<FmcByFleetMasterDto>> response = new ResponseBase<List<FmcByFleetMasterDto>>();
            var parsFmc = await _mediator.Send(new GetFmcByFleetMaster { account_id = accountId });
            if (parsFmc.Count > 0)
            {
                response.Data = parsFmc;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API get list of fleet regarding fmc
        /// <param name="accountId"> accountId </param> 
        /// </summary>
        /// <returns> List of Fleet regarding fmc </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<FleetByFmcMasterDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFleetByFmcMaster(long accountId)
        {
            ResponseBase<List<FleetByFmcMasterDto>> response = new ResponseBase<List<FleetByFmcMasterDto>>();
            var parsFleet = await _mediator.Send(new GetFleetByFmcMaster { account_id = accountId });
            if (parsFleet.Count > 0)
            {
                response.Data = parsFleet;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API to Get Primary contac Master Data
        /// <param name="accountId"> accountId </param>
        /// </summary>
        /// <returns> List of Primary Account Master Data   </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<PrimaryContactMasterDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountContactMasterData(long accountId)
        {
            ResponseBase<List<PrimaryContactMasterDto>> response = new ResponseBase<List<PrimaryContactMasterDto>>();
            var contactDetails = await _mediator.Send(new GetPrimaryContactMasterQuery { account_id = accountId });
            if (contactDetails.Count > 0)
            {
                response.Data = contactDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API to Get Account Detail
        /// <param name="accountId"> accountId </param>
        /// </summary>
        /// <returns> List of account Detail according to account id(Account) </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<AccountDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountDetail(int accountId)
        {
            ResponseBase<AccountDetailsDto> response = new ResponseBase<AccountDetailsDto>();
            var accountDetails = await _mediator.Send(new GetAccountDetailsQuery { account_id = accountId });
            if (accountDetails != null)
            {
                response.Data = accountDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API to Get Account List for FMC
        /// </summary>
        /// <returns> List of account List according to filter </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<FMCFleet>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFMCFleet(AccountAdvancedFilter filter)
        {
            var response = new ResponseBase<FMCFleet>();

            var accountDetails = await _mediator.Send(new GetFMCFleetQuery { reqParm = filter });
            if (accountDetails.fMCFleets.Count > 0)
            {

                response.Data = accountDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = accountDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to Get Account List for  FLEET
        /// </summary>
        /// <returns> List of account List according to filter </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<FleetFMC>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFleetFMC(AccountAdvancedFilter filter)
        {
            var response = new ResponseBase<FleetFMC>();

            /*
            SearchFilter searchFilter = null;

            //Check if searchFilterJSON is null or empty
            //If yes call the query to get the default column and filter for the user/account type 
            if (string.IsNullOrEmpty(fleetFMCReq.searchFilterJson))
            {
                var userPreference = await _mediator.Send(new GetGridViewPreferenceQuery { entity_name = fleetFMCReq.entityName });
                if (userPreference != null)
                {
                    string json = userPreference.myview_filter;
                    searchFilter = JsonConvert.DeserializeObject<SearchFilter>(json);
                }
            }
            else // User has submitted a custom search filter input and wants to run a custom search
            {
                searchFilter = JsonConvert.DeserializeObject<SearchFilter>(fleetFMCReq.searchFilterJson);
            }

            */

            //var accountDetails = await _mediator.Send(new GetFleetFMCQuery {account_id = (long)fleetFMCReq.account_id,entity_name = fleetFMCReq.entityName,searchFilters = searchFilter,account_name = fleetFMCReq.accountName});
            var accountDetails = await _mediator.Send(new GetFleetFMCQuery { reqParm = filter });
            if (accountDetails.fMCFleets.Count > 0)
            {
                response.Data = accountDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = accountDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// Retrieve the account address stored in the account
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<AccountAddressDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountAddress(long accountId)
        {
            ResponseBase<List<AccountAddressDto>> response = new ResponseBase<List<AccountAddressDto>>();
            var accountAddress = await _mediator.Send(new GetAccountAddressQuery { account_id = accountId });
            if (accountAddress != null)
            {
                response.Data = accountAddress;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");

                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API gets Organization Accounts(including parent and child accounts) 
        /// </summary>
        /// <returns> Accounts list </returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<OrganizationAccountsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetOrganizationAccounts()
        {
            ResponseBase<List<OrganizationAccountsDto>> response = new ResponseBase<List<OrganizationAccountsDto>>();
            var organizationAccountsDtos = await _mediator.Send(new GetOrganizationAccountsQuery { });
            if (organizationAccountsDtos.Count > 0)
            {
                response.Data = organizationAccountsDtos;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API to Get FMC list for Pars from DB     
        /// </summary>
        /// <returns> List of FMC</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<ParsFMC>), StatusCodes.Status200OK)]
        //public async Task<IActionResult> GetParsFmc(string entityName, string searchFilterJson, string accountName)
        public async Task<IActionResult> GetParsFmc(AccountAdvancedFilter filter)
        {
            var response = new ResponseBase<ParsFMC>();

            /*
            SearchFilter searchFilter = null;
            //Check if searchFilterJSON is null or empty
            //If yes call the query to get the default column and filter for the user/account type 
            //if (string.IsNullOrEmpty(searchFilterJson))
            //{
            //    var userPreference = await _mediator.Send(new GetGridViewPreferenceQuery { entity_name = entityName });
            //    if (userPreference != null)
            //    {
            //        string json = userPreference.myview_filter;
            //        searchFilter = JsonConvert.DeserializeObject<SearchFilter>(json);
            //    }
            //    else
            //        throw new BusinessException("PARS_RECORD_NOT_FOUND");
            //}
            //else // User has submitted a custom search filter input and wants to run a custom search            
            //    searchFilter = JsonConvert.DeserializeObject<SearchFilter>(searchFilterJson);

            //var result = await _mediator.Send(new GetParsFMCQuery { entity_name = entityName, searchFilters = searchFilter, account_name = accountName });
            */
            var result = await _mediator.Send(new GetParsFMCQuery { reqParm = filter });
            if (result.fmcList.Count > 0)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to Get Fleet List for Pars
        /// </summary>
        /// <returns> List of fleet for pars </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<ParsFleet>), StatusCodes.Status200OK)]
        //public async Task<IActionResult> GetParsFleet(string entityName, string searchFilterJson, string accountName)
        public async Task<IActionResult> GetParsFleet(AccountAdvancedFilter filter)
        {
            var response = new ResponseBase<ParsFleet>();

            /*
               SearchFilter searchFilter = null;
               //Check if searchFilterJSON is null or empty
               //If yes call the query to get the default column and filter for the user/account type 
               if (string.IsNullOrEmpty(searchFilterJson))
               {
                   var userPreference = await _mediator.Send(new GetGridViewPreferenceQuery { entity_name = entityName });
                   if (userPreference != null)
                   {
                       string json = userPreference.myview_filter;
                       searchFilter = JsonConvert.DeserializeObject<SearchFilter>(json);
                   }
                   else
                       throw new BusinessException("PARS_RECORD_NOT_FOUND");
               }
               else // User has submitted a custom search filter input and wants to run a custom search            
                   searchFilter = JsonConvert.DeserializeObject<SearchFilter>(searchFilterJson);

             */

            //var parsFleet = await _mediator.Send(new GetParsFleetQuery { entity_name = entityName, searchFilters = searchFilter, account_name = accountName });
            var parsFleet = await _mediator.Send(new GetParsFleetQuery { reqParm = filter });
            if (parsFleet.fleetList.Count > 0)
            {
                response.Data = parsFleet;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = parsFleet;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to Customer Account_Mapped
        /// </summary>
        /// <param name="accountMappedReqDto"   
        /// <returns> true /false </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CustomerAccountMapped(List<CustomerAccountMappedReq> customerAccountMappedReq)
        {
            ResponseBase<bool> responseBase = new ResponseBase<bool>();
            bool result = await _mediator.Send(new CustomerAccountMappedCommand { linked_account_mapped = customerAccountMappedReq });
            if (result)
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(responseBase);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API to  Get Customer Fleet_Account_Mapped
        /// </summary>
        /// <param name="accountId"   
        /// <returns> FleetAccountMappedDto  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<FleetAccountMappedDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFleetAccountMapped(long accountId, long fmcId)
        {
            ResponseBase<List<FleetAccountMappedDto>> responseBase = new ResponseBase<List<FleetAccountMappedDto>>();
            var result = await _mediator.Send(new GetFleetAccountMappedQuery { account_id = accountId, fmc_id = fmcId });
            if (result is not null)
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(responseBase);
            }
            else
                throw new BusinessException("NO_UNMAPPED_FLEET_FOUND");
        }

        /// <summary>
        /// API to  Get Active Agreements
        /// </summary>
        /// <param name="fmcId"></param>   
        /// <param name="fleetId"></param>   
        /// <returns> ActiveAgreementsDto  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<AgreementsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetActiveAgreements(long currencyId)
        {
            ResponseBase<AgreementsDto> responseBase = new ResponseBase<AgreementsDto>();
            var result = await _mediator.Send(new GetActiveAgreementsQuery { currency_id = currencyId });
            if (result is not null)
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(responseBase);
            }
            else
                throw new BusinessException("PARS_RECORD_FOUND");
        }

        /// <summary>
        /// API to  price list By agreement id
        /// </summary>
        /// <param name="agreementId"></param>   
        /// <returns> PriceListByAgreementIdDto  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<ActivePriceListByAgreementIdDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetActivePriceListByAgreementId(long agreementId)
        {
            ResponseBase<List<ActivePriceListByAgreementIdDto>> responseBase = new ResponseBase<List<ActivePriceListByAgreementIdDto>>();
            var result = await _mediator.Send(new GetActivePriceListByAgreementIdQuery { agreement_id = agreementId });
            if (result is not null)
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(responseBase);
            }
            else
                throw new BusinessException("PARS_RECORD_FOUND");
        }

        /// <summary>
        /// API to  update account
        /// </summary>
        /// <param name="UpdateAccountReq"></param>   
        /// <returns> Bool  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<ActivePriceListByAgreementIdDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateFMCAccount(UpdateFMCAccountReq updateAccountReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            Tuple<bool, bool, bool> result = await _mediator.Send(new UpdateFMCAccountCommand { updateAccountReq = updateAccountReq });
            if (result.Item1)
            {
                response.Data = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_ACCOUNT_DUPLICATE_ENTRY");
                return new OkObjectResult(response);
            }
            if (result.Item2)
            {
                response.Data = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_USER_DUPLICATE_ENTRY");
                return new OkObjectResult(response);
            }
            if (result.Item3)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API to  update account
        /// </summary>
        /// <param name="UpdateAccountReq"></param>   
        /// <returns> Bool  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<ActivePriceListByAgreementIdDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateFleetAccount(UpdateFleetAccountReq updateAccountReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new UpdateFleetAccountCommand { updateAccountReq = updateAccountReq });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");
        }

        /// <summary>
        /// API to Get Parent Account
        /// </summary>
        /// <returns> List of Primary Account Master Data   </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<ParentAccountDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetParentAccountByAccountId(long accountId)
        {
            ResponseBase<List<ParentAccountDto>> response = new ResponseBase<List<ParentAccountDto>>();
            var parentAccounts = await _mediator.Send(new GetParentAccountQuery { account_id = accountId });
            if (parentAccounts.Count > 0)
            {
                response.Data = parentAccounts;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API to  update account financial detail
        /// </summary>
        /// <param name="UpdateAccountReq"></param>   
        /// <returns> Bool  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateAccountFinancialDetail(UpdateAccountFinancialDetailReq updateAccountFinancialDetailReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new UpdateAccountFinancialDetailCommand { updateAccountFinancialDetailReq = updateAccountFinancialDetailReq });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");
        }

        /// <summary>
        /// API to  create account
        /// </summary>
        /// <param name="CreateAccountReq"></param>   
        /// <returns> Bool  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> AddNewAccount(CreateAccountReq createAccountReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            Tuple<bool, bool, long> result = await _mediator.Send(new CreateAccountCommand { createAccountReq = createAccountReq });
            if (result.Item1)
            {
                response.Data = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_ACCOUNT_DUPLICATE_ENTRY");
                return new OkObjectResult(response);
            }
            if (result.Item2)
            {
                response.Data = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_USER_DUPLICATE_ENTRY");
                return new OkObjectResult(response);
            }
            if (result.Item3 > 0)
            {
                response.Data = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CREATION_FAILURE");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to  update account  detail
        /// </summary>
        /// <param name="UpdateAccountReq"></param>   
        /// <returns> Bool  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateAccount(UpdateAccountReq updateAccountReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            Tuple<bool, bool, bool> result = await _mediator.Send(new UpdateAccountCommand { updateAccountReq = updateAccountReq });
            if (result.Item1)
            {
                response.Data = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_ACCOUNT_DUPLICATE_ENTRY");
                return new OkObjectResult(response);
            }
            if (result.Item2)
            {
                response.Data = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_USER_DUPLICATE_ENTRY");
                return new OkObjectResult(response);
            }
            if (result.Item3)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API to  update account staus by id 
        /// </summary>
        /// <param name="UpdateAccountStatusReq"></param>   
        /// <returns> Bool  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateAccountStatus(UpdateAccountStatusReq updateAccountReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new UpdateAccountStatusCommand
            {
                id = updateAccountReq.id,
                status = updateAccountReq.status
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// Check Duplicate Fleet Number
        /// </summary>
        /// <param name="fleetNumber"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CheckDuplicateFleetNumber(string fleetNumber, long fmcId)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CheckDuplicateFleetNumberQuery { fleetNumber = fleetNumber, fmcId = fmcId });
            if (result)
            {
                response.Data = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("FLEET_NUMBER_ALREDY_EXIST");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = true;
                response.MessageDetail = null;
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API get list of fmc regarding fleet
        /// </summary>
        /// <returns> List of Fmc regarding fleet </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAccountListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountListByName(long accountTypeId, string searchFilter)
        {
            ResponseBase<List<GetAccountListDto>> response = new ResponseBase<List<GetAccountListDto>>();
            var parsFmc = await _mediator.Send(new GetAccountListByNameQuery { account_type_id = accountTypeId, searchFilter = searchFilter });
            if (parsFmc.Count > 0)
            {
                response.Data = parsFmc;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }
        #endregion  API METHODS

        #region **** APIs FOR ACCOUNT DOMAINS ****

        /// <summary>
        /// API to Post Domain
        /// </summary>
        /// <returns> Create Data Response  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateDomain(CreateDomainCommandDto createDomeinReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var createRecord = await _mediator.Send(new CreateDomainCommand { createDomainReq = createDomeinReq });
            if (createRecord.Item2)
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            else if (createRecord.Item1)
            {
                response.Data = createRecord.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");
        }

        /// <summary>
        /// API toUpdate Domain data
        /// </summary>
        /// <returns> id of record   </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateDomain(UpdateDomainRecordDto domainReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateDomainRecordCommand
            {
                id = domainReq.id,
                name = domainReq.name,
                description = domainReq.description,
                accountId = domainReq.account_id
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
        }

        /// <summary>
        /// API to UPdate Domain Status
        /// </summary>
        /// <returns>    </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateDomainStatus(UpdateDomainStatusDto updateDomainReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateDomainStatusCommand
            {
                id = updateDomainReq.id,
                is_active = updateDomainReq.is_active,
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API to Get All Domian List By Account Id
        /// </summary>
        /// <returns> List of Domain Data   </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<GetAllDomainListByAccountIdDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllDomainListByAccountId(long accountId)
        {
            ResponseBase<List<GetAllDomainListByAccountIdDto>> response = new ResponseBase<List<GetAllDomainListByAccountIdDto>>();
            var domainlist = await _mediator.Send(new GetAllDomainListByAccountIdQuery { account_id = accountId });
            if (domainlist?.Count > 0)
            {
                response.Data = domainlist;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = domainlist;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to Get  Domian  By Domain Id
        /// </summary>
        /// <returns> Domain Data  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<GetDomainByDomainIdDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetDomainByDomainId(long Id)
        {
            ResponseBase<List<GetDomainByDomainIdDto>> response = new ResponseBase<List<GetDomainByDomainIdDto>>();
            var accountDetails = await _mediator.Send(new GetDomainByDomainIdQuery { id = Id });
            if (accountDetails?.Count > 0)
            {
                List<GetDomainByDomainIdDto> resp = new List<GetDomainByDomainIdDto>();
                response.Data = accountDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }
        #endregion

        #region  API CONTROLLER FOR CONTACT PARS
        /// <summary>
        /// Create Customer Query
        /// </summary>
        /// <param name="createContactReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        /// 
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateCustomerQuery(CreateCustomerQueryReq createCustomerQueryReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateCostumerQueryCommand { contactUsQueryReq = createCustomerQueryReq });
            if (result != null)
            {
                #region SEND ALERT EMAIL TO PARS ADMIN
                CustomerNotificationEmail resetPasswordReq = new CustomerNotificationEmail();
                resetPasswordReq.full_name = createCustomerQueryReq.name;
                resetPasswordReq.email = createCustomerQueryReq.email;
                resetPasswordReq.description = createCustomerQueryReq.description;
                resetPasswordReq.base_url = _config["appSettings:WebAppBaseURI"];
                string queueName = _config["RabbitMQSettings:QueueName"];
                MergedContent emailTemplateContent = await _templateMapper.MergeTemplateByCode<CustomerNotificationEmail>("QUERY_EMAIL_TEMPLATE", resetPasswordReq);

                //Publish send email event for sending reset password link to user.
                SendEmail emailMessage = new SendEmail
                {
                    ToPartyEmails = new List<string>(new[] { GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.EmailPARSAdmin.PARSAdmin) }),
                    Subject = emailTemplateContent.subject,
                    MessageBody = emailTemplateContent.body_text,
                    IsMessageHTML = emailTemplateContent.body_text.EndsWith("</html>", StringComparison.OrdinalIgnoreCase),
                    EntityId = result,
                    EntitName = "queries"
                };
                await _bus.Publish(emailMessage);
                //var endpoint = await _bus.GetSendEndpoint(new Uri("queue:" + queueName));
                //await endpoint.Send(emailMessage);
                #endregion

                response.Data = true;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");
        }

        /// <summary>
        /// Update Customer Query Status
        /// </summary>
        /// <param name="updateContactUsQueryStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateCustomerQueryStatus(UpdateCustomerQueryStatusReq updateContactUsQueryStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateCustomerQueryStatusCommand { updateCustomerQueryStatusReq = updateContactUsQueryStatusReq });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// Get Customer Query List 
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<GetCustomerQueriesListDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCustomerQueryList(long id)
        {
            ResponseBase<List<GetCustomerQueriesListDto>> response = new ResponseBase<List<GetCustomerQueriesListDto>>();
            List<GetCustomerQueriesListDto> result = await _mediator.Send(new GetCustomerQueryListQuery { id = id });
            if (result.Count > 0)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }
        #endregion

        #region API VALIDATIONS
        public class UpdateAccountReqValidator : AbstractValidator<UpdateFMCAccountReq>
        {
            public UpdateAccountReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }
        public class FMCFleetReq
        {
            public long? account_id { get; set; }
            public string entityName { get; set; }
            public string searchFilterJson { get; set; }
            public string fleet_no { get; set; }
            public string accountName { get; set; }
        }
        public class FMCFleetReqValidator : AbstractValidator<FMCFleetReq>
        {
            public FMCFleetReqValidator()
            {
                RuleFor(p => p.account_id).NotNull().WithMessage("FMC id shouldn't be null.");
            }
        }
        public class FleetFMCReq
        {
            public long? account_id { get; set; }
            public string entityName { get; set; }
            public string accountName { get; set; }
            public string searchFilterJson { get; set; }
        }
        public class FleetFMCReqValidator : AbstractValidator<FleetFMCReq>
        {
            public FleetFMCReqValidator()
            {
                RuleFor(p => p.account_id).NotNull().WithMessage("Account id shouldn't be null.");
            }
        }
        public class UpdateContactParsStatusReqValidator : AbstractValidator<UpdateCustomerQueryStatusReq>
        {
            public UpdateContactParsStatusReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }
        public class UpdateAccountsReqValidator : AbstractValidator<UpdateAccountReq>
        {
            public UpdateAccountsReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }
        public class UpdateAccountStatusReq
        {
            public long id { get; set; }
            public bool status { get; set; }
        }
        public class UpdateAccountStatusReqValidator : AbstractValidator<UpdateAccountStatusReq>
        {
            public UpdateAccountStatusReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }
        public class CreateAccountReqValidator : AbstractValidator<CreateAccountReq>
        {
            public CreateAccountReqValidator()
            {
                RuleFor(p => p.account_name).NotNull().WithMessage("Account name shouldn't be null.");
            }
        }
        public class AccountMasterDataReq
        {
            public long? fmc_id { get; set; }
        }
        #endregion
    }
}


