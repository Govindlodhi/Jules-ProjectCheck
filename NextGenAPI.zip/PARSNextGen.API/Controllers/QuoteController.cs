﻿using CRMSyncServices.Application.CQRS.PickupSurvey.Queries;
using Dapper;
using FluentValidation;
using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Calculation.Queries;
using PARSNextGen.Application.Preference.Preference.Queries;
using PARSNextGen.Application.Preference.RuleEditor.Queries;
using PARSNextGen.Application.Quotes.AdvanceQuote.Command;
using PARSNextGen.Application.Quotes.AdvanceQuote.Queries;
using PARSNextGen.Application.Quotes.ConvertQuoteRequestToServiceRequest.Command;
using PARSNextGen.Application.Quotes.CopyQuote.Command;
using PARSNextGen.Application.Quotes.QuickQuote.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.ServiceRequest.Command;
using PARSNextGen.Application.ServiceRequest.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Storage.GetStorage.GetStorageDetails.Queries;
using PARSNextGen.Application.User.UserViewPreference.Queries;
using PARSNextGen.Application.Vehicle.VehicleDetail.Queries;
using PARSNextGen.Contracts;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using static PARSNextGen.API.Controllers.AuthController;
using static PARSNextGen.Domain.Common.EnumTypes;
using Formatting = Newtonsoft.Json.Formatting;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class QuoteController : Controller
    {
        private readonly ILogger<QuoteController> _logger;
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;
        private readonly IConfiguration _config;
        private readonly IAzureMapService _azureMapService;
        private readonly ITemplateMapper _templateMapper;
        private readonly IBus _bus;
        private readonly ISqlContext _sqlContext;
        private readonly IHostEnvironment _hostingEnvironment;
        public QuoteController(IMediator mediator, ILogger<QuoteController> logger, ICustomMessageService customMsgSvc,
            IConfiguration config, IAzureMapService azureMapService, ITemplateMapper templateMapper, IBus bus,
            ISqlContext sqlContext, IHostEnvironment hostingEnvironment)
        {
            _logger = logger;
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
            _config = config;
            _azureMapService = azureMapService;
            _templateMapper = templateMapper;
            _bus = bus;
            _sqlContext = sqlContext;
            _hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        /// This API gets list of master data.
        /// </summary>
        /// <returns> List of  MasterData  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<QouteRequestMasterDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetRequestMasterData()
        {
            var response = new ResponseBase<QouteRequestMasterDto>();
            var result = await _mediator.Send(new GetRequestMasterDataQuery { });
            if (result != null)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// </summary>
        /// <returns> List of quote for fleet/fmc according to account_type_id</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<QuoteList>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetQuoteList(long moveType, long statusReason, string entityName, string searchFilterJson)
        {
            var response = new ResponseBase<QuoteList>();
            SearchFilter searchFilter = null;
            //Check if searchFilterJSON is null or empty 
            //If yes call the query to get the default column and filter for the user/account type 
            if (string.IsNullOrEmpty(searchFilterJson))
            {
                var userPreference = await _mediator.Send(new GetGridViewPreferenceQuery { entity_name = entityName });
                if (userPreference != null)
                {
                    string json = userPreference.myview_filter;
                    searchFilter = JsonConvert.DeserializeObject<SearchFilter>(json);
                }
                else
                {
                    throw new BusinessException("PARS_RECORD_NOT_FOUND");
                }
            }
            else // User has submitted a custom search filter input and wants to run a custom search
            {
                searchFilter = JsonConvert.DeserializeObject<SearchFilter>(searchFilterJson);
            }
            var quoteFleet = await _mediator.Send(new GetQuoteListQuery
            {
                move_type = moveType,
                status_reason = statusReason,
                entity_name = entityName,
                searchFilters = searchFilter
            });
            if (quoteFleet.totalCount > 0)
            {
                response.Data = quoteFleet;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API Get Quote Detail
        /// </summary>
        /// /// <param name="id">Quote Id</param>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<QuoteDetailDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetQuoteDetail(long id)
        {
            ResponseBase<List<QuoteDetailDto>> response = new ResponseBase<List<QuoteDetailDto>>();
            var QuoteDetail = await _mediator.Send(new GetQuoteDetailQuery { id = id });
            if (QuoteDetail.Count > 0)
            {
                response.Data = QuoteDetail;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API Create Quote  
        /// </summary>
        /// <returns> true/false</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateQuote(List<CreateQuoteReq> quoteReq)
        {
            ResponseBase<bool> responseBase = new ResponseBase<bool>();
            bool quote = (bool)await _mediator.Send(new CreateQuoteCommand { createQuoteReq = quoteReq });
            if (quote)
            {
                responseBase.Data = true;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(responseBase);
            }
            else
            {
                responseBase.Data = false;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CREATION_FAILURE");
                return new OkObjectResult(responseBase);
            }
        }

        /// <summary>
        /// Update Quote
        /// </summary>
        /// <returns> true/false</returns>
        /// <exception cref="BusinessException"></exception>
        ///    
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateQuote(List<UpdateQuoteReq> updateQuoteReq)
        {
            ResponseBase<bool> responseBase = new ResponseBase<bool>();
            bool quote = await _mediator.Send(new UpdateQuoteCommand { updateQuoteReq = updateQuoteReq });
            if (quote)
            {
                responseBase.Data = true;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(responseBase);
            }
            else
            {
                responseBase.Data = false;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_UPDATION_FAILURE");
                return new OkObjectResult(responseBase);
            }
        }

        /// <summary>
        /// API Calculate Quick Quote  
        /// </summary>
        /// <returns> true/false</returns>
        /// <exception cref="BusinessException"></exception>
        ///    
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<CalculationResponseDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CalculateQuickQuote(CalculateQuickQuoteReq calculateQuickQuoteReq)
        {
            ResponseBase<CalculationResponseDto> responseBase = new ResponseBase<CalculationResponseDto>();

            #region Get related agreement
            //var agreement_id = await _mediator.Send(new GetAgreementQuery { fmc_id = calculateQuickQuoteReq.fmc_id, fleet_id = calculateQuickQuoteReq.fleet_id });
            //if (agreement_id == null)
            //    throw new BusinessException("PARS_AGREEMENT_NOT_FOUND");
            //#endregion End

            //#region Get related price list
            //long? price_list_id = null;
            //var price_list = await _mediator.Send(new GetActivePriceListByAgreementIdQuery { agreement_id = (long)agreement_id });
            //if (price_list == null)
            //    throw new BusinessException("PARS_PRICELIST_NOT_FOUND");
            //int i = 0;
            //foreach (var pricelistObj in price_list)
            //{
            //    if (i == 0)
            //    {
            //        price_list_id = pricelistObj.id;
            //        i++;
            //    }
            //}
            #endregion End

            #region Get Distance betweeen pickup and delivery

            string pick_lat = string.Empty;
            string pick_lon = string.Empty;
            string del_lat = string.Empty;
            string del_lon = string.Empty;
            long? location1_country_id = null;
            long? location2_country_id = null;
            //Get latitude and longitude for Pickup address

            ZipCodeAddressReq pick_postal_code = new ZipCodeAddressReq();
            pick_postal_code.postalCode = calculateQuickQuoteReq.pick_postal_code;
            var addressRes = await _azureMapService.GetByZipCodeAddress(pick_postal_code);
            if (addressRes != null)
            {
                if (addressRes.lat != null || addressRes.lon != null)
                {
                    pick_lat = addressRes.lat;
                    pick_lon = addressRes.lon;
                    if (addressRes.country != null && (addressRes.country.ToUpper() == "USA" || addressRes.country.ToUpper() == "UNITED STATES" || addressRes.country == "Unated States"))
                        location1_country_id = (long)EnumTypes.Country.United_States;

                    if (addressRes.country != null && (addressRes.country.ToUpper() == "CANADA" || addressRes.country.ToLower() == "canada" || addressRes.country == "Canada"))
                        location1_country_id = (long)EnumTypes.Country.Canada;
                }
                else
                {
                    throw new BusinessException("PARS_PICKUP_COORDINATE_NOT_FOUND");
                }
            }
            else
            {
                throw new BusinessException("PARS_PICKUP_COORDINATE_NOT_FOUND");
            }

            if (calculateQuickQuoteReq.del_storage_id == null)
            {
                //Get latitude and longitude for Delivery address
                ZipCodeAddressReq del_postal_code = new ZipCodeAddressReq();
                del_postal_code.postalCode = calculateQuickQuoteReq.del_postal_code;
                var addressRes1 = await _azureMapService.GetByZipCodeAddress(del_postal_code);
                if (addressRes1 != null)
                {
                    if (addressRes1.lat != null || addressRes1.lon != null)
                    {
                        del_lat = addressRes1.lat;
                        del_lon = addressRes1.lon;

                        if (addressRes1.country == null || addressRes1.country.ToUpper() == "USA" || addressRes1.country.ToUpper() == "UNITED STATES" || addressRes1.country == "Unated States")
                            location2_country_id = (long)EnumTypes.Country.United_States;
                        if (addressRes1.country != null && addressRes1.country.ToUpper() == "CANADA" && addressRes1.country.ToLower() == "canada")
                            location2_country_id = (long)EnumTypes.Country.Canada;
                    }
                    else
                    {
                        throw new BusinessException("PARS_DELIVERY_COORDINATE_NOT_FOUND");
                    }
                }
                else
                {
                    throw new BusinessException("PARS_DELIVERY_COORDINATE_NOT_FOUND");
                }
            }
            else
            {
                //long parsStorageId = 7;
                var storagedetail = await _mediator.Send(new GetStorageDetailQuery { id = (long)calculateQuickQuoteReq.del_storage_id });
                if (storagedetail != null)
                {
                    del_lat = storagedetail.latitude.ToString();
                    del_lon = storagedetail.longitude.ToString();
                    location2_country_id = storagedetail.country_id;
                }
                else
                {
                    throw new BusinessException("PARS_DELIVERY_COORDINATE_NOT_FOUND");
                }
            }
            string coordinate = string.Format("{0},{1}:{2},{3}", pick_lat.ToString(CultureInfo.InvariantCulture), pick_lon.ToString(CultureInfo.InvariantCulture), del_lat.ToString(CultureInfo.InvariantCulture), del_lon.ToString(CultureInfo.InvariantCulture));
            //Get Distance between pickup and delivery
            var routeLengthResponse = await _azureMapService.CalculateDistanceBetweenCoordinates(coordinate);
            if (routeLengthResponse == null)
                throw new Exception("PARS_NO_ROUTE_FOUND");

            #endregion End Distance

            #region get default services
            PreferenceReq preferenceReq = new PreferenceReq();
            preferenceReq.agreement_id = calculateQuickQuoteReq.agreement_id;
            preferenceReq.category_id = (long)EnumTypes.Category_Types.service_request;
            preferenceReq.event_type_id = (long)EnumTypes.Event_Type.new_service_request;
            preferenceReq.rule_type_id = (long)EnumTypes.Rule_Type.Evaluation;
            preferenceReq.crm_service_list = null;
            preferenceReq.isElectricVehicle = false;

            var servicesListReq = await _mediator.Send(new GetPreferencesListQuery { preferenceReq = preferenceReq });

            Application.Utility.Preference.Models.service_request sr_request = new Application.Utility.Preference.Models.service_request();
            sr_request.vehicle_type = (int)calculateQuickQuoteReq.vehicle_type_id;
            sr_request.primary_fuel_type = (int)calculateQuickQuoteReq.primary_fuel_type_id;
            sr_request.fuel_type = (int)calculateQuickQuoteReq.fuel_type_id;
            sr_request.transportation_type_id = (int)calculateQuickQuoteReq.transportation_type_id;
            sr_request.pickup_address_type = (int)EnumTypes.address_type.Residence;
            sr_request.delivery_address_type = (int)calculateQuickQuoteReq.del_address_type;

            foreach (var item in servicesListReq)
            {
                if (item.category_id == (long)Category_Types.service_request)
                {
                    item.modelJson = JsonConvert.SerializeObject(sr_request);
                    item.price_list_id = calculateQuickQuoteReq.price_list_id;
                }
            }

            var jsonResults = await _mediator.Send(new EvaluateRulesQuery { preferencesListReq = servicesListReq });
            var applicableServices = await _mediator.Send(new GetDefaultServicesQuery { jsonResults = jsonResults, price_list_id = calculateQuickQuoteReq.price_list_id, agreement_id = calculateQuickQuoteReq.agreement_id, rule_type_id = preferenceReq.rule_type_id, service_standard = (long)EnumTypes.Service_Standard.Standard });

            PriceCalculationReq priceCalculationReq = new PriceCalculationReq();
            priceCalculationReq.transportation_type_id = calculateQuickQuoteReq.transportation_type_id;//1;


            //primary fuel type mapping in case manually selection, fuel type
            if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Gasoline)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Electric)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Electric;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Diesel)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Diesel;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Compressed_Hydrogen)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Compressed_Hydrogen;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Compressed_Natural_Gas)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Compressed_Natural_Gas;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.FuelCell)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.FuelCell;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Liquefied_Natural_Gas)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Liquefied_Natural_Gas;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Liquefied_Petroleum_Gas)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Liquefied_Petroleum_Gas;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Methanol)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Methanol;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Natural_Gas)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Natural_Gas;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Neat_Ethanol)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Neat_Ethanol;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)EnumTypes.NHTSAFuelType.Neat_Methanol)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Neat_Methanol;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)NHTSAFuelType.Hybrid)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
            }
            else if (calculateQuickQuoteReq.fuel_type_id == (long)NHTSAFuelType.PH_EV)
            {
                priceCalculationReq.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Electric;
            }
            priceCalculationReq.fuel_type_id = calculateQuickQuoteReq.fuel_type_id;//2;
            //priceCalculationReq.primary_fuel_type_id = calculateQuickQuoteReq.fuel_type_id;//2;
            priceCalculationReq.fleet_id = calculateQuickQuoteReq.fleet_id;//2;
            priceCalculationReq.fmc_id = calculateQuickQuoteReq.fmc_id;// 2;
            priceCalculationReq.price_list_id = calculateQuickQuoteReq.price_list_id;// 2;
            priceCalculationReq.agreement_id = calculateQuickQuoteReq.agreement_id; ;// 2;
            priceCalculationReq.vehicle_type_id = calculateQuickQuoteReq.vehicle_type_id;// 2;
            priceCalculationReq.pick_postal_code = calculateQuickQuoteReq.pick_postal_code;// "47427";
            priceCalculationReq.del_postal_code = calculateQuickQuoteReq.del_postal_code;// "30008";
            priceCalculationReq.pickup_storage_id = calculateQuickQuoteReq.pick_storage_id;// "30008";
            priceCalculationReq.delivery_storage_id = calculateQuickQuoteReq.del_storage_id;// "30008";
            //priceCalculationReq.distance = calculateQuickQuoteReq.distance;
            if (routeLengthResponse != null)
                priceCalculationReq.distance = routeLengthResponse.distance;

            priceCalculationReq.distance = routeLengthResponse.distance;
            priceCalculationReq.location1_country_id = location1_country_id;
            priceCalculationReq.location2_country_id = location2_country_id;

            priceCalculationReq.pickup_latitude = pick_lat;
            priceCalculationReq.pickup_longitude = pick_lon;
            priceCalculationReq.delivery_latitude = del_lat;
            priceCalculationReq.delivery_longitude = del_lon;

            priceCalculationReq.servicereqs = new List<ApplicableServiceDto>();
            // Remove Drive Away Tariff -38 
            int index = applicableServices.FindIndex(x => x.service_id == (int)EnumTypes.transportation_type.Driveaway);
            if (index > 0)
                applicableServices.RemoveAt(index);
            //Auto Carrier Tariff -39
            index = applicableServices.FindIndex(x => x.service_id == (int)EnumTypes.transportation_type.Auto_Carrier);
            if (index > 0)
                applicableServices.RemoveAt(index);

            priceCalculationReq.servicereqs = applicableServices;

            #region Rate Type - Calculated
            //ApplicableServiceDto serviceReq = new ApplicableServiceDto();
            //serviceReq.id = 1; serviceReq.rate_type_id = 1; serviceReq.per_mile_rate = 10; serviceReq.flat_rate = 10; serviceReq.actual_rate = 10; serviceReq.fuel_surcharge_rate = 10; serviceReq.fuel_surcharge_amount = 10; serviceReq.surcharge_type_id = 1; serviceReq.surcharge_amount = 10; serviceReq.markup_type_id = 1; serviceReq.markup_number = 10; serviceReq.discount_type_id = 1; serviceReq.discount_rate = 10; serviceReq.rebate_type_id = 1; serviceReq.rebate_rate = 10;
            //priceCalculationReq.servicereqs.Add(serviceReq);

            #endregion

            #region Rate Type - Actual
            //ApplicableServiceDto serviceReqActual = new ApplicableServiceDto();
            //serviceReqActual.id = 2; serviceReqActual.rate_type_id = 5; serviceReqActual.per_mile_rate = 10; serviceReqActual.flat_rate = 10; serviceReqActual.actual_rate = 10; serviceReqActual.fuel_surcharge_rate = 10; serviceReqActual.fuel_surcharge_amount = 10; serviceReqActual.surcharge_type_id = 1; serviceReqActual.surcharge_amount = 10; serviceReqActual.markup_type_id = 1; serviceReqActual.markup_number = 10; serviceReqActual.discount_type_id = 1; serviceReqActual.discount_rate = 10; serviceReqActual.rebate_type_id = 1; serviceReqActual.rebate_rate = 10;
            //priceCalculationReq.servicereqs.Add(serviceReqActual);
            #endregion

            #region Rate Type - Per Mile
            //ApplicableServiceDto serviceReqPerMile = new ApplicableServiceDto();
            //serviceReqPerMile.id = 3; serviceReqPerMile.rate_type_id = 3; serviceReqPerMile.per_mile_rate = 10; serviceReqPerMile.flat_rate = 10; serviceReqPerMile.actual_rate = 10; serviceReqPerMile.fuel_surcharge_rate = 10; serviceReqPerMile.fuel_surcharge_amount = 10; serviceReqPerMile.surcharge_type_id = 1; serviceReqPerMile.surcharge_amount = 10; serviceReqPerMile.markup_type_id = 1; serviceReqPerMile.markup_number = 10; serviceReqPerMile.discount_type_id = 1; serviceReqPerMile.discount_rate = 10; serviceReqPerMile.rebate_type_id = 1; serviceReqPerMile.rebate_rate = 10;
            //priceCalculationReq.servicereqs.Add(serviceReqPerMile);
            #endregion

            #endregion end

            #region get calculate price
            var response = await _mediator.Send(new PriceCalculationQuery { priceCalculationReq = priceCalculationReq });
            #endregion end calculate price

            if (response != null)
            {
                responseBase.Data = response;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_PRICE_CALCULATED_SUCCESSFULL");
                return new OkObjectResult(responseBase);
            }
            else
            {
                responseBase.Data = response;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CALCULATION_FAILURE");
                return new OkObjectResult(responseBase);
            }
        }

        /// <summary>
        /// Method for Get Applicable Services List
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<ApplicableServiceDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetApplicableServicesList(QuoteRequestServiceReq quoteRequestServiceReq)
        {
            ResponseBase<List<ApplicableServiceDto>> response = new ResponseBase<List<ApplicableServiceDto>>();
            List<ApplicableServiceDto> applicableServiceList = new List<ApplicableServiceDto>();
            #region get default services
            PreferenceReq preferenceReq = new PreferenceReq();
            preferenceReq.agreement_id = quoteRequestServiceReq.agreement_id;
            preferenceReq.category_id = (long)EnumTypes.Category_Types.service_request;
            preferenceReq.event_type_id = quoteRequestServiceReq.event_type_id;
            preferenceReq.rule_type_id = (long)EnumTypes.Rule_Type.Evaluation;
            var servicesListReq = await _mediator.Send(new GetPreferencesListQuery { preferenceReq = preferenceReq });

            #region RequestModel 

            Application.Utility.Preference.Models.service_request sr_request = new Application.Utility.Preference.Models.service_request();
            sr_request.vehicle_type = (int)quoteRequestServiceReq.vehicle_type_id;
            sr_request.primary_fuel_type = (int)quoteRequestServiceReq.primary_fuel_type_id;
            sr_request.fuel_type = (int)quoteRequestServiceReq.fuel_type_id;

            if (quoteRequestServiceReq.transportation_type_id == (long)EnumTypes.transportation_type.Auto_Carrier)
                sr_request.transportation_type_id = (int)EnumTypes.transportation_type.Auto_Carrier;
            else
                sr_request.transportation_type_id = (int)EnumTypes.transportation_type.Driveaway;

            sr_request.retail = quoteRequestServiceReq.retail;
            if (quoteRequestServiceReq.location1_address_type_id != null)
                sr_request.pickup_address_type = (int)quoteRequestServiceReq.location1_address_type_id;

            sr_request.is_verify_pickup_city = quoteRequestServiceReq.is_verify_location1_city;

            if (quoteRequestServiceReq.location1_state_id != null)
                sr_request.pickup_state = (int)quoteRequestServiceReq.location1_state_id;
            sr_request.is_verify_pickup_state = quoteRequestServiceReq.is_verify_location1_state;
            sr_request.pickup_postal_code = quoteRequestServiceReq.location1_postal_code;
            sr_request.is_verify_pickup_postal_code = quoteRequestServiceReq.is_verify_location1_postal_code;

            if (quoteRequestServiceReq.location1_country_id != null)
                sr_request.pickup_country = (int)quoteRequestServiceReq.location1_country_id;

            sr_request.is_verify_pickup_country = quoteRequestServiceReq.is_verify_location1_country;

            if (quoteRequestServiceReq.location1_storage_id != null)
                sr_request.pickup_storage = (int)quoteRequestServiceReq.location1_storage_id;

            sr_request.has_pickup_date_constraints = quoteRequestServiceReq.has_location1_date_constraints;

            if (quoteRequestServiceReq.location1_date_constraint_type_id != null)
                sr_request.pickup_date_constraint_type_id = (int)quoteRequestServiceReq.location1_date_constraint_type_id;
            //sr_request.requested_pickup_date = quoteRequestServiceReq.requested_pickup_date;

            if (quoteRequestServiceReq.location2_address_type_id != null)
                sr_request.delivery_address_type = (int)quoteRequestServiceReq.location2_address_type_id;
            sr_request.is_verify_delivery_city = quoteRequestServiceReq.is_verify_location2_city;

            if (quoteRequestServiceReq.location2_state_id != null)
                sr_request.delivery_state = (int)quoteRequestServiceReq.location2_state_id;
            sr_request.is_verify_delivery_state = quoteRequestServiceReq.is_verify_location2_state;
            sr_request.delivery_postal_code = quoteRequestServiceReq.location2_postal_code;
            sr_request.is_verify_delivery_postal_code = quoteRequestServiceReq.is_verify_location2_postal_code;

            if (quoteRequestServiceReq.location2_country_id != null)
                sr_request.delivery_country = (int)quoteRequestServiceReq.location2_country_id;
            sr_request.is_verify_delivery_country = quoteRequestServiceReq.is_verify_location2_country;

            if (quoteRequestServiceReq.location2_storage_id != null)
                sr_request.delivery_storage = (int)quoteRequestServiceReq.location2_storage_id;
            sr_request.has_delivery_date_constraints = quoteRequestServiceReq.has_location2_date_constraints;

            if (quoteRequestServiceReq.location2_date_constraints_type_id != null)
                sr_request.delivery_date_constraints_type = (int)quoteRequestServiceReq.location2_date_constraints_type_id;


            if (quoteRequestServiceReq.bill_to != null)
                sr_request.bill_to = (int)quoteRequestServiceReq.bill_to;
            sr_request.pickup_is_vip_contact = quoteRequestServiceReq.location1_is_vip_contact;

            if (quoteRequestServiceReq.location1_time_zone_id != null)
                sr_request.pickup_time_zone = (int)quoteRequestServiceReq.location1_time_zone_id;
            sr_request.has_pickup_sensitivities = quoteRequestServiceReq.has_location1_sensitivities;
            //sr_request.pickup_date_sensitivities = quoteRequestServiceReq.pickup_date_sensitivities;

            if (quoteRequestServiceReq.location1_sensitivity_type_id != null)
                sr_request.pickup_sensitivity_type = (int)quoteRequestServiceReq.location1_sensitivity_type_id;
            sr_request.delivery_is_vip_contact = quoteRequestServiceReq.location2_is_vip_contact;

            if (quoteRequestServiceReq.location2_time_zone_id != null)
                sr_request.delivery_time_zone = (int)quoteRequestServiceReq.location2_time_zone_id;
            sr_request.has_delivery_sensitivities = quoteRequestServiceReq.has_location2_sensitivities;
            //sr_request.delivery_date_sensitivities = (int)quoteRequestServiceReq.vehicle_type_id;

            if (quoteRequestServiceReq.location2_sensitivity_type_id != null)
                sr_request.delivery_sensitivity_type = (int)quoteRequestServiceReq.location2_sensitivity_type_id;

            sr_request.can_pars_issue_a_temp_tag = quoteRequestServiceReq.can_pars_issue_a_temp_tag;
            sr_request.is_inspection_be_needed = quoteRequestServiceReq.is_inspection_be_needed;
            sr_request.do_not_complete_inspection_if_required = quoteRequestServiceReq.do_not_complete_inspection_if_required;
            sr_request.pickup_towing_required = quoteRequestServiceReq.location1_towing_required;
            sr_request.vehicle_repossession_required = quoteRequestServiceReq.vehicle_repossession_required;
            sr_request.is_vehicle_at_impound = quoteRequestServiceReq.is_vehicle_at_impound;
            #endregion

            #region VEHICLE PLATE STATUS
            sr_request.is_new_vehicle_never_registered = false;
            sr_request.plates_are_expired_or_misplaced = false;
            sr_request.do_you_want_pars_to_handle_t_n_r = false;
            sr_request.is_pars_to_issue_a_temp_tag = false;
            sr_request.is_renewal = false;
            sr_request.is_transfer = false;
            sr_request.is_new_vehicle_never_registered = false;
            sr_request.is_plate_replacement = false;

            if (quoteRequestServiceReq.event_type_id == (long)EnumTypes.Event_Type.t_n_r_preferences)
            {
                #region REMOVE T&R REALTED SERVICES

                // Remove Initial_T_and_R -27 
                int? index = null;
                index = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Initial_T_and_R);
                if (index != null && index != -1)
                {
                    quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)index);
                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Initial_T_and_R);
                }

                //Remove Shipping_Handling_Fee
                index = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Shipping_Handling_Fee);
                if (index != null && index != -1)
                {
                    // quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)index);
                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => (x.service_id == (long)EnumTypes.Service.Shipping_Handling_Fee && x.dependent_service_id == null));
                }

                //Remove Tags_30_Day_Temp
                index = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Tags_30_Day_Temp);
                if (index != null && index != -1)
                {
                    quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)index);
                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Tags_30_Day_Temp);
                }

                //Remove Registration_Renewal
                index = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Registration_Renewal);
                if (index != null && index != -1)
                {
                    // quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)index);
                    quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)index);
                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Registration_Renewal);
                }

                //Remove Transfer
                index = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Transfer);
                if (index != null && index != -1)
                {
                    quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)index);
                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Transfer);
                    //quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)index);
                }

                //Remove Plate Replacement
                index = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Plate_Replacement);
                if (index != null && index != -1)
                {
                    // quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)index);
                    quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)index);
                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Plate_Replacement);
                }
                #endregion

                #region T&R Related Fields
                // serviceOrder.does_the_vehicle_have_current_registration = req.does_the_vehicle_have_current_registration;
                //serviceOrder.do_you_want_pars_to_handle_t_n_r = null;
                //serviceOrder.will_you_send_the_plates_to_fleet_driver = null;
                //serviceOrder.is_pars_to_issue_a_temp_tag = null;
                //serviceOrder.new_vehicle_never_registered = null;
                //serviceOrder.do_you_want_pars_to_delay_delivery = null;
                //serviceOrder.requested_t_n_r_service_type_id = null;

                if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.Yes)
                {
                    if (quoteRequestServiceReq.new_vehicle_never_registered == null)
                    {
                        // applicableServiceList = request.applicableServiceDto;
                        applicableServiceList = quoteRequestServiceReq.applicableServiceDto;
                        response.Data = applicableServiceList;
                        response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                        return new OkObjectResult(response);
                    }
                    else if (!(bool)quoteRequestServiceReq.new_vehicle_never_registered)
                    {
                        sr_request.is_renewal = false;
                        sr_request.is_transfer = false;
                        sr_request.is_new_vehicle_never_registered = false;
                        sr_request.is_plate_replacement = false;
                        sr_request.plates_are_expired_or_misplaced = true;
                        //Pars to handle = Yes 
                        if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                        {
                            if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                            {
                                sr_request.do_you_want_pars_to_handle_t_n_r = true;
                                if (quoteRequestServiceReq.requested_t_n_r_service_type_id != null)
                                {
                                    if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Renewal)
                                    {
                                        sr_request.is_renewal = true;
                                        sr_request.is_transfer = false;
                                        sr_request.is_new_vehicle_never_registered = false;
                                        sr_request.is_plate_replacement = false;
                                    }
                                    else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Replacenent)
                                    {
                                        sr_request.is_renewal = false;
                                        sr_request.is_transfer = false;
                                        sr_request.is_new_vehicle_never_registered = false;
                                        sr_request.is_plate_replacement = true;
                                    }
                                    else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Transfer)
                                    {
                                        sr_request.is_renewal = false;
                                        sr_request.is_transfer = true;
                                        sr_request.is_new_vehicle_never_registered = false;
                                        sr_request.is_plate_replacement = false;
                                    }
                                }

                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                {
                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                }
                            }
                            else
                            {
                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                {
                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                }
                            }
                        }
                    }
                }
                else if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.No)
                {
                    sr_request.is_renewal = false;
                    sr_request.is_transfer = false;
                    sr_request.is_new_vehicle_never_registered = false;
                    sr_request.is_plate_replacement = false;

                    if (quoteRequestServiceReq.new_vehicle_never_registered == null)
                    {
                        // applicableServiceList = request.applicableServiceDto;
                        applicableServiceList = quoteRequestServiceReq.applicableServiceDto;
                        response.Data = applicableServiceList;
                        response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                        return new OkObjectResult(response);
                    }
                    else if ((bool)quoteRequestServiceReq.new_vehicle_never_registered)
                    {
                        sr_request.is_renewal = false;
                        sr_request.is_transfer = false;
                        sr_request.is_new_vehicle_never_registered = true;
                        sr_request.is_plate_replacement = false;

                        //Do you want PARS to handle T&R?
                        if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                        {
                            if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                            {
                                sr_request.do_you_want_pars_to_handle_t_n_r = true;
                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                {
                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                }
                            }
                            else
                            {
                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                {
                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                }
                            }
                        }
                    }
                    else
                    {
                        sr_request.plates_are_expired_or_misplaced = true;
                        if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                        {
                            if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                            {
                                sr_request.do_you_want_pars_to_handle_t_n_r = true;
                                if (quoteRequestServiceReq.requested_t_n_r_service_type_id != null)
                                {
                                    if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Renewal)
                                    {
                                        sr_request.is_renewal = true;
                                        sr_request.is_transfer = false;
                                        sr_request.is_new_vehicle_never_registered = false;
                                        sr_request.is_plate_replacement = false;
                                    }
                                    else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Replacenent)
                                    {
                                        sr_request.is_renewal = false;
                                        sr_request.is_transfer = false;
                                        sr_request.is_new_vehicle_never_registered = false;
                                        sr_request.is_plate_replacement = true;
                                    }
                                    else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Transfer)
                                    {
                                        sr_request.is_renewal = false;
                                        sr_request.is_transfer = true;
                                        sr_request.is_new_vehicle_never_registered = false;
                                        sr_request.is_plate_replacement = false;
                                    }
                                }

                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                {
                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                }
                            }
                            else
                            {
                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                {
                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                }
                            }
                        }
                    }
                }
                else if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.I_dont_know)
                {
                    if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                    {
                        if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                            sr_request.is_pars_to_issue_a_temp_tag = true;
                    }
                }
                #endregion END

                if (quoteRequestServiceReq.will_you_send_the_plates_to_fleet_driver != null)
                {
                    if (!(bool)quoteRequestServiceReq.will_you_send_the_plates_to_fleet_driver)
                    {
                        sr_request.will_you_send_plates_to_pars = true;
                    }
                }
            }

            #endregion END

            sr_request.is_vehicle_plate_valid = true;
            if (sr_request.is_plate_replacement)
            {
                if (quoteRequestServiceReq.vehicle_plate_expiration_date != null)
                {
                    if (quoteRequestServiceReq.vehicle_plate_expiration_date < System.DateTime.Now)
                    {
                        // sr_request.is_renewal = true;
                        sr_request.is_vehicle_plate_valid = false;
                    }
                }
            }

            foreach (var item in servicesListReq)
            {
                if (item.category_id == (long)Category_Types.service_request)
                {
                    item.modelJson = JsonConvert.SerializeObject(sr_request);
                    item.price_list_id = quoteRequestServiceReq.price_list_id;
                }
            }

            var jsonResults = await _mediator.Send(new EvaluateRulesQuery { preferencesListReq = servicesListReq });
            var applicableServices = await _mediator.Send(new GetDefaultServicesQuery
            {
                jsonResults = jsonResults,
                price_list_id = quoteRequestServiceReq.price_list_id,
                agreement_id = quoteRequestServiceReq.agreement_id,
                rule_type_id = preferenceReq.rule_type_id,
                event_type_id = preferenceReq.event_type_id,
                service_standard = (long)EnumTypes.Service_Standard.Standard,
                applicableServiceDto = quoteRequestServiceReq.applicableServiceDto,
            });

            PriceCalculationReq priceCalculationReq = new PriceCalculationReq();
            priceCalculationReq.servicereqs = new List<ApplicableServiceDto>();
            priceCalculationReq.servicereqs = applicableServices;
            applicableServiceList = priceCalculationReq.servicereqs;
            #endregion end

            if (applicableServiceList != null)
            {
                response.Data = applicableServiceList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// Method for add service Master Details 
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<ApplicableServiceDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> AddServiceOnRequest(QuoteRequestServiceReq quoteRequestServiceReq)
        {
            ResponseBase<List<ApplicableServiceDto>> response = new ResponseBase<List<ApplicableServiceDto>>();

            #region get default services
            List<JsonResult> jsonResults = new List<JsonResult>();
            List<ApplicableServiceDto> applicableServicesResponse = new List<ApplicableServiceDto>();
            List<ApplicableServiceDto> applicableServices = new List<ApplicableServiceDto>();
            foreach (var serv in quoteRequestServiceReq.service_id)
            {
                PreferenceReq preferenceReq = new PreferenceReq();
                preferenceReq.agreement_id = quoteRequestServiceReq.agreement_id;
                preferenceReq.service_id = serv;
                preferenceReq.rule_type_id = (long)EnumTypes.Rule_Type.Actionable;
                preferenceReq.event_type_id = (long)EnumTypes.Event_Type.new_service_request;

                var servicesListReq = await _mediator.Send(new GetPreferencesListQuery { preferenceReq = preferenceReq });
                if (servicesListReq.Count > 0)
                {
                    #region Request Model
                    Application.Utility.Preference.Models.service_request sr_request = new Application.Utility.Preference.Models.service_request();
                    sr_request.transportation_type_id = (int)quoteRequestServiceReq.transportation_type_id;
                    sr_request.vehicle_type = (int)quoteRequestServiceReq.vehicle_type_id;
                    sr_request.fuel_type = (int)quoteRequestServiceReq.fuel_type_id;
                    sr_request.primary_fuel_type = (int)quoteRequestServiceReq.primary_fuel_type_id;
                    //sr_request.service_id = (int)quoteRequestServiceReq.vehicle_type_id;
                    sr_request.retail = quoteRequestServiceReq.retail;
                    if (quoteRequestServiceReq.location1_address_type_id != null)
                        sr_request.pickup_address_type = (int)quoteRequestServiceReq.location1_address_type_id;

                    sr_request.is_verify_pickup_city = quoteRequestServiceReq.is_verify_location1_city;

                    if (quoteRequestServiceReq.location1_state_id != null)
                        sr_request.pickup_state = (int)quoteRequestServiceReq.location1_state_id;
                    sr_request.is_verify_pickup_state = quoteRequestServiceReq.is_verify_location1_state;
                    sr_request.pickup_postal_code = quoteRequestServiceReq.location1_postal_code;
                    sr_request.is_verify_pickup_postal_code = quoteRequestServiceReq.is_verify_location1_postal_code;

                    if (quoteRequestServiceReq.location1_country_id != null)
                        sr_request.pickup_country = (int)quoteRequestServiceReq.location1_country_id;

                    sr_request.is_verify_pickup_country = quoteRequestServiceReq.is_verify_location1_country;

                    if (quoteRequestServiceReq.location1_storage_id != null)
                        sr_request.pickup_storage = (int)quoteRequestServiceReq.location1_storage_id;

                    sr_request.has_pickup_date_constraints = quoteRequestServiceReq.has_location1_date_constraints;

                    if (quoteRequestServiceReq.location1_date_constraint_type_id != null)
                        sr_request.pickup_date_constraint_type_id = (int)quoteRequestServiceReq.location1_date_constraint_type_id;
                    //sr_request.requested_pickup_date = quoteRequestServiceReq.requested_pickup_date;

                    if (quoteRequestServiceReq.location2_address_type_id != null)
                        sr_request.delivery_address_type = (int)quoteRequestServiceReq.location2_address_type_id;
                    sr_request.is_verify_delivery_city = quoteRequestServiceReq.is_verify_location2_city;

                    if (quoteRequestServiceReq.location2_state_id != null)
                        sr_request.delivery_state = (int)quoteRequestServiceReq.location2_state_id;
                    sr_request.is_verify_delivery_state = quoteRequestServiceReq.is_verify_location2_state;
                    sr_request.delivery_postal_code = quoteRequestServiceReq.location2_postal_code;
                    sr_request.is_verify_delivery_postal_code = quoteRequestServiceReq.is_verify_location2_postal_code;

                    if (quoteRequestServiceReq.location2_country_id != null)
                        sr_request.delivery_country = (int)quoteRequestServiceReq.location2_country_id;
                    sr_request.is_verify_delivery_country = quoteRequestServiceReq.is_verify_location2_country;

                    if (quoteRequestServiceReq.location2_storage_id != null)
                        sr_request.delivery_storage = (int)quoteRequestServiceReq.location2_storage_id;
                    sr_request.has_delivery_date_constraints = quoteRequestServiceReq.has_location2_date_constraints;

                    if (quoteRequestServiceReq.location2_date_constraints_type_id != null)
                        sr_request.delivery_date_constraints_type = (int)quoteRequestServiceReq.location2_date_constraints_type_id;

                    if (quoteRequestServiceReq.bill_to != null)
                        sr_request.bill_to = (int)quoteRequestServiceReq.bill_to;
                    sr_request.pickup_is_vip_contact = quoteRequestServiceReq.location1_is_vip_contact;

                    if (quoteRequestServiceReq.location1_time_zone_id != null)
                        sr_request.pickup_time_zone = (int)quoteRequestServiceReq.location1_time_zone_id;
                    sr_request.has_pickup_sensitivities = quoteRequestServiceReq.has_location1_sensitivities;
                    //sr_request.pickup_date_sensitivities = quoteRequestServiceReq.pickup_date_sensitivities;

                    if (quoteRequestServiceReq.location1_sensitivity_type_id != null)
                        sr_request.pickup_sensitivity_type = (int)quoteRequestServiceReq.location1_sensitivity_type_id;
                    sr_request.delivery_is_vip_contact = quoteRequestServiceReq.location2_is_vip_contact;

                    if (quoteRequestServiceReq.location2_time_zone_id != null)
                        sr_request.delivery_time_zone = (int)quoteRequestServiceReq.location2_time_zone_id;
                    sr_request.has_delivery_sensitivities = quoteRequestServiceReq.has_location2_sensitivities;
                    //sr_request.delivery_date_sensitivities = (int)quoteRequestServiceReq.vehicle_type_id;

                    if (quoteRequestServiceReq.location2_sensitivity_type_id != null)
                        sr_request.delivery_sensitivity_type = (int)quoteRequestServiceReq.location2_sensitivity_type_id;
                    sr_request.can_pars_issue_a_temp_tag = quoteRequestServiceReq.can_pars_issue_a_temp_tag;
                    sr_request.is_inspection_be_needed = quoteRequestServiceReq.is_inspection_be_needed;
                    sr_request.do_not_complete_inspection_if_required = quoteRequestServiceReq.do_not_complete_inspection_if_required;
                    sr_request.pickup_towing_required = quoteRequestServiceReq.location1_towing_required;
                    sr_request.vehicle_repossession_required = quoteRequestServiceReq.vehicle_repossession_required;
                    sr_request.is_vehicle_at_impound = quoteRequestServiceReq.is_vehicle_at_impound;
                    #endregion End


                    foreach (var item in servicesListReq)
                    {
                        if (item.category_id == (long)Category_Types.service_request)
                        {
                            item.modelJson = JsonConvert.SerializeObject(sr_request);
                            item.price_list_id = quoteRequestServiceReq.price_list_id;
                        }
                    }

                    jsonResults = await _mediator.Send(new EvaluateRulesQuery { preferencesListReq = servicesListReq });
                    applicableServices = await _mediator.Send(new GetDefaultServicesQuery { jsonResults = jsonResults, price_list_id = quoteRequestServiceReq.price_list_id, agreement_id = quoteRequestServiceReq.agreement_id, rule_type_id = preferenceReq.rule_type_id, service_standard = (long)EnumTypes.Service_Standard.New });
                }
                else
                {
                    applicableServices = await _mediator.Send(new GetDefaultServicesQuery { jsonResults = jsonResults, price_list_id = quoteRequestServiceReq.price_list_id, service_id = serv, agreement_id = quoteRequestServiceReq.agreement_id, rule_type_id = null, service_standard = (long)EnumTypes.Service_Standard.New });
                }
                foreach (var itm in applicableServices)
                { applicableServicesResponse.Add(itm); }

            }
            #endregion end

            if (applicableServicesResponse != null)
            {
                response.Data = applicableServicesResponse;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// Method to Get Service details for Request in related pricelist to fmc and fleet
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<RequestServices>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServicesForRequest(RequestServicesReq requestServicesReq)
        {
            ResponseBase<List<RequestServices>> response = new ResponseBase<List<RequestServices>>();
            #region Get Services in Pricelist
            var activeRequestServices = await _mediator.Send(new GetActiveRequestServicesQuery { priceListId = requestServicesReq.price_list_id });
            if (activeRequestServices.Count > 0)
            {

                response.Data = activeRequestServices;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
            #endregion Get Services in Pricelist
        }

        /// <summary>
        /// Method for advance quote  calculation
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<CalculationResponseDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CalculateAdvanceQuote(PriceCalculationReq calculationReq)
        {
            ResponseBase<CalculationResponseDto> response = new ResponseBase<CalculationResponseDto>();

            #region Handle_For_Route_Not_Found_OR_Unknown_Vehicle_Type - Code Commented by OP
            CalculationResponseDto calculationResponse = new CalculationResponseDto();
            /*
            //if (calculationReq.distance == null || calculationReq.pickup_latitude == null || calculationReq.pickup_longitude == null ||
            //    calculationReq.delivery_latitude == null || calculationReq.delivery_longitude == null || calculationReq.vehicle_type_id == (long)VehicleType.NotMatched || calculationReq.vehicle_type_id == (long)VehicleType.Unknown || calculationReq.vehicle_type_id == (long)VehicleType.OtherPowered ||
            //    calculationReq.vehicle_type_id == (long)VehicleType.OtherUnpowered)
            //{
            //    ApplicableServiceDto serviceObj = new ApplicableServiceDto();
            //    if(calculationReq.pickup_towing_required)
            //    {
            //        serviceObj.service_id = (long)EnumTypes.Transport_service.Auto_Carrier_Tariff;
            //        serviceObj.service = "Auto Carrier Transport";                  
            //    }
            //    else
            //    {
            //        serviceObj.service_id = (long)EnumTypes.Transport_service.Drive_Away_Tariff;
            //        serviceObj.service = "Driveaway Transport";
            //    }
            //    serviceObj.sub_category_id = 5;
            //    serviceObj.sub_category = "Transport";
            //    calculationResponse.serviceresp = new List<ApplicableServiceDto>();
            //    calculationResponse.serviceresp.Add(serviceObj);
            //    calculationResponse.serviceresp.AddRange(calculationReq.servicereqs);
            //    response.Data = calculationResponse;
            //    response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_NO_ROUTE_FOUND");
            //    return new OkObjectResult(response);
            //}
            */

            #endregion End_Handle_For_Route_Not_Found_OR_Unknown_Vehicle_Type

            #region Get related agreement
            //var agreement_id = await _mediator.Send(new GetAgreementQuery { fmc_id = calculationReq.fmc_id, fleet_id = calculationReq.fleet_id });
            //if (agreement_id == null)
            //    throw new BusinessException("PARS_AGREEMENT_NOT_FOUND");
            //#endregion End          

            //#region Get related price list
            //long? price_list_id = null;
            //var price_list = await _mediator.Send(new GetActivePriceListByAgreementIdQuery { agreement_id = (long)agreement_id });
            //if (price_list == null)
            //    throw new BusinessException("PARS_PRICELIST_NOT_FOUND");
            //int i = 0;
            //foreach (var pricelistObj in price_list)
            //{
            //    if (i == 0)
            //    {
            //        price_list_id = pricelistObj.id;
            //        i++;
            //    }
            //}
            #endregion End


            #region Request Model
            PriceCalculationReq priceCalculationReq = new PriceCalculationReq();
            priceCalculationReq.transportation_type_id = calculationReq.transportation_type_id;//1;
            priceCalculationReq.primary_fuel_type_id = calculationReq.primary_fuel_type_id;//2;
            priceCalculationReq.fleet_id = calculationReq.fleet_id;//2;
            priceCalculationReq.fmc_id = calculationReq.fmc_id;// 2;
            priceCalculationReq.agreement_id = calculationReq.agreement_id;
            priceCalculationReq.price_list_id = calculationReq.price_list_id;
            priceCalculationReq.vehicle_type_id = calculationReq.vehicle_type_id;// 2;
            priceCalculationReq.pick_postal_code = calculationReq.pick_postal_code;// "47427";
            priceCalculationReq.del_postal_code = calculationReq.del_postal_code;// "30008";
            priceCalculationReq.pickup_storage_id = calculationReq.pickup_storage_id;// "30008";
            priceCalculationReq.delivery_storage_id = calculationReq.delivery_storage_id;// "30008";
            priceCalculationReq.location1_country_id = calculationReq.location1_country_id;
            priceCalculationReq.location2_country_id = calculationReq.location2_country_id;

            priceCalculationReq.distance = calculationReq.distance;
            priceCalculationReq.adj_duration = calculationReq.adj_duration;

            priceCalculationReq.pickup_latitude = calculationReq.pickup_latitude;
            priceCalculationReq.pickup_longitude = calculationReq.pickup_longitude;
            priceCalculationReq.delivery_latitude = calculationReq.delivery_latitude;
            priceCalculationReq.delivery_longitude = calculationReq.delivery_longitude;
            priceCalculationReq.servicereqs = new List<ApplicableServiceDto>();

            // Remove Drive Away Tariff -27 
            int? index = null;
            index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Transport_service.Drive_Away_Tariff);
            if (index != null && index != -1)
                calculationReq.servicereqs.RemoveAt((int)index);
            //Auto Carrier Tariff -1
            index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Transport_service.Auto_Carrier_Tariff);
            if (index > 0 && index != -1)
                calculationReq.servicereqs.RemoveAt((int)index);

            //Both -40
            index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Transport_service.Both);
            if (index > 0 && index != -1)
                calculationReq.servicereqs.RemoveAt((int)index);

            //Either - 41
            index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Transport_service.Either);
            if (index > 0 && index != -1)
                calculationReq.servicereqs.RemoveAt((int)index);

            #region T&R related service remove

            ////if (calculationReq.transportation_type_id == (long)EnumTypes.transportation_type.Driveaway)
            ////{
            //index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Service.Initial_T_and_R);
            //if (index > 0 && index != -1)
            //    calculationReq.servicereqs.RemoveAt((int)index);
            //index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Service.Shipping_Handling_Fee);
            //if (index > 0 && index != -1)
            //    calculationReq.servicereqs.RemoveAt((int)index);

            ////index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Service.Inspection_Miscellaneous);
            ////if (index > 0 && index != -1)

            //    calculationReq.servicereqs.RemoveAt((int)index);
            //index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Service.Tags_30_Day_Temp);
            //if (index > 0 && index != -1)
            //    calculationReq.servicereqs.RemoveAt((int)index);
            ////}

            #endregion

            #region This service currently not in use
            ////Tow -44
            //index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Special_Handling.Tow);
            //if (index > 0 && index != -1)
            //    calculationReq.servicereqs.RemoveAt((int)index);

            ////Repossession = 45,
            //index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Special_Handling.Repossession);
            //if (index > 0 && index != -1)
            //    calculationReq.servicereqs.RemoveAt((int)index);

            ////Impounded = 46,
            //index = calculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Special_Handling.Impounded);
            //if (index > 0 && index != -1)
            //    calculationReq.servicereqs.RemoveAt((int)index);
            #endregion

            priceCalculationReq.servicereqs = calculationReq.servicereqs;
            priceCalculationReq.is_vehicle_at_impound = calculationReq.is_vehicle_at_impound;
            priceCalculationReq.pickup_towing_required = calculationReq.pickup_towing_required;
            priceCalculationReq.vehicle_repossession_required = calculationReq.vehicle_repossession_required;
            #region VEHICLE REGISTRATION STATUS RELATED FIELDS
            priceCalculationReq.is_plate_exist = calculationReq.is_plate_exist;
            priceCalculationReq.vehicle_plate_expiration_date = calculationReq.vehicle_plate_expiration_date;

            priceCalculationReq.has_vehicle_ever_been_titled = calculationReq.has_vehicle_ever_been_titled;
            priceCalculationReq.state_transfer_agent_type_id = calculationReq.state_transfer_agent_type_id;
            priceCalculationReq.issuing_agent_type_id = calculationReq.issuing_agent_type_id;
            priceCalculationReq.renewal_agent_type_id = calculationReq.renewal_agent_type_id;
            priceCalculationReq.can_pars_issue_a_temp_tag = calculationReq.can_pars_issue_a_temp_tag;
            priceCalculationReq.is_inspection_be_needed = calculationReq.is_inspection_be_needed;

            priceCalculationReq.plate_status = calculationReq.plate_status;
            priceCalculationReq.do_you_want_pars_to_handle_t_n_r = calculationReq.do_you_want_pars_to_handle_t_n_r;
            priceCalculationReq.is_pars_to_issue_a_temp_tag = calculationReq.is_pars_to_issue_a_temp_tag;
            priceCalculationReq.will_you_send_the_plates_to_fleet_driver = calculationReq.will_you_send_the_plates_to_fleet_driver;
            priceCalculationReq.want_pars_to_deliver_on_current_plates = calculationReq.want_pars_to_deliver_on_current_plates;
            priceCalculationReq.is_prerequisite_inspections_in_delivery_state_required = calculationReq.is_prerequisite_inspections_in_delivery_state_required;

            #endregion END

            #endregion End Model

            #region get calculate price
            var calculatePrice = await _mediator.Send(new PriceCalculationQuery { priceCalculationReq = priceCalculationReq });
            #endregion end calculate price

            if (calculatePrice != null)
            {
                response.Data = calculatePrice;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_PRICE_CALCULATED_SUCCESSFULL");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CALCULATION_FAILURE");
            }
        }

        /// <summary>
        /// Get Move Type Through Prefrence
        /// </summary>
        /// <param name="quoteRequestServiceReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<GetMoveTypeDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetMoveTypeThroughPrefrence(QuoteRequestServiceReq quoteRequestServiceReq)
        {
            ResponseBase<GetMoveTypeDto> response = new ResponseBase<GetMoveTypeDto>();
            var moveType = await _mediator.Send(new GetMoveTypeQuery { moveTypeReq = quoteRequestServiceReq });
            if (moveType != null)
            {
                response.Data = moveType;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API Create Quote Information  
        /// </summary>
        /// <returns> true/false</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateServiceRequest(CreateServiceRequestReq createServiceRequestReqs)
        {
            #region GET QUEUE RULE
            var rootPath = _hostingEnvironment.ContentRootPath;
            var fullPath = Path.Combine(rootPath, "queuerules.json");
            var queueRule = System.IO.File.ReadAllText(fullPath);
            #endregion

            ResponseBase<bool> responseBase = new ResponseBase<bool>();

            Tuple<bool, bool> result = await _mediator.Send(new CreateServiceRequestCommand { createServiceRequestReqs = createServiceRequestReqs, queueRule = queueRule });
            if (result.Item1 == true)
            {
                responseBase.Data = false;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_PICKUP_AND_DELIVERY_ADDRESS_NOT_STORAGE_IN_BOTH_CASE");
                return new OkObjectResult(responseBase);
            }
            else if (result.Item2 == true)
            {
                responseBase.Data = true;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(responseBase);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        /// <summary>
        /// API Update Service Request Details  
        /// </summary>
        /// <returns> true/false</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateServiceRequest(UpdateServiceRequestReq updateServiceRequestReqs)
        {
            ResponseBase<bool> responseBase = new ResponseBase<bool>();
            #region GET QUEUE RULE
            var rootPath = _hostingEnvironment.ContentRootPath;
            var fullPath = Path.Combine(rootPath, "queuerules.json");
            var queueRule = System.IO.File.ReadAllText(fullPath);
            #endregion
            Tuple<bool, bool> result = await _mediator.Send(new UpdateServiceRequestCommand { updateServiceRequestReqs = updateServiceRequestReqs, queueRule = queueRule });
            if (result.Item1 == true)
            {
                responseBase.Data = false;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_PICKUP_AND_DELIVERY_ADDRESS_NOT_STORAGE_IN_BOTH_CASE");
                return new OkObjectResult(responseBase);
            }
            if (result.Item2 == true)
            {
                responseBase.Data = true;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(responseBase);
            }
            else
            {
                responseBase.Data = false;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_UPDATION_FAILURE");
                return new OkObjectResult(responseBase);
            }
        }

        /// <summary>
        /// API GET SERVICE REQUEST LIST AND QUOTE REQUEST LIST
        /// </summary>
        /// <param name="serviceRequestType"></param>
        /// <param name="filter_type_id"></param>
        /// <param name="searchFilterJson"></param>
        /// <returns>Service Request List Dtos</returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<ServiceRequestListDtos>>), StatusCodes.Status200OK)]
        //public async Task<IActionResult> GetServiceRequestList(long? serviceRequestType, long? filterTypeId, long? accountId)
        public async Task<IActionResult> GetServiceRequestList(ServiceRequestAdvanceFilters req)
        {
            /*
              SearchFilter searchFilter = null;
            if (string.IsNullOrEmpty(searchFilterJson))
            {
                string entityName = serviceRequestType == (long)EnumTypes.service_request_type.service_request ? "service_request" : serviceRequestType == (long)EnumTypes.service_request_type.quote_request ? "quote_request" : null;
                //Get User Grid Prefrence
                var userPreference = await _mediator.Send(new GetGridViewPreferenceQuery { entity_name = entityName });
                if (userPreference != null)
                {
                    if (userPreference.myview_filter != null)
                    {
                        string json = userPreference.myview_filter;
                        searchFilter = JsonConvert.DeserializeObject<SearchFilter>(json);
                    }
                }
            }
            else // User has submitted a custom search filter input and wants to run a custom search
            {
                searchFilter = JsonConvert.DeserializeObject<SearchFilter>(searchFilterJson);
            } */

            var response = new ResponseBase<List<ServiceRequestListDtos>>();
            //var serviceRequestList = await _mediator.Send(new GetServiceRequestListQuery {service_request_type = serviceRequestType,filter_type_id = filterTypeId,account_id = accountId });
            var serviceRequestList = await _mediator.Send(new GetServiceRequestListQuery { reqParm = req });

            if (serviceRequestList.Count > 0)
            {
                response.Data = serviceRequestList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            }
            else
            {
                response.Data = serviceRequestList;
                response.IsSuccessful = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
            }
            return new OkObjectResult(response);
        }

        /// <summary>
        /// Get Vehicle Related Service Requests
        /// </summary>
        /// <param name="vehicleId"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<ServiceRequestListDtos>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehicleRelatedServiceRequests(long vehicleId, long serviceRequestTypeId)
        {
            var response = new ResponseBase<List<ServiceRequestListDtos>>();
            var serviceRequestList = await _mediator.Send(new GetVehicleRelatedServiceRequestListQuery
            {
                vehicle_id = vehicleId,
                service_request_type_id = serviceRequestTypeId
            });

            if (serviceRequestList.Count > 0)
            {
                response.Data = serviceRequestList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            }
            else
            {
                response.Data = serviceRequestList;
                response.IsSuccessful = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
            }
            return new OkObjectResult(response);
        }


        /// <summary>
        /// API gets Service Request Detail through Service Request Number
        /// </summary>
        /// <param name="serviceRequestNumber"></param>
        /// <returns> Detail of service request</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<ServiceRequestDetailDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServiceRequestDetail(long serviceRequestId)
        {
            ResponseBase<ServiceRequestDetailDto> response = new ResponseBase<ServiceRequestDetailDto>();
            try
            {
                var result = await _mediator.Send(new GetServiceDetailsByIdQuery { service_request_id = serviceRequestId });
                //   var QuoteDetail1 = await _mediator.Send(new GetServiceRequestDetailQuery { service_request_id = serviceRequestId });

                if (result != null)
                {
                    response.Data = result;
                    response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                    return new OkObjectResult(response);
                }
                else
                {
                    throw new BusinessException("PARS_RECORD_NOT_FOUND");
                }
            }
            catch (Exception ex)
            {
                if (ex.Message == "PARS_SERVICE_REQUEST_ALREADY_SUBMITTED")
                {
                    response.Data = null;
                    response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_SERVICE_REQUEST_ALREADY_SUBMITTED");
                    return new OkObjectResult(response);
                }
                else throw new BusinessException(ex.Message);
            }
        }

        /// <summary>
        /// API gets a list Support Contacts which will be belongs to PARS or FMC or FMC-Fleet
        /// </summary>
        /// <param name="supportContactsInServiceRequestReq"></param>
        /// <returns> List of service request</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<SupportContactsOnServiceRequestDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSupportContactsOnRequest(SupportContactReq supportContactsOnServiceRequestReq)
        {
            ResponseBase<List<SupportContactsOnServiceRequestDto>> response = new ResponseBase<List<SupportContactsOnServiceRequestDto>>();
            var result = await _mediator.Send(new GetSupportContactsOnRequestQuery
            {
                fmc_id = supportContactsOnServiceRequestReq.fmc_Id,
                fleet_id = supportContactsOnServiceRequestReq.fleet_id
            });
            if (result != null)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to Delete records Support Contacts, Transport Orders, Service Orders related to Service Request and Delete Service Request  
        /// </summary>
        /// <param name="service_request_id"></param>
        /// <returns> Status Delete or Not</returns>
        /// <exception cref="BusinessException"></exception>
        /// 
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<bool>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> DeleteServiceRequest(long service_request_id)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new DeleteServiceRequestCommand
            {
                serviceRequestId = service_request_id
            });
            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_DELETE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_DELETION_FAILURE");
        }

        /// <summary>
        ///Convert Quote Request To Service Request
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<bool>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ConvertQuoteRequestToServiceRequest(ConvertQuoteRequestToServiceRequestReq req)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            Tuple<bool, bool> result = await _mediator.Send(new ConvertQuoteRequestToServiceRequestCommand
            {
                quote_number = req.quote_number,
                quote_id = req.quote_id

            });
            if (result.Item2)
            {
                response.Data = result.Item2;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_QUOTE_CONVERT_TO_ORDER_SUCCESS");
                return new OkObjectResult(response);
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.IsSuccessful = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_QUOTE_EXPIRED");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result.Item2;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_QUOTE_TO_SERVICE_REQUEST_CONVERT_FAILED");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// Method for Get Applicable Services List
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<ICIntructionForServiceOrderDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetICInstructionList(QuoteRequestServiceReq quoteRequestServiceReq)
        {
            ResponseBase<List<ICIntructionForServiceOrderDto>> response = new ResponseBase<List<ICIntructionForServiceOrderDto>>();

            var ICInstructionList = await _mediator.Send(new GetICIntructionForServiceOrderQuery { quoteRequestServiceReq = quoteRequestServiceReq });

            if (ICInstructionList != null)
            {
                response.Data = ICInstructionList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// Method for Get inspection Services List by CODE EFFECT RULE ENGINE rules
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<ApplicableServiceDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetStateInspectionRelatedServices(QuoteRequestServiceReq quoteRequestServiceReq)
        {
            ResponseBase<List<ApplicableServiceDto>> response = new ResponseBase<List<ApplicableServiceDto>>();
            List<ApplicableServiceDto> applicableServiceList = new List<ApplicableServiceDto>();
            #region get default services
            StateInspectionPreferenceReq preferenceReq = new StateInspectionPreferenceReq();
            // preferenceReq.agreement_id = quoteRequestServiceReq.agreement_id;

            //get vehicle additional detail.
            var vehicleDetail = await _mediator.Send(new GetVehicleDetailQuery { id = (long)quoteRequestServiceReq.vehicle_id });

            // In cases of renewal, pickup state inspections would be applicable.

            if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Renewal)
            {
                preferenceReq.inspection_state_id = (long)quoteRequestServiceReq.location1_state_id;
            }
            else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Replacenent)
            {
                preferenceReq.inspection_state_id = (long)quoteRequestServiceReq.location2_state_id;
                if (vehicleDetail.license_expires_date != null)
                {
                    if (vehicleDetail.license_expires_date < System.DateTime.Now.AddDays(30))
                    {

                        preferenceReq.inspection_state_id = (long)quoteRequestServiceReq.location1_state_id;
                    }
                }
            }
            else
            {
                preferenceReq.inspection_state_id = (long)quoteRequestServiceReq.location2_state_id;
            }

            var servicesListReq = await _mediator.Send(new GetStateInspectionPreferencesListQuery { preferenceReq = preferenceReq });
            #region REMOVE T&R REALTED SERVICES

            if (quoteRequestServiceReq.applicableServiceDto != null)
            {
                // Remove Emissions_Smog_Inspection = 17,
                int? index = null;
                index = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.inspection_services.Emissions_Smog_Inspection);
                if (index != null && index != -1)
                {
                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.service_id == (long)EnumTypes.inspection_services.Emissions_Smog_Inspection);
                }

                //Remove State_Inspection = 18,
                index = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.inspection_services.State_Inspection);
                if (index != null && index != -1)
                {
                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.service_id == (long)EnumTypes.inspection_services.State_Inspection);
                }

                //Remove VIN_Inspection = 19,
                index = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.inspection_services.VIN_Inspection);
                if (index != null && index != -1)
                {
                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.service_id == (long)EnumTypes.inspection_services.VIN_Inspection);
                }

                //Remove  Weight_Slip = 20,
                index = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.inspection_services.Weight_Slip);
                if (index != null && index != -1)
                {
                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.service_id == (long)EnumTypes.inspection_services.Weight_Slip);
                }

                quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Shipping_Handling_Fee);






            }

            #endregion

            #region RequestModel 

            Application.Utility.Preference.Models.service_request sr_request = new Application.Utility.Preference.Models.service_request();
            sr_request.vehicle_type = (int)vehicleDetail.vehicle_type_id;
            sr_request.primary_fuel_type = (int)vehicleDetail.primary_fuel_type_id;
            if (vehicleDetail.gvwr != null)
            {
                string gvwr = vehicleDetail.gvwr;
                string pattern = @"(\d{1,3},\d{3}) - (\d{1,3},\d{3}) lb";
                Match match = Regex.Match(gvwr, pattern);
                if (match.Success)
                {
                    // Extract the captured value
                    string valueString = match.Groups[2].Value;

                    // Replace the comma with an empty string to get the numeric value as a string
                    string numericValueString = valueString.Replace(",", "");

                    sr_request.gvwr = Convert.ToInt32(numericValueString);

                }

            }
            sr_request.fuel_type = (int)vehicleDetail.fuel_type_id;
            if (quoteRequestServiceReq.transportation_type_id != null)
                sr_request.transportation_type_id = (int)quoteRequestServiceReq.transportation_type_id;

            sr_request.retail = quoteRequestServiceReq.retail;
            if (quoteRequestServiceReq.location1_address_type_id != null)
                sr_request.pickup_address_type = (int)quoteRequestServiceReq.location1_address_type_id;

            sr_request.is_verify_pickup_city = quoteRequestServiceReq.is_verify_location1_city;

            if (quoteRequestServiceReq.location1_state_id != null)
                sr_request.pickup_state = (int)quoteRequestServiceReq.location1_state_id;



            sr_request.is_verify_pickup_state = quoteRequestServiceReq.is_verify_location1_state;
            sr_request.pickup_postal_code = quoteRequestServiceReq.location1_postal_code;
            sr_request.is_verify_pickup_postal_code = quoteRequestServiceReq.is_verify_location1_postal_code;

            if (quoteRequestServiceReq.location1_country_id != null)
                sr_request.pickup_country = (int)quoteRequestServiceReq.location1_country_id;

            sr_request.is_verify_pickup_country = quoteRequestServiceReq.is_verify_location1_country;

            if (quoteRequestServiceReq.location1_storage_id != null)
                sr_request.pickup_storage = (int)quoteRequestServiceReq.location1_storage_id;

            sr_request.has_pickup_date_constraints = quoteRequestServiceReq.has_location1_date_constraints;

            if (quoteRequestServiceReq.location1_date_constraint_type_id != null)
                sr_request.pickup_date_constraint_type_id = (int)quoteRequestServiceReq.location1_date_constraint_type_id;
            //sr_request.requested_pickup_date = quoteRequestServiceReq.requested_pickup_date;

            #region DELIVERY POINT

            if (quoteRequestServiceReq.location2_address_type_id != null)
                sr_request.delivery_address_type = (int)quoteRequestServiceReq.location2_address_type_id;


            if (!string.IsNullOrWhiteSpace(quoteRequestServiceReq.location2_city))
                sr_request.delivery_city = quoteRequestServiceReq.location2_city;

            sr_request.is_verify_delivery_city = quoteRequestServiceReq.is_verify_location2_city;

            if (quoteRequestServiceReq.location2_state_id != null)
            {
                sr_request.delivery_state = (int)quoteRequestServiceReq.location2_state_id;
                sr_request.delivery_state_name = quoteRequestServiceReq.location2_state;
            }




            sr_request.is_verify_delivery_state = quoteRequestServiceReq.is_verify_location2_state;

            sr_request.delivery_postal_code = quoteRequestServiceReq.location2_postal_code;
            sr_request.is_verify_delivery_postal_code = quoteRequestServiceReq.is_verify_location2_postal_code;

            if (!string.IsNullOrWhiteSpace(quoteRequestServiceReq.location2_county))
            {
                sr_request.delivery_county = quoteRequestServiceReq.location2_county;
                //Remove Accents/Diacritics
                var deliveryCounty = quoteRequestServiceReq.location2_county.Normalize(NormalizationForm.FormD);
                deliveryCounty = deliveryCounty.Replace("'", "");
                sr_request.delivery_county = deliveryCounty;
            }

            if (quoteRequestServiceReq.location2_country_id != null)
                sr_request.delivery_country = (int)quoteRequestServiceReq.location2_country_id;

            sr_request.is_verify_delivery_country = quoteRequestServiceReq.is_verify_location2_country;

            if (quoteRequestServiceReq.location2_storage_id != null)
                sr_request.delivery_storage = (int)quoteRequestServiceReq.location2_storage_id;

            #endregion END

            sr_request.has_delivery_date_constraints = quoteRequestServiceReq.has_location2_date_constraints;

            if (quoteRequestServiceReq.location2_date_constraints_type_id != null)
                sr_request.delivery_date_constraints_type = (int)quoteRequestServiceReq.location2_date_constraints_type_id;


            if (quoteRequestServiceReq.bill_to != null)
                sr_request.bill_to = (int)quoteRequestServiceReq.bill_to;
            sr_request.pickup_is_vip_contact = quoteRequestServiceReq.location1_is_vip_contact;

            if (quoteRequestServiceReq.location1_time_zone_id != null)
                sr_request.pickup_time_zone = (int)quoteRequestServiceReq.location1_time_zone_id;
            sr_request.has_pickup_sensitivities = quoteRequestServiceReq.has_location1_sensitivities;
            //sr_request.pickup_date_sensitivities = quoteRequestServiceReq.pickup_date_sensitivities;

            if (quoteRequestServiceReq.location1_sensitivity_type_id != null)
                sr_request.pickup_sensitivity_type = (int)quoteRequestServiceReq.location1_sensitivity_type_id;
            sr_request.delivery_is_vip_contact = quoteRequestServiceReq.location2_is_vip_contact;

            if (quoteRequestServiceReq.location2_time_zone_id != null)
                sr_request.delivery_time_zone = (int)quoteRequestServiceReq.location2_time_zone_id;
            sr_request.has_delivery_sensitivities = quoteRequestServiceReq.has_location2_sensitivities;
            //sr_request.delivery_date_sensitivities = (int)quoteRequestServiceReq.vehicle_type_id;

            if (quoteRequestServiceReq.location2_sensitivity_type_id != null)
                sr_request.delivery_sensitivity_type = (int)quoteRequestServiceReq.location2_sensitivity_type_id;

            sr_request.can_pars_issue_a_temp_tag = quoteRequestServiceReq.can_pars_issue_a_temp_tag;
            sr_request.is_inspection_be_needed = quoteRequestServiceReq.is_inspection_be_needed;
            sr_request.do_not_complete_inspection_if_required = quoteRequestServiceReq.do_not_complete_inspection_if_required;
            sr_request.pickup_towing_required = quoteRequestServiceReq.location1_towing_required;
            sr_request.vehicle_repossession_required = quoteRequestServiceReq.vehicle_repossession_required;
            sr_request.is_vehicle_at_impound = quoteRequestServiceReq.is_vehicle_at_impound;
            // sr_request.vehicle_license_state= quoteRequestServiceReq.vehicle_license_state_id;



            int vehicleAge = (int)(System.DateTime.Now.Year - vehicleDetail.year);
            sr_request.vehicle_age = vehicleAge;

            #region Electric vehicle or Non-electric Vehicle
            bool isElectricVehicle = false;
            if (vehicleDetail.primary_fuel_type_id != null)
            {
                if (vehicleDetail.primary_fuel_type_id == (long)NHTSAFuelType.Electric
                   || vehicleDetail.primary_fuel_type_id == (long)NHTSAFuelType.PH_EV
                   || vehicleDetail.primary_fuel_type_id == (long)NHTSAFuelType.Hybrid)
                {
                    isElectricVehicle = true;
                }
            }
            sr_request.is_electric_vehicle = isElectricVehicle;

            //if (quoteRequestServiceReq.pars_perform_inspection == null)
            //    sr_request.pars_perform_inspection = false;
            //else
            //    sr_request.pars_perform_inspection = (bool)quoteRequestServiceReq.pars_perform_inspection;


            #endregion END



            sr_request.is_commercial_vehicle = vehicleDetail.is_commercial_vehicle != null ? (bool)vehicleDetail.is_commercial_vehicle : false;

            //if (quoteRequestServiceReq.year != null)
            //{
            //    int currentYear = System.DateTime.Now.Year;

            //    if (quoteRequestServiceReq.year < currentYear)
            //    {
            //        sr_request.vehicle_age = (int)(currentYear - quoteRequestServiceReq.year);
            //    }
            //}


            #region T&R Related Fields
            // serviceOrder.does_the_vehicle_have_current_registration = req.does_the_vehicle_have_current_registration;

            //serviceOrder.do_you_want_pars_to_handle_t_n_r = null;
            //serviceOrder.will_you_send_the_plates_to_fleet_driver = null;
            //serviceOrder.is_pars_to_issue_a_temp_tag = null;
            //serviceOrder.new_vehicle_never_registered = null;
            //serviceOrder.do_you_want_pars_to_delay_delivery = null;
            //serviceOrder.requested_t_n_r_service_type_id = null;


            if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.Yes)
            {
                if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Transfer)
                {
                    sr_request.is_renewal = false;
                    sr_request.is_transfer = true;
                    sr_request.is_new_vehicle_never_registered = false;
                    sr_request.is_plate_replacement = false;
                }

                if (quoteRequestServiceReq.new_vehicle_never_registered == null)
                {
                    //// applicableServiceList = request.applicableServiceDto;
                    //applicableServiceList = quoteRequestServiceReq.applicableServiceDto;
                    //response.Data = applicableServiceList;
                    //response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                    //return new OkObjectResult(response);

                }
                else if (!(bool)quoteRequestServiceReq.new_vehicle_never_registered)
                {
                    sr_request.is_renewal = false;
                    sr_request.is_transfer = false;
                    sr_request.is_new_vehicle_never_registered = false;
                    sr_request.is_plate_replacement = false;
                    sr_request.plates_are_expired_or_misplaced = true;
                    //Pars to handle = Yes 
                    if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                    {

                        if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                        {
                            sr_request.do_you_want_pars_to_handle_t_n_r = true;
                            if (quoteRequestServiceReq.requested_t_n_r_service_type_id != null)
                            {
                                if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Renewal)
                                {
                                    sr_request.is_renewal = true;
                                    sr_request.is_transfer = false;
                                    sr_request.is_new_vehicle_never_registered = false;
                                    sr_request.is_plate_replacement = false;
                                }
                                else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Replacenent)
                                {
                                    sr_request.is_renewal = false;
                                    sr_request.is_transfer = false;
                                    sr_request.is_new_vehicle_never_registered = false;
                                    sr_request.is_plate_replacement = true;
                                }
                                else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Transfer)
                                {
                                    sr_request.is_renewal = false;
                                    sr_request.is_transfer = true;
                                    sr_request.is_new_vehicle_never_registered = false;
                                    sr_request.is_plate_replacement = false;
                                }
                            }

                            if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                            {
                                if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                    sr_request.is_pars_to_issue_a_temp_tag = true;
                            }

                        }
                        else
                        {
                            if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                            {
                                if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                    sr_request.is_pars_to_issue_a_temp_tag = true;
                            }
                        }
                    }
                }

            }
            else if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.No)
            {
                sr_request.is_renewal = false;
                sr_request.is_transfer = false;
                sr_request.is_new_vehicle_never_registered = false;
                sr_request.is_plate_replacement = false;



                if (quoteRequestServiceReq.new_vehicle_never_registered == null)
                {
                    //// applicableServiceList = request.applicableServiceDto;
                    //applicableServiceList = quoteRequestServiceReq.applicableServiceDto;
                    //response.Data = applicableServiceList;
                    //response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                    //return new OkObjectResult(response);


                }
                else if ((bool)quoteRequestServiceReq.new_vehicle_never_registered)
                {
                    sr_request.is_renewal = false;
                    sr_request.is_transfer = false;
                    sr_request.is_new_vehicle_never_registered = true;
                    sr_request.is_plate_replacement = false;

                    //Do you want PARS to handle T&R?
                    if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                    {
                        if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                        {
                            sr_request.do_you_want_pars_to_handle_t_n_r = true;
                            if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                            {
                                if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                    sr_request.is_pars_to_issue_a_temp_tag = true;
                            }
                        }
                        else
                        {
                            if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                            {
                                if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                    sr_request.is_pars_to_issue_a_temp_tag = true;
                            }
                        }
                    }
                }
                else
                {

                    sr_request.plates_are_expired_or_misplaced = true;
                    if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                    {
                        if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                        {
                            sr_request.do_you_want_pars_to_handle_t_n_r = true;
                            if (quoteRequestServiceReq.requested_t_n_r_service_type_id != null)
                            {
                                if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Renewal)
                                {
                                    sr_request.is_renewal = true;
                                    sr_request.is_transfer = false;
                                    sr_request.is_new_vehicle_never_registered = false;
                                    sr_request.is_plate_replacement = false;
                                }
                                else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Replacenent)
                                {
                                    sr_request.is_renewal = false;
                                    sr_request.is_transfer = false;
                                    sr_request.is_new_vehicle_never_registered = false;
                                    sr_request.is_plate_replacement = true;
                                }
                                else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Transfer)
                                {
                                    sr_request.is_renewal = false;
                                    sr_request.is_transfer = true;
                                    sr_request.is_new_vehicle_never_registered = false;
                                    sr_request.is_plate_replacement = false;
                                }
                            }

                            if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                            {
                                if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                    sr_request.is_pars_to_issue_a_temp_tag = true;
                            }

                        }
                        else
                        {
                            if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                            {
                                if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                    sr_request.is_pars_to_issue_a_temp_tag = true;
                            }
                        }
                    }

                }

            }
            else if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.I_dont_know)
            {
                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                {
                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                        sr_request.is_pars_to_issue_a_temp_tag = true;
                }
            }
            #endregion END

            if (quoteRequestServiceReq.will_you_send_the_plates_to_fleet_driver != null)
            {
                if (!(bool)quoteRequestServiceReq.will_you_send_the_plates_to_fleet_driver)
                {
                    sr_request.will_you_send_plates_to_pars = true;
                }
            }

            #endregion

            if (!sr_request.is_transfer && vehicleDetail.license_state_id != null)
            {
                if (sr_request.delivery_state != vehicleDetail.license_state_id)
                {
                    sr_request.is_transfer = true;
                }
            }
            sr_request.is_vehicle_plate_valid = true;
            if (sr_request.is_plate_replacement)
            {
                if (vehicleDetail.license_expires_date != null)
                {
                    if (vehicleDetail.license_expires_date < System.DateTime.Now.AddDays(30))
                    {
                        // sr_request.is_renewal = true;
                        sr_request.is_vehicle_plate_valid = false;
                    }
                }
            }

            //Get inspection which will be aplicacable unconditionall.
            //List><PreferenceDto> unconditionalInspection = servicesListReq.Where(x => x.rule_json != null).ToList();
            var prefs = servicesListReq.Where(x => x.rule_json != null).ToList();

            List<string> unconditionalInspections = new List<string>();
            foreach (var item in servicesListReq)
            {
                if (item.category_id == (long)Category_Types.service_request)
                {
                    if (item.rule_json != null)
                        item.modelJson = JsonConvert.SerializeObject(sr_request);
                    else if (item.is_inspection_required)
                        unconditionalInspections.Add(item.service_id.ToString());
                }
            }

            var jsonResults = await _mediator.Send(new EvaluateRulesQuery { preferencesListReq = servicesListReq });
            var applicableServices = await _mediator.Send(new GetStateInspectionServicesQuery
            {
                jsonResults = jsonResults,
                price_list_id = quoteRequestServiceReq.price_list_id,
                agreement_id = quoteRequestServiceReq.agreement_id,
                //rule_type_id = preferenceReq.rule_type_id,
                //event_type_id = preferenceReq.event_type_id,
                delivery_state_id = preferenceReq.inspection_state_id,
                service_standard = (long)EnumTypes.Service_Standard.Standard,
                applicableServiceDto = quoteRequestServiceReq.applicableServiceDto,
                unconditionalInspections = unconditionalInspections,
            });

            PriceCalculationReq priceCalculationReq = new PriceCalculationReq();
            priceCalculationReq.servicereqs = new List<ApplicableServiceDto>();
            priceCalculationReq.servicereqs = applicableServices;

            applicableServiceList = priceCalculationReq.servicereqs;
            #endregion end

            if (applicableServiceList != null)
            {
                response.Data = applicableServiceList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        ///<summary>
        ///Get State Inspection Services
        ///</summary>
        ///<returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<ApplicableServiceDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetStateInspectionServices(StateInspectionReq stateInspectionReq)
        {
            ResponseBase<List<ApplicableServiceDto>> response = new ResponseBase<List<ApplicableServiceDto>>();
            List<ApplicableServiceDto> applicableServiceList = new List<ApplicableServiceDto>();
            applicableServiceList = await _mediator.Send(new GetStateInspectionServiceListQuery { stateInspectionReq = stateInspectionReq });


            if (applicableServiceList != null)
            {
                response.Data = applicableServiceList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// Get VIN Decode For Test
        /// </summary>
        /// <param name="VINNumber"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<JsonElement>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVINDecodeForTest(string VINNumber)
        {
            ResponseBase<JsonElement> response = new ResponseBase<JsonElement>();
            string str = "";

            // const string bingRequest = "https://dev.virtualearth.net/REST/v1/Locations/{0}/{1}/{2}/{3}/{4}?maxResults=3&key=ArEh7jvoYAk3jNH02fkigjM4xAzDtOP_ENBPmaXWLjyl304zI3Knn0hlSxRIIojx";

            const string URLstr = "https://specifications.vinaudit.com/v3/specifications?format=xml&include=attributes,equipment,recalls,warranties,colors&key=YX91WGLK7A7P2CQ&vin={0}";

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var reqUrl = string.Format(URLstr, VINNumber);
            JsonElement json1 = new JsonElement();

            using var client = new HttpClient();
            var req = (HttpWebRequest)WebRequest.Create(reqUrl);
            HttpResponseMessage response1 = await client.GetAsync(reqUrl);
            req.Method = "GET";
            req.AutomaticDecompression = DecompressionMethods.Deflate | DecompressionMethods.GZip;
            using (var response2 = await req.GetResponseAsync())
            {
                using (var streamIn = new StreamReader(response2.GetResponseStream()))
                {
                    var strResponse = streamIn.ReadToEnd();
                    str = strResponse.Replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n", "");
                    // To convert an XML node contained in string xml into a JSON string   
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(str);
                    str = string.Empty;
                    str = JsonConvert.SerializeXmlNode(doc, Formatting.None, true);
                    str = JsonConvert.SerializeXmlNode(doc);
                    json1 = System.Text.Json.JsonSerializer.Deserialize<JsonElement>(str);
                }
            }
            response.IsSuccessful = true;
            response.Data = json1;
            return new OkObjectResult(response);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<StatusDuplicateOrConflictOrder>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CheckDuplicateOrConflictOrder(DuplicateOrConflictOrderReq duplicateOrConflictOrderReq)
        {
            ResponseBase<StatusDuplicateOrConflictOrder> response = new ResponseBase<StatusDuplicateOrConflictOrder>();
            StatusDuplicateOrConflictOrder result = await _mediator.Send(new GetDuplicateOrConflictOrderDetailsQuery { reqObj = duplicateOrConflictOrderReq });
            response.Data = result;
            return new OkObjectResult(response);
        }


        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<ApplicableServiceDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CancelServiceRequest(CancelServiceRequestReq cancelServiceRequestReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = false;

            CancelServiceRequestTemplateParameters cancelSRTemplateParameters = new CancelServiceRequestTemplateParameters();
            string fromEmail = _config["PARSSetting:PARSCustomerSupportEmail"];

            MergedContent emailTemplateContent = null;
            using (var conn = _sqlContext.GetOpenConnection())
            {
                string query = @"SELECT sr.service_request_number,CONCAT(c.first_name, ' ', c.last_name) AS cs_specialist,
                                c.primary_email AS customer_support_email,c.phone_1 AS phone_number,
                                createdUa.user_name AS created_by_email,STRING_AGG(
                                CONCAT('Fleet: ', v.current_fleet_number, ', Unit: ', v.current_unit_number,
                                ', VIN: ', v.vin ), '; ') AS vehicle
                                FROM service_request sr
                                LEFT JOIN user_auth ua ON sr.css_id = ua.id
                                LEFT JOIN contact c ON ua.contact_id = c.id
                                LEFT JOIN user_auth createdUa ON createdUa.id = sr.created_by
                                LEFT JOIN service_order so ON so.service_request_id = sr.id
                                LEFT JOIN vehicle v ON v.id = so.vehicle_id
                                WHERE sr.id = @ServiceRequestId 
                                AND so.service_order_type_id = 1
                                GROUP BY sr.service_request_number,c.first_name, 
                                c.last_name, c.primary_email,  c.phone_1,  createdUa.user_name

                                UPDATE service_request SET service_request_status_reason_id = @StatusReasonId,
                                service_request_status_id = @StatusId WHERE id = @ServiceRequestId;";

                using (var multi = conn.QueryMultiple(query, new
                {
                    ServiceRequestId = cancelServiceRequestReq.service_request_id,
                    StatusId = (int)service_request_status.Cancelled,
                    StatusReasonId = (int)service_request_status_reason.CanceledByCustomer,
                    CancelationReasonId = (int)service_request_status_reason.CanceledByCustomer
                }))
                {
                    cancelSRTemplateParameters = multi.ReadFirstOrDefault<CancelServiceRequestTemplateParameters>();
                    cancelSRTemplateParameters.cancelation_reason = cancelServiceRequestReq.cancelation_reason;
                    cancelSRTemplateParameters.web_base_url = _config["appSettings:WebAppBaseURI"];
                    emailTemplateContent = await _templateMapper.MergeTemplateByCode<CancelServiceRequestTemplateParameters>
                    ("CANCEL_SERVICE_REQUEST", cancelSRTemplateParameters);
                    result = true;
                }

                //Publish Email
                SendEmail emailMessage = new SendEmail
                {
                    ToPartyEmails = new List<string>(new[] { cancelSRTemplateParameters.created_by_email }),
                    Subject = emailTemplateContent.subject + cancelSRTemplateParameters.service_request_number + cancelSRTemplateParameters.vehicle,
                    MessageBody = emailTemplateContent.body_text,
                    IsMessageHTML = emailTemplateContent.body_text.EndsWith("</html>", StringComparison.OrdinalIgnoreCase)
                };

                await _bus.Publish(emailMessage);

                if (result)
                {
                    response.Data = result;
                    response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_SERVICE_REQUEST_CANCELLED_SUCCESSFULLY");
                    return new OkObjectResult(response);
                }
                else
                {
                    response.Data = result;
                    response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_SERVICE_REQUEST_CANCELLED_ERROR");
                    return new OkObjectResult(response);
                }
            }
        }

        /// <summary>
        ///Convert Quote Request To Service Request
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<bool>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CopyQuoteRequest(CopyQuoteRequestReq req)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            Tuple<bool, bool> result = await _mediator.Send(new CopyQuoteCommand
            {
                //quote_number = req.quote_number,
                quote_id = req.quote_id

            });
            if (result.Item2)
            {
                response.Data = result.Item2;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_COPY_QUOTE_SUCCESSFULLY");
                return new OkObjectResult(response);
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.IsSuccessful = false;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_QUOTE_EXPIRED");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result.Item2;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_COPY_QUOTE_FAILED");
                return new OkObjectResult(response);
            }
        }



        #region API CONTRACT MODEL AND VALIDATORS
        class UpdateQuoteReqValidator : AbstractValidator<UpdateQuoteReq>
        {
            public UpdateQuoteReqValidator()
            {
                RuleFor(x => x.id).NotEmpty();
                RuleFor(x => x.vehicle_id).NotNull();
                RuleFor(x => x.pickup_address_type_id).NotNull();
                RuleFor(x => x.delivery_address_type_id).NotNull();
                RuleFor(x => x.quote_activation_date).NotNull();
                RuleFor(x => x.quote_expiration_date).NotNull();
            }
        }
        class CreateQuoteReqValidator : AbstractValidator<CreateQuoteReq>
        {
            public CreateQuoteReqValidator()
            {
                RuleFor(x => x.vehicle_id).NotNull();
                RuleFor(x => x.pickup_address_type_id).NotNull();
                RuleFor(x => x.delivery_address_type_id).NotNull();
                RuleFor(x => x.quote_activation_date).NotNull();
                RuleFor(x => x.quote_expiration_date).NotNull();
            }
        }
        public class SupportContactReq
        {
            public long? fmc_Id { get; set; }
            public long? fleet_id { get; set; }
        }
        class SupportContactReqValidator : AbstractValidator<SupportContactReq>
        {
            public SupportContactReqValidator()
            {
                RuleFor(x => x.fmc_Id).NotEqual(0);
                RuleFor(x => x.fleet_id).NotEqual(0);
            }
        }


        class UpdateContactToPARSReqValidator : AbstractValidator<UpdateContactToPARSReq>
        {
            public UpdateContactToPARSReqValidator()
            {
                RuleFor(x => x.id).NotEqual(0);
            }
        }
        public class UpdateContactToPARSStatusReq
        {
            public long id { get; set; }
            public bool status { get; set; }
        }
        public class UpdateAccountStatusReqValidator : AbstractValidator<UpdateContactToPARSStatusReq>
        {
            public UpdateAccountStatusReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }

        public class CopyQuoteRequestReq
        {
            public long? quote_id { get; set; }
        }

        #endregion
    }
}

