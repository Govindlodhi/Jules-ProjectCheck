﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.ServiceRequest.Queries;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.VINValidation.Command;
using PARSNextGen.Application.VINValidation.Queries;
using PARSNextGen.Domain.Common;
using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class VINDecoderController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMessageService;
        private readonly IConfiguration _config;
        public VINDecoderController(IMediator mediator, ICustomMessageService customMessageService, IConfiguration config)
        {
            _mediator = mediator;
            _customMessageService = customMessageService;
            _config = config;
        }

        #region API CONTROLLER METHODS

        /// <summary>
        /// API is used for vin validation.
        /// </summary>
        /// <param name="NhstaVinValidationReq"> vinNumber </param>
        /// <returns> VINBasicInformationDto </returns>
        /// <exception cref="Exception"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<VehicleDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> VINValidate(NhstaVinValidationReq nhstaVinValidationReq)
        {
            ResponseBase<VehicleDto> response = new ResponseBase<VehicleDto>();
            var vinNumber = nhstaVinValidationReq.VINNumber.Trim();
            var vehicle_id = nhstaVinValidationReq.vehicleId != null ? nhstaVinValidationReq.vehicleId : null;
            if (VINCheck.IsVINValid(vinNumber))
            {
                using (var client = new HttpClient())
                {
                    try
                    {
                        string url = string.Format(_config["appSettings:NhtsaApiUrl"], vinNumber);
                        HttpResponseMessage vehicleResponse = client.GetAsync(url).Result;
                        var decodedVin = JsonConvert.DeserializeObject<NhtsaVinDecodeModel>(vehicleResponse.Content.ReadAsStringAsync().Result);
                        var vinInfo = decodedVin.Results.FirstOrDefault();
                        vinInfo.SetVehicleInformation();
                        vinInfo.ValidateMake();

                        var vehicleInformation = new VINBasicInformationDto(vinNumber)
                        {
                            make = vinInfo.Make,
                            model = vinInfo.Model,
                            year = vinInfo.ModelYear,
                            vin = vinInfo.VIN,
                            raw_result = vehicleResponse.ToString(),
                            engine_type = vinInfo.EngineType,
                            body_style = vinInfo.BodyStyle,
                            vehicle_class = vinInfo.VehicleClass,
                            fuel_type_primary = vinInfo.FuelTypePrimary,
                            fuel_type_secondary = vinInfo.FuelTypeSecondary,
                            drive_type = vinInfo.DriveType,
                            gvwr = vinInfo.GVWR
                        };

                        var carType = VehicleTypeMapping.DetectCarType(vehicleInformation);
                        var vehicle = new VehicleDto();
                        if (carType != EnumTypes.VehicleType.Unknown)
                        {
                            if (vehicleInformation.make != null)
                            {
                                vehicle.make = vehicleInformation.make;
                            }
                            if (vehicleInformation.model != null)
                            {
                                vehicle.model = vehicleInformation.model;
                            }
                            if (vehicleInformation.year != null)
                            {
                                vehicle.year = int.Parse(vehicleInformation.year);
                            }
                            if (vehicleInformation.body_style != null)
                            {
                                vehicle.body_style = vehicleInformation.body_style;
                            }
                            if (vehicleInformation.engine_type != null)
                            {
                                vehicle.engine_type = vehicleInformation.engine_type;
                            }
                            if (vehicleInformation.drive_type != null)
                            {
                                vehicle.drive_type = vehicleInformation.drive_type;
                            }
                            if (vehicleInformation.gvwr != null)
                            {
                                vehicle.gvwr = vehicleInformation.gvwr;
                            }
                            if (vehicleInformation.vehicle_class != null)
                            {
                                var vehicleClassNumber = int.Parse(vehicleInformation.vehicle_class.Substring(0, 1));
                                if (vehicleClassNumber >= 3)
                                {
                                    vehicle.is_commercial_vehicle = true;
                                }
                            }
                            if (carType == EnumTypes.VehicleType.NotMatched)
                            {
                                vehicle.vehicle_type_id = null;
                            }
                            else
                            {
                                vehicle.vehicle_type_id = (long)carType;
                            }


                        }

                        #region Fuel_Type_Mapping 

                        if ((vehicleInformation.fuel_type_primary == EnumTypes.NHTSAFuelType.Gasoline.ToString() || vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Ethanol) ||
                            vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Flexible_Fuel)) && string.IsNullOrWhiteSpace(vehicleInformation.fuel_type_secondary))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
                        }
                        if (vehicleInformation.fuel_type_primary == EnumTypes.NHTSAFuelType.Diesel.ToString() && string.IsNullOrWhiteSpace(vehicleInformation.fuel_type_secondary))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Diesel;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Diesel;
                        }
                        if ((vehicleInformation.fuel_type_primary == EnumTypes.NHTSAFuelType.Gasoline.ToString() || vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Ethanol) ||
                            vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Flexible_Fuel)) && vehicleInformation.fuel_type_secondary == EnumTypes.NHTSAFuelType.Electric.ToString())
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Hybrid;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
                            vehicle.secondary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Electric;
                        }
                        if (vehicleInformation.fuel_type_primary == EnumTypes.NHTSAFuelType.Electric.ToString() && string.IsNullOrWhiteSpace(vehicleInformation.fuel_type_secondary))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Electric;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Electric;
                        }
                        if (vehicleInformation.fuel_type_primary == EnumTypes.NHTSAFuelType.Electric.ToString() && (vehicleInformation.fuel_type_secondary == EnumTypes.NHTSAFuelType.Gasoline.ToString() ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Ethanol) || vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Flexible_Fuel)))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.PH_EV;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Electric;
                            vehicle.secondary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
                        }
                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Hydrogen))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Compressed_Hydrogen;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Compressed_Hydrogen;
                        }
                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Natural_Gas))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Compressed_Natural_Gas;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Compressed_Natural_Gas;
                        }
                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.FuelCell))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.FuelCell;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.FuelCell;
                        }
                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Natural_Gas))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Liquefied_Natural_Gas;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Liquefied_Natural_Gas;
                        }
                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Petroleum_Gas))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Liquefied_Petroleum_Gas;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Liquefied_Petroleum_Gas;
                        }
                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Methanol))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Methanol;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Methanol;
                        }
                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Natural_Gas))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Natural_Gas;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Natural_Gas;
                        }

                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Ethanol))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Neat_Ethanol;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Neat_Ethanol;
                        }
                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Methanol))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Neat_Methanol;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Neat_Methanol;
                        }

                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Flexible_Fuel) && (
                            vehicleInformation.fuel_type_secondary == EnumTypes.NHTSAFuelType.Gasoline.ToString() ||
                            vehicleInformation.fuel_type_secondary == EnumTypes.NHTSAFuelType.Diesel.ToString() ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Hydrogen) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.FuelCell) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Petroleum_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Methanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Ethanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Methanol)))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
                        }

                        if (vehicleInformation.fuel_type_primary == EnumTypes.NHTSAFuelType.Gasoline.ToString() && (
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Flexible_Fuel) ||
                            vehicleInformation.fuel_type_secondary == EnumTypes.NHTSAFuelType.Diesel.ToString() ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Ethanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Hydrogen) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.FuelCell) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Petroleum_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Methanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Ethanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Methanol)))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
                        }

                        if (vehicleInformation.fuel_type_primary == EnumTypes.NHTSAFuelType.Diesel.ToString() && (
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Flexible_Fuel) ||
                            vehicleInformation.fuel_type_secondary == EnumTypes.NHTSAFuelType.Gasoline.ToString() ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Ethanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Hydrogen) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.FuelCell) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Petroleum_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Methanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Ethanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Methanol)))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Diesel;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Diesel;
                        }

                        if (vehicleInformation.fuel_type_primary == EnumTypes.NHTSAFuelType.Electric.ToString() && (
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Hydrogen) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.FuelCell) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Petroleum_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Methanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Ethanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Methanol)))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Electric;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Electric;
                        }

                        if (vehicleInformation.fuel_type_primary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Ethanol) && (
                            vehicleInformation.fuel_type_secondary == EnumTypes.NHTSAFuelType.Gasoline.ToString() ||
                            vehicleInformation.fuel_type_secondary == EnumTypes.NHTSAFuelType.Diesel.ToString() ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Hydrogen) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Compressed_Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.FuelCell) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Liquefied_Petroleum_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Methanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Natural_Gas) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Ethanol) ||
                            vehicleInformation.fuel_type_secondary == GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.NHTSAFuelType.Neat_Methanol)))
                        {
                            vehicle.fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
                            vehicle.primary_fuel_type_id = (long)EnumTypes.NHTSAFuelType.Gasoline;
                        }

                        #endregion End_Fuel_Type_Mapping

                        bool vehicleStatus = await _mediator.Send(new VerifyVehicleCommand
                        {
                            vehicleId = vehicle_id,
                            vehicle_type_id = (long)vehicle.vehicle_type_id,
                            primary_fuel_type_id = vehicle.primary_fuel_type_id,
                            secondary_fuel_type_id = vehicle.secondary_fuel_type_id,
                            make = vehicle.make,
                            model = vehicle.model,
                            year = vehicle.year,
                            body_style = vehicle.body_style,
                            engine_type = vehicle.engine_type,
                            is_verified = true,
                            drive_type = vehicle.drive_type,
                            gvwr = vehicle.gvwr
                        });

                        if (vehicle != null)
                        {
                            response.Data = vehicle;
                            response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                            return new OkObjectResult(response);
                        }
                        else                      
                            throw new BusinessException("PARS_RECORD_NOT_FOUND");
                    }
                    catch (Exception)
                    {
                        var vehicleInfo = new VehicleDto();
                        var result = new VINBasicInformationDto(vinNumber);
                        var rawResponse = DownloadDataForVin(vinNumber).Result.ToString();
                        if (!string.IsNullOrWhiteSpace(rawResponse))
                        {
                            result.raw_result = rawResponse;
                            XDocument xmlDocument = XDocument.Parse(rawResponse);
                            var vinNode = xmlDocument.Descendants("VIN").FirstOrDefault();
                            if (vinNode != null)
                            {
                                var isSuccess = vinNode.Attribute("Status").Value == "SUCCESS";
                                var isFailed = vinNode.Attribute("Status").Value == "FAILED";
                                if (isSuccess)
                                {
                                    var vehicle = xmlDocument.Descendants("Vehicle").FirstOrDefault();
                                    if (vehicle != null)
                                    {
                                        vehicleInfo.model = GetStringFromVehicle(vehicle, "Model");
                                        vehicleInfo.make = GetStringFromVehicle(vehicle, "Make");
                                        vehicleInfo.year = Convert.ToInt32(GetStringFromVehicle(vehicle, "Model Year"));
                                        vehicleInfo.body_style = GetStringFromVehicle(vehicle, "Body Style");
                                        vehicleInfo.engine_type = GetStringFromVehicle(vehicle, "Engine Type");
                                    }
                                    if (vehicleInfo != null)
                                    {
                                        response.Data = vehicleInfo;
                                        response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                                        return new OkObjectResult(response);
                                    }
                                }
                                else
                                {
                                    throw new Exception("PARS_VIN_VALIDATION_FAILED");
                                }
                            }

                        }
                        else
                            throw new Exception("PARS_RESPONSE_NULL");
                        return new OkObjectResult(result);
                    }
                }
            }
            else
            {
                throw new Exception("PARS_VIN_DECODE_FAILED");
            }

            #region Methods define for VINDecode

            static string GetStringFromVehicle(XElement vehicle, string itemKey)
            {
                var modelElement = vehicle.Descendants().FirstOrDefault(f => f.Attribute("Key") != null && f.Attribute("Key").Value == itemKey);
                if (modelElement != null)
                {
                    return modelElement.Attribute("Value").Value;
                }
                return null;
            }

            async Task<string> DownloadDataForVin(string vin)
            {
                string vinSpecificUrl = null;
                int reportFormat_Lite = int.Parse(_config["appSettings:ReportFormat_Lite"]);
                string productionFormatUrl = _config["appSettings:VINQueryProductionFormat"];
                string trilLicenseId = _config["appSettings:TrialLicenseKey"];
                //http://ws.vinquery.com/restxml.aspx?accessCode=7dbf4fbb-0851-4123-9b2f-d098f54f13b4&vin=1HGCR2F78FA147254&reportType=3

                vinSpecificUrl = string.Format(productionFormatUrl, trilLicenseId, vin, reportFormat_Lite);
                var httpClient = new HttpClient();
                string data = await httpClient.GetStringAsync(vinSpecificUrl);
                return data;
            }
            #endregion
        }

        /// <summary>
        /// Get VIN Validate From NHTSA
        /// </summary>
        /// <param name="nhstaVinValidationReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<VehicleDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVINValidateFromNHTSA(NhstaVinValidationReq nhstaVinValidationReq)
        {
            ResponseBase<VehicleDto> response = new ResponseBase<VehicleDto>();
            var vinNumber = nhstaVinValidationReq.VINNumber.Trim();
            var vehicle_id = nhstaVinValidationReq.vehicleId != null ? nhstaVinValidationReq.vehicleId : null;
            var result = await _mediator.Send(new VinValidateFromNhtsaQuery { VINNumber = vinNumber, vehicleId = vehicle_id });
            if (result != null)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// Vehicle Recall From NHTSA
        /// </summary>
        /// <param name="vehicleRecallReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<VehicleDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> VehicleRecallFromNHTSA(VehicleRecallReq vehicleRecallReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new VehicleRecallByNhtsa { vehicleRecallReq = vehicleRecallReq });
            if (result!)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }
        #endregion

        //For Pars Support
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<dynamic>), StatusCodes.Status200OK)]
        public async Task<IActionResult> VINDecode(string VINNumber)
        {
            if (VINCheck.IsVINValid(VINNumber))
            {
                using (var client = new HttpClient())
                {
                    string url = string.Format(_config["appSettings:NhtsaApiUrl"], VINNumber);
                    HttpResponseMessage vehicleResponse = client.GetAsync(url).Result;
                    JsonConvert.DeserializeObject<dynamic>(vehicleResponse.Content.ReadAsStringAsync().Result);
                    return new OkObjectResult(vehicleResponse.Content.ReadAsStringAsync().Result);
                }
            }
            else
                throw new BusinessException("PARS_VIN_DECODE_FAILED");
        }

        #region API CONTRACT MODEL AND VALIDATORS
        public class NhstaVinValidationReq
        {
            public string VINNumber { get; set; }
            public long? vehicleId { get; set; }
        }
        public class NhtsaVinValidation : AbstractValidator<NhstaVinValidationReq>
        {
            public NhtsaVinValidation()
            {
                RuleFor(x => x.VINNumber).Length(17).WithMessage("VIN must be 17 characters in length.");
                RuleFor(x => x.VINNumber).NotEmpty().WithMessage("VIN must not be empty.");
            }
        }
        #endregion        
    }
}