﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Contact.CheckDuplicateContact;
using PARSNextGen.Application.Contact.GetContactDetail.Queries;
using PARSNextGen.Application.Contact.GetContacts.Command;
using PARSNextGen.Application.Contact.GetContacts.Queries;
using PARSNextGen.Application.Contact.GetContactsMaster.Queries;
using PARSNextGen.Application.Service;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class ContactController : Controller
    {

        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMessageService;

        public ContactController(IMediator mediator, ICustomMessageService customMessageService)
        {
            _mediator = mediator;
            _customMessageService = customMessageService;
        }

        #region API CONTROLLER METHODS

        /// <summary>
        /// API to get contacts
        /// </summary>
        /// <param name="pageNo"> Page Number </param>
        /// <param name="pageSize"> Page Size</param>
        /// <returns> List of contacts. </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<ContactsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAddressBookByAccountId(long accountId)
        {
            ResponseBase<List<ContactsDto>> response = new ResponseBase<List<ContactsDto>>();
            var result = await _mediator.Send(new GetContactsQuery { account_id = accountId });
            if (result.Count > 0)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }




        /// <summary>
        /// API to get contact detail
        /// </summary>
        /// <param name="id"> contact id </param>
        /// <returns> contact detail. </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<ContactDetailDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetContactDetail(long id)
        {
            ResponseBase<ContactDetailDto> response = new ResponseBase<ContactDetailDto>();
            var contactDetail = await _mediator.Send(new GetContactDetailQuery { id = id });
            if (contactDetail != null)
            {
                response.Data = contactDetail;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }



        /// <summary>
        /// API to Get Contact Master Data
        /// </summary>
        /// <returns> List of Contact Master Data   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<ContactMasterDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetContactMasterData()
        {
            ResponseBase<List<ContactMasterDto>> response = new ResponseBase<List<ContactMasterDto>>();
            var contactDetails = await _mediator.Send(new GetContactMasterQuery { });
            if (contactDetails != null)
            {
                List<ContactMasterDto> resp = new List<ContactMasterDto>();
                resp.Add(contactDetails);
                response.Data = resp;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }



        /// <summary>
        /// API to create contact details 
        /// </summary>
        /// <param name="createContactReq"> CreateContactReq</param>
        /// <returns> Create Contact. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status201Created)]
        public async Task<IActionResult> AddNewContact(CreateContactReq createContactReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            long result = await _mediator.Send(new CreateContactCommand { createContactReq = createContactReq });

            if (result > 0)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
        }

        /// <summary>
        /// API gets check duplicate Contact
        /// </summary>
        /// <param name="vinReq"> class for Check Duplicate VIN request</param>
        /// <returns> boolean value true or false  </returns>
        /// 

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CheckDuplicateContact(ContactCheckReq contactCheckReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool isExistContact = await _mediator.Send(new CheckDuplicateContactQuery { email = contactCheckReq.email });
            if (isExistContact)
            {
                response.Data = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("CONTACT_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = false;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CONTACT_NOT_EXIST");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to update contact details 
        /// </summary>
        /// <param name="updateContactReq"> UpdateContactReq</param>
        /// <returns> Update Contact. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateContact(UpdateContactReq updateContactReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateContactCommand { updateContactReq = updateContactReq });

            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// API to update contact status 
        /// </summary>
        /// <param name="updateContactStatusReq"> UpdateContactStatusReq</param>
        /// <returns> Update Contact. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateContactStatus(UpdateContactStatusReq contactStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateContactStatusCommand
            {
                id = contactStatusReq.id,
                status = contactStatusReq.status

            });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        #endregion CreateContactCommand


        #region CONTACT API MODELS AND VALIDATIONS

        public class ContactListReq
        {
            public long? fmc_Id { get; set; }
            public long? fleet_id { get; set; }
        }

        class ContactListReqValidator : AbstractValidator<ContactListReq>
        {
            public ContactListReqValidator()
            {
                RuleFor(x => x.fmc_Id).NotEqual(0);
                RuleFor(x => x.fleet_id).NotEqual(0);
            }
        }

        public class CreateContactReqValidator : AbstractValidator<CreateContactReq>
        {
            public CreateContactReqValidator()
            {
                RuleFor(p => p.primary_email).NotNull().WithMessage(" Please Provide Email ");
                RuleFor(p => p.account_id).NotNull().NotEmpty().NotEqual(0).WithMessage(" Please Provide FMC or Fleet id ");

            }
        }

        public class ContactCheckReq
        {
            public string email { get; set; }
            //public long accountId { get; set; }
        }

        public class ContactCheckReqValidator : AbstractValidator<ContactCheckReq>
        {
            public ContactCheckReqValidator()
            {
                RuleFor(p => p.email).NotNull().WithMessage(" Please Provide Email ");
                // RuleFor(p => p.accountId).NotNull().NotEmpty().NotEqual(0).WithMessage(" Please Provide FMC or Fleet id ");

            }
        }

        //Update vehicle_attribute_configuration status Dto and Validator
        public class UpdateContactStatusReq
        {
            public long id { get; set; }
            public bool status { get; set; }
        }
        public class UpdateContactStatusReqValidator : AbstractValidator<UpdateContactStatusReq>
        {
            public UpdateContactStatusReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }

        class UpdateContactReqValidator : AbstractValidator<UpdateContactReq>
        {
            public UpdateContactReqValidator()
            {
                RuleFor(x => x.id).NotEqual(0);
            }
        }

        #endregion

    }
}
