﻿using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Account.Accounts.Queries;
using PARSNextGen.Application.OrderBatchImport;
using PARSNextGen.Application.OrderBatchImport.OrderBatchMaster;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.WheelsOrderBatchImport.Queries;
using PARSNextGen.Contracts;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static PARSNextGen.Domain.Common.EnumTypes;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class OrderBatchImportController : Controller
    {
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;
        private readonly IConfiguration _config;
        private readonly ICurrentUserService _currentUserContext;
        private readonly IBus _bus;
        public OrderBatchImportController(ILogger<OrderBatchImportController> logger, IMediator mediator,
            ICustomMessageService customMsgSvc, IConfiguration config, ISqlContext dbCntx,
            IAzureDocumentService azureService, IAzureMapService azureMapService, IBus bus, ICurrentUserService currentUserContext)
        {
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
            _config = config;
            _currentUserContext = currentUserContext;
            _bus = bus;
        }

        #region MASTER API FOR ORDER BATCH IMPORT 

        /// <summary>
        /// Get account list for order batch import
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAccountListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountListForOrderBatch()
        {
            ResponseBase<List<OrderBatchMasterBaseEntity>> response = new();
            var accountList = await _mediator.Send(new AccountListForOrderBatchQuery { });
            if (accountList.Count > 0)
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            else
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");

            response.Data = accountList;
            return new OkObjectResult(response);
        }

        /// <summary>
        /// Get FMC list for order batch import
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<OrderBatchMasterBaseEntity>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFMCListForOrderBatch()
        {
            ResponseBase<List<OrderBatchMasterBaseEntity>> response = new();
            var FMCList = await _mediator.Send(new GetAccountFMCsForOrderBatchQuery { });

            if (FMCList.Count > 0)
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            else
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");

            response.Data = FMCList;
            return new OkObjectResult(response);
        }

        /// <summary>
        /// Get Fleet list for order batch import
        /// </summary>
        /// <param name="fmc_id"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAccountListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFleetListForOrderBatch(long fmc_id)
        {
            ResponseBase<List<OrderBatchMasterBaseEntity>> response = new();
            List<OrderBatchMasterBaseEntity> fleetList = new();

            if (fmc_id > 0)
                fleetList = await _mediator.Send(new FleetListForOrderBatchQuery { fmc_id = fmc_id });

            if (fleetList.Count > 0)
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            else
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");

            response.Data = fleetList;
            return new OkObjectResult(response);
        }

        /// <summary>
        /// Get account FMCs list for order batch
        /// </summary>
        /// <param name="account_id"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAccountListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountFMCsListForOrderBatch(long account_id)
        {
            ResponseBase<List<OrderBatchMasterBaseEntity>> response = new();
            List<OrderBatchMasterBaseEntity> FMCList = new();

            if (account_id > 0)
                FMCList = await _mediator.Send(new GetFMCListForOrderBatchQuery { account_id = account_id });

            if (FMCList.Count > 0)
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            else
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");

            response.Data = FMCList;
            return new OkObjectResult(response);
        }

        /// <summary>
        /// Get contact list by given account id, for order batch import
        /// </summary>
        /// <param name="account_id"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAccountListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetContactListForOrderBatch(long account_id)
        {
            ResponseBase<List<OrderBatchMasterBaseEntity>> response = new();
            List<OrderBatchMasterBaseEntity> contactList = new();

            if (account_id > 0)
                contactList = await _mediator.Send(new ContactListForOrderBatchQuery { id = account_id });

            if (contactList.Count > 0)
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            else
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");

            response.Data = contactList;
            return new OkObjectResult(response);
        }

        /// <summary>
        /// Get CS specialist list for order batch import
        /// </summary>
        /// <param name="account_id"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAccountListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCSSpecialistListForOrderBatch()
        {
            ResponseBase<List<OrderBatchMasterBaseEntity>> response = new();
            List<OrderBatchMasterBaseEntity> csList = new();

            csList = await _mediator.Send(new CSCSSpecialistListForOrderBatchQuery { });

            if (csList.Count > 0)
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
            else
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");

            response.Data = csList;
            return new OkObjectResult(response);
        }

        #endregion

        #region ORDER BATCH IMPORT APIs

        /// <summary>
        /// API to create order btch import record
        /// </summary>
        /// <param name="orderBatchImportReq"> OrderBatchImportReq</param>
        /// <returns> OrderBatchImport </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateOrderBatchImport([FromForm] CreateOrderBatchImportReq orderBatchImportReq)
        {
            if (_currentUserContext.AccountId == (long)Account.PARS)
            {
                ResponseBase<bool> response = new();
                CommonMethodsForBatchImport commonMethodsForBatchImport = new(_config);

                List<string> filesName = commonMethodsForBatchImport.SaveFileToAzureStorage(orderBatchImportReq.file);

                List<int> result = await _mediator.Send(new CreateOrderBatchImportCommand
                {
                    orderBatchImportReq = orderBatchImportReq,
                    filesName = filesName
                });

                if (result != null && result.Count > 0)
                {
                    var sendEndpoint = await _bus.GetSendEndpoint(new Uri($"{_config["AzureBusSettings:batchImportQueueURL"]}"));
                    foreach (var id in result)
                        await sendEndpoint.Send(new MessageBase { RecordId = id });

                    response.Data = true;
                    response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                {
                    if (filesName.Count > 0)
                        commonMethodsForBatchImport.DeleteFileFromAzureStorage(filesName);
                    throw new BusinessException("PARS_CREATION_FAILURE");
                }
            }
            else
            {
                throw new BusinessException("PARS_BULK_RECORD_PERMISSION_DENIED");
            }
        }

        /// <summary>
        /// API to get order batch import list 
        /// </summary>
        /// <returns> OrderBatchImportDto </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<OrderBatchImportDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetOrderBatchImportList(long filterId)
        {
            ResponseBase<List<OrderBatchImportDto>> response = new ResponseBase<List<OrderBatchImportDto>>();
            var result = await _mediator.Send(new OrderBatchImportListQuery { filterId = filterId });

            if (result != null)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to get list of order batch import row
        /// </summary>
        /// <returns> OrderBatchImportDto </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<OrderBatchRowData>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetOrderBatchRowList(long batchId, long? filterId)
        {
            ResponseBase<OrderBatchRowData> response = new ResponseBase<OrderBatchRowData>();
            var result = await _mediator.Send(new OrderBatchRowListQuery { batchId = batchId, filterId = filterId });
            if (result != null)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to get batch import details 
        /// </summary>
        /// <param name="orderBatchImportReq"> OrderBatchImportReq</param>
        /// <returns> OrderBatchImport </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<OrderBatchRowEditorDtos>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetOrderBatchRowErrorDetails(long id)
        {
            ResponseBase<OrderBatchRowEditorDtos> response = new ResponseBase<OrderBatchRowEditorDtos>();
            var result = await _mediator.Send(new BatchRowErrorDetailsQuery { id = id });
            if (result != null)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to get download uploded batch file
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<string>), StatusCodes.Status200OK)]
        public async Task<IActionResult> DownloadUplodedBatchFile(string fileName)
        {
            ResponseBase<string> response = new();
            CommonMethodsForBatchImport commonMethodsForBatchImport = new(_config);
            string base64StringFile = await commonMethodsForBatchImport.GetBase64FilesFromAzureStorage(fileName);
            if (!string.IsNullOrEmpty(base64StringFile))
            {
                response.Data = "data:application/octet-stream;base64," + base64StringFile;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_DOCUMENT_DOWNLOAD_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_FILE_NOT_AVAILABE_IN_STORAGE");
        }

        /// <summary>
        /// API to get update order batch import row
        /// </summary>
        /// <param name="updateOrderImportRowReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateOrderBatchImportRowDetails(UpdateOrderImportRowReq updateOrderImportRowReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateOrderBatchImportRowCommand { updateOrderImportRowReq = updateOrderImportRowReq });
            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// API to get resubmit order batch import row
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ResubmitOrderBatchImportRow(long id)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new ReSubmitOrderBatchRowCommand { id = id });
            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_ORDER_GEN_SUBMIT_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_ORDER_GEN_RESUBMIT_FAILED");
        }

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ReProcessAllBatchImportRows(long id)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            try
            {
                bool result = await _mediator.Send(new ReProcessOrderBatchRowCommand { id = id });

                if (result)
                {
                    response.Data = result;
                    response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("ROW_REPROCESSING_REQUEST_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                    throw new BusinessException("PARS_ROW_REPROCESSING_REQUEST_FAILED");
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("PARS_"))
                    throw new BusinessException(ex.Message);
                else throw new Exception(ex.Message);
            }
        }
        #endregion

        /* NOT IN USE CODE

        /// <summary>
        /// API to get Order Batch Import details 
        /// </summary>
        /// <param name="orderBatchImportReq"> OrderBatchImportReq</param>
        /// <returns> OrderBatchImport </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<OrderBatchImportDetailDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetOrderBatchImportDetails(long import_id)
        {
            ResponseBase<OrderBatchImportDetailDto> response = new ResponseBase<OrderBatchImportDetailDto>();
            var result = await _mediator.Send(new OrderBatchImportDetailQuery
            {
                importId = import_id
            });
            if (result != null)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }

        }

        /// <summary>
        /// API to create Order Batch Import details 
        /// </summary>
        /// <param name="orderBatchImportReq"> OrderBatchImportReq</param>
        /// <returns> OrderBatchImport </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateOrderBatchImport(UpdateOrderBatchImportReq orderBatchImportReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            bool result = await _mediator.Send(new UpdateOrderBatchImportCommand
            {
                updateOrderBatchImportReq = orderBatchImportReq
            });
            if (result)
            {
                response.Data = orderBatchImportReq.id;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }

        }

        /// <summary>
        /// API to create Order Batch Import Row details 
        /// </summary>
        /// <param name="orderBatchImportRowReq"> CreateOrderImportRowReq</param>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateOrderBatchImportRow(CreateOrderImportRowReq orderBatchImportRowReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new CreateOrderBatchImportRowCommand
            {
                createOrderImportRowReq = orderBatchImportRowReq
            });
            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }

        }

        /// <summary>
        /// API is being used for VIN Check 
        /// </summary>
        /// <param name="orderBatchImportRowReq"> CreateOrderImportRowReq</param>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> OrderImportVinCheck(OrderImportVINCheckReq req)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = true;
            int count = 0;
            if (req.vinNumber != null)
            {
                foreach (var vin in req.vinNumber)
                {
                    if (VINCheck.IsVINValid(vin.vin_number))
                    {
                        using (var con = _dbCntx.GetOpenConnection())
                        {
                            DynamicParameters dp = new DynamicParameters();
                            dp.Add("@id", vin.batch_row_id);
                            string userAuthQuery = @"Update order_batch_row set vin_check_status = 1, is_vehicle_varified = 1 where id = @id ";
                            var updateUserAuth = await con.ExecuteAsyncWithRetry(userAuthQuery, dp, commandType: CommandType.Text);
                            //if (updateUserAuth > 0)
                            //    result = updateUserAuth > 0 ? true : false;
                            if (updateUserAuth > 0)
                            {
                                DynamicParameters dps = new DynamicParameters();
                                // dp.Add("@updatedOn", DateTime.UtcNow);
                                dps.Add("@import_id", req.import_id);
                                dps.Add("@updated_by", _currentUserContext.LoggedInUserId);
                                //var updaeBatchQuery = @" update order_batch_import set updated_on = getutcdate(), updated_by = @updated_by where id = @id ";
                                var updaeBatchQuery = @"sp_update_batch_import_date";
                                var updateBatchImport = await con.ExecuteAsyncWithRetry(updaeBatchQuery, dps, commandType: CommandType.StoredProcedure);

                            }
                        }
                    }
                    else
                        count++;
                }
            }
            if (count == 0)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_VERIFIED");
                return new OkObjectResult(response);
            }
            else if (count > 0)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CERTAIN_RECORDS_NOT_VERIFIED");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORDS_NOT_VERIFIED");
                return new OkObjectResult(response);
            }

        }

        /// <summary>
        /// API to Download Order Batch Import File 
        /// </summary>
        /// <param name="req"> DownloadOrderBatchFileReq</param>
        /// <returns> DownloadOrderBatchImportFileDto </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<DownloadOrderBatchImportFileDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> DownloadBatchImportFile(DownloadOrderBatchFileReq req)
        {
            ResponseBase<DownloadOrderBatchImportFileDto> response = new ResponseBase<DownloadOrderBatchImportFileDto>();
            DownloadOrderBatchImportFileDto fileDto = new DownloadOrderBatchImportFileDto();
            if (req.id != 0)
            {
                using (var con = _dbCntx.GetOpenConnection())
                {
                    DynamicParameters dp = new DynamicParameters();
                    var query = @"SELECT import_file_url as file_url,import_file_name as file_name from order_batch_import where id = @Id ";
                    dp.Add("@Id", req.id);

                    fileDto = await con.QueryFirstOrDefaultAsyncWithRetry<DownloadOrderBatchImportFileDto>(query, dp, commandType: CommandType.Text);
                    if (fileDto != null)
                    {
                        string fileURl = string.Empty;
                        string fileName = string.Empty;
                        //if(!string.IsNullOrWhiteSpace(fileDto.file_name))
                        //    fileName = fileDto.file_name;
                        if (!string.IsNullOrWhiteSpace(fileDto.file_url))
                            fileURl = fileDto.file_url;
                        if (!string.IsNullOrWhiteSpace(fileURl))
                        {
                            var downloadDoc = await _azureService.DownloadOrderBatchFile(fileURl, fileName);
                            if (downloadDoc != null)
                            {
                                response.Data = downloadDoc;
                                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_DOCUMENT_DOWNLOAD_SUCCESS");
                                return new OkObjectResult(response);
                            }
                            else
                                throw new BusinessException("PARS_DOCUMENT_DOWNLOAD_FAILURE");
                        }
                    }
                    else
                        throw new BusinessException("PARS_DOCUMENT_DOWNLOAD_FAILURE");

                }
                throw new BusinessException("PARS_DOCUMENT_DOWNLOAD_FAILURE");
            }
            else
                throw new BusinessException("PARS_DOCUMENT_DOWNLOAD_FAILURE");

        }

        /// <summary>
        /// API is being used for Pikcup Address Verify
        /// </summary>
        /// <param name="orderBatchImportRowReq"> CreateOrderImportRowReq</param>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> OrderImportPickupAddressVerify(BatchImportAddressVarifyReq req)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = true;
            int count = 0;
            if (req.addresses != null)
            {
                foreach (var row in req.addresses)
                {
                    VerifyAddressReq verifyAddressReq = new VerifyAddressReq();
                    verifyAddressReq.AddressLine1 = row.AddressLine1;
                    verifyAddressReq.CountryCode = row.CountryCode;
                    verifyAddressReq.City = row.City;
                    verifyAddressReq.State = row.State;
                    verifyAddressReq.PostalCode = row.PostalCode;
                    verifyAddressReq.Country = row.Country;
                    if (row.County == "United States")
                        verifyAddressReq.CountryCode = "US";
                    if (row.County == "Canada")
                        verifyAddressReq.CountryCode = "CAN";
                    verifyAddressReq.County = row.County;
                    verifyAddressReq.StateId = row.StateId;
                    verifyAddressReq.CountryId = row.CountryId;
                    var address = await _azureMapService.VerifyAddress(verifyAddressReq);
                    if (address is not null)
                    {
                        if (address.verification_status != (long)Verification_Status.Not_Verified && address.verification_status != 0)
                        {
                            using (var con = _dbCntx.GetOpenConnection())
                            {
                                DynamicParameters dp = new DynamicParameters();
                                dp.Add("@id", row.batch_row_id);
                                string userAuthQuery = @"Update order_batch_row set is_verified_location1_address_varified = 1 where id = @id ";
                                var updateUserAuth = await con.ExecuteAsyncWithRetry(userAuthQuery, dp, commandType: CommandType.Text);
                                //if (updateUserAuth > 0)
                                //    result = updateUserAuth > 0 ? true : false;
                                if (updateUserAuth > 0)
                                {
                                    DynamicParameters dps = new DynamicParameters();
                                    // dp.Add("@updatedOn", DateTime.UtcNow);
                                    dps.Add("@import_id", req.import_id);
                                    dps.Add("@updated_by", _currentUserContext.LoggedInUserId);
                                    //var updaeBatchQuery = @" update order_batch_import set updated_on = getutcdate(), updated_by = @updated_by where id = @id ";
                                    var updaeBatchQuery = @"sp_update_batch_import_date";
                                    var updateBatchImport = await con.ExecuteAsyncWithRetry(updaeBatchQuery, dps, commandType: CommandType.StoredProcedure);

                                }
                            }
                        }
                        else
                            count++;
                    }
                }
            }
            if (count == 0)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_VERIFIED");
                return new OkObjectResult(response);
            }
            else if (count > 0)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CERTAIN_RECORDS_NOT_VERIFIED");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORDS_NOT_VERIFIED");
                return new OkObjectResult(response);
            }

        }

        /// <summary>
        /// API is being used for Delivery Address Verify
        /// </summary>
        /// <param name="orderBatchImportRowReq"> CreateOrderImportRowReq</param>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> OrderImportDeliveryAddressVerify(BatchImportAddressVarifyReq req)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = true;
            int count = 0;
            if (req.addresses != null)
            {
                foreach (var row in req.addresses)
                {
                    VerifyAddressReq verifyAddressReq = new VerifyAddressReq();
                    verifyAddressReq.AddressLine1 = row.AddressLine1;
                    verifyAddressReq.CountryCode = row.CountryCode;
                    verifyAddressReq.City = row.City;
                    verifyAddressReq.State = row.State;
                    verifyAddressReq.PostalCode = row.PostalCode;
                    verifyAddressReq.Country = row.Country;
                    if (row.County == "United States")
                        verifyAddressReq.CountryCode = "US";
                    if (row.County == "Canada")
                        verifyAddressReq.CountryCode = "CAN";
                    verifyAddressReq.County = row.County;
                    verifyAddressReq.StateId = row.StateId;
                    verifyAddressReq.CountryId = row.CountryId;

                    var address = await _azureMapService.VerifyAddress(verifyAddressReq);
                    if (address is not null)
                    {
                        if (address.verification_status != (long)Verification_Status.Not_Verified && address.verification_status != 0)
                        {
                            using (var con = _dbCntx.GetOpenConnection())
                            {
                                DynamicParameters dp = new DynamicParameters();
                                dp.Add("@id", row.batch_row_id);
                                string userAuthQuery = @"Update order_batch_row set is_verified_location2_address_varified = 1 where id = @id ";
                                var updateUserAuth = await con.ExecuteAsyncWithRetry(userAuthQuery, dp, commandType: CommandType.Text);
                                //if (updateUserAuth > 0)
                                //    result = updateUserAuth > 0 ? true : false;
                                if (updateUserAuth > 0)
                                {
                                    DynamicParameters dps = new DynamicParameters();
                                    // dp.Add("@updatedOn", DateTime.UtcNow);
                                    dps.Add("@import_id", req.import_id);
                                    dps.Add("@updated_by", _currentUserContext.LoggedInUserId);
                                    //var updaeBatchQuery = @" update order_batch_import set updated_on = getutcdate(), updated_by = @updated_by where id = @id ";
                                    var updaeBatchQuery = @"sp_update_batch_import_date";
                                    var updateBatchImport = await con.ExecuteAsyncWithRetry(updaeBatchQuery, dps, commandType: CommandType.StoredProcedure);

                                }
                            }
                        }
                        else
                            count++;
                    }
                }
            }
            if (count == 0)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_VERIFIED");
                return new OkObjectResult(response);
            }
            else if (count > 0)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CERTAIN_RECORDS_NOT_VERIFIED");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORDS_NOT_VERIFIED");
                return new OkObjectResult(response);
            }

        }

        /// <summary>
        /// API is being used for Create Service/Quote Request using batch import row
        /// </summary>
        /// <param name="batchGenerateReq"> OrderBatchGenerateReq</param>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GenerateServiceRequestOrderBatch(OrderBatchGenerateReq batchGenerateReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = false;
            /*
            List<CreateNewServiceRequestReq> serviceRequestReqsList = new List<CreateNewServiceRequestReq>();

            #region GetApplicableAgreement

            var agreementDetails = await _mediator.Send(new GetApplicableAgreementQuery
            {
                fmc_id = batchGenerateReq.fmc_id,
                fleet_id = batchGenerateReq.fleet_id
            });
            if (agreementDetails == null)
                throw new BusinessException("PARS_CREATION_FAILURE");

            #endregion EndApplicableAgreement

            #region GetOrderBatchRowList

            var resultList = await _mediator.Send(new OrderBatchRowListQuery { id = batchGenerateReq.import_id });

            #endregion EndGetOrderBatchRowList

            if (resultList.Count > 0)
            {
                Tuple<bool, bool> isServiceReqCreate = new Tuple<bool, bool>(false, false);
                int processed = 1;
                int failure = 0;
                foreach (var req in resultList)
                {
                    //serviceRequestReqsList = new List<CreateNewServiceRequestReq>();

                    if (req.error_message != null)
                    {
                        failure++;
                        continue;
                    }
                    #region CheckIfRecordAlreadyCreatedByBatchRow

                    using(var con = _dbCntx.GetOpenConnection())
                    {
                        var query = @"Select * from service_request where order_batch_row_id = " + req.id + "";
                        int isRecordExists = await con.ExecuteScalarAsync<int>(query, commandType: CommandType.Text);
                        if (isRecordExists > 0)
                        {
                            long? orderBatchRowId = req.id; ;
                            string errorMsg = "Record is already created by Batch Row";
                            bool updateOrderBatchRow = await _mediator.Send(new UpdateOrderBatchErrorMessageCommand { orderBatchImportId = (long)orderBatchRowId, errorMessage = errorMsg });
                            continue;
                        }
                    }

                    #endregion

                    #region GetSupportContactList

                    var supportContact = await _mediator.Send(new GetSupportContactsOnRequestQuery
                    {
                        fmc_id = batchGenerateReq.fmc_id,
                        fleet_id = batchGenerateReq.fleet_id
                    });
                   

                    #endregion

                    #region GetMoveTypeThroughPrefrence

                    #region GetMoveTypeThroughPrefrenceModel

                    QuoteRequestServiceReq quoteRequestServiceReq = new QuoteRequestServiceReq();
                    quoteRequestServiceReq.transportation_type_id = req.transportation_type_id;
                    quoteRequestServiceReq.fmc_id = batchGenerateReq.fmc_id;
                    quoteRequestServiceReq.fleet_id = batchGenerateReq.fleet_id;
                    if (agreementDetails.agreement_id != 0)
                        quoteRequestServiceReq.agreement_id = agreementDetails.agreement_id;
                    if (agreementDetails.agreement_type_id != 0)
                        quoteRequestServiceReq.agreement_id = agreementDetails.agreement_type_id;
                    quoteRequestServiceReq.pars_perform_inspection = agreementDetails.pars_perform_inspection;
                    quoteRequestServiceReq.currency_id = agreementDetails.currency_id;
                    quoteRequestServiceReq.event_type_id = (long)EnumTypes.Event_Type.transport_preferences;
                    quoteRequestServiceReq.price_list_id = agreementDetails.price_list_id;
                    quoteRequestServiceReq.vehicle_type_id = (long)req.vehicle_type_id;
                    //quoteRequestServiceReq.fuel_type_id = req.vehicle_fuel_type_id;
                    quoteRequestServiceReq.fuel_type_id = 1;
                    //quoteRequestServiceReq.primary_fuel_type_id = req.primary_fuel_type_id;
                    quoteRequestServiceReq.primary_fuel_type_id = 1;
                    quoteRequestServiceReq.has_location1_date_constraints = (bool)req.has_location1_date_constraints;
                    quoteRequestServiceReq.location1_postal_code = req.location1_postal_code;
                    quoteRequestServiceReq.location1_address_type_id = req.location1_address_type_id;
                    quoteRequestServiceReq.location2_address_type_id = req.location2_address_type_id;
                    quoteRequestServiceReq.location2_postal_code = req.location2_postal_code;
                    quoteRequestServiceReq.location1_state_id = req.location1_state_id;
                    quoteRequestServiceReq.location2_state_id = req.location2_state_id;
                    quoteRequestServiceReq.location1_country_id = req.location1_country_id;
                    quoteRequestServiceReq.location2_country_id = req.location2_country_id;
                    if(req.location1_storage_id != null)
                        quoteRequestServiceReq.location1_storage_id = req.location1_storage_id;
                    quoteRequestServiceReq.location2_storage_id = req.location2_storage_id;
                    quoteRequestServiceReq.location1_date_constraint_type_id = req.location1_date_constraints_type_id;
                    quoteRequestServiceReq.requested_location1_date = req.location1_requested_date;

                    quoteRequestServiceReq.has_location2_date_constraints = (bool)req.has_location2_date_constraints;
                    quoteRequestServiceReq.location2_date_constraints_type_id = req.location2_date_constraints_type_id;
                    quoteRequestServiceReq.requested_location2_to_date = req.location2_requested_date;
                    quoteRequestServiceReq.bill_to = agreementDetails.default_bill_to_id;
                    quoteRequestServiceReq.location1_is_vip_contact = (bool)req.is_location1_vip_contact;
                    quoteRequestServiceReq.location1_time_zone_id = req.location1_time_zone_id;
                    quoteRequestServiceReq.has_location1_sensitivities = (bool)req.has_location1_sensitivities;
                    quoteRequestServiceReq.location1_date_sensitivities = req.location1_sensitivities_date;
                    quoteRequestServiceReq.location1_sensitivity_type_id = req.location1_sensitivity_type_id;

                    quoteRequestServiceReq.location2_is_vip_contact = (bool)req.location2_vip_contact;
                    quoteRequestServiceReq.location2_time_zone_id = req.location2_time_zone_id;
                    quoteRequestServiceReq.has_location2_sensitivities = (bool)req.has_location2_sensitivities;
                    quoteRequestServiceReq.location2_date_sensitivities = req.location1_sensitivities_date;
                    quoteRequestServiceReq.location2_sensitivity_type_id = req.location2_sensitivity_type_id;

                    quoteRequestServiceReq.can_pars_issue_a_temp_tag = (bool)req.is_pars_to_issue_a_temp_tag;
                    //quoteRequestServiceReq.is_inspection_be_needed = (bool)req.is_prior_inspection_required;

                    //quoteRequestServiceReq.do_not_complete_inspection_if_required = (bool)req.do_not_complete_inspection_if_required;
                    quoteRequestServiceReq.location1_towing_required = (bool)req.location1_towing_required;
                    quoteRequestServiceReq.vehicle_repossession_required = (bool)req.vehicle_repossession_required;
                    //quoteRequestServiceReq.is_vehicle_at_impound = (bool)req.is_vehicle_at_impound;
                    //quoteRequestServiceReq.service_notification_icon = (long)req.service_notification_icon;
                    quoteRequestServiceReq.does_the_vehicle_have_current_registration = req.does_the_vehicle_have_current_registration;
                    quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r = req.do_you_want_pars_to_handle_t_n_r;
                    quoteRequestServiceReq.will_you_send_the_plates_to_fleet_driver = req.will_you_send_the_plates_to_fleet_driver;
                    quoteRequestServiceReq.is_pars_to_issue_a_temp_tag = req.is_pars_to_issue_a_temp_tag;
                    quoteRequestServiceReq.new_vehicle_never_registered = req.new_vehicle_never_registered;
                    quoteRequestServiceReq.do_you_want_pars_to_delay_delivery = req.do_you_want_pars_to_delay_delivery;
                    quoteRequestServiceReq.requested_t_n_r_service_type_id = req.requested_t_n_r_service_type_id;
                    //quoteRequestServiceReq.is_commercial_vehicle = req.is_commercial_vehicle;
                    quoteRequestServiceReq.vehicle_license_state_id = req.licence_state_id;
                    int number = int.Parse(req.vehicle_year);
                    quoteRequestServiceReq.year = number;

                    #endregion EndGetMoveTypeThroughPrefrenceModel
                    GetMoveTypeDto moveType = new GetMoveTypeDto();
                    try
                    {
                       moveType = await _mediator.Send(new GetMoveTypeQuery { moveTypeReq = quoteRequestServiceReq });
                    }
                    catch(Exception ex) 
                    {
                        long? orderBatchRowId = req.id; ;
                        string errorMsg = ex.Message.ToString();
                        bool updateOrderBatchRow = await _mediator.Send(new UpdateOrderBatchErrorMessageCommand { orderBatchImportId = (long)orderBatchRowId, errorMessage = errorMsg });
                        continue;
                    }


                    #endregion EndGetMoveTypeThroughPrefrence

                    #region GetExtraServices
                    List<long?> service_id = new List<long?>();
                    List<ApplicableServiceDto> getExtraServices = new List<ApplicableServiceDto>();
                    string[] services = null;
                    if(req.product!=null)
                    {
                        services = req.product.Split(';');
                        foreach (string service in services)
                        {
                            //long serviceId = GetServiceId(service);

                            if (_serviceDictionary.TryGetValue(service.Trim(), out var id))
                                service_id.Add(id);

                            //service_id.Add(serviceId);
                        }

                        getExtraServices = await _mediator.Send(new StateInspectionsServicesQuery { price_list_id = agreementDetails.price_list_id, service_id = service_id });

                    }

                    #endregion

                    #region GetApplicableServices
                    List<ApplicableServiceDto> applicableServiceList = new List<ApplicableServiceDto>();

                    #region get default services
                    PreferenceReq preferenceReq = new PreferenceReq();
                    preferenceReq.agreement_id = agreementDetails.agreement_id;
                    preferenceReq.category_id = (long)EnumTypes.Category_Types.service_request;
                    preferenceReq.event_type_id = 1;
                    preferenceReq.rule_type_id = (long)EnumTypes.Rule_Type.Evaluation;
                    var servicesListReq = await _mediator.Send(new GetPreferencesListQuery { preferenceReq = preferenceReq });

                    #region RequestModel 

                    Application.Utility.Preference.Models.service_request sr_request = new Application.Utility.Preference.Models.service_request();
                    sr_request.vehicle_type = (int)req.vehicle_type_id;
                    sr_request.primary_fuel_type = (int)req.primary_fuel_type_id;
                    sr_request.fuel_type = (int)req.vehicle_fuel_type_id;

                    if (quoteRequestServiceReq.transportation_type_id == (long)EnumTypes.transportation_type.Auto_Carrier)
                        sr_request.transportation_type_id = (int)EnumTypes.transportation_type.Auto_Carrier;
                    else
                        sr_request.transportation_type_id = (int)EnumTypes.transportation_type.Driveaway;

                    sr_request.retail = quoteRequestServiceReq.retail;
                    if (quoteRequestServiceReq.location1_address_type_id != null)
                        sr_request.pickup_address_type = (int)req.location1_address_type_id;


                    if (quoteRequestServiceReq.location1_state_id != null)
                        sr_request.pickup_state = (int)req.location1_state_id;
                    sr_request.pickup_postal_code = req.location1_postal_code;

                    if (quoteRequestServiceReq.location1_country_id != null)
                        sr_request.pickup_country = (int)req.location1_country_id;


                    if (quoteRequestServiceReq.location1_storage_id != null)
                        sr_request.pickup_storage = (int)req.location1_storage_id;

                    sr_request.has_pickup_date_constraints = (bool)req.has_location1_date_constraints;

                    if (quoteRequestServiceReq.location1_date_constraint_type_id != null)
                        sr_request.pickup_date_constraint_type_id = (int)req.location1_date_constraints_type_id;

                    if (quoteRequestServiceReq.location2_address_type_id != null)
                        sr_request.delivery_address_type = (int)req.location2_address_type_id;

                    if (quoteRequestServiceReq.location2_state_id != null)
                        sr_request.delivery_state = (int)req.location2_state_id;
                    //sr_request.is_verify_delivery_state = req.is_verify_location2_state;
                    sr_request.delivery_postal_code = req.location2_postal_code;
                    //sr_request.is_verify_delivery_postal_code = req.is_verify_location2_postal_code;

                    if (quoteRequestServiceReq.location2_country_id != null)
                        sr_request.delivery_country = (int)req.location2_country_id;
                    //sr_request.is_verify_delivery_country = req.is_verify_location2_country;

                    if (quoteRequestServiceReq.location2_storage_id != null)
                        sr_request.delivery_storage = (int)req.location2_storage_id;
                    //sr_request.has_delivery_date_constraints = req.has_location2_date_constraints;

                    if (quoteRequestServiceReq.location2_date_constraints_type_id != null)
                        sr_request.delivery_date_constraints_type = (int)req.location2_date_constraints_type_id;

                    if (quoteRequestServiceReq.bill_to != null)
                        sr_request.bill_to = (int)req.location1_address_type_id;
                    sr_request.pickup_is_vip_contact = (bool)req.is_location1_vip_contact;

                    if (quoteRequestServiceReq.location1_time_zone_id != null)
                        sr_request.pickup_time_zone = (int)req.location1_time_zone_id;
                    sr_request.has_pickup_sensitivities = (bool)req.has_location1_sensitivities;
                    //sr_request.pickup_date_sensitivities = quoteRequestServiceReq.pickup_date_sensitivities;

                    if (quoteRequestServiceReq.location1_sensitivity_type_id != null)
                        sr_request.pickup_sensitivity_type = (int)quoteRequestServiceReq.location1_sensitivity_type_id;
                    sr_request.delivery_is_vip_contact = (bool)req.location2_vip_contact;

                    if (quoteRequestServiceReq.location2_time_zone_id != null)
                        sr_request.delivery_time_zone = (int)req.location2_time_zone_id;
                    sr_request.has_delivery_sensitivities = (bool)req.has_location2_sensitivities;

                    if (quoteRequestServiceReq.location2_sensitivity_type_id != null)
                        sr_request.delivery_sensitivity_type = (int)req.location2_sensitivity_type_id;

                    sr_request.can_pars_issue_a_temp_tag = (bool)req.is_pars_to_issue_a_temp_tag;
                    //sr_request.is_inspection_be_needed = req.is_inspection_be_needed;
                    //sr_request.do_not_complete_inspection_if_required = (bool)req.do_not_complete_inspection_if_required;
                    sr_request.pickup_towing_required = (bool)req.location1_towing_required;
                    sr_request.vehicle_repossession_required = (bool)req.vehicle_repossession_required;
                    //sr_request.is_vehicle_at_impound = (bool)req.is_vehicle_at_impound;
                    #endregion

                    #region VEHICLE PLATE STATUS
                    sr_request.is_new_vehicle_never_registered = false;
                    sr_request.plates_are_expired_or_misplaced = false;
                    sr_request.do_you_want_pars_to_handle_t_n_r = false;
                    sr_request.is_pars_to_issue_a_temp_tag = false;
                    sr_request.is_renewal = false;
                    sr_request.is_transfer = false;
                    sr_request.is_new_vehicle_never_registered = false;
                    sr_request.is_plate_replacement = false;

                    if (quoteRequestServiceReq.event_type_id == (long)EnumTypes.Event_Type.t_n_r_preferences)
                    {
                        #region REMOVE T&R REALTED SERVICES

                        // Remove Initial_T_and_R -27 
                        int? indx = null;
                        indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Initial_T_and_R);
                        if (indx != null && indx != -1)
                        {
                            quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)indx);
                            quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Initial_T_and_R);
                        }

                        //Remove Shipping_Handling_Fee
                        indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Shipping_Handling_Fee);
                        if (indx != null && indx != -1)
                        {
                            quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => (x.service_id == (long)EnumTypes.Service.Shipping_Handling_Fee && x.dependent_service_id == null));
                        }

                        //Remove Tags_30_Day_Temp
                        indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Tags_30_Day_Temp);
                        if (indx != null && indx != -1)
                        {
                            quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)indx);
                            quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Tags_30_Day_Temp);
                        }

                        //Remove Registration_Renewal
                        indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Registration_Renewal);
                        if (indx != null && indx != -1)
                        {
                            quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)indx);
                            quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Registration_Renewal);
                        }

                        //Remove Transfer
                        indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Transfer);
                        if (indx != null && indx != -1)
                        {
                            quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)indx);
                            quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Transfer);
                        }

                        //Remove Plate Replacement
                        indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Plate_Replacement);
                        if (indx != null && indx != -1)
                        {
                            quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)indx);
                            quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Plate_Replacement);
                        }

                        #endregion

                        #region T&R Related Fields

                        if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.Yes)
                        {
                            if (quoteRequestServiceReq.new_vehicle_never_registered == null)
                            {
                                applicableServiceList = quoteRequestServiceReq.applicableServiceDto;                              
                            }
                            else if (!(bool)quoteRequestServiceReq.new_vehicle_never_registered)
                            {
                                sr_request.is_renewal = false;
                                sr_request.is_transfer = false;
                                sr_request.is_new_vehicle_never_registered = false;
                                sr_request.is_plate_replacement = false;
                                sr_request.plates_are_expired_or_misplaced = true;
                                //Pars to handle = Yes 
                                if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                                {

                                    if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                                    {
                                        sr_request.do_you_want_pars_to_handle_t_n_r = true;
                                        if (quoteRequestServiceReq.requested_t_n_r_service_type_id != null)
                                        {
                                            if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Renewal)
                                            {
                                                sr_request.is_renewal = true;
                                                sr_request.is_transfer = false;
                                                sr_request.is_new_vehicle_never_registered = false;
                                                sr_request.is_plate_replacement = false;
                                            }
                                            else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Replacenent)
                                            {
                                                sr_request.is_renewal = false;
                                                sr_request.is_transfer = false;
                                                sr_request.is_new_vehicle_never_registered = false;
                                                sr_request.is_plate_replacement = true;
                                            }
                                            else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Transfer)
                                            {
                                                sr_request.is_renewal = false;
                                                sr_request.is_transfer = true;
                                                sr_request.is_new_vehicle_never_registered = false;
                                                sr_request.is_plate_replacement = false;
                                            }
                                        }

                                        if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                        {
                                            if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                sr_request.is_pars_to_issue_a_temp_tag = true;
                                        }

                                    }
                                    else
                                    {
                                        if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                        {
                                            if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                sr_request.is_pars_to_issue_a_temp_tag = true;
                                        }
                                    }
                                }
                            }

                        }
                        else if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.No)
                        {
                            sr_request.is_renewal = false;
                            sr_request.is_transfer = false;
                            sr_request.is_new_vehicle_never_registered = false;
                            sr_request.is_plate_replacement = false;



                            if (quoteRequestServiceReq.new_vehicle_never_registered == null)
                            {
                                applicableServiceList = quoteRequestServiceReq.applicableServiceDto;
                            }
                            else if ((bool)quoteRequestServiceReq.new_vehicle_never_registered)
                            {
                                sr_request.is_renewal = false;
                                sr_request.is_transfer = false;
                                sr_request.is_new_vehicle_never_registered = true;
                                sr_request.is_plate_replacement = false;

                                //Do you want PARS to handle T&R?
                                if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                                {
                                    if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                                    {
                                        sr_request.do_you_want_pars_to_handle_t_n_r = true;
                                        if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                        {
                                            if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                sr_request.is_pars_to_issue_a_temp_tag = true;
                                        }
                                    }
                                    else
                                    {
                                        if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                        {
                                            if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                sr_request.is_pars_to_issue_a_temp_tag = true;
                                        }
                                    }
                                }
                            }
                            else
                            {

                                sr_request.plates_are_expired_or_misplaced = true;
                                if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                                {
                                    if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                                    {
                                        sr_request.do_you_want_pars_to_handle_t_n_r = true;
                                        if (quoteRequestServiceReq.requested_t_n_r_service_type_id != null)
                                        {
                                            if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Renewal)
                                            {
                                                sr_request.is_renewal = true;
                                                sr_request.is_transfer = false;
                                                sr_request.is_new_vehicle_never_registered = false;
                                                sr_request.is_plate_replacement = false;
                                            }
                                            else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Replacenent)
                                            {
                                                sr_request.is_renewal = false;
                                                sr_request.is_transfer = false;
                                                sr_request.is_new_vehicle_never_registered = false;
                                                sr_request.is_plate_replacement = true;
                                            }
                                            else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Transfer)
                                            {
                                                sr_request.is_renewal = false;
                                                sr_request.is_transfer = true;
                                                sr_request.is_new_vehicle_never_registered = false;
                                                sr_request.is_plate_replacement = false;
                                            }
                                        }

                                        if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                        {
                                            if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                sr_request.is_pars_to_issue_a_temp_tag = true;
                                        }

                                    }
                                    else
                                    {
                                        if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                        {
                                            if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                sr_request.is_pars_to_issue_a_temp_tag = true;
                                        }
                                    }
                                }

                            }

                        }
                        else if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.I_dont_know)
                        {
                            if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                            {
                                if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                    sr_request.is_pars_to_issue_a_temp_tag = true;
                            }
                        }
                        #endregion END

                        if (quoteRequestServiceReq.will_you_send_the_plates_to_fleet_driver != null)
                        {
                            if (!(bool)quoteRequestServiceReq.will_you_send_the_plates_to_fleet_driver)
                            {
                                sr_request.will_you_send_plates_to_pars = true;
                            }
                        }
                    }

                    #endregion END

                    foreach (var item in servicesListReq)
                    {
                        if (item.category_id == (long)Category_Types.service_request)
                        {
                            item.modelJson = JsonConvert.SerializeObject(sr_request);
                            item.price_list_id = quoteRequestServiceReq.price_list_id;
                        }
                    }

                    var jsonResults = await _mediator.Send(new EvaluateRulesQuery { preferencesListReq = servicesListReq });
                    var applicableServices = await _mediator.Send(new GetDefaultServicesQuery
                    {
                        jsonResults = jsonResults,
                        price_list_id = quoteRequestServiceReq.price_list_id,
                        agreement_id = quoteRequestServiceReq.agreement_id,
                        rule_type_id = preferenceReq.rule_type_id,
                        event_type_id = preferenceReq.event_type_id,

                        service_standard = (long)EnumTypes.Service_Standard.Standard,
                        applicableServiceDto = quoteRequestServiceReq.applicableServiceDto,


                    });

                    #endregion end

                    #endregion EndGetApplicableServices

                    #region PriceCalculation

                    #region Request Model

                    PriceCalculationReq priceCalculationReq = new PriceCalculationReq();
                    priceCalculationReq.servicereqs = new List<ApplicableServiceDto>();
                    applicableServices.AddRange((IEnumerable<ApplicableServiceDto>)getExtraServices);
                    priceCalculationReq.servicereqs = applicableServices;

                    applicableServiceList = priceCalculationReq.servicereqs;

                    priceCalculationReq.transportation_type_id = req.transportation_type_id;//1;
                    priceCalculationReq.primary_fuel_type_id = (long)req.primary_fuel_type_id;//2;
                    priceCalculationReq.fleet_id = batchGenerateReq.fleet_id;//2;
                    priceCalculationReq.fmc_id = batchGenerateReq.fmc_id;// 2;
                    priceCalculationReq.agreement_id = agreementDetails.agreement_id;
                    priceCalculationReq.price_list_id = agreementDetails.price_list_id;
                    priceCalculationReq.vehicle_type_id = (long)req.vehicle_type_id;// 2;
                    priceCalculationReq.pick_postal_code = req.location1_postal_code;// "47427";
                    priceCalculationReq.del_postal_code = req.location2_postal_code;// "30008";
                    priceCalculationReq.pickup_storage_id = req.location1_storage_id;// "30008";
                    priceCalculationReq.delivery_storage_id = req.location2_storage_id;// "30008";
                    priceCalculationReq.location1_country_id = req.location1_country_id;
                    priceCalculationReq.location2_country_id = req.location2_country_id;

                    priceCalculationReq.distance = moveType.estimate_distance;
                    priceCalculationReq.adj_duration = moveType.adj_duration_in_hours;

                    priceCalculationReq.pickup_latitude = moveType.pick_latitude;
                    priceCalculationReq.pickup_longitude = moveType.pick_longitude;
                    priceCalculationReq.delivery_latitude = moveType.del_latitude;
                    priceCalculationReq.delivery_longitude = moveType.del_longitude;

                    // Remove Drive Away Tariff -27 
                    int? index = null;
                    index = priceCalculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Transport_service.Drive_Away_Tariff);
                    if (index != null && index != -1)
                        priceCalculationReq.servicereqs.RemoveAt((int)index);
                    //Auto Carrier Tariff -1
                    index = priceCalculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Transport_service.Auto_Carrier_Tariff);
                    if (index > 0 && index != -1)
                        priceCalculationReq.servicereqs.RemoveAt((int)index);

                    //Both -40
                    index = priceCalculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Transport_service.Both);
                    if (index > 0 && index != -1)
                        priceCalculationReq.servicereqs.RemoveAt((int)index);

                    //Either - 41
                    index = priceCalculationReq.servicereqs.FindIndex(x => x.service_id == (long)EnumTypes.Transport_service.Either);
                    if (index > 0 && index != -1)
                        priceCalculationReq.servicereqs.RemoveAt((int)index);

  

                    

                    //priceCalculationReq.is_vehicle_at_impound = req.is_vehicle_at_impound;
                    priceCalculationReq.pickup_towing_required = req.location1_towing_required;
                    priceCalculationReq.vehicle_repossession_required = req.vehicle_repossession_required;
                    #region VEHICLE REGISTRATION STATUS RELATED FIELDS
                    //priceCalculationReq.is_plate_exist = req.is_plate_exist;
                   // priceCalculationReq.vehicle_plate_expiration_date = req.vehicle_plate_expiration_date;


                    //priceCalculationReq.has_vehicle_ever_been_titled = req.has_vehicle_ever_been_titled;
                    //priceCalculationReq.state_transfer_agent_type_id = req.state_transfer_agent_type_id;
                    //priceCalculationReq.issuing_agent_type_id = req.issuing_agent_type_id;
                    //priceCalculationReq.renewal_agent_type_id = req.renewal_agent_type_id;
                    //priceCalculationReq.can_pars_issue_a_temp_tag = req.can_pars_issue_a_temp_tag;
                    //priceCalculationReq.is_inspection_be_needed = req.is_inspection_be_needed;

                   // priceCalculationReq.plate_status = req.plate_status;
                    priceCalculationReq.do_you_want_pars_to_handle_t_n_r = req.do_you_want_pars_to_handle_t_n_r;
                    priceCalculationReq.is_pars_to_issue_a_temp_tag = req.is_pars_to_issue_a_temp_tag;
                    priceCalculationReq.will_you_send_the_plates_to_fleet_driver = req.will_you_send_the_plates_to_fleet_driver;
                    //priceCalculationReq.want_pars_to_deliver_on_current_plates = req.want_pars_to_deliver_on_current_plates;
                    //priceCalculationReq.is_prerequisite_inspections_in_delivery_state_required = req.is_prerequisite_inspections_in_delivery_state_required;

                    #endregion END

                    #endregion End Model
                    CalculationResponseDto calculatePrice = new CalculationResponseDto();
                    try
                    {
                        calculatePrice = await _mediator.Send(new PriceCalculationQuery { priceCalculationReq = priceCalculationReq });
                    }
                    catch (Exception ex)
                    {
                        long? orderBatchRowId = req.id; ;
                        string errorMsg = ex.Message.ToString();
                        bool updateOrderBatchRow = await _mediator.Send(new UpdateOrderBatchErrorMessageCommand { orderBatchImportId = (long)orderBatchRowId, errorMessage = errorMsg });
                        continue;
                    }


                    #endregion EndPriceCalculation

                    #region CreateServiceRequest
                    CreateNewServiceRequestReq createServiceRequest = new CreateNewServiceRequestReq();

                    createServiceRequest = new CreateNewServiceRequestReq();
                    createServiceRequest.service_request_type_id = batchGenerateReq.import_type_id;
                    createServiceRequest.transportation_type_id = req.transportation_type_id;
                    createServiceRequest.move_type_id = req.move_type_id == 0 ? null : req.move_type_id;
                    createServiceRequest.primary_service_order_type_id = (long)EnumTypes.service_order_type.Transport;
                    createServiceRequest.order_batch_row_id = req.id == 0 ? null : req.id;
                    createServiceRequest.bill_to_id = agreementDetails.default_bill_to_id;
                    createServiceRequest.requested_by_id = batchGenerateReq.requested_by_id;
                    createServiceRequest.fmc_id = batchGenerateReq.fmc_id;
                    createServiceRequest.fleet_id = batchGenerateReq.fleet_id;
                    createServiceRequest.emails = req.emails;
                    createServiceRequest.vehicle_id = req.vehicle_id;
                    createServiceRequest.vin = req.vin;
                    //createServiceRequest.retail = req.retail;
                    //createServiceRequest.plate_status_reason_id = req.plate_status_reason_id;
                    createServiceRequest.netsuite_cust_id = batchGenerateReq.ns_cust_id;
                    createServiceRequest.customer_ref_no = req.customer_ref;
                    createServiceRequest.customer_po = req.customer_po;
                    //createServiceRequest.project_no = req.project_no;
                    createServiceRequest.agreement_id = agreementDetails.agreement_id;
                    createServiceRequest.price_list_id = agreementDetails.price_list_id;
                    createServiceRequest.currency_id = agreementDetails.currency_id;
                    //createServiceRequest.field_office_id = req.field_office_id;
                    //createServiceRequest.open_recalls = req.open_recalls;
                    createServiceRequest.total_calculated_amount = calculatePrice.total_calculated_amount;
                    createServiceRequest.fleet_rebate_amount = calculatePrice.rebate_discount;
                    createServiceRequest.over_head_holdback_amount = calculatePrice.over_head_holdback_amount;
                    createServiceRequest.discount_amount = calculatePrice.discounted_amount;
                    createServiceRequest.suggested_Ic_pay = calculatePrice.suggested_ic_pay;
                    createServiceRequest.total_amount = calculatePrice.total_amount;
                    if(batchGenerateReq.import_type_id == (long)EnumTypes.service_request_type.quote_request)
                    {
                        createServiceRequest.quote_status_id = (long)EnumTypes.quote_status.Active;
                        createServiceRequest.quote_status_reason_id = (long)EnumTypes.quote_status_reason.Submitted;
                    }
                    else if(batchGenerateReq.import_type_id == (long)EnumTypes.service_request_type.service_request)
                    {
                        createServiceRequest.service_request_status_id = (long)EnumTypes.service_request_status.Active;
                        createServiceRequest.service_request_status_reason_id = (long)EnumTypes.service_request_status_reason.Draft;
                    }
                   
                    #region Service Order Related Fields

                    createServiceRequest.transportation_type_id = req.transportation_type_id;
                    
                    createServiceRequest.location1_address_type_id = req.location1_address_type_id;
                    createServiceRequest.location1_address_line_1 = req.location1_street1;
                    createServiceRequest.is_location1_address_line_1_verified = true;
                    createServiceRequest.location1_address_line_2 = req.location1_street2;
                    createServiceRequest.is_location1_pickup_address_line_2_verified = true;
                    createServiceRequest.location1_address_line_3 = req.location1_street3;
                    createServiceRequest.is_location1_address_line_3_verified = true;
                    createServiceRequest.location1_city = req.location1_city;
                    createServiceRequest.location1_county = req.location1_county;
                    createServiceRequest.is_location1_city_varified = true;
                    //createServiceRequest.location1_state_id = req.location1_state_id;
                    createServiceRequest.location1_state_id = req.location1_state_id == 0 ? null : req.location1_state_id;
                    createServiceRequest.is_location1_state_verified = true;
                    createServiceRequest.location1_postal_code = req.location1_postal_code;
                    createServiceRequest.is_location1_postal_code_verified = true;
                    createServiceRequest.pickup_latitude = moveType.pick_latitude;
                    createServiceRequest.pickup_longitude = moveType.pick_longitude;
                    createServiceRequest.location1_country_id = req.location1_country_id == 0 ? null : req.location1_country_id;
                    createServiceRequest.is_location1_country_verified = true;
                    createServiceRequest.location1_storage_id = req.location1_storage_id;
                   
                    createServiceRequest.location1_date_constraint_type_id = req.location1_date_constraints_type_id == 0 ? null : req.location1_date_constraints_type_id;
                    if(createServiceRequest.location1_date_constraint_type_id!=null)
                        createServiceRequest.has_location1_date_constraints = true;
                    else
                        createServiceRequest.has_location1_date_constraints = false;


                    //createServiceRequest.location1_urgency_reason = req.location1_urgency_reason;
                    createServiceRequest.requested_location1_from_date = req.location1_requested_date;
                    createServiceRequest.requested_location1_to_date = req.location1_requested_date;
                    createServiceRequest.location2_address_type_id = req.location2_address_type_id == 0 ? null : req.location2_address_type_id;
                    //createServiceRequest.location2_address_detail = req.location2_address_detail;
                    createServiceRequest.location2_address_line_1 = req.location2_street1;
                    createServiceRequest.is_location2_address_line_1_verified = true;
                    createServiceRequest.location2_address_line_2 = req.location2_street2;
                    createServiceRequest.is_location2_address_line_2_verified = true;
                    createServiceRequest.location2_address_line_3 = req.location2_street3;
                    createServiceRequest.is_location2_address_line_3_verified = true;
                    createServiceRequest.location2_county = req.location2_county;
                    //createServiceRequest.is_location2_county_verified = req.is_location2_county_verified;
                    createServiceRequest.location2_city = req.location2_city;
                    createServiceRequest.is_location2_city_verified = true;
                    createServiceRequest.location2_state_id = req.location2_state_id == 0 ? null : req.location2_state_id;
                    createServiceRequest.is_location2_state_varified = true;
                    createServiceRequest.location2_postal_code = req.location2_postal_code;
                    createServiceRequest.is_location2_postal_code_verified = true;
                    createServiceRequest.delivery_latitude = moveType.del_latitude;
                    createServiceRequest.delivery_longitude = moveType.del_longitude;
                    createServiceRequest.location2_country_id = req.location2_country_id == 0 ? null : req.location2_country_id;
                    createServiceRequest.is_location2_country_verified = true;
                    createServiceRequest.location2_date_constraints_type_id = req.location2_date_constraints_type_id == 0 ? null : req.location2_date_constraints_type_id;
                    if(createServiceRequest.location2_date_constraints_type_id!=null)
                        createServiceRequest.has_location2_date_constraints = true;
                    else
                        createServiceRequest.has_location2_date_constraints = false;

                    //createServiceRequest.location2_urgency_reason = req.location2_urgency_reason;
                    createServiceRequest.requested_location2_from_date = req.location2_requested_date;
                    createServiceRequest.requested_location2_to_date = req.location2_requested_date;
                    createServiceRequest.location2_storage_id = req.location2_storage_id;
                    //createServiceRequest.is_location2_release_to_transporter = req.is_location2_release_to_transporter;
                    createServiceRequest.is_location1_contact_from_address_book = false;
                    createServiceRequest.location1_contact_id = req.location1_contact_id == 0 ? null : req.location1_contact_id;
                    createServiceRequest.location1_contact_name = req.location1_contact;
                    createServiceRequest.is_location1_is_vip_contact = req.is_location1_vip_contact;
                    createServiceRequest.location1_contact_country_code_1 = req.location1_contact_country_code_1;
                    createServiceRequest.location1_contact_country_code_2 = req.location1_contact_country_code_2;
                    createServiceRequest.location1_contact_country_code_3 = req.location1_contact_country_code_3;
                    createServiceRequest.location1_contact_country_code_4 = req.location1_contact_country_code_4;
                    createServiceRequest.location1_contact_phone_1 = req.location1_contact_phone_1;
                    createServiceRequest.location1_contact_phone_2 = req.location1_contact_phone_2;
                    createServiceRequest.location1_contact_phone_3 = req.location1_contact_phone_3;
                    createServiceRequest.location1_contact_phone_4 = req.location1_contact_phone_4;
                    createServiceRequest.location1_contact_phone_type_1 = req.location1_contact_phone_type_1;
                    createServiceRequest.location1_contact_phone_type_2 = req.location1_contact_phone_type_2;
                    createServiceRequest.location1_contact_phone_type_3 = req.location1_contact_phone_type_3;
                    createServiceRequest.location1_contact_phone_type_4 = req.location1_contact_phone_type_4;
                    createServiceRequest.location1_extension = req.location1_extension;


                    #region map list phone of location1_contact 

                    List<service_request_phone_type>? location1_contact_list = new List<service_request_phone_type>();
                    if (req.location1_mobile_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location1_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";

                        location1_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 1,
                            phone_number = req.location1_mobile_phone,
                            country_code = countryCode,
                        });

                    }

                    if (req.location1_office_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location1_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        location1_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 2,
                            phone_number = req.location1_office_phone,
                            extension = req.location1_extension,
                            country_code=countryCode,
                        });

                    }
                    if (req.location1_home_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location1_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        location1_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 3,
                            phone_number = req.location1_home_phone,
                            country_code = countryCode,
                        });

                    }
                    if (req.location1_business_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location1_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        location1_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 4,
                            phone_number = req.location1_business_phone,
                            country_code =countryCode,
                        });

                    }
                    createServiceRequest.location1_contact_list = location1_contact_list;

                    #endregion


                    createServiceRequest.location1_contact_primary_email = req.location1_contact_email;
                    createServiceRequest.location1_contact_secondary_email = req.location1_email2;
                    createServiceRequest.location1_time_zone_id = req.location1_time_zone_id == 0 ? null : req.location1_time_zone_id;

                    createServiceRequest.location1_notes = req.location1_notes;
                    createServiceRequest.have_alternate_location1_contact_details = req.have_alternate_location1_contact_details;
                    createServiceRequest.alternate_location1_contact_name = req.location1_alternative_contact;
                    createServiceRequest.alternate_location1_contact_email = req.alternate_location1_contact_email;

                    #region map list phone of location1 alternate contact

                    List<service_request_phone_type>? alternate_location1_contact_list = new List<service_request_phone_type>();
                    if (req.alternate_location1_contact_mobile_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location1_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        alternate_location1_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 1,
                            phone_number = req.alternate_location1_contact_mobile_phone,
                            country_code = countryCode,
                        });
                    }
                    if (req.location1_alternative_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location1_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        alternate_location1_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 2,
                            phone_number = req.location1_alternative_phone,
                            country_code= countryCode,
                        });
                    }
                    createServiceRequest.alternate_location1_contact_list = alternate_location1_contact_list;

                    #endregion End


                    //createServiceRequest.do_you_want_to_save_location1_contact = req.do_you_want_to_save_location1_contact;
                    createServiceRequest.has_location1_sensitivities = req.has_location1_sensitivities;
                    createServiceRequest.location1_sensitivities_date = req.location1_sensitivities_date;
                    createServiceRequest.location1_sensitivity_details = req.location1_sensitivity_details;
                    createServiceRequest.location1_sensitivity_type_id = req.location1_sensitivity_type_id;
                    createServiceRequest.is_location2_contact_from_address_book = false;
                    createServiceRequest.location2_contact_id = req.location2_contact_id == 0 ? null : req.location2_contact_id;
                    createServiceRequest.location2_contact_name = req.location2_contact;
                    createServiceRequest.is_location2_is_vip_contact = req.location2_vip_contact;
                    createServiceRequest.location2_contact_country_code_1 = req.location2_contact_country_code_1;
                    createServiceRequest.location2_contact_country_code_2 = req.location2_contact_country_code_2;
                    createServiceRequest.location2_contact_country_code_3 = req.location2_contact_country_code_3;
                    createServiceRequest.location2_contact_country_code_4 = req.location2_contact_country_code_4;
                    createServiceRequest.location2_contact_phone_1 = req.location2_contact_phone_1;
                    createServiceRequest.location2_contact_phone_2 = req.location2_contact_phone_2;
                    createServiceRequest.location2_contact_phone_3 = req.location2_contact_phone_3;
                    createServiceRequest.location2_contact_phone_4 = req.location2_contact_phone_4;
                    createServiceRequest.location2_contact_phone_type_1 = req.location2_contact_phone_type_1;
                    createServiceRequest.location2_contact_phone_type_2 = req.location2_contact_phone_type_2;
                    createServiceRequest.location2_contact_phone_type_3 = req.location2_contact_phone_type_3;
                    createServiceRequest.location2_contact_phone_type_4 = req.location2_contact_phone_type_4;
                    createServiceRequest.location2_extension = req.location2_extension;


                    #region map list phone of location2_contact 

                    List<service_request_phone_type>? location2_contact_list = new List<service_request_phone_type>();
                    if (req.location2_mobile_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location2_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        location2_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 1,
                            phone_number = req.location2_mobile_phone,
                            country_code = countryCode,
                        });

                    }

                    if (req.location2_office_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location2_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        location2_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 2,
                            phone_number = req.location2_office_phone,
                            extension = req.location2_extension,
                            country_code = countryCode
                        });

                    }
                    if (req.location2_home_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location2_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        location2_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 3,
                            phone_number = req.location2_home_phone,
                            country_code=countryCode
                        });

                    }
                    if (req.location2_business_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location2_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        location2_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 4,
                            phone_number = req.location2_business_phone,
                            country_code =  countryCode
                        });

                    }
                    createServiceRequest.location2_contact_list = location2_contact_list;

                    #endregion


                    createServiceRequest.location2_contact_primary_email = req.location2_contact_email;
                    createServiceRequest.location2_contact_secondary_email = req.location2_email2;
                    //createServiceRequest.is_delivery_contact_same_as_pickup_contact = req.is_delivery_contact_same_as_pickup_contact;
                    createServiceRequest.location2_time_zone_id = req.location2_time_zone_id == 0 ? null : req.location2_time_zone_id;
                    createServiceRequest.location2_notes = req.location2_notes;
                    createServiceRequest.have_alternate_location2_contact_details = req.have_alternate_location2_contact_details;
                    createServiceRequest.alternate_location2_contact_name = req.location2_alternative_contact;
                    createServiceRequest.alternate_location2_contact_email = req.alternate_location2_contact_email;

                    #region map list phone of location1 alternate contact

                    List<service_request_phone_type>? alternate_location2_contact_list = new List<service_request_phone_type>();
                    if(req.alternate_location2_contact_mobile_phone!=null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location2_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        alternate_location2_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 1,
                            phone_number = req.alternate_location2_contact_mobile_phone,
                            country_code = countryCode,
                        });
                    }
                    if (req.location2_alternative_phone != null)
                    {
                        string countryCode = string.Empty;
                        long countryId = req.location2_country_id;
                        if (countryId == (long)EnumTypes.Country.United_States)
                            countryCode = "us";
                        else
                            countryCode = "ca";
                        alternate_location2_contact_list.Add(new service_request_phone_type
                        {
                            contact_type_id = 2,
                            phone_number = req.location2_alternative_phone,
                            country_code= countryCode,
                        });
                    }
                    createServiceRequest.alternate_location2_contact_list = alternate_location2_contact_list;

                    #endregion End

                    //createServiceRequest.do_you_want_to_save_location2_contact = req.do_you_want_to_save_location2_contact;
                    createServiceRequest.has_location2_sensitivities = req.has_location2_sensitivities;
                    createServiceRequest.location2_date_sensitivities = req.location2_sensitivities_date;
                    createServiceRequest.location2_sensitivity_type_id = req.location2_sensitivity_type_id;
                    createServiceRequest.location2_sensitivity_details = req.location2_sensitivity_details;
                    createServiceRequest.is_plate_exist = req.is_plate_exist;
                    createServiceRequest.vehicle_plate_expiration_date = req.vehicle_plate_expiration_date;
                    createServiceRequest.vehicle_plate_number = req.vehicle_plate_number;
                    createServiceRequest.vehicle_plate_state_id = req.vehicle_plate_state_id;
                    createServiceRequest.vehicle_plate_country_id = req.vehicle_plate_country_id;
                    createServiceRequest.has_vehicle_ever_been_titled = req.has_vehicle_ever_been_titled;
                    #region VEHICLE PLATE STATUS RELATED PARAMETERS		
                    createServiceRequest.does_the_vehicle_have_current_registration = req.does_the_vehicle_have_current_registration;
                    createServiceRequest.do_you_want_pars_to_handle_t_n_r = req.do_you_want_pars_to_handle_t_n_r;
                    createServiceRequest.will_you_send_the_plates_to_fleet_driver = req.will_you_send_the_plates_to_fleet_driver;
                    createServiceRequest.is_pars_to_issue_a_temp_tag = req.is_pars_to_issue_a_temp_tag;
                    createServiceRequest.new_vehicle_never_registered = req.new_vehicle_never_registered;
                    createServiceRequest.do_you_want_pars_to_delay_delivery = req.do_you_want_pars_to_delay_delivery;
                    createServiceRequest.requested_t_n_r_service_type_id = req.requested_t_n_r_service_type_id;
                    #endregion
                    createServiceRequest.can_pars_issue_a_temp_tag = req.can_pars_issue_a_temp_tag;
                    createServiceRequest.is_prior_inspection_required = req.is_prior_inspection_required;
                    createServiceRequest.ins_mailing_address_line_1 = req.ins_mailing_address_line_1;
                    createServiceRequest.ins_mailing_address_line_2 = req.ins_mailing_address_line_2;
                    createServiceRequest.ins_mailing_address_line_3 = req.ins_mailing_address_line_3;
                    createServiceRequest.ins_mailing_postal_code = req.ins_mailing_postal_code;
                    createServiceRequest.ins_mailing_county = req.ins_mailing_county;
                    createServiceRequest.ins_mailing_city = req.ins_mailing_city;
                    createServiceRequest.ins_mailing_state_id = req.ins_mailing_state_id;
                    createServiceRequest.ins_mailing_country_id = req.ins_mailing_country_id;
                    createServiceRequest.is_temptag_issued = req.is_temptag_issued;
                    createServiceRequest.temptag_number = req.temptag_number;
                    createServiceRequest.temptag_expiration_date = req.temptag_expiration_date;
                    createServiceRequest.temptag_state_id = req.temptag_state_id;
                    createServiceRequest.do_not_complete_inspection_if_required = req.do_not_complete_inspection_if_required;
                    createServiceRequest.pickup_towing_required = req.pickup_towing_required;
                    //createServiceRequest.is_vehicle_at_impound = req.is_vehicle_at_impound;
                    //createServiceRequest.can_pars_handle_inspections_before_delivery = req.can_pars_handle_inspections_before_delivery;
                    createServiceRequest.is_pars_authorized_to_use_a_temp_tag = req.is_pars_authorized_to_use_a_temp_tag;
                    //createServiceRequest.towing_type_id = req.towing_type_id;
                    createServiceRequest.towing_type_id = req.towing_type_id == 0 ? null : req.towing_type_id;
                    createServiceRequest.towing_remark = req.towing_remark;
                    //createServiceRequest.pars_authorized_to_perform_repossession_if_required = req.pars_authorized_to_perform_repossession_if_required;
                    createServiceRequest.repossession_remark = req.repossession_remark;
                    if (createServiceRequest.repossession_remark != null)
                        createServiceRequest.vehicle_repossession_required = true;
                    else
                        createServiceRequest.vehicle_repossession_required = false;
                    createServiceRequest.instructions_for_drivers = req.customer_instruction;
                    createServiceRequest.is_cost_effective = req.is_cost_effective;
                    createServiceRequest.pars_discretion_remark = req.pars_discretion_remark;
                    //createServiceRequest.repair_status_id = req.repair_status_id;
                    createServiceRequest.repair_instructions = req.repair_instructions;
                    //createServiceRequest.repair_claim = req.repair_claim;
                    //createServiceRequest.have_more_info = req.have_more_info;
                    //createServiceRequest.additional_info = req.additional_info;
                    createServiceRequest.special_handling_info = req.special_handling_instruction;

                    #endregion End Service Order Related Fields

                    List<CreateServiceOrderReq> createServiceOrderReqsList = new List<CreateServiceOrderReq>();
                    CreateServiceOrderReq createServiceOrderReq = null;

                    if (calculatePrice.serviceresp.Count>0)
                    {
                        foreach(var item in calculatePrice.serviceresp)
                        {
                            createServiceOrderReq = new CreateServiceOrderReq();
                            createServiceOrderReq.service_order_type_id = item.service_order_type_id;
                            createServiceOrderReq.transportation_type_id = moveType.transportation_type;
                            createServiceOrderReq.vehicle_id = req.vehicle_type_id;
                            createServiceOrderReq.service_id = item.service_id;
                            createServiceOrderReq.dependent_service_id = item.dependent_service_id;


                            createServiceOrderReq.rate_type_id = item.rate_type_id;
                            createServiceOrderReq.description = item.description;
                            createServiceOrderReq.amount = item.amount;
                            createServiceOrderReq.authorized_amount = item.authorized_amount;
                            createServiceOrderReq.actual_amount = item.actual_amount;
                            createServiceOrderReq.amount_modified_reason = item.amount_modified_reason;
                            createServiceOrderReq.is_price_modifiable = item.is_price_modifiable;
                            createServiceOrderReq.per_mile_rate = item.per_mile_rate;
                            createServiceOrderReq.estimate_distance = item.distance;
                            createServiceOrderReq.estimate_duration = moveType.estimate_duration;
                            createServiceOrderReq.est_duration_min = moveType.est_duration_min;
                            createServiceOrderReq.adj_duration = moveType.adj_duration;
                            createServiceOrderReq.adj_duration_in_hours = moveType.adj_duration_in_hours;
                            createServiceOrderReq.adj_duration_min = moveType.adj_duration_min;
                            createServiceOrderReq.fuel_surcharge_rate = item.fuel_surcharge_rate;
                            createServiceOrderReq.fuel_surcharge_amount = item.fuel_surcharge_amount;
                            createServiceOrderReq.pickup_hub_fee = item.pickup_hub_fee;
                            createServiceOrderReq.delivery_hub_fee = item.delivery_hub_fee;
                            createServiceOrderReq.admin_fee = item.admin_fee;
                            createServiceOrderReq.surcharge_rate = item.surcharge_rate;
                            createServiceOrderReq.surcharge_type_id = item.surcharge_type_id;
                            createServiceOrderReq.surcharge_amount = item.surcharge_amount;
                            createServiceOrderReq.markup_number = item.markup_number;
                            createServiceOrderReq.markup_type_id = item.markup_type_id;
                            createServiceOrderReq.markup_amount = item.markup_amount;
                            createServiceOrderReq.discount_rate = item.discount_rate;
                            createServiceOrderReq.discount_type_id = item.discount_type_id;
                            createServiceOrderReq.discount_amount = item.discount_amount;
                            createServiceOrderReq.rebate_rate = item.rebate_rate;
                            createServiceOrderReq.rebate_type_id = item.rebate_type_id;
                            createServiceOrderReq.rebate_amount = item.rebate_amount;
                            createServiceOrderReq.total_amount = item.total_amount;
                           //if(item.can_modify!=null)
                                createServiceOrderReq.can_modify = (bool)item.can_modify;
                            if(item.is_read_only !=null)
                                createServiceOrderReq.is_read_only = (bool)item.is_read_only;
                            else 
                                createServiceOrderReq.is_read_only = false;


                            if(item.service_notification_icon!=null)
                                createServiceOrderReq.service_notification_icon = (int)item.service_notification_icon;
                            if(item.service_standard!=null)
                                createServiceOrderReq.service_standard = (long)item.service_standard;
                            createServiceOrderReq.remark = "";
                            createServiceOrderReq.is_billable = true;
                            createServiceOrderReq.have_more_info = item.have_more_info;
                            createServiceOrderReq.is_ic_instruction = item.is_ic_instruction;
                            if (item.is_major_service != null)
                                createServiceOrderReq.is_major_service = (bool)item.is_major_service;
                            createServiceOrderReq.additional_info = item.additional_info;

                            createServiceOrderReqsList.Add(createServiceOrderReq);
                        }
                    }
                    createServiceRequest.createServiceOrderReqs = createServiceOrderReqsList;

                    List<ServiceRequestSupportContactReq> supportContactList = new List<ServiceRequestSupportContactReq>();
                    ServiceRequestSupportContactReq supportContactReq = null;
                    if(supportContact.Count>0)
                    {
                        foreach(var contact in supportContact)
                        {
                            supportContactReq = new ServiceRequestSupportContactReq();
                            supportContactReq.support_contact_id = contact.id;
                            supportContactList.Add(supportContactReq);
                        }
                    }
                    createServiceRequest.serviceRequestSupportContactReqs = supportContactList;

                    createServiceRequest.createServiceOrderReqs = createServiceOrderReqsList;

                    createServiceRequest.processed_rows = processed;
                    createServiceRequest.failure_rows = failure;
                    createServiceRequest.order_import_id = batchGenerateReq.import_id;

                    processed++;

                    serviceRequestReqsList.Add(createServiceRequest);
              
                    #endregion EndCreateServiceRequest


                }
                isServiceReqCreate = await _mediator.Send(new GenerateServiceRequestOrderBatchCommand { createNewServiceRequestReqs = serviceRequestReqsList, queueRule = null });

                if (isServiceReqCreate.Item1 == true)
                {
                    throw new Exception("PARS_PICKUP_AND_DELIVERY_ADDRESS_NOT_STORAGE_IN_BOTH_CASE");
                }
                else if (isServiceReqCreate.Item2 == true)
                {
                    result = true;
                    if (result)
                    {
                        using (var con = _dbCntx.GetOpenConnection())
                        {
                            DynamicParameters dps = new DynamicParameters();
                            int processedRow = resultList.Count;
                            int partiallyFailureRow = resultList.Count - serviceRequestReqsList.Count;
                            dps.Add("@import_id", batchGenerateReq.import_id);
                            dps.Add("@processedRow", processedRow);
                            dps.Add("@partiallyFailureRow", partiallyFailureRow);
                            dps.Add("@updated_by", _currentUserContext.LoggedInUserId);
                            var updaeBatchQuery = @"sp_update_batch_import_date";
                            var updateBatchImport = await con.ExecuteAsyncWithRetry(updaeBatchQuery, dps, commandType: CommandType.StoredProcedure);

                        }

                    }
                }
                else
                    throw new BusinessException("PARS_CREATION_FAILURE");

            }
            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");
            
            return new OkObjectResult(response);
        }

        /// <summary>
        /// API is being used for Create Service/Quote Request using batch import row
        /// </summary>
        /// <param name="req"> OrderBatchSubmitReq</param>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SubmitServiceRequestOrderBatch(OrderBatchSubmitReq req)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = false;
            /*
            if(req.serviceRequestId.Count>0)
            {
                Tuple<bool, bool> isServiceReqUpdate = new Tuple<bool, bool>(false, false);
                List<UpdateServiceRequestReq> updateServiceReqs = new List<UpdateServiceRequestReq>();

                #region GET QUEUE RULE
                var rootPath = _hostingEnvironment.ContentRootPath; //get the root path

                var fullPath = Path.Combine(rootPath, "queuerules.json"); //combine the root path with that of our json file inside mydata directory

                var queueRule = System.IO.File.ReadAllText(fullPath); //read all the content inside the file
                #endregion

                foreach (var serviceRequestId in req.serviceRequestId)
                {
                    //var requestDetail = await _mediator.Send(new GetServiceRequestDetailQuery { service_request_id = serviceRequestId });
                    Tuple<List<ServiceRequestDetailDto>, string> requestDetail = await _mediator.Send(new GetServiceRequestDetailOrderBatchQuery { service_request_id = serviceRequestId });
                    if(requestDetail.Item2 != string.Empty)
                    {
                        long? orderBatchRowId = requestDetail.Item1[0].order_batch_row_id;
                        string errorMsg = requestDetail.Item2.ToString();
                        bool updateOrderBatchRow = await _mediator.Send(new UpdateOrderBatchErrorMessageCommand { orderBatchImportId = (long)orderBatchRowId, errorMessage = errorMsg });
                        continue;
                    }
                    if (requestDetail != null)
                    {
                        
                        UpdateServiceRequestReq updateService = null;
                        
                        foreach (var serviceReq in requestDetail.Item1)
                        {
                            #region Service Request Related Fields

                            updateService = new UpdateServiceRequestReq();
                            updateService.id = (long)serviceReq.id;
                            updateService.service_request_number = serviceReq.service_request_number;
                            updateService.service_request_type_id = serviceReq.service_request_type_id;
                            updateService.move_type_id = serviceReq.move_type_id;
                            //updateService.impersonat_user_id = serviceReq.impersonat_user_id;
                            updateService.primary_service_order_type_id = serviceReq.primary_service_order_type_id;
                            updateService.order_batch_row_id = serviceReq.order_batch_row_id;
                            updateService.bill_to_id = serviceReq.bill_to_id;
                            updateService.requested_by_id = serviceReq.requested_by_id;
                            updateService.fmc_id = serviceReq.fmc_id;
                            updateService.fleet_id = serviceReq.fleet_id;
                            updateService.emails = serviceReq.emails;
                            updateService.vehicle_id = serviceReq.vehicle_id;
                            updateService.vin = serviceReq.vin;
                            updateService.retail = serviceReq.retail;
                            updateService.plate_status_reason_id = serviceReq.plate_status_reason_id;
                            updateService.netsuite_cust_id = serviceReq.netsuite_cust_id;
                            updateService.customer_ref_no = serviceReq.customer_ref_no;
                            updateService.customer_po = serviceReq.customer_po;
                            updateService.project_no = serviceReq.project_no;
                            updateService.agreement_id = serviceReq.agreement_id;
                            updateService.price_list_id = serviceReq.price_list_id;
                            updateService.currency_id = serviceReq.currency_id;
                            updateService.field_office_id = serviceReq.field_office_id;
                            updateService.open_recalls = serviceReq.open_recalls;
                            updateService.total_calculated_amount = serviceReq.total_calculated_amount;
                            updateService.fleet_rebate_amount = serviceReq.fleet_rebate_amount;
                            updateService.over_head_holdback_amount = serviceReq.over_head_holdback_amount;
                            updateService.discount_amount = serviceReq.discount_amount;
                            updateService.suggested_Ic_pay = serviceReq.suggested_Ic_pay;
                            updateService.total_amount = serviceReq.total_amount;
                            updateService.remark = serviceReq.remark;

                            if (serviceReq.service_request_type_id == (long)EnumTypes.service_request_type.quote_request)
                            {
                                updateService.quote_status_id = (long)EnumTypes.quote_status.Active;
                                updateService.quote_status_reason_id = (long)EnumTypes.quote_status.Active;
                            }
                            else if (serviceReq.service_request_type_id == (long)EnumTypes.service_request_type.service_request)
                            {
                                updateService.service_request_status_id = (long)EnumTypes.service_request_status.Active;
                                updateService.service_request_status_reason_id = (long)EnumTypes.service_request_status_reason.Submitted;
                            }

                           
                            //updateService.isDuplicateOrder = serviceReq.isDuplicateOrder;
                            //updateService.isConflictOrder = serviceReq.isConflictOrder;

                            #endregion End

                            #region Service Order Related Fields

                            updateService.transportation_type_id = serviceReq.transportation_type_id;
                            updateService.location1_address_type_id = (long)serviceReq.location1_address_type_id;
                            updateService.location1_address_detail = serviceReq.location1_address_detail;
                            updateService.location1_address_line_1 = serviceReq.location1_address_line_1;
                            updateService.is_location1_address_line_1_verified = serviceReq.is_location1_address_line_1_verified;
                            updateService.location1_address_line_2 = serviceReq.location1_address_line_2;
                            updateService.is_location1_pickup_address_line_2_verified = serviceReq.is_location1_pickup_address_line_2_verified;
                            updateService.location1_address_line_3 = serviceReq.location1_address_line_3;
                            updateService.is_location1_address_line_3_verified = serviceReq.is_location1_address_line_3_verified;
                            updateService.location1_county = serviceReq.location1_county;
                            updateService.is_location1_county_verified = serviceReq.is_location1_county_verified;
                            updateService.location1_city = serviceReq.location1_city;
                            updateService.is_location1_city_varified = serviceReq.is_location1_city_varified;
                            updateService.location1_state_id = serviceReq.location1_state_id;
                            updateService.is_location1_state_verified = serviceReq.is_location1_state_verified;
                            updateService.location1_postal_code = serviceReq.location1_postal_code;
                            updateService.is_location1_postal_code_verified = serviceReq.is_location1_postal_code_verified;
                            updateService.pickup_latitude = serviceReq.pickup_latitude;
                            updateService.pickup_longitude = serviceReq.pickup_longitude;
                            updateService.location1_country_id = serviceReq.location1_country_id;
                            updateService.is_location1_country_verified = serviceReq.is_location1_country_verified;
                            updateService.location1_storage_id = serviceReq.location1_storage_id;
                            updateService.has_location1_date_constraints = serviceReq.has_location1_date_constraints;
                            updateService.location1_date_constraint_type_id = serviceReq.location1_date_constraint_type_id;
                            updateService.location1_urgency_reason = serviceReq.location1_urgency_reason;
                            updateService.requested_location1_from_date = serviceReq.requested_location1_from_date;
                            updateService.requested_location1_to_date = serviceReq.requested_location1_to_date;
                            updateService.location2_address_type_id = serviceReq.location2_address_type_id;
                            updateService.location2_address_detail = serviceReq.location2_address_detail;
                            updateService.location2_address_line_1 = serviceReq.location2_address_line_1;
                            updateService.is_location2_address_line_1_verified = serviceReq.is_location2_address_line_1_verified;
                            updateService.location2_address_line_2 = serviceReq.location2_address_line_2;
                            updateService.is_location2_address_line_2_verified = serviceReq.is_location2_address_line_2_verified;
                            updateService.location2_address_line_3 = serviceReq.location2_address_line_3;
                            updateService.is_location2_address_line_3_verified = serviceReq.is_location2_address_line_3_verified;
                            updateService.location2_county = serviceReq.location2_county;
                            updateService.is_location2_county_verified = serviceReq.is_location2_county_verified;
                            updateService.location2_city = serviceReq.location2_city;
                            updateService.is_location2_city_verified = serviceReq.is_location2_city_verified;
                            updateService.location2_state_id = serviceReq.location2_state_id;
                            updateService.is_location2_state_varified = serviceReq.is_location2_state_varified;
                            updateService.location2_postal_code = serviceReq.location2_postal_code;
                            updateService.is_location2_postal_code_verified = serviceReq.is_location2_postal_code_verified;
                            updateService.delivery_latitude = serviceReq.delivery_latitude;
                            updateService.delivery_longitude = serviceReq.delivery_longitude;
                            updateService.location2_country_id = serviceReq.location2_country_id;
                            updateService.is_location2_country_verified = serviceReq.is_location2_country_verified;
                            updateService.has_location2_date_constraints = serviceReq.has_location2_date_constraints;
                            updateService.location2_date_constraints_type_id = serviceReq.location2_date_constraints_type_id;
                            updateService.location2_urgency_reason = serviceReq.location2_urgency_reason;
                            updateService.requested_location2_from_date = serviceReq.requested_location2_from_date;
                            updateService.requested_location2_to_date = serviceReq.requested_location2_to_date;
                            updateService.location2_storage_id = serviceReq.location2_storage_id;
                            updateService.is_location2_release_to_transporter = serviceReq.is_location2_release_to_transporter;
                            updateService.is_location1_contact_from_address_book = false;
                            updateService.location1_contact_id = serviceReq.location1_contact_id;
                            updateService.location1_contact_name = serviceReq.location1_contact_name;
                            updateService.is_location1_is_vip_contact = serviceReq.is_location1_is_vip_contact;
                            updateService.location1_contact_country_code_1 = serviceReq.location1_contact_country_code_1;
                            updateService.location1_contact_country_code_2 = serviceReq.location1_contact_country_code_2;
                            updateService.location1_contact_country_code_3 = serviceReq.location1_contact_country_code_3;
                            updateService.location1_contact_country_code_4 = serviceReq.location1_contact_country_code_4;
                            updateService.location1_contact_phone_1 = serviceReq.location1_contact_phone_1;
                            updateService.location1_contact_phone_2 = serviceReq.location1_contact_phone_2;
                            updateService.location1_contact_phone_3 = serviceReq.location1_contact_phone_3;
                            updateService.location1_contact_phone_4 = serviceReq.location1_contact_phone_4;
                            updateService.location1_contact_phone_type_1 = serviceReq.location1_contact_phone_type_1;
                            updateService.location1_contact_phone_type_2 = serviceReq.location1_contact_phone_type_2;
                            updateService.location1_contact_phone_type_3 = serviceReq.location1_contact_phone_type_3;
                            updateService.location1_contact_phone_type_4 = serviceReq.location1_contact_phone_type_4;
                            updateService.location1_extension = serviceReq.location1_extension;
                            updateService.location1_contact_list = serviceReq.location1_contact_list;
                            updateService.location1_contact_primary_email = serviceReq.location1_contact_primary_email;
                            updateService.location1_contact_secondary_email = serviceReq.location1_contact_secondary_email;
                            updateService.location1_time_zone_id = serviceReq.location1_time_zone_id;
                            updateService.location1_notes = serviceReq.location1_notes;
                            updateService.have_alternate_location1_contact_details = serviceReq.have_alternate_location1_contact_details;
                            updateService.alternate_location1_contact_name = serviceReq.alternate_location1_contact_name;
                            updateService.alternate_location1_contact_list = serviceReq.alternate_location1_contact_list;

                            updateService.alternate_location1_contact_email = serviceReq.alternate_location1_contact_email;
                            //updateService.do_you_want_to_save_location1_contact = serviceReq.do_you_want_to_save_location1_contact;
                            updateService.has_location1_sensitivities = serviceReq.has_location1_sensitivities;
                            updateService.location1_sensitivities_date = serviceReq.location1_sensitivities_date;
                            updateService.location1_sensitivity_details = serviceReq.location1_sensitivity_details;
                            updateService.location1_sensitivity_type_id = serviceReq.location1_sensitivity_type_id;
                            updateService.is_location2_contact_from_address_book = false;
                            updateService.location2_contact_id = serviceReq.location2_contact_id;
                            updateService.location2_contact_name = serviceReq.location2_contact_name;
                            updateService.is_location2_is_vip_contact = serviceReq.is_location2_is_vip_contact;
                            updateService.location2_contact_country_code_1 = serviceReq.location2_contact_country_code_1;
                            updateService.location2_contact_country_code_2 = serviceReq.location2_contact_country_code_2;
                            updateService.location2_contact_country_code_3 = serviceReq.location2_contact_country_code_3;
                            updateService.location2_contact_country_code_4 = serviceReq.location2_contact_country_code_4;
                            updateService.location2_contact_phone_1 = serviceReq.location2_contact_phone_1;
                            updateService.location2_contact_phone_2 = serviceReq.location2_contact_phone_2;
                            updateService.location2_contact_phone_3 = serviceReq.location2_contact_phone_3;
                            updateService.location2_contact_phone_4 = serviceReq.location2_contact_phone_4;
                            updateService.location2_contact_phone_type_1 = serviceReq.location2_contact_phone_type_1;
                            updateService.location2_contact_phone_type_2 = serviceReq.location2_contact_phone_type_2;
                            updateService.location2_contact_phone_type_3 = serviceReq.location2_contact_phone_type_3;
                            updateService.location2_contact_phone_type_4 = serviceReq.location2_contact_phone_type_4;
                            updateService.location2_extension = serviceReq.location2_extension;
                            updateService.location2_contact_list = serviceReq.location2_contact_list;
                            updateService.location2_contact_primary_email = serviceReq.location2_contact_primary_email;
                            updateService.location2_contact_secondary_email = serviceReq.location2_contact_secondary_email;
                            //updateService.is_delivery_contact_same_as_pickup_contact = serviceReq.is_delivery_contact_same_as_pickup_contact;
                            updateService.location2_time_zone_id = serviceReq.location2_time_zone_id;
                            updateService.have_alternate_location2_contact_details = serviceReq.have_alternate_location2_contact_details;
                            updateService.alternate_location2_contact_name = serviceReq.alternate_location2_contact_name;
                            updateService.alternate_location2_contact_list = serviceReq.alternate_location2_contact_list;

                            updateService.alternate_location2_contact_email = serviceReq.alternate_location2_contact_email;
                            //updateService.do_you_want_to_save_location2_contact = serviceReq.do_you_want_to_save_location2_contact;
                            updateService.has_location2_sensitivities = serviceReq.has_location2_sensitivities;
                            updateService.location2_date_sensitivities = serviceReq.location2_date_sensitivities;
                            updateService.location2_sensitivity_type_id = serviceReq.location2_sensitivity_type_id;
                            updateService.location2_sensitivity_details = serviceReq.location2_sensitivity_details;
                            updateService.is_plate_exist = serviceReq.is_plate_exist;
                            updateService.vehicle_plate_expiration_date = serviceReq.vehicle_plate_expiration_date;
                            updateService.vehicle_plate_number = serviceReq.vehicle_plate_number;
                            updateService.vehicle_plate_state_id = serviceReq.vehicle_plate_state_id;
                            updateService.vehicle_plate_country_id = serviceReq.vehicle_plate_country_id;
                            updateService.has_vehicle_ever_been_titled = serviceReq.has_vehicle_ever_been_titled;

                            #region VEHICLE PLATE STATUS RELATED PARAMETERS
                            updateService.does_the_vehicle_have_current_registration = serviceReq.does_the_vehicle_have_current_registration;
                            updateService.do_you_want_pars_to_handle_t_n_r = serviceReq.do_you_want_pars_to_handle_t_n_r;
                            updateService.will_you_send_the_plates_to_fleet_driver = serviceReq.will_you_send_the_plates_to_fleet_driver;
                            updateService.is_pars_to_issue_a_temp_tag = serviceReq.is_pars_to_issue_a_temp_tag;
                            updateService.new_vehicle_never_registered = serviceReq.new_vehicle_never_registered;
                            updateService.do_you_want_pars_to_delay_delivery = serviceReq.do_you_want_pars_to_delay_delivery;
                            updateService.requested_t_n_r_service_type_id = serviceReq.requested_t_n_r_service_type_id;
                            #endregion End

                            updateService.can_pars_issue_a_temp_tag = serviceReq.can_pars_issue_a_temp_tag;
                            updateService.is_prior_inspection_required = serviceReq.is_prior_inspection_required;
                            updateService.ins_mailing_address_line_1 = serviceReq.ins_mailing_address_line_1;
                            updateService.ins_mailing_address_line_2 = serviceReq.ins_mailing_address_line_2;
                            updateService.ins_mailing_address_line_3 = serviceReq.ins_mailing_address_line_3;
                            updateService.ins_mailing_postal_code = serviceReq.ins_mailing_postal_code;
                            updateService.ins_mailing_county = serviceReq.ins_mailing_county;
                            updateService.ins_mailing_city = serviceReq.ins_mailing_city;
                            updateService.ins_mailing_state_id = serviceReq.ins_mailing_state_id;
                            updateService.ins_mailing_country_id = serviceReq.ins_mailing_country_id;
                            updateService.is_temptag_issued = serviceReq.is_temptag_issued;
                            updateService.temptag_number = serviceReq.temptag_number;
                            updateService.temptag_expiration_date = serviceReq.temptag_expiration_date;
                            updateService.temptag_state_id = serviceReq.temptag_state_id;
                            updateService.do_not_complete_inspection_if_required = serviceReq.do_not_complete_inspection_if_required;
                            updateService.pickup_towing_required = serviceReq.pickup_towing_required;
                            updateService.vehicle_repossession_required = serviceReq.vehicle_repossession_required;
                            updateService.is_vehicle_at_impound = serviceReq.is_vehicle_at_impound;
                            updateService.can_pars_handle_inspections_before_delivery = serviceReq.can_pars_handle_inspections_before_delivery;
                            updateService.is_pars_authorized_to_use_a_temp_tag = serviceReq.is_pars_authorized_to_use_a_temp_tag;
                            updateService.towing_type_id = serviceReq.towing_type_id;
                            updateService.towing_remark = serviceReq.towing_remark;
                            updateService.repossession_remark = serviceReq.repossession_remark;
                            updateService.instructions_for_drivers = serviceReq.instructions_for_drivers;

                            updateService.is_cost_effective = serviceReq.is_cost_effective;
                            updateService.pars_discretion_remark = serviceReq.pars_discretion_remark;

                            updateService.repair_status_id = serviceReq.repair_status_id;
                            updateService.repair_instructions = serviceReq.repair_instructions;
                            updateService.repair_claim = serviceReq.repair_claim;
                            updateService.have_more_info = serviceReq.have_more_info;
                            updateService.additional_info = serviceReq.additional_info;
                            updateService.special_handling_info = serviceReq.special_handling_info;

                            #endregion End Service Order Related Fields

                             if(serviceReq.serviceOrders.Count > 0)
                            {
                                List<CreateServiceOrderReq> createServiceOrderReqs = new List<CreateServiceOrderReq>();
                                    CreateServiceOrderReq createServiceOrderReq = null;
                                foreach (var serviceOrder in serviceReq.serviceOrders)
                                {
                                    createServiceOrderReq = new CreateServiceOrderReq();
                                    createServiceOrderReq.service_order_type_id = serviceOrder.service_order_type_id;

                                    createServiceOrderReq.transportation_type_id = serviceOrder.transportation_type_id;
                                    createServiceOrderReq.vehicle_id = (long)serviceOrder.vehicle_id;
                                    createServiceOrderReq.service_id = serviceOrder.service_id;
                                    createServiceOrderReq.dependent_service_id = serviceOrder.dependent_service_id;
                                    createServiceOrderReq.rate_type_id = serviceOrder.rate_type_id;
                                    createServiceOrderReq.description = serviceOrder.description;
                                    createServiceOrderReq.service_ic = serviceOrder.agent_or_ic;
                                    createServiceOrderReq.amount = serviceOrder.amount;
                                    createServiceOrderReq.authorized_amount = serviceOrder.authorized_amount;
                                    createServiceOrderReq.actual_amount = serviceOrder.actual_amount;
                                    createServiceOrderReq.amount_modified_reason = serviceOrder.amount_modified_reason;
                                    createServiceOrderReq.is_price_modifiable = serviceOrder.is_price_modifiable;
                                    createServiceOrderReq.per_mile_rate = serviceOrder.per_mile_rate;
                                    createServiceOrderReq.estimate_distance = serviceOrder.estimate_distance;
                                    createServiceOrderReq.estimate_duration = serviceOrder.estimate_duration;
                                    createServiceOrderReq.est_duration_min = serviceOrder.est_duration_min;
                                    createServiceOrderReq.adj_duration = serviceOrder.adj_duration;
                                    createServiceOrderReq.adj_duration_in_hours = serviceOrder.adj_duration_in_hours;
                                    createServiceOrderReq.adj_duration_min = serviceOrder.adj_duration_min;
                                    createServiceOrderReq.fuel_surcharge_rate = serviceOrder.fuel_surcharge_rate;
                                    createServiceOrderReq.fuel_surcharge_amount = serviceOrder.fuel_surcharge_amount;
                                    createServiceOrderReq.pickup_hub_fee = serviceOrder.pickup_hub_fee;
                                    createServiceOrderReq.delivery_hub_fee = serviceOrder.delivery_hub_fee;
                                    createServiceOrderReq.admin_fee = serviceOrder.admin_fee;
                                    createServiceOrderReq.surcharge_rate = serviceOrder.surcharge_rate;
                                    createServiceOrderReq.surcharge_type_id = serviceOrder.surcharge_type_id;
                                    createServiceOrderReq.surcharge_amount = serviceOrder.surcharge_amount;
                                    createServiceOrderReq.markup_number = serviceOrder.markup_number;
                                    createServiceOrderReq.markup_type_id = serviceOrder.markup_type_id;
                                    createServiceOrderReq.markup_amount = serviceOrder.markup_amount;
                                    createServiceOrderReq.discount_rate = serviceOrder.discount_rate;
                                    createServiceOrderReq.discount_type_id = serviceOrder.discount_type_id;
                                    createServiceOrderReq.discount_amount = serviceOrder.discount_amount;
                                    createServiceOrderReq.rebate_rate = serviceOrder.rebate_rate;
                                    createServiceOrderReq.rebate_type_id = serviceOrder.rebate_type_id;
                                    createServiceOrderReq.rebate_amount = serviceOrder.rebate_amount;
                                    createServiceOrderReq.total_amount = serviceOrder.total_amount;
                                    createServiceOrderReq.can_modify = (bool)serviceOrder.can_modify;
                                    createServiceOrderReq.is_read_only = (bool)serviceOrder.is_read_only;
                                    createServiceOrderReq.service_notification_icon = serviceOrder.service_notification_icon;
                                    if (serviceOrder.service_standard != null)
                                        createServiceOrderReq.service_standard = (long)serviceOrder.service_standard;
                                    createServiceOrderReq.remark = serviceOrder.remark;
                                    createServiceOrderReq.is_billable = serviceOrder.is_billable;
                                    createServiceOrderReq.have_more_info = serviceOrder.have_more_info;
                                    //createServiceOrderReq.is_ic_instruction = serviceOrder.is_ic_instruction;
                                    createServiceOrderReq.is_major_service = (bool)serviceOrder.is_major_service;
                                    createServiceOrderReq.additional_info = serviceOrder.additional_info;

                                    createServiceOrderReqs.Add(createServiceOrderReq);
                                }

                                updateService.createServiceOrderReqs = createServiceOrderReqs;
                            }

                            #region Support Contact
                            List<UpdateServiceRequestSupportContactReq> supportContactList = new List<UpdateServiceRequestSupportContactReq>();
                            UpdateServiceRequestSupportContactReq supportContactReq = null;
                            if (serviceReq.supportContacts.Count>0)
                            {
                                foreach (var contact in serviceReq.supportContacts)
                                {
                                    supportContactReq = new UpdateServiceRequestSupportContactReq();
                                    supportContactReq.support_contact_id = contact.id;
                                    supportContactList.Add(supportContactReq);
                                }
                            }
                            updateService.serviceRequestSupportContactReqs = supportContactList;

                            #endregion End Support Contact

                            #region Default IC 

                            QuoteRequestServiceReq quoteRequestServiceReq = new QuoteRequestServiceReq();
                            quoteRequestServiceReq.transportation_type_id = serviceReq.transportation_type_id;
                            quoteRequestServiceReq.fmc_id = serviceReq.fmc_id;
                            quoteRequestServiceReq.fleet_id = serviceReq.fleet_id;
                            if (serviceReq.agreement_id != 0)
                                quoteRequestServiceReq.agreement_id = (long)serviceReq.agreement_id;
                            if (serviceReq.agreement_type_id != 0)
                                quoteRequestServiceReq.agreement_id = (long)serviceReq.agreement_type_id;
                            //quoteRequestServiceReq.pars_perform_inspection = serviceReq.pars_perform_inspection;
                            quoteRequestServiceReq.currency_id = (long)serviceReq.currency_id;
                            quoteRequestServiceReq.event_type_id = (long)EnumTypes.Event_Type.transport_preferences;
                            quoteRequestServiceReq.price_list_id = (long)serviceReq.price_list_id;
                            quoteRequestServiceReq.vehicle_type_id = (long)serviceReq.vehicle_type_id;
                            quoteRequestServiceReq.fuel_type_id = (long)serviceReq.fuel_type_id;
                            quoteRequestServiceReq.primary_fuel_type_id = (long)serviceReq.primary_fuel_type_id;
                            quoteRequestServiceReq.has_location1_date_constraints = (bool)serviceReq.has_location1_date_constraints;
                            quoteRequestServiceReq.location1_postal_code = serviceReq.location1_postal_code;
                            quoteRequestServiceReq.location1_address_type_id = serviceReq.location1_address_type_id;
                            quoteRequestServiceReq.location2_address_type_id = serviceReq.location2_address_type_id;
                            quoteRequestServiceReq.location2_postal_code = serviceReq.location2_postal_code;
                            quoteRequestServiceReq.location1_state_id = serviceReq.location1_state_id;
                            quoteRequestServiceReq.location2_state_id = serviceReq.location2_state_id;
                            quoteRequestServiceReq.location1_country_id = serviceReq.location1_country_id;
                            quoteRequestServiceReq.location2_country_id = serviceReq.location2_country_id;
                            if (serviceReq.location1_storage_id != null)
                                quoteRequestServiceReq.location1_storage_id = serviceReq.location1_storage_id;
                            quoteRequestServiceReq.location2_storage_id = serviceReq.location2_storage_id;
                            quoteRequestServiceReq.location1_date_constraint_type_id = serviceReq.location1_date_constraint_type_id;
                            quoteRequestServiceReq.requested_location1_date = serviceReq.requested_location1_from_date;

                            quoteRequestServiceReq.has_location2_date_constraints = (bool)serviceReq.has_location2_date_constraints;
                            quoteRequestServiceReq.location2_date_constraints_type_id = serviceReq.location2_date_constraints_type_id;
                            quoteRequestServiceReq.requested_location2_to_date = serviceReq.requested_location2_to_date;
                            quoteRequestServiceReq.bill_to = serviceReq.bill_to_id;
                            quoteRequestServiceReq.location1_is_vip_contact = (bool)serviceReq.is_location1_is_vip_contact;
                            quoteRequestServiceReq.location1_time_zone_id = serviceReq.location1_time_zone_id;
                            quoteRequestServiceReq.has_location1_sensitivities = (bool)serviceReq.has_location1_sensitivities;
                            quoteRequestServiceReq.location1_date_sensitivities = serviceReq.location1_sensitivities_date;
                            quoteRequestServiceReq.location1_sensitivity_type_id = serviceReq.location1_sensitivity_type_id;

                            quoteRequestServiceReq.location2_is_vip_contact = (bool)serviceReq.is_location2_is_vip_contact;
                            quoteRequestServiceReq.location2_time_zone_id = serviceReq.location2_time_zone_id;
                            quoteRequestServiceReq.has_location2_sensitivities = (bool)serviceReq.has_location2_sensitivities;
                            quoteRequestServiceReq.location2_date_sensitivities = serviceReq.location1_sensitivities_date;
                            quoteRequestServiceReq.location2_sensitivity_type_id = serviceReq.location2_sensitivity_type_id;

                            //quoteRequestServiceReq.can_pars_issue_a_temp_tag = (bool)serviceReq.is_pars_to_issue_a_temp_tag;
                            quoteRequestServiceReq.can_pars_issue_a_temp_tag = (bool)(serviceReq.is_pars_to_issue_a_temp_tag == null ? false : serviceReq.is_pars_to_issue_a_temp_tag);
                            //quoteRequestServiceReq.is_inspection_be_needed = (bool)req.is_prior_inspection_required;

                            //quoteRequestServiceReq.do_not_complete_inspection_if_required = (bool)req.do_not_complete_inspection_if_required;
                            //quoteRequestServiceReq.location1_towing_required = (bool)serviceReq.pickup_towing_required;
                            quoteRequestServiceReq.location1_towing_required = (bool)(serviceReq.pickup_towing_required ?? false);
                            quoteRequestServiceReq.vehicle_repossession_required = (bool)(serviceReq.vehicle_repossession_required ?? false);
                            //quoteRequestServiceReq.is_vehicle_at_impound = (bool)req.is_vehicle_at_impound;
                            //quoteRequestServiceReq.service_notification_icon = (long)req.service_notification_icon;
                            quoteRequestServiceReq.does_the_vehicle_have_current_registration = serviceReq.does_the_vehicle_have_current_registration;
                            quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r = serviceReq.do_you_want_pars_to_handle_t_n_r;
                            quoteRequestServiceReq.will_you_send_the_plates_to_fleet_driver = serviceReq.will_you_send_the_plates_to_fleet_driver;
                            quoteRequestServiceReq.is_pars_to_issue_a_temp_tag = serviceReq.is_pars_to_issue_a_temp_tag;
                            quoteRequestServiceReq.new_vehicle_never_registered = serviceReq.new_vehicle_never_registered;
                            quoteRequestServiceReq.do_you_want_pars_to_delay_delivery = serviceReq.do_you_want_pars_to_delay_delivery;
                            quoteRequestServiceReq.requested_t_n_r_service_type_id = serviceReq.requested_t_n_r_service_type_id;
                            //quoteRequestServiceReq.is_commercial_vehicle = req.is_commercial_vehicle;
                            quoteRequestServiceReq.vehicle_license_state_id = serviceReq.license_state_id;
                            quoteRequestServiceReq.year = serviceReq.year;



                            #region GetApplicableServices
                            List<ApplicableServiceDto> applicableServiceList = new List<ApplicableServiceDto>();

                            #region get default services
                            PreferenceReq preferenceReq = new PreferenceReq();
                            preferenceReq.agreement_id = (long)serviceReq.agreement_id;
                            preferenceReq.category_id = (long)EnumTypes.Category_Types.service_request;
                            preferenceReq.event_type_id = 1;
                            preferenceReq.rule_type_id = (long)EnumTypes.Rule_Type.Evaluation;
                            var servicesListReq = await _mediator.Send(new GetPreferencesListQuery { preferenceReq = preferenceReq });

                            #region RequestModel 

                            Application.Utility.Preference.Models.service_request sr_request = new Application.Utility.Preference.Models.service_request();
                            sr_request.vehicle_type = (int)serviceReq.vehicle_type_id;
                            sr_request.primary_fuel_type = (int)serviceReq.primary_fuel_type_id;
                            sr_request.fuel_type = (int)serviceReq.fuel_type_id;

                            if (quoteRequestServiceReq.transportation_type_id == (long)EnumTypes.transportation_type.Auto_Carrier)
                                sr_request.transportation_type_id = (int)EnumTypes.transportation_type.Auto_Carrier;
                            else
                                sr_request.transportation_type_id = (int)EnumTypes.transportation_type.Driveaway;

                            sr_request.retail = quoteRequestServiceReq.retail;
                            if (quoteRequestServiceReq.location1_address_type_id != null)
                                sr_request.pickup_address_type = (int)serviceReq.location1_address_type_id;


                            if (quoteRequestServiceReq.location1_state_id != null)
                                sr_request.pickup_state = (int)serviceReq.location1_state_id;
                            sr_request.pickup_postal_code = serviceReq.location1_postal_code;

                            if (quoteRequestServiceReq.location1_country_id != null)
                                sr_request.pickup_country = (int)serviceReq.location1_country_id;


                            if (quoteRequestServiceReq.location1_storage_id != null)
                                sr_request.pickup_storage = (int)serviceReq.location1_storage_id;

                            sr_request.has_pickup_date_constraints = (bool)serviceReq.has_location1_date_constraints;

                            if (quoteRequestServiceReq.location1_date_constraint_type_id != null)
                                sr_request.pickup_date_constraint_type_id = (int)serviceReq.location1_date_constraint_type_id;

                            if (quoteRequestServiceReq.location2_address_type_id != null)
                                sr_request.delivery_address_type = (int)serviceReq.location2_address_type_id;

                            if (quoteRequestServiceReq.location2_state_id != null)
                                sr_request.delivery_state = (int)serviceReq.location2_state_id;
                            //sr_request.is_verify_delivery_state = req.is_verify_location2_state;
                            sr_request.delivery_postal_code = serviceReq.location2_postal_code;
                            //sr_request.is_verify_delivery_postal_code = req.is_verify_location2_postal_code;

                            if (quoteRequestServiceReq.location2_country_id != null)
                                sr_request.delivery_country = (int)serviceReq.location2_country_id;
                            //sr_request.is_verify_delivery_country = req.is_verify_location2_country;

                            if (quoteRequestServiceReq.location2_storage_id != null)
                                sr_request.delivery_storage = (int)serviceReq.location2_storage_id;
                            //sr_request.has_delivery_date_constraints = req.has_location2_date_constraints;

                            if (quoteRequestServiceReq.location2_date_constraints_type_id != null)
                                sr_request.delivery_date_constraints_type = (int)serviceReq.location2_date_constraints_type_id;

                            if (quoteRequestServiceReq.bill_to != null)
                                sr_request.bill_to = (int)serviceReq.location1_address_type_id;
                            sr_request.pickup_is_vip_contact = (bool)serviceReq.is_location1_is_vip_contact;

                            if (quoteRequestServiceReq.location1_time_zone_id != null)
                                sr_request.pickup_time_zone = (int)serviceReq.location1_time_zone_id;
                            sr_request.has_pickup_sensitivities = (bool)serviceReq.has_location1_sensitivities;
                            //sr_request.pickup_date_sensitivities = quoteRequestServiceReq.pickup_date_sensitivities;

                            if (quoteRequestServiceReq.location1_sensitivity_type_id != null)
                                sr_request.pickup_sensitivity_type = (int)quoteRequestServiceReq.location1_sensitivity_type_id;
                            sr_request.delivery_is_vip_contact = (bool)serviceReq.is_location2_is_vip_contact;

                            if (quoteRequestServiceReq.location2_time_zone_id != null)
                                sr_request.delivery_time_zone = (int)serviceReq.location2_time_zone_id;
                            sr_request.has_delivery_sensitivities = (bool)serviceReq.has_location2_sensitivities;

                            if (quoteRequestServiceReq.location2_sensitivity_type_id != null)
                                sr_request.delivery_sensitivity_type = (int)serviceReq.location2_sensitivity_type_id;

                            sr_request.can_pars_issue_a_temp_tag = (bool)(serviceReq.is_pars_to_issue_a_temp_tag ?? false);
                            //sr_request.is_inspection_be_needed = req.is_inspection_be_needed;
                            //sr_request.do_not_complete_inspection_if_required = (bool)req.do_not_complete_inspection_if_required;
                            sr_request.pickup_towing_required = (bool)(serviceReq.pickup_towing_required ?? false);
                            sr_request.vehicle_repossession_required = (bool)(serviceReq.vehicle_repossession_required ?? false);
                            //sr_request.is_vehicle_at_impound = (bool)req.is_vehicle_at_impound;
                            #endregion

                            #region VEHICLE PLATE STATUS
                            sr_request.is_new_vehicle_never_registered = false;
                            sr_request.plates_are_expired_or_misplaced = false;
                            sr_request.do_you_want_pars_to_handle_t_n_r = false;
                            sr_request.is_pars_to_issue_a_temp_tag = false;
                            sr_request.is_renewal = false;
                            sr_request.is_transfer = false;
                            sr_request.is_new_vehicle_never_registered = false;
                            sr_request.is_plate_replacement = false;

                            if (quoteRequestServiceReq.event_type_id == (long)EnumTypes.Event_Type.t_n_r_preferences)
                            {
                                #region REMOVE T&R REALTED SERVICES

                                // Remove Initial_T_and_R -27 
                                int? indx = null;
                                indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Initial_T_and_R);
                                if (indx != null && indx != -1)
                                {
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)indx);
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Initial_T_and_R);
                                }

                                //Remove Shipping_Handling_Fee
                                indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Shipping_Handling_Fee);
                                if (indx != null && indx != -1)
                                {
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => (x.service_id == (long)EnumTypes.Service.Shipping_Handling_Fee && x.dependent_service_id == null));
                                }

                                //Remove Tags_30_Day_Temp
                                indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Tags_30_Day_Temp);
                                if (indx != null && indx != -1)
                                {
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)indx);
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Tags_30_Day_Temp);
                                }

                                //Remove Registration_Renewal
                                indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Registration_Renewal);
                                if (indx != null && indx != -1)
                                {
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)indx);
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Registration_Renewal);
                                }

                                //Remove Transfer
                                indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Transfer);
                                if (indx != null && indx != -1)
                                {
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)indx);
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Transfer);
                                }

                                //Remove Plate Replacement
                                indx = quoteRequestServiceReq.applicableServiceDto.FindIndex(x => x.service_id == (long)EnumTypes.Service.Plate_Replacement);
                                if (indx != null && indx != -1)
                                {
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAt((int)indx);
                                    quoteRequestServiceReq.applicableServiceDto.RemoveAll(x => x.dependent_service_id == (long)EnumTypes.Service.Plate_Replacement);
                                }

                                #endregion

                                #region T&R Related Fields

                                if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.Yes)
                                {
                                    if (quoteRequestServiceReq.new_vehicle_never_registered == null)
                                    {
                                        applicableServiceList = quoteRequestServiceReq.applicableServiceDto;
                                    }
                                    else if (!(bool)quoteRequestServiceReq.new_vehicle_never_registered)
                                    {
                                        sr_request.is_renewal = false;
                                        sr_request.is_transfer = false;
                                        sr_request.is_new_vehicle_never_registered = false;
                                        sr_request.is_plate_replacement = false;
                                        sr_request.plates_are_expired_or_misplaced = true;
                                        //Pars to handle = Yes 
                                        if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                                        {

                                            if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                                            {
                                                sr_request.do_you_want_pars_to_handle_t_n_r = true;
                                                if (quoteRequestServiceReq.requested_t_n_r_service_type_id != null)
                                                {
                                                    if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Renewal)
                                                    {
                                                        sr_request.is_renewal = true;
                                                        sr_request.is_transfer = false;
                                                        sr_request.is_new_vehicle_never_registered = false;
                                                        sr_request.is_plate_replacement = false;
                                                    }
                                                    else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Replacenent)
                                                    {
                                                        sr_request.is_renewal = false;
                                                        sr_request.is_transfer = false;
                                                        sr_request.is_new_vehicle_never_registered = false;
                                                        sr_request.is_plate_replacement = true;
                                                    }
                                                    else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Transfer)
                                                    {
                                                        sr_request.is_renewal = false;
                                                        sr_request.is_transfer = true;
                                                        sr_request.is_new_vehicle_never_registered = false;
                                                        sr_request.is_plate_replacement = false;
                                                    }
                                                }

                                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                                {
                                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                                }

                                            }
                                            else
                                            {
                                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                                {
                                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                                }
                                            }
                                        }
                                    }

                                }
                                else if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.No)
                                {
                                    sr_request.is_renewal = false;
                                    sr_request.is_transfer = false;
                                    sr_request.is_new_vehicle_never_registered = false;
                                    sr_request.is_plate_replacement = false;



                                    if (quoteRequestServiceReq.new_vehicle_never_registered == null)
                                    {
                                        applicableServiceList = quoteRequestServiceReq.applicableServiceDto;
                                    }
                                    else if ((bool)quoteRequestServiceReq.new_vehicle_never_registered)
                                    {
                                        sr_request.is_renewal = false;
                                        sr_request.is_transfer = false;
                                        sr_request.is_new_vehicle_never_registered = true;
                                        sr_request.is_plate_replacement = false;

                                        //Do you want PARS to handle T&R?
                                        if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                                        {
                                            if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                                            {
                                                sr_request.do_you_want_pars_to_handle_t_n_r = true;
                                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                                {
                                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                                }
                                            }
                                            else
                                            {
                                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                                {
                                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {

                                        sr_request.plates_are_expired_or_misplaced = true;
                                        if (quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r != null)
                                        {
                                            if ((bool)quoteRequestServiceReq.do_you_want_pars_to_handle_t_n_r)
                                            {
                                                sr_request.do_you_want_pars_to_handle_t_n_r = true;
                                                if (quoteRequestServiceReq.requested_t_n_r_service_type_id != null)
                                                {
                                                    if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Renewal)
                                                    {
                                                        sr_request.is_renewal = true;
                                                        sr_request.is_transfer = false;
                                                        sr_request.is_new_vehicle_never_registered = false;
                                                        sr_request.is_plate_replacement = false;
                                                    }
                                                    else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Replacenent)
                                                    {
                                                        sr_request.is_renewal = false;
                                                        sr_request.is_transfer = false;
                                                        sr_request.is_new_vehicle_never_registered = false;
                                                        sr_request.is_plate_replacement = true;
                                                    }
                                                    else if (quoteRequestServiceReq.requested_t_n_r_service_type_id == (long)EnumTypes.requested_t_n_r_service_type.Transfer)
                                                    {
                                                        sr_request.is_renewal = false;
                                                        sr_request.is_transfer = true;
                                                        sr_request.is_new_vehicle_never_registered = false;
                                                        sr_request.is_plate_replacement = false;
                                                    }
                                                }

                                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                                {
                                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                                }

                                            }
                                            else
                                            {
                                                if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                                {
                                                    if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                                        sr_request.is_pars_to_issue_a_temp_tag = true;
                                                }
                                            }
                                        }

                                    }

                                }
                                else if (quoteRequestServiceReq.does_the_vehicle_have_current_registration == (int)EnumTypes.plate_status.I_dont_know)
                                {
                                    if (quoteRequestServiceReq.is_pars_to_issue_a_temp_tag != null)
                                    {
                                        if ((bool)quoteRequestServiceReq.is_pars_to_issue_a_temp_tag)
                                            sr_request.is_pars_to_issue_a_temp_tag = true;
                                    }
                                }
                                #endregion END

                                if (quoteRequestServiceReq.will_you_send_the_plates_to_fleet_driver != null)
                                {
                                    if (!(bool)quoteRequestServiceReq.will_you_send_the_plates_to_fleet_driver)
                                    {
                                        sr_request.will_you_send_plates_to_pars = true;
                                    }
                                }
                            }

                            #endregion END

                            foreach (var item in servicesListReq)
                            {
                                if (item.category_id == (long)Category_Types.service_request)
                                {
                                    item.modelJson = JsonConvert.SerializeObject(sr_request);
                                    item.price_list_id = quoteRequestServiceReq.price_list_id;
                                }
                            }

                            var jsonResults = await _mediator.Send(new EvaluateRulesQuery { preferencesListReq = servicesListReq });
                            var applicableServices = await _mediator.Send(new GetDefaultServicesQuery
                            {
                                jsonResults = jsonResults,
                                price_list_id = quoteRequestServiceReq.price_list_id,
                                agreement_id = quoteRequestServiceReq.agreement_id,
                                rule_type_id = preferenceReq.rule_type_id,
                                event_type_id = preferenceReq.event_type_id,

                                service_standard = (long)EnumTypes.Service_Standard.Standard,
                                applicableServiceDto = quoteRequestServiceReq.applicableServiceDto,


                            });



                            #endregion end

                            #endregion EndGetApplicableServices

                            updateService.icParameter = quoteRequestServiceReq;
                            if(applicableServices!=null)
                                updateService.icParameter.applicableServiceDto = applicableServices;

                            #endregion End

                            #region Duplicate Or Conflict Order

                            DuplicateOrConflictOrderReq conflictOrderReq = new DuplicateOrConflictOrderReq();
                            conflictOrderReq.pickUpAddressTypeId = serviceReq.location1_address_type_id;
                            conflictOrderReq.pickUpAddressStorageCRMId = null;
                            conflictOrderReq.pickupContactName = serviceReq.location1_contact_name;
                            conflictOrderReq.pickupConEmail = serviceReq.location1_contact_primary_email;
                            conflictOrderReq.pickupMobile = serviceReq.location1_contact_phone_1;
                            conflictOrderReq.deliveryAddressTypeId = serviceReq.location2_address_type_id;
                            conflictOrderReq.deliveryAddressStorageCRMId = null;
                            conflictOrderReq.deliveryContactName = serviceReq.location2_contact_name;
                            conflictOrderReq.deliveryConEmail = serviceReq.location2_contact_primary_email;
                            conflictOrderReq.deliveryMobile = serviceReq.location2_contact_phone_1;
                            conflictOrderReq.deliveryMobile = serviceReq.location2_contact_phone_1;

                            updateService.duplicateOrConflictOrderReq = conflictOrderReq;

                            #endregion                         

                            updateServiceReqs.Add(updateService);

                        }
                        //isServiceReqUpdate = await _mediator.Send(new UpdateServiceRequestCommand { updateServiceRequestReqs = updateServiceReqs, queueRule = queueRule });

                        //if (isServiceReqUpdate.Item1 == true)
                        //{
                        //    throw new Exception("PARS_PICKUP_AND_DELIVERY_ADDRESS_NOT_STORAGE_IN_BOTH_CASE");
                        //}
                        //else if (isServiceReqUpdate.Item2 == true)
                        //{
                        //    result = true;
                        //}
                        //else
                        //    throw new BusinessException("PARS_UPDATION_FAILURE");
                    }
                }
                if(updateServiceReqs.Count == 0)
                    result = true;
                //throw new BusinessException("PARS_UPDATION_FAILURE");
                else
                    isServiceReqUpdate = await _mediator.Send(new SubmitServiceRequestOrderBatchCommand { updateServiceRequestReqs = updateServiceReqs, queueRule = queueRule });

                if (isServiceReqUpdate.Item1 == true)
                {
                    throw new Exception("PARS_PICKUP_AND_DELIVERY_ADDRESS_NOT_STORAGE_IN_BOTH_CASE");
                }
                else if (isServiceReqUpdate.Item2 == true)
                {
                    result = true;
                }
                else
                {
                    result = true;
                }
            }
           

            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");

        }

        /// <summary>
        /// API is being used for Sync to CRM
        /// </summary>
        /// <param name="req"> OrderBatchSubmitReq</param>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> SyncToCRM(long import_id)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new SyncToCRMCommand { import_id = import_id });
            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORDS_SYNCED_SUCCESSFULLY");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORDS_SYNCED_FAILURE");
            }
        }

        /// <summary>
        /// API to create Order Batch Import Row details 
        /// </summary>
        /// <param name="orderBatchImportRowReq"> CreateOrderImportRowReq</param>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateOrderBatchImportRow(UpdateOrderBatchRowReq orderBatchImportRowReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateOrderBatchRowCommand
            {
                orderBatchRowReq = orderBatchImportRowReq
            });
            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }

        }


        #region API_CONTRACT_MODEL_AND_VALIDATORS
        /*
        public class OrderBatchImportReqValidator : AbstractValidator<CreateOrderBatchImportReq>
        {
            public OrderBatchImportReqValidator()
            {
                RuleFor(p => p.requested_by_id).NotNull();
                RuleFor(p => p.import_type_id).NotNull();
                RuleFor(p => p.file).NotEmpty().NotNull();
            }
        }
        public class OrderImportVINCheckReq
        {
            public long import_id { get; set; }
            public List<VinVerify> vinNumber { get; set; }
        }
        public class VinVerify
        {
            public long batch_row_id { get; set; }
            public string vin_number { get; set; }
        }
        public class OrderImportVINCheckReqValidator : AbstractValidator<OrderImportVINCheckReq>
        {
            public OrderImportVINCheckReqValidator()
            {
                RuleFor(p => p.import_id).NotEqual(0);
            }
        }
        public class DownloadOrderBatchFileReq
        {
            public long id { get; set; }
        }
        public class CreateOrderImportRowReqValidator : AbstractValidator<CreateOrderImportRowReq>
        {
            public CreateOrderImportRowReqValidator()
            {
                RuleFor(p => p.import_id).NotEqual(0);
            }
        }
        public class UpdateOrderBatchImportReqValidator : AbstractValidator<UpdateOrderBatchImportReq>
        {
            public UpdateOrderBatchImportReqValidator()
            {
                RuleFor(p => p.id).NotNull().WithMessage("import_id can not be null."); ;
            }
        }
        public class OrderBatchGenerateReqValidator : AbstractValidator<OrderBatchGenerateReq>
        {
            public OrderBatchGenerateReqValidator()
            {
                RuleFor(p => p.import_id).NotNull().WithMessage("import_id can not be null."); ;
            }
        }
        public class OrderBatchSubmitReqValidator : AbstractValidator<OrderBatchSubmitReq>
        {
            public OrderBatchSubmitReqValidator()
            {
                RuleFor(p => p.serviceRequestId)
                    .Must(ids => ids != null && ids.Count > 0)
                    .WithMessage("serviceRequestId can not be null.");
            }
        }
       
        #endregion END_API_CONTRACT_MODEL_AND_VALIDATORS
    
*/
    }
}
