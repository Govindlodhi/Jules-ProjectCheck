﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.Vehicle.CheckDuplicateVIN.Queries;
using PARSNextGen.Application.Vehicle.QuickSearch.Queries;
using PARSNextGen.Application.Vehicle.VehicleAttributeConfiguration.Command;
using PARSNextGen.Application.Vehicle.VehicleAttributeConfiguration.Queries;
using PARSNextGen.Application.Vehicle.VehicleDetail.Queries;
using PARSNextGen.Application.Vehicle.VehicleForFleet.Queries;
using PARSNextGen.Application.Vehicle.VehicleForPars.Queries;
using PARSNextGen.Application.Vehicle.VehicleMaterials.Command;
using PARSNextGen.Application.Vehicle.VehicleMaterials.Quries;
using PARSNextGen.Application.Vehicle.Vehicles.Command;
using PARSNextGen.Application.Vehicle.Vehicles.Queries;
using PARSNextGen.Application.Vehicle.VehiclesForFMC.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMessageService;
        public VehicleController(IMediator mediator, ICustomMessageService customMessageService, IConfiguration config)
        {
            _mediator = mediator;
            _customMessageService = customMessageService;
        }

        /// <summary>
        /// API to get list of vehicles for fmc
        /// </summary>
        /// <returns> List of vehicle for fmc </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<FMCVehicles>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehiclesForFMC(AdvancedFilter filter)
        {
            var response = new ResponseBase<FMCVehicles>();
            var vehicleDetails = await _mediator.Send(new GetVehiclesForFmcQuery { reqParm = filter });
            if (vehicleDetails.totalCount == 0)
            {
                response.Data = null;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = vehicleDetails;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API gets list of vehicles for fleet
        /// </summary>
        /// <returns> List of vehicle for fleet </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<FleetVehicles>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehiclesForAccount(AdvancedFilter filter)
        {
            var response = new ResponseBase<FleetVehicles>();

            var vehicleDetails = await _mediator.Send(new GetVehiclesForAccountQuery { reqParm = filter });
            if (vehicleDetails != null)
            {
                if (vehicleDetails.totalCount == 0)
                {
                    response.Data = vehicleDetails;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                    return new OkObjectResult(response);
                }
                else
                {
                    response.Data = vehicleDetails;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                    return new OkObjectResult(response);
                }
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API get details of Vehicle for Pars
        /// </summary>
        /// <returns>  List of vehicle for Pars </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<ParsVehiclesDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehiclesForPars(AdvancedFilter filter)
        {
            var response = new ResponseBase<ParsVehiclesDto>();
            var vehicleDetails = await _mediator.Send(new GetVehiclesForParsQuery { reqParm = filter });
            if (vehicleDetails != null)
            {
                if (vehicleDetails.totalCount == 0)
                {
                    response.Data = vehicleDetails;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                    return new OkObjectResult(response);
                }
                else
                {
                    response.Data = vehicleDetails;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                    return new OkObjectResult(response);
                }
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API get details of Vehicle Master
        /// </summary>
        /// <returns> List of all master Data </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(VehicleMasterDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehiclesMasterData()
        {
            ResponseBase<VehicleMasterDto> response = new ResponseBase<VehicleMasterDto>();
            var VehicleDetails = await _mediator.Send(new GetVehicleMasterQuery { });
            if (VehicleDetails != null)
            {
                response.Data = VehicleDetails;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API to get vehicle details by id.
        /// </summary>
        /// <param name="vehicle_id"> VehicleId </param>
        /// <returns> Vehicle Dto </returns>
        /// <exception cref="Exception"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(VehicleDetailDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehicleById(long vehicleId)
        {
            ResponseBase<VehicleDetailDto> response = new ResponseBase<VehicleDetailDto>();
            var vehicleDetails = await _mediator.Send(new GetVehicleDetailQuery { id = vehicleId });
            if (vehicleDetails is not null)
            {
                response.Data = vehicleDetails;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = vehicleDetails;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to create vehicle.
        /// </summary>
        /// <param name="createRoleReq"> class for vehicle data for create vehicle record </param>
        /// <returns> Created new vehicle id. </returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateVehicle(CreateVehicleReq createVehicleReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            if (string.IsNullOrEmpty(createVehicleReq.vin) && createVehicleReq.vin_unavilability_reasons_id == null)
                throw new BusinessException("PARS_VIN_VALIDATION_UNAVILABILITY_REASONS");

            bool ifExistVin = await _mediator.Send(new CheckDuplicateVINQuery { Vin_number = createVehicleReq.vin });
            if (ifExistVin)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("VEHICLE_VIN_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                long newVehicleId = await _mediator.Send(new CreateVehicleCommand { createVehicleReq = createVehicleReq });
                if (newVehicleId > 0)
                {
                    response.Data = newVehicleId;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                    throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        /// <summary>
        /// API for update vehicle details.
        /// </summary>
        /// <param name="updateVehicleReq"> class for vehicles data for update. </param>
        /// <returns> updated vehicle id. </returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateVehicle(UpdateVehicleReq updateVehicleReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            bool newVehicleId = await _mediator.Send(new UpdateVehicleCommand { updateVehicleReq = updateVehicleReq });
            if (newVehicleId)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// This API method used for update vehicle status
        /// </summary>
        /// <param name="updateVehicleAttConfigStatusReq"> Dto takes  id and vehicle attribute configuration status. </param>
        /// <returns> 204 No Content Status Code. </returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateVehicleStatus(UpdateVehicleStatusReq updateVehicleStatusReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            bool isUpdateSuccessful = await _mediator.Send(new UpdateVehicleStatusCommand { id = updateVehicleStatusReq.id, status = updateVehicleStatusReq.status });
            if (isUpdateSuccessful)
            {
                response.Data = updateVehicleStatusReq.id;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API for create and update vehicle tenancy.
        /// </summary>
        /// <param name="manageVehicleTenancyReq"> class for vehicles tenancy data for create and update. </param>
        /// <returns> updated vehicle id. </returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ManageVehicleTenancy(ManageVehicleTenancyReq manageVehicleTenancyReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool newVehicleId = await _mediator.Send(new ManageVehicleTenancyCommand { manageVehicleTenancyReq = manageVehicleTenancyReq });
            if (newVehicleId)
            {
                if (manageVehicleTenancyReq.id != null)
                {
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                {
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                    return new OkObjectResult(response);
                }
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API for create and update vehicle owner.
        /// </summary>
        /// <param name="manageVehicleOwnerReq"> class for vehicles owner data for create and update. </param>
        /// <returns> updated vehicle id. </returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> ManageVehicleOwner(ManageVehicleOwnerReq manageVehicleOwnerReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool newVehicleId = await _mediator.Send(new ManageVehicleOwnerCommand { manageVehicleOwnerReq = manageVehicleOwnerReq });
            if (newVehicleId)
            {
                if (manageVehicleOwnerReq.id != null)
                {
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                    return new OkObjectResult(response);
                }
                else
                {
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                    return new OkObjectResult(response);
                }
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API for QuickSearchVehicle....
        /// </summary>
        /// <param name="QuickSearchVehicleReq"> class for QuickSearchVehicle request</param>
        /// <returns> Searchble Vihicle data  </returns>
        [HttpPost]
        [ProducesResponseType(typeof(List<QuickSearchVehicleDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> QuickSearchForVehicle(QuickSearchVehicleReq request)
        {
            ResponseBase<List<QuickSearchVehicleDto>> response = new ResponseBase<List<QuickSearchVehicleDto>>();
            var data = await _mediator.Send(new QuickSearchForVehicleQuery { quickSearchRequest = request });
            if (data != null)
            {
                response.Data = data.ToList();
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RESPONSE_NULL");
        }

        /// <summary>
        /// API gets check duplicate VIN
        /// </summary>
        /// <param name="vinReq"> class for Check Duplicate VIN request</param>
        /// <returns> boolean value true or false  </returns>
        /// 
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CheckDuplicateVIN(VinCheckReq vinReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool ifExistVin = await _mediator.Send(new CheckDuplicateVINQuery { Vin_number = vinReq.Vin });
            if (ifExistVin)
            {
                response.Data = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("VEHICLE_VIN_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = false;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_VIN_EXIST");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API for get vehicle tenancy 
        /// </summary>
        /// <paramer> vehicle id </paramer>
        /// <returns> List of Vehicle Tenancy </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<VehicleTenancy>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehicleTenancy(long vehicleId)
        {
            ResponseBase<VehicleTenancy> response = new ResponseBase<VehicleTenancy>();
            var VehicleDetails = await _mediator.Send(new GetVehicleTenancyQuery { vehicle_id = vehicleId });
            if (VehicleDetails != null)
            {
                response.Data = VehicleDetails;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API get Vehicle Tenancy 
        /// </summary>
        /// <returns> List of Vehicle Tenancy </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<VehicleTenancyDetailDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehicleTenancyDetailById(long Id)
        {
            ResponseBase<VehicleTenancyDetailDto> response = new ResponseBase<VehicleTenancyDetailDto>();
            var VehicleDetails = await _mediator.Send(new GetVehicleTenancyDetailQuery { id = Id });
            if (VehicleDetails != null)
            {
                response.Data = VehicleDetails;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API gets Vehicle By Current Location
        /// </summary>
        /// <params>latitude</params>
        /// <params>longitude</params>
        /// <params>distanceRadius</params>
        /// <params>country_id</params>
        /// <returns> Vehicle List </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<VehicleQuickSearchDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehiclesOfNearestLocations(VehiclesOfNearestLocationsReq vehiclesOfNearestLocationsReq)
        {
            ResponseBase<List<VehicleQuickSearchDto>> response = new ResponseBase<List<VehicleQuickSearchDto>>();
            List<VehicleQuickSearchDto> vehiclesList = await _mediator.Send(new GetVehiclesOfNearestLocationsQuery
            {
                post_code = vehiclesOfNearestLocationsReq.postCode,
                distance_radius = vehiclesOfNearestLocationsReq.distanceRadius,
                fmc_id = vehiclesOfNearestLocationsReq.fmcId,
                fleet_id = vehiclesOfNearestLocationsReq.fleetId,
                fleet_no = vehiclesOfNearestLocationsReq.fleetNo
            });
            if (vehiclesList.Count > 0)
            {
                response.Data = vehiclesList;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = vehiclesList;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to get vehicle owner details 
        /// </summary>
        /// <returns> VehicleOwnerDto  </returns>
        /// <exception cref="Exception"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<VehicleOwnerDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehicleOwnerList(long vehicleId)
        {
            ResponseBase<List<VehicleOwnerDto>> response = new ResponseBase<List<VehicleOwnerDto>>();
            var vehicleOwnerDetails = await _mediator.Send(new GetVehicleOwnerListQuery { vehicle_id = vehicleId });
            if (vehicleOwnerDetails.Count > 0)
            {
                response.Data = vehicleOwnerDetails;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API to Validate if Combination of Fleet no. and unit no. exist
        /// </summary>
        /// <params>fleetNo</params>
        /// <params>unitNo</params>
        /// <returns> VehicleId  </returns>
        /// <exception cref="Exception"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<long?>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CheckFleetAndUnitNo(string fleetNo, string unitNo)
        {
            ResponseBase<long?> response = new ResponseBase<long?>();

            long? vehicleId = await _mediator.Send(new CheckFleetandUnitNoQuery
            {
                fleet_no = fleetNo,
                unit_no = unitNo
            });
            if (vehicleId > 0)
            {
                response.Data = vehicleId;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FLEET_UNIT_EXIST");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_FLEET_UNIT_NOT_EXIST");
        }

        /// <summary>
        /// API for update vehicle glovebox record(registration).
        /// </summary>
        /// <param name="vehicleGloveBoxReq"> class for vehicles data for update. </param>
        /// <returns> updated vehicle id. </returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateVehicleGloveBox(UpdateVehicleGloveBoxReq vehicleGloveBoxReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            bool newVehicleId = await _mediator.Send(new UpdateVehicleGloveBoxCommand { req = vehicleGloveBoxReq });
            if (newVehicleId)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API get Current Vehicle Tenancy 
        /// </summary>
        /// <params>vehicleId,fmcId,fleetId</params>
        /// <returns>  Vehicle Tenancy  record - fmc, fleet, unit no., start date</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<CurrentVehicleTenancyDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCurrentVehicleTenancy(CurrentVehicleTenancyReq currentVehicleTenancyRqt)
        {
            ResponseBase<CurrentVehicleTenancyDto> response = new ResponseBase<CurrentVehicleTenancyDto>();

            var vehicleTenany = await _mediator.Send(new GetCurrentVehicleTenancyQuery { currentVehicleTenancyReq = currentVehicleTenancyRqt });
            if (vehicleTenany != null)
            {
                response.Data = vehicleTenany;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// isVehicleEligibleForTemptag
        /// Check if msa signed and msa_expiry_date
        /// Check if a temp tag has not been issued yet
        ///  Check if the vehicle does not come into storage
        /// </summary>
        /// <params>fleetNo</params>
        /// <params>unitNo</params>
        /// <returns> VehicleId  </returns>
        /// <exception cref="Exception"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> isVehicleEligibleForTemptag(VehicleEligibleForTemptagReq vehicleEligibleForTemptagReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var isEligible = await _mediator.Send(new VehicleEligibleForTemptagQuery
            {
                account_id = vehicleEligibleForTemptagReq.accountId,
                vehicle_id = vehicleEligibleForTemptagReq.vehicleId
            });
            if (isEligible)
            {
                response.Data = isEligible;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_VEHICLE_ELIGIBLE_FOR_TEMPTAG");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = isEligible;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_VEHICLE_NOT_ELIGIBLE_FOR_TEMPTAG");
                return new OkObjectResult(response);
            }
        }

        #region Vehicle Attribute Configuration API's

        /// <summary>
        /// API to get vehicle attribute configuration list
        /// </summary>
        /// <returns> VehicleAttributeConfigDTO  </returns>
        /// <exception cref="Exception"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<VehicleAttributeConfigDTO>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehicleAttributeConfigList()
        {
            ResponseBase<List<VehicleAttributeConfigDTO>> response = new ResponseBase<List<VehicleAttributeConfigDTO>>();
            var details = await _mediator.Send(new VehicleAttributeConfigListQuery { });
            if (details.Count > 0)
            {
                response.Data = details;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API gets vehicle_attribute_configuration 
        /// <param name="fmc_id"></param>
        /// <param name="fleet_id"></param>
        /// <returns> User Define Field</returns>
        /// </summary>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<VehicleAttributeConfigDTO>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehicleAttributeConfig(VehicleAttrConfReq vehicleAttrConfReq)
        {
            ResponseBase<VehicleAttributeConfigDTO> responseBase = new ResponseBase<VehicleAttributeConfigDTO>();
            var result = await _mediator.Send(new VehicleAttributeConfigQuery { fmc_Id = vehicleAttrConfReq.fmc_Id, fleet_id = vehicleAttrConfReq.fleet_id });
            if (result is null)
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            else
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(responseBase);
            }
        }

        /// <summary>
        /// API gets vehicle_attribute_configuration 
        /// <param name="id"></param>
        /// <returns> User Define Field</returns>
        /// </summary>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<VehicleAttributeConfigDTO>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehicleAttributeConfigById(long id)
        {
            ResponseBase<VehicleAttributeConfigDTO> responseBase = new ResponseBase<VehicleAttributeConfigDTO>();
            var result = await _mediator.Send(new VehicleAttributeConfigByIdQuery { Id = id });
            if (result != null)
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(responseBase);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// API to create Vehicle Attribute Configuration
        /// </summary>
        /// <param name="vehicleAttributeConfig"> VehicleAttributeConfigReq</param>
        /// <returns> Create vehicleAttributeConfig. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateVehicleAttributeConfig(CreateVehicleAttributeConfigReq vehicleAttributeConfig)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new CreateVehicleAttributeConfigCommand { vehicleAttributeConfigReq = vehicleAttributeConfig });
            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
        }

        /// <summary>
        /// API to update Vehicle Attribute Configuration
        /// </summary>
        /// <param name="updateServiceReq"> UpdateServiceReq</param>
        /// <returns> Update Price. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateVehicleAttrConfig(UpdateVehicleAttributeConfigReq updateVehicleAttributeConfigReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateVehicleAttributeConfigCommand { updateVehicleAttributeConfigReq = updateVehicleAttributeConfigReq });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API to update vehicle attribute configuration status.
        /// </summary>
        /// <param name="updateVehicleAttConfigStatusReq"> Dto takes  id and vehicle attribute configuration status. </param>
        /// <returns> 204 No Content Status Code. </returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateStatusVehicleAttrConfig(UpdateVehicleAttConfigStatusReq updateVehicleAttConfigStatusReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            bool isUpdateSuccessful = await _mediator.Send(new UpdateVehicleAttrConfigStatusCommand { id = updateVehicleAttConfigStatusReq.id, status = updateVehicleAttConfigStatusReq.status });
            if (isUpdateSuccessful)
            {
                response.Data = updateVehicleAttConfigStatusReq.id;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        #endregion End Vehicle Attribute Configuration Details               

        /// <summary>
        /// API gets vehicle materials list 
        /// <param name=""> vehicle_id</param>
        /// <returns> User Define Field</returns>
        /// </summary>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<VehicleMaterialsDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetVehicleMaterialsListById(long vehicleId)
        {
            ResponseBase<List<VehicleMaterialsDto>> responseBase = new ResponseBase<List<VehicleMaterialsDto>>();
            var result = await _mediator.Send(new GetVehicleMaterialsListQuery { vehicle_id = vehicleId });
            if (result.Count > 0)
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(responseBase);
            }
            else
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(responseBase);
            }
        }

        /// <summary>
        /// API gets vehicle materials by id 
        /// <param name=""></param>
        /// <returns> User Define Field</returns>
        /// </summary>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<MaterialsDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetMaterialsDetails(long id)
        {
            ResponseBase<MaterialsDetailsDto> responseBase = new ResponseBase<MaterialsDetailsDto>();
            var result = await _mediator.Send(new GetMaterialsDetailsQuery { Id = id });
            if (result != null)
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(responseBase);
            }
            else
            {
                responseBase.Data = null;
                responseBase.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(responseBase);
            }
        }

        /// <summary>
        /// API to create Vehicle Materials
        /// </summary>
        /// <param name="createMaterialsReq"> CreateMaterialsReq</param>
        /// <returns> Create createVehicleMaterials. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> AddMaterialsForVehicle(CreateMaterialsReq createMaterialsReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new CreateVehicleMaterialCommand { createMaterialsReq = createMaterialsReq });
            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");
        }

        /// <summary>
        /// API to updateVehicle  materials.
        /// </summary>
        /// <param name="updateMaterialsReq"> Dto takes  id and vehicle materials. </param>
        /// <returns> 204 No Content Status Code. </returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateMaterials(UpdateMaterialsReq updateMaterialsReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            bool isUpdateSuccessful = await _mediator.Send(new UpdateVehicleMaterialCommand { updateMaterialsReq = updateMaterialsReq });
            if (isUpdateSuccessful)
            {
                response.Data = (long)updateMaterialsReq.id;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        #region API CONTRACT MODEL AND VALIDATORS       
        public class UpdateVehicleReqValidator : AbstractValidator<UpdateVehicleReq>
        {
            public UpdateVehicleReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }
        public class VinValidation : AbstractValidator<VinCheckReq>
        {
            public VinValidation()
            {
                RuleFor(x => x.Vin).Length(17).WithMessage("VIN must be 17 characters in length.");
                RuleFor(x => x.Vin).NotEmpty().WithMessage("VIN must not be empty.");
            }
        }
        public class VinCheckReq
        {
            public string Vin { get; set; }
        }
        public class UpdateVehicleGloveBoxReqValidator : AbstractValidator<UpdateVehicleGloveBoxReq>
        {
            public UpdateVehicleGloveBoxReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }
        public class CurrentVehicleTenancyReqValidator : AbstractValidator<CurrentVehicleTenancyReq>
        {
            public CurrentVehicleTenancyReqValidator()
            {
                RuleFor(p => p.vehicle_id).NotEmpty().NotNull();
            }
        }
        public class ManageVehicleOwnerReqValidator : AbstractValidator<ManageVehicleOwnerReq>
        {
            public ManageVehicleOwnerReqValidator()
            {
                RuleFor(p => p.owner_type_id).NotEmpty().WithMessage("owner type must not empty");
            }
        }
        public class VehicleAttrConfReq
        {
            public long? fmc_Id { get; set; }
            public long? fleet_id { get; set; }
        }
        public class UpdateVehicleAttributeConfigReqValidator : AbstractValidator<UpdateVehicleAttributeConfigReq>
        {
            public UpdateVehicleAttributeConfigReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }
        public class UpdateVehicleAttConfigStatusReq
        {
            public long id { get; set; }
            public bool status { get; set; }
        }
        public class UpdateVehicleAttConfigStatusReqValidator : AbstractValidator<UpdateVehicleAttConfigStatusReq>
        {
            public UpdateVehicleAttConfigStatusReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }
        public class CreateMaterialsReqValidator : AbstractValidator<CreateMaterialsReq>
        {
            public CreateMaterialsReqValidator()
            {
                RuleFor(p => p.vehicle_id).NotEmpty().WithMessage("Please provide vehicle");
                RuleFor(p => p.vehicle_id).NotNull().WithMessage("Please provide vehicle");
                RuleFor(p => p.vehicle_id).NotEqual(0).WithMessage("Please provide vehicle");
                RuleFor(p => p.materials_type_id).NotEmpty().WithMessage("Please select material type");
                RuleFor(p => p.materials_status_id).NotEmpty().WithMessage("Please select material status");
            }
        }
        public class UpdateMaterialsReqValidator : AbstractValidator<UpdateMaterialsReq>
        {
            public UpdateMaterialsReqValidator()
            {
                RuleFor(p => p.id).NotEmpty().NotNull().NotEqual(0);
                RuleFor(p => p.vehicle_id).NotEmpty().WithMessage("Please provide vehicle");
                RuleFor(p => p.vehicle_id).NotNull().WithMessage("Please provide vehicle");
                RuleFor(p => p.vehicle_id).NotEqual(0).WithMessage("Please provide vehicle");
                RuleFor(p => p.materials_type_id).NotEmpty().WithMessage("Please select material type");
                RuleFor(p => p.materials_status_id).NotEmpty().WithMessage("Please select material status");
            }
        }
        public class UpdateVehicleStatusReq
        {
            public long id { get; set; }
            public bool status { get; set; }
        }
        public class UpdateVehicleStatusReqValidator : AbstractValidator<UpdateVehicleStatusReq>
        {
            public UpdateVehicleStatusReqValidator()
            {
                RuleFor(p => p.id).NotEmpty();
            }
        }
        #endregion
    }
}

