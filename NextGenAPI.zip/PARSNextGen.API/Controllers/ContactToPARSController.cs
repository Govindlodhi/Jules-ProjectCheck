﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.ContactPars.Command;
using PARSNextGen.Application.ContactPars.Queries;
using PARSNextGen.Application.FieldOffice.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.ServiceRequest.Command;
using PARSNextGen.Application.ServiceRequest.Queries;
using System.Collections.Generic;
using System.Threading.Tasks;
using static PARSNextGen.API.Controllers.QuoteController;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class ContactToPARSController : Controller
    {
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;

        public ContactToPARSController(IMediator mediator, ICustomMessageService customMsgSvc)
        {
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
        }
        #region Contact_To_PARS

        /// <summary>
        /// Method for Get Contact To PARS List
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<ContactToPARSListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCaseList(long account_id)
        {
            ResponseBase<List<ContactToPARSListDto>> response = new ResponseBase<List<ContactToPARSListDto>>();

            var contactToPARList = await _mediator.Send(new ContactToPARSListQuery { account_id = account_id });
            if (contactToPARList.Count > 0)
            {
                response.Data = contactToPARList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        // <summary>
        /// API Create Contact To PARS Information  
        /// </summary>
        /// <returns> true/false</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateCase(List<CreateContactToPARSReq> createContactToPARSReq)
        {
            ResponseBase<bool> responseBase = new ResponseBase<bool>();
            bool result = await _mediator.Send(new CreateContactToPARSCommand { createContactToPARSReq = createContactToPARSReq });
            if (result)
            {
                responseBase.Data = true;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(responseBase);
            }
            else
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CREATION_FAILURE");
                return new OkObjectResult(responseBase);

            }
        }
        // <summary>
        /// API Update Contact To PARS Information  
        /// </summary>
        /// <returns> true/false</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateCases(UpdateContactToPARSReq updateContactToPARSReq)
        {
            ResponseBase<bool> responseBase = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateContactToPARSCommand { updateContactToPARSReq = updateContactToPARSReq });
            if (result)
            {
                responseBase.Data = true;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(responseBase);
            }
            else
            {

                responseBase.Data = result;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_UPDATION_FAILURE");
                return new OkObjectResult(responseBase);
            }
        }

        /// <summary>
        /// Method for Get Contact To PARS Details  by id
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<ContactToPARSDetailDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCaseDetails(long id)
        {
            ResponseBase<ContactToPARSDetailDto> response = new ResponseBase<ContactToPARSDetailDto>();

            var contactToPARList = await _mediator.Send(new ContactToPARSDetailQuery { id = id });
            if (contactToPARList != null)
            {
                response.Data = contactToPARList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = contactToPARList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// API to  update account staus by id 
        /// </summary>
        /// <param name="UpdateAccountStatusReq"></param>   
        /// <returns> Bool  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateCaseStatus(UpdateContactToPARSStatusReq updateContactToPARSStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new UpdateContactToPARSStatusCommand
            {
                id = updateContactToPARSStatusReq.id,
                status = updateContactToPARSStatusReq.status
            });
            if (result)
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = result;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_UPDATION_FAILURE");
                return new OkObjectResult(response);
            }

        }


        /// <summary>
        /// Method for Get Case Type Master List
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<CaseTypeMasterDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCaseTypeMaster()
        {
            ResponseBase<List<CaseTypeMasterDto>> response = new ResponseBase<List<CaseTypeMasterDto>>();

            var caseTypeList = await _mediator.Send(new GetCaseTypeMasterQuery { });
            if (caseTypeList.Count > 0)
            {
                response.Data = caseTypeList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = caseTypeList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }




        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<SubjectContactParsDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSubjectContactPars()
        {
            ResponseBase<List<SubjectContactParsDto>> response = new ResponseBase<List<SubjectContactParsDto>>();

            var subjectList = await _mediator.Send(new GetSubjectListQuery { });
            if (subjectList.Count > 0)
            {
                response.Data = subjectList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = subjectList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        // <summary>
        /// API Create Contact To PARS Information  
        /// </summary>
        /// <returns> true/false</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateContactPARS(List<ContactParsReq> createContactPARSReq)
        {
            ResponseBase<bool> responseBase = new ResponseBase<bool>();
            bool result = await _mediator.Send(new CreateContactParsCommand { contactParsReq = createContactPARSReq });
            if (result)
            {
                responseBase.Data = true;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(responseBase);
            }
            else
            {
                responseBase.Data = result;
                responseBase.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_CREATION_FAILURE");
                return new OkObjectResult(responseBase);

            }
        }
        #endregion
    }
}
