﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.FieldOffice.Command;
using PARSNextGen.Application.FieldOffice.Queries;
using PARSNextGen.Application.Master.AccountType.Command;
using PARSNextGen.Application.Master.AccountType.Query;
using PARSNextGen.Application.Master.AgreementType.Command;
using PARSNextGen.Application.Master.AgreementType.Query;
using PARSNextGen.Application.Master.Category.Command;
using PARSNextGen.Application.Master.Category.Query;
using PARSNextGen.Application.Master.CountryMaster.Queries;
using PARSNextGen.Application.Master.DocumentType.Command;
using PARSNextGen.Application.Master.DocumentType.Query;
using PARSNextGen.Application.Master.Queue.Command;
using PARSNextGen.Application.Master.Queue.Query;
using PARSNextGen.Application.Master.Service.Command;
using PARSNextGen.Application.Master.Service.Queries;
using PARSNextGen.Application.Master.StateMaster.Queries;
using PARSNextGen.Application.Master.SubCategory.Queries;
using PARSNextGen.Application.Master.SupportContact.Command;
using PARSNextGen.Application.Master.SupportContact.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SyncLogHistory.Command;
using PARSNextGen.Application.SyncLogHistory.Queries;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class MasterController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMessageService;

        public MasterController(IMediator mediator, ICustomMessageService customMessageService)
        {
            _mediator = mediator;
            _customMessageService = customMessageService;
        }

        #region API CONTROLLER METHODS

        /// <summary>
        /// API to get contries
        /// </summary>
        /// <param name="pageNo"> Page Number </param>
        /// <param name="pageSize"> Page Size</param>
        /// <returns> List of countries. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(List<CountryDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCountries()
        {
            ResponseBase<List<CountryDto>> response = new ResponseBase<List<CountryDto>>();

            var countries = await _mediator.Send(new GetCountryQuery { });
            if (countries != null)
            {
                response.Data = countries;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");

        }

        /// <summary>
        /// API to get state based on countryId
        /// </summary>
        /// <param name="pageNo"> Page Number </param>
        /// <param name="pageSize"> Page Size</param>
        /// <returns> List of state of a country. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(List<stateDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetStateData(long CountryId)
        {
            ResponseBase<List<stateDto>> response = new ResponseBase<List<stateDto>>();

            var stateData = await _mediator.Send(new GetStateQuery { country_id = CountryId });
            if (stateData != null)
            {
                response.Data = stateData;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");

        }

        /// <summary>
        /// API to get Sub Category based on Category
        /// </summary>
        /// <param name="pageNo"> Page Number </param>
        /// <param name="pageSize"> Page Size</param>
        /// <returns> List of Sub Category of a country. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(List<SubCategoryDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSubCategory(long categoryId)
        {
            ResponseBase<List<SubCategoryDto>> response = new ResponseBase<List<SubCategoryDto>>();

            var stateData = await _mediator.Send(new GetSubCategoryQuery { category_id = categoryId });
            if (stateData != null)
            {
                response.Data = stateData;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");

        }

        #region Service Master API's

        /// <summary>
        /// API to get Master service list
        /// </summary>
        /// <param name="pageNo"> Page Number </param>
        /// <param name="pageSize"> Page Size</param>
        /// <returns> List of Sub Category of a country. </returns>
        /// <exception cref="BusinessException"></exception>CreateService
        [HttpGet]
        [ProducesResponseType(typeof(List<ServiceDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServiceList()
        {
            ResponseBase<List<ServiceDto>> response = new ResponseBase<List<ServiceDto>>();

            var result = await _mediator.Send(new GetServiceQuery { });
            if (result != null)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");

        }

        /// <summary>
        /// API to create Service 
        /// </summary>
        /// <param name="createService"> CreateServiceReq</param>
        /// <returns> Create Service. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateService(CreateServiceReq createServiceReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new CreateServiceCommand { createServiceReq = createServiceReq });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
        }
        /// <summary>
        /// API to update Service
        /// </summary>
        /// <param name="updateServiceReq"> UpdateServiceReq</param>
        /// <returns> Update Price. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateService(UpdateServiceReq updateServiceReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateServiceCommand { updateServiceReq = updateServiceReq });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
        }

        /// <summary>
        /// API to update Service status.
        /// </summary>
        /// <param name="updateServiceStatus"> Dto takes service id and service status. </param>
        /// <returns> 204 No Content Status Code. </returns>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<long>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateServiceStatus(UpdateServiceStatusReq updateServiceStatusReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            bool isUpdateSuccessful = await _mediator.Send(new UpdateServiceStatusCommand { service_id = updateServiceStatusReq.service_id, service_status = updateServiceStatusReq.service_status });
            if (isUpdateSuccessful)
            {
                response.Data = updateServiceStatusReq.service_id;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API to Get Service Master Data
        /// </summary>
        /// <returns> List of Service Master Data   </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<ServiceMasterDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServiceMasterData()
        {
            ResponseBase<ServiceMasterDto> response = new ResponseBase<ServiceMasterDto>();
            var serviceDetails = await _mediator.Send(new GetServiceMasterQuery { });
            if (serviceDetails is not null)
            {
                response.Data = serviceDetails;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");

        }

        /// <summary>
        /// API to get Service based on Id
        /// </summary>
        /// <param name="pageNo"> Page Number </param>
        /// <param name="pageSize"> Page Size</param>
        /// <returns> service based on service id. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ServiceDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServiceById(long ServiceId)
        {
            ResponseBase<ServiceDto> response = new ResponseBase<ServiceDto>();

            var stateData = await _mediator.Send(new GetServiceByIdQuery { id = ServiceId });
            if (stateData is not null)
            {
                response.Data = stateData;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");

        }
        #endregion

        #region Support Contact Realted API

        /// <summary>
        /// API to Get Service Master Data
        /// </summary>
        /// <returns> List of Service Master Data   </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(SupportContactMasterDataDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSupportContactMasterData()
        {
            ResponseBase<SupportContactMasterDataDto> response = new ResponseBase<SupportContactMasterDataDto>();
            var serviceDetails = await _mediator.Send(new GetSupportContactMasterDataQuery { });
            if (serviceDetails != null)
            {
                response.Data = serviceDetails;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");

        }

        /// <summary>
        /// This API method used to create support contact 
        /// </summary>
        /// <param name="createService"> CreateServiceReq</param>
        /// <returns> Create Service. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateSupportContact(CreateSupportContactReq createSupportContactReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new CreateSupportContactCommand { createSupportContactReq = createSupportContactReq });
            if (result)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_DUPLICATE_ENTRY");

        }

        /// <summary>
        /// This method used for update support contact basic details
        /// </summary>
        /// <param name="createService"> CreateServiceReq</param>
        /// <returns> Create Service. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateSupportContact(UpdateSupportContactReq updateSupportContactReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateSupportContactCommand { updateSupportContactReq = updateSupportContactReq });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// This API method used for update support contact status
        /// </summary>
        /// <param name="createService"> CreateServiceReq</param>
        /// <returns> Create Service. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateSupportContactStatus(UpdateSupportContactStatusReq updateSupportContactStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateSupportContactStatusCommand { updateSupportContactStatusReq = updateSupportContactStatusReq });
            if (result)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");

        }

        /// <summary>
        /// This API method used for get support contact list based on account type, fmc and fleet
        /// </summary>
        /// <param name="pageNo"> Page Number </param>
        /// <param name="pageSize"> Page Size</param>
        /// <returns> List of SupportContact. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(List<SupportContactListDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSupportContactList(SupportContactListReq supportContactListReq)
        {
            ResponseBase<List<SupportContactListDto>> response = new ResponseBase<List<SupportContactListDto>>();

            var result = await _mediator.Send(new GetSupportContactQuery { supportContactListReq = supportContactListReq });
            if (result is not null)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// This API method used for get support contact list based on id.
        /// </summary>
        /// <param name="pageNo"> Page Number </param>
        /// <param name="pageSize"> Page Size</param>
        /// <returns> List of SupportContact. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(SupportContactDetailDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSupportContactDetailById(long id)
        {
            ResponseBase<SupportContactDetailDto> response = new ResponseBase<SupportContactDetailDto>();

            var result = await _mediator.Send(new SupportContactDetailQuery { id = id });
            if (result is not null)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        #endregion

        #region API CONTROLLER FOR QUEUE METHODS

        /// <summary>
        /// API to create Queue 
        /// </summary>
        /// <param name="createQueue"> </param>
        /// <returns> Create Queue. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateQueue(CreateQueueReq createQueueReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateQueueCommand { createQueueReq = createQueueReq });

            if (result.Item2)
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");
        }

        /// <summary>
        /// Api to update queue
        /// </summary>
        /// <param name="updatequeueReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateQueue(UpdateQueueReq updatequeueReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateQueueCommand { updateQueueReq = updatequeueReq });
            if (result)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");

        }

        /// <summary>
        /// This API method used for update queue status
        /// </summary>
        /// <param name="updatequeueReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateQueueStatus(UpdateQueueStatusReq updatequeueReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateQueueStatusCommand { id = updatequeueReq.id, is_active = updatequeueReq.is_active });
            if (result)
            {
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");

        }

        /// <summary>
        /// This API used for get queue list
        /// </summary>
        /// <returns> List of Queue Data  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(GetAllQueueListDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllQueue()
        {
            ResponseBase<List<GetAllQueueListDto>> response = new ResponseBase<List<GetAllQueueListDto>>();
            var domainlist = await _mediator.Send(new GetAllQueueListQuery { });
            if (domainlist?.Count > 0)
            {
                response.Data = domainlist;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// This API method used for get queue basic details based on id
        /// </summary>
        /// <returns> Get Queue Data By Id </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(GetQueueDetailByIdDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetQueueDetailById(long id)
        {
            ResponseBase<GetQueueDetailByIdDto> response = new ResponseBase<GetQueueDetailByIdDto>();
            var queue = await _mediator.Send(new GetQueueDetailByIdQuery { id = id });
            if (queue is not null)
            {
                response.Data = queue;
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");

        }

        #endregion

        #region API CONTROLLER FOR ACCOUNT-TYPE METHOD.
        /// <summary>
        /// This method used for create account type
        /// </summary>
        /// <param name="createAccountType"> </param>
        /// <returns> Create account-type. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateAccountType(CreateAccountTypeReq createAccountTypeReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateAccountTypeCommand { createAccountTypeReq = createAccountTypeReq });
            if (result.Item2)
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            else if (result.Item1)
            {
                response.IsSuccessful = true;
                response.Data = result.Item1;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");

        }

        /// <summary>
        /// This API used for update queue basic details
        /// </summary>
        /// <param name="updateAccountType"></param>
        /// <returns> update record..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateAccountType(UpdateAccountTypeReq updateAccountTypeReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateAccountTypeCommand { updateAccountTypeReq = updateAccountTypeReq });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// This API used for update account type status
        /// </summary>
        /// <param name="updatequeueReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateAccountTypeStatus(UpdateAccountTypeStatusReq updateAccountTypeStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateAccountTypeStatusCommand { typeStatusReq = updateAccountTypeStatusReq });
            if (result)
            {
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// This API method used for get account type list
        /// </summary>
        /// <returns> List of Accounttype Data  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<GetAllAccountTypeDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllAccountTypeList()
        {
            ResponseBase<List<GetAllAccountTypeDto>> response = new ResponseBase<List<GetAllAccountTypeDto>>();
            var domainlist = await _mediator.Send(new GetAllAccountTypeQuery { });
            if (domainlist?.Count > 0)
            {
                response.Data = domainlist;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");

        }

        /// <summary>
        /// This API used for get account type basic details based on id
        /// </summary>
        /// <returns> List of Accounttype Data  </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(GetAccountTypeByIdDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAccountTypeById(long id)
        {
            ResponseBase<GetAccountTypeByIdDto> response = new ResponseBase<GetAccountTypeByIdDto>();
            var domain = await _mediator.Send(new GetAccountTypeByIdQuery { id = id });
            if (domain is not null)
            {
                response.Data = domain;
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        #endregion

        #region API CONTROLLER FOR CATEGORY

        /// <summary>
        /// API to create category
        /// </summary>
        /// <param name="createCategory"> </param>
        /// <returns> Create category </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateCategory(CreateCategoryReq createCategory)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateCategoryCommand { createCategory = createCategory });
            if (result.Item2)
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            else if (result.Item1)
            {
                response.IsSuccessful = true;
                response.Data = result.Item1;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");
        }

        /// <summary>
        /// This API used for update category basic details based on id
        /// </summary>
        /// <param name="updateAccountType"></param>
        /// <returns> update record..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateCategory(UpdateCategoryReq updateCategoryReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateCategoryCommand { Req = updateCategoryReq });
            if (result)
            {
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// This API method used for update category status based on id
        /// </summary>
        /// <param name="updateAccountTypeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateCategoryStatus(UpdateCategoryStatusReq updateCategoryStatus)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateCategoryStatusCommand { UpdateCategory = updateCategoryStatus });
            if (result)
            {
                response.Data = result;
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// This method used for get category list
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAllCategoryDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllCategory()
        {
            ResponseBase<List<GetAllCategoryDto>> response = new ResponseBase<List<GetAllCategoryDto>>();
            var category = await _mediator.Send(new GetAllCategoryQuery { });
            if (category.Count > 0)
            {
                response.Data = category;
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// This API method used for get category basic details based on id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(GetCategoryByIdDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCategoryById(long id)
        {
            ResponseBase<GetCategoryByIdDto> response = new ResponseBase<GetCategoryByIdDto>();
            var category = await _mediator.Send(new GetCategoryByIdQuery { id = id });
            if (category is not null)
            {
                response.Data = category;
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        #endregion

        #region API CONTROOLER FOR DOCUMENT-TYPE

        /// <summary>
        ///This API method used for create document type basic details 
        /// </summary>
        /// <param name="createDocTypeReq"> </param>
        /// <returns> Create category </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateDocumentType(CreateDocumentTypeReq createDocTypeReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateDocumentTypeCommand { createDocTypeReq = createDocTypeReq });
            if (result.Item2)
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_CREATION_FAILURE");
        }

        /// <summary>
        /// This API method used for update document type basic details based on id
        /// </summary>
        /// <param name="updateAccountType"></param>
        /// <returns> update record..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateDocumentTypeDetails(UpdateDocumentTypeReq updateDocumentReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateDocumentTypeCommand { typeReq = updateDocumentReq });
            if (result)
            {
                response.IsSuccessful = true;
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// This API method used for update document type status based on id
        /// </summary>
        /// <param name="updateAccountTypeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateDocumentTypeStatus(UpdateDocumentTypeStatusReq updateDocStatus)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateDocumentTypeStatusCommand { statusReq = updateDocStatus });
            if (result)
            {
                response.IsSuccessful = true;
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// This API method used for get document type basic details based on id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(GetDocumentTypeDtos), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetDocumentTypeById(long id)
        {
            ResponseBase<GetDocumentTypeDtos> response = new ResponseBase<GetDocumentTypeDtos>();
            var category = await _mediator.Send(new GetDocumentTypeQuery { id = id });
            if (category is not null)
            {
                response.Data = category;
                response.IsSuccessful = true;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        /// <summary>
        /// This API method used for Get document type list
        /// </summary>
        /// <returns> list of records..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(List<GetAllDocumentTypeDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllDocumentType()
        {
            ResponseBase<List<GetAllDocumentTypeDto>> response = new ResponseBase<List<GetAllDocumentTypeDto>>();
            var category = await _mediator.Send(new GetAllDocumentTypeQuery { });
            if (category.Count > 0)
            {
                response.Data = category;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
        }

        #endregion

        #region API CONTROLLER FOR AGREEMENT-TYPE

        /// <summary>
        /// 
        /// </summary>
        /// <param name="createAgreementType"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateAgreementType(CreateAgreementTypeReq createAgreementType)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateAgreementTypeCommand { CreateAgreementTypeReq = createAgreementType });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        /// <summary>
        /// Api to  update Account Type
        /// </summary>
        /// <param name="updateAccountType"></param>
        /// <returns> update record..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateAgreementTypeDetails(UpdateAgreementTypeReq updateAgreementType)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateAgreementTypeCommand
            {
                id = updateAgreementType.id,
                name = updateAgreementType.name,
                description = updateAgreementType.description
            });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        /// <summary>
        /// Api to update queue status
        /// </summary>
        /// <param name="updatequeueReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateAgreementTypeStatus(UpdateAgreementTypeStatusReq updateAccountTypeStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            bool result = await _mediator.Send(new UpdateAgreementTypeStatusCommand { id = updateAccountTypeStatusReq.id, is_active = updateAccountTypeStatusReq.is_active });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        /// <summary>
        /// GetCategory By id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAgreementTypeByIdDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAgreementTypeDetails(long id)
        {
            ResponseBase<List<GetAgreementTypeByIdDto>> response = new ResponseBase<List<GetAgreementTypeByIdDto>>();
            var category = await _mediator.Send(new GetAgreementTypeByIdQuery { id = id });
            if (category?.Count > 0)
            {
                response.Data = category;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns> list of records..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<GetAllAgreementTypeReq>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllAgreementType()
        {
            ResponseBase<List<GetAllAgreementTypeReq>> response = new ResponseBase<List<GetAllAgreementTypeReq>>();
            var category = await _mediator.Send(new GetAllAgreementTypeQuery { });
            if (category?.Count > 0)
            {
                response.Data = category;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        #endregion

        #region API - CONTROLLER FOR SYNC LOG HISTORY

        /// <summary>
        /// Get Sync log History List
        /// </summary>
        /// <returns> SyncLogHistoryDto..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<List<SyncLogHistoryDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSyncLogHistoryList(SyncLogHistoryReq syncLogHistoryReq)
        {
            ResponseBase<List<SyncLogHistoryDto>> response = new ResponseBase<List<SyncLogHistoryDto>>();
            var result = await _mediator.Send(new GetSyncLogHistoryListQuery
            {
                entity_name = syncLogHistoryReq.entity_name,
                sync_log_status_id = syncLogHistoryReq.sync_log_status_id,
                operation_id = syncLogHistoryReq.operation_id,
            });
            if (result != null)
            {
                if (result.Count == 0)
                {
                    response.Data = result;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                    return new OkObjectResult(response);
                }
                else
                {
                    response.Data = result;
                    response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                    return new OkObjectResult(response);
                }
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns> list of records..</returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<SyncLogStatusMasterListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSyncLogStatusMasterList()
        {
            ResponseBase<List<SyncLogStatusMasterListDto>> response = new ResponseBase<List<SyncLogStatusMasterListDto>>();
            var syncLogStatusList = await _mediator.Send(new SyncLogStatusMasterListQuery { });
            if (syncLogStatusList != null)
            {
                List<SyncLogStatusMasterListDto> list = new List<SyncLogStatusMasterListDto>();
                list.Add(syncLogStatusList);
                response.Data = list;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        /// <summary>
        /// API to create Service 
        /// </summary>
        /// <param name="createService"> CreateServiceReq</param>
        /// <returns> Create Service. </returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateSyncLogHistory(UpdateSyncLogHistoryReq updateSyncLogHistory)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateSyncLogHistoryCommand
            {
                id = updateSyncLogHistory.id

            });
            if (result)
            {
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        #endregion

        #region API - Field Office

        /// <summary>
        /// This method used for get active field office details list
        /// </summary>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpGet]
        [ProducesResponseType(typeof(List<FieldOfficeDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFieldOfficeList()
        {
            ResponseBase<List<FieldOfficeDto>> response = new ResponseBase<List<FieldOfficeDto>>();

            var fieldOfficeList = await _mediator.Send(new FieldOfficeListQuery { });
            if (fieldOfficeList.Count > 0)
            {
                response.Data = fieldOfficeList;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = fieldOfficeList;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// This method used for get inactive field office details list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<FieldOfficeDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetInactiveFieldOfficeList()
        {
            ResponseBase<List<FieldOfficeDto>> response = new ResponseBase<List<FieldOfficeDto>>();

            var fieldOfficeList = await _mediator.Send(new GetInactiveFieldOfficeListQuery { });
            if (fieldOfficeList.Count > 0)
            {
                response.Data = fieldOfficeList;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = fieldOfficeList;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// This method used for get inactive field office details list
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        [ProducesResponseType(typeof(List<FieldOfficeDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFieldOfficeDetailsById(long id)
        {
            ResponseBase<FieldOfficeDto> response = new ResponseBase<FieldOfficeDto>();

            var fieldOffice = await _mediator.Send(new GetFieldOfficeDetailsByIdQuery { id = id });
            if (fieldOffice is not null)
            {
                response.Data = fieldOffice;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                response.Data = fieldOffice;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_NOT_FOUND");
                return new OkObjectResult(response);
            }
        }

        /// <summary>
        /// This method used for create field office details
        /// </summary>
        /// <param name="officeReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(long), StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateFieldOffice(FieldOfficeReq officeReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            var office_id = await _mediator.Send(new ManageFieldOfficeCommand { officeReq = officeReq });
            if (office_id > 0)
            {
                response.Data = office_id;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                if (office_id == -1)
                    throw new BusinessException("PARS_DUPLICATE_BUSINESS_UNIT");
                else
                    throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }
        /// <summary>
        /// This method used for update field office details
        /// </summary>
        /// <param name="officeReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(long), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateFieldOffice(FieldOfficeReq officeReq)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            var office_id = await _mediator.Send(new ManageFieldOfficeCommand { officeReq = officeReq });

            if (office_id > 0)
            {
                response.Data = office_id;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                if (office_id == -1)
                    throw new BusinessException("PARS_DUPLICATE_ENTRY");
                else
                    throw new BusinessException("PARS_CREATION_FAILURE");
            }


        }

        /// <summary>
        /// This method used for update field office status
        /// </summary>
        /// <param name="officeReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(long), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateFieldOfficeStatus(long id, bool is_active)
        {
            ResponseBase<long> response = new ResponseBase<long>();

            var office_id = await _mediator.Send(new ChangeFieldOfficeStatusCommand { id = id, is_active = is_active });

            if (office_id > 0)
            {
                response.Data = office_id;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");


        }

        #endregion

        #endregion

        #region Service API MODELS AND VALIDATIONS


        public class CreateServiceReqValidator : AbstractValidator<CreateServiceReq>
        {
            public CreateServiceReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();
                RuleFor(p => p.category_id).NotNull().NotEmpty();
                RuleFor(p => p.sub_category_id).NotNull().NotEmpty().NotEqual(0);
                RuleFor(p => p.rate_type_id).NotNull().NotEmpty().NotEqual(0);

            }
        }
        public class UpdateServiceReqValidator : AbstractValidator<UpdateServiceReq>
        {
            public UpdateServiceReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();
                RuleFor(p => p.id).NotNull().NotEmpty();

            }
        }
        //Update Service status Dto and Validator
        public class UpdateServiceStatusReq
        {
            public long service_id { get; set; }
            public bool service_status { get; set; }
        }
        public class UpdateServiceStatusReqValidator : AbstractValidator<UpdateServiceStatusReq>
        {
            public UpdateServiceStatusReqValidator()
            {
                RuleFor(p => p.service_id).NotEqual(0);
            }
        }

        public class GetQueueDetailByIdDtoValidator : AbstractValidator<GetQueueDetailByIdDto>
        {
            public GetQueueDetailByIdDtoValidator()
            {
                RuleFor(p => p.id).NotNull().NotEmpty();
            }
        }

        public class UpdateQueueStatusReqValidator : AbstractValidator<UpdateQueueStatusReq>
        {
            public UpdateQueueStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
            }
        }

        public class UpdateQueueReqValidator : AbstractValidator<UpdateQueueReq>
        {
            public UpdateQueueReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
            }
        }

        public class UpdateAccountTypeReqValidator : AbstractValidator<UpdateAccountTypeReq>
        {
            public UpdateAccountTypeReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
            }
        }

        public class GetAccountTypeByIdReqValidator : AbstractValidator<GetAccountTypeByIdDto>
        {
            public GetAccountTypeByIdReqValidator()
            {
                RuleFor(p => p.id).NotNull().NotEmpty();
            }
        }

        public class UpdateAccountTypeStatusReqValidator : AbstractValidator<UpdateAccountTypeStatusReq>
        {
            public UpdateAccountTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
            }
        }

        public class GetCategoryByIdReqValidator : AbstractValidator<GetCategoryByIdDto>
        {
            public GetCategoryByIdReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }

        public class UpdateCategoryReqValidator : AbstractValidator<UpdateCategoryReq>
        {
            public UpdateCategoryReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }

        public class UpdateCategoryStatusReqValidator : AbstractValidator<UpdateCategoryStatusReq>
        {
            public UpdateCategoryStatusReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }

        public class GetDocumentTypeReqValidator : AbstractValidator<GetDocumentTypeDtos>
        {
            public GetDocumentTypeReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }
        public class UpdateDocumentTypeStatusReqValidaor : AbstractValidator<UpdateDocumentTypeStatusReq>
        {
            public UpdateDocumentTypeStatusReqValidaor()
            {
                RuleFor(p => p.id).NotNull();
            }
        }
        public class UpdateDocumentTypeReqValidator : AbstractValidator<UpdateDocumentTypeReq>
        {
            public UpdateDocumentTypeReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }

        public class UpdateAgreementTypeReqValidator : AbstractValidator<UpdateAgreementTypeReq>
        {
            public UpdateAgreementTypeReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }
        public class UpdateAgreementTypeStatusReqValidator : AbstractValidator<UpdateAgreementTypeStatusReq>
        {
            public UpdateAgreementTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }
        public class GetAgreementTypeByIdDtoValidator : AbstractValidator<GetAgreementTypeByIdDto>
        {
            public GetAgreementTypeByIdDtoValidator()
            {
                RuleFor(p => p.id).NotNull();
            }
        }

        #endregion 
    }
}
