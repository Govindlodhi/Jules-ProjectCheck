﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.AdministratorMaster.EventTypes.Command;
using PARSNextGen.Application.AdministratorMaster.EventTypes.Queries;
using PARSNextGen.Application.AdministratorMaster.FleetSizes.Command;
using PARSNextGen.Application.AdministratorMaster.FleetSizes.Queries;
using PARSNextGen.Application.AdministratorMaster.FuelSurCharges.Command;
using PARSNextGen.Application.AdministratorMaster.FuelSurCharges.Queries;
using PARSNextGen.Application.AdministratorMaster.FuelTypes.Command;
using PARSNextGen.Application.AdministratorMaster.FuelTypes.Queries;
using PARSNextGen.Application.AdministratorMaster.HubLocations.Command;
using PARSNextGen.Application.AdministratorMaster.HubLocations.Queries;
using PARSNextGen.Application.AdministratorMaster.MoveTypes.Command;
using PARSNextGen.Application.AdministratorMaster.MoveTypes.Queries;
using PARSNextGen.Application.AdministratorMaster.PreferenceTypes.Command;
using PARSNextGen.Application.AdministratorMaster.PreferenceTypes.Queries;
using PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Command;
using PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Queries;
using PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Command;
using PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Queries;
using PARSNextGen.Application.AdministratorMaster.ServiceRequestTypes.Command;
using PARSNextGen.Application.AdministratorMaster.ServiceRequestTypes.Queries;
using PARSNextGen.Application.AdministratorMaster.TransportationPreferenceTypes.Command;
using PARSNextGen.Application.AdministratorMaster.TransportationPreferenceTypes.Queries;
using PARSNextGen.Application.AdministratorMaster.TransportationTypes.Command;
using PARSNextGen.Application.AdministratorMaster.TransportationTypes.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.ServiceRequest.Queries;
using StackExchange.Redis;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class ServiceRequestMasterController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;
        private readonly ConnectionMultiplexer _redis;
        private readonly IDatabase _db;
        private readonly IDistributedCache _cache;

        public ServiceRequestMasterController(IMediator mediator, ICustomMessageService customMsgSvc, IDistributedCache cache)
        {
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
            _cache = cache;
        }
        #region API METHODS


        #region EVENT TYPE API METHODS

        // <summary>
        /// API to Get Event Type List
        /// </summary>
        /// <returns> List of Event Type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<EventTypeListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEventTypeList()
        {
            ResponseBase<List<EventTypeListDto>> response = new ResponseBase<List<EventTypeListDto>>();
            List<EventTypeListDto> eventTypeList = null;

            var data = _cache.GetString("GetEventTypeList");

            if (data != null)
                eventTypeList = JsonConvert.DeserializeObject<List<EventTypeListDto>>(data);
            else
            {
                eventTypeList = await _mediator.Send(new EventTypeListQuery { });
                _cache.SetString("GetEventTypeList", JsonConvert.SerializeObject(eventTypeList));
            }

            if (eventTypeList != null)
            {
                
                response.Data = eventTypeList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        // <summary>
        /// API to Get Event Type List
        /// </summary>
        /// <returns> List of Event Type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<EventTypeDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEventTypeDetails(long id)
        {
            ResponseBase<EventTypeDetailsDto> response = new ResponseBase<EventTypeDetailsDto>();
            var eventTypeDetails = await _mediator.Send(new EventTypeDetailsQuery { id = id });
            if (eventTypeDetails != null)
            {

                response.Data = eventTypeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        // <summary>
        /// Api to create eventType
        /// </summary>
        /// <param name="createEventTypeReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateEventType(CreateEventTypeCommandReq createEventTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateEventTypeCommand { createEventTypeCommandReq = createEventTypeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update eventType
        /// </summary>
        /// <param name="updateEventTypeReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateEventType(UpdateEventTypeCommandReq UpdateEventTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateEventTypeCommand
            {
                updateEventTypeCommandReq = UpdateEventTypeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        /// <summary>
        /// Api to update eventType status
        /// </summary>
        /// <param name="updateEventTypeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateEventTypeStatus(UpdateEventTypeStatusReq updateEventTypeStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateEventTypeStatusCommand { id = updateEventTypeStatusReq.id, is_active = updateEventTypeStatusReq.is_active });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        #endregion END EVENT TYPE METHOD

        #region FLEET SIZE API METHOD

        // <summary>
        /// API to Get Fleet Size List
        /// </summary>
        /// <returns> List of Fleet Size   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<FleetSizeListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFleetSizeList()
        {
            ResponseBase<List<FleetSizeListDto>> response = new ResponseBase<List<FleetSizeListDto>>();
            var fleetSizeList = await _mediator.Send(new FleetSizeListQuery { });
            if (fleetSizeList != null)
            {

                response.Data = fleetSizeList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        // <summary>
        /// API to Get Fleet size Details
        /// </summary>
        /// <returns> LGet Details of fleet size   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<FleetSizeDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFleetSizeDetails(long id)
        {
            ResponseBase<FleetSizeDetailsDto> response = new ResponseBase<FleetSizeDetailsDto>();
            var fleetSizeDetails = await _mediator.Send(new FleetSizeDetailsQuery { id = id });
            if (fleetSizeDetails != null)
            {

                response.Data = fleetSizeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// Api to create Fleet Size
        /// </summary>
        /// <param name="CreateFleetSizeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateFleetSize(CreateFleetSizeCommandReq createFleetSizeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateFleetSizeCommand { createFleetSizeCommandReq = createFleetSizeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update fleet size
        /// </summary>
        /// <param name="updateFleetSizeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateFleetSize(UpdateFleetSizeCommandReq updateFleetSizeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateFleetSizeCommand
            {
                updateFleetSizeCommandReq = updateFleetSizeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        /// <summary>
        /// Api to update fleet size status
        /// </summary>
        /// <param name="updateFleetSizeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateFleetSizeStatus(UpdateFleetSizeStatusReq updateFleetSizeStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateFleetSizeStatusCommand { id = updateFleetSizeStatusReq.id, is_active = updateFleetSizeStatusReq.is_active });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        #endregion END FLEET SIZE API METHOD

        #region MOVE TYPE API METHODS

        // <summary>
        /// API to Get Request Type List
        /// </summary>
        /// <returns> List of Request Type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<MoveTypeListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetMoveTypeList()
        {
            ResponseBase<List<MoveTypeListDto>> response = new ResponseBase<List<MoveTypeListDto>>();
            var requestTypeList = await _mediator.Send(new MoveTypeListQuery { });
            if (requestTypeList != null)
            {

                response.Data = requestTypeList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// API to Get Request Type Details
        /// </summary>
        /// <returns> LGet Details of fleet size   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<MoveTypeDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetMoveTypeDetails(long id)
        {
            ResponseBase<MoveTypeDetailsDto> response = new ResponseBase<MoveTypeDetailsDto>();
            var requestTypeDetails = await _mediator.Send(new MoveTypeDetailsQuery { id = id });
            if (requestTypeDetails != null)
            {

                response.Data = requestTypeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// Api to create Move Type
        /// </summary>
        /// <param name="createMoveTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateMoveType(CreateMoveTypeCommandReq createMoveTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateMoveTypeCommand { createMoveTypeCommandReq = createMoveTypeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update move type
        /// </summary>
        /// <param name="updateMoveTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateMoveType(UpdateMoveTypeCommandReq updateMoveTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateMoveTypeCommand
            {
                updateMoveTypeCommandReq = updateMoveTypeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        // <summary>
        /// Api to update move type status
        /// </summary>
        /// <param name="updateMoveTypeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateMoveTypeStatus(UpdateMoveTypeStatusReq updateMoveTypeStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateMoveTypeStatusCommand { id = updateMoveTypeStatusReq.id, is_active = updateMoveTypeStatusReq.is_active });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        #endregion END REQUEST TYPE API METHODS

        #region SERVICE REQUEST TYPE API METHODS

        // <summary>
        /// API to Get Service Request Type List
        /// </summary>
        /// <returns> List of Request Type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<ServiceRequestTypeListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServiceRequestTypeList()
        {
            ResponseBase<List<ServiceRequestTypeListDto>> response = new ResponseBase<List<ServiceRequestTypeListDto>>();
            var serviceRequestTypeLists = await _mediator.Send(new ServiceRequestTypeListQuery { });
            if (serviceRequestTypeLists != null)
            {

                response.Data = serviceRequestTypeLists;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// API to Get Request Type Details
        /// </summary>
        /// <returns> LGet Details of fleet size   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<ServiceRequestTypeDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServiceRequestTypeDetails(long id)
        {
            ResponseBase<ServiceRequestTypeDetailsDto> response = new ResponseBase<ServiceRequestTypeDetailsDto>();
            var serviceRequestTypeDetails = await _mediator.Send(new ServiceRequestTypeDetailsQuery { id = id });
            if (serviceRequestTypeDetails != null)
            {

                response.Data = serviceRequestTypeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// Api to create Service Request Type
        /// </summary>
        /// <param name="createServiceRequestTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateServiceRequestType(CreateServiceRequestTypeCommandReq createServiceRequestTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateServiceRequestTypeCommand { createServiceRequestTypeCommandReq = createServiceRequestTypeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update service request type
        /// </summary>
        /// <param name="updateServiceRequestTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateServiceRequestType(UpdateServiceRequestTypeCommandReq updateServiceRequestTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateServiceRequestTypeCommand
            {
                updateServiceRequestTypeCommandReq = updateServiceRequestTypeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update service request type status
        /// </summary>
        /// <param name="updateServiceRequestTypeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateServiceRequestTypeStatus(UpdateServiceRequestTypeStatusReq updateServiceRequestTypeStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateServiceRequestTypeStatusCommand { id = updateServiceRequestTypeStatusReq.id, is_active = updateServiceRequestTypeStatusReq.is_active });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }



        #endregion END SERVICE REQUEST TYPE API METHODS

        #region SERVICE ORDER TYPE API METHOD

        // <summary>
        /// API to Get Service Order Type List
        /// </summary>
        /// <returns> List of Service Order Type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<ServiceOrderTypeListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServiceOrderTypeList()
        {
            ResponseBase<List<ServiceOrderTypeListDto>> response = new ResponseBase<List<ServiceOrderTypeListDto>>();
            var serviceOrderTypeLists = await _mediator.Send(new ServiceOrderTypeListQuery { });
            if (serviceOrderTypeLists != null)
            {

                response.Data = serviceOrderTypeLists;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// API to Get Service Order Type Details
        /// </summary>
        /// <returns> LGet Details of fleet size   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<ServiceOrderTypeDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServiceOrderTypeDetails(long id)
        {
            ResponseBase<ServiceOrderTypeDetailsDto> response = new ResponseBase<ServiceOrderTypeDetailsDto>();
            var serviceOrderTypeDetails = await _mediator.Send(new ServiceOrderTypeDetailsQuery { id = id });
            if (serviceOrderTypeDetails != null)
            {

                response.Data = serviceOrderTypeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        // <summary>
        /// Api to create Service Order Type
        /// </summary>
        /// <param name="createServiceOrderTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateServiceOrderType(CreateServiceOrderTypeCommandReq createServiceOrderTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateServiceOrderTypeCommand { createServiceOrderTypeCommandReq = createServiceOrderTypeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update service order type
        /// </summary>
        /// <param name="updateServiceOrderTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateServiceOrderType(UpdateServiceOrderTypeCommandReq updateServiceOrderTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateServiceOrderTypeCommand
            {
                updateServiceOrderTypeCommandReq = updateServiceOrderTypeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update service order type status
        /// </summary>
        /// <param name="updateServiceRequestTypeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateServiceOrderTypeStatus(UpdateServiceOrderTypeStatusReq updateServiceOrderTypeStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateServiceOrderTypeStatusCommand { id = updateServiceOrderTypeStatusReq.id, is_active = updateServiceOrderTypeStatusReq.is_active });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        #endregion END SERVICE ORDER TYPE API METHOD

        #region TRANSPORTATION TYPE API METHOD

        // <summary>
        /// API to Get Transportation Type List
        /// </summary>
        /// <returns> List of Transportation Type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<TransportationTypeListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetTransportationTypeList()
        {
            ResponseBase<List<TransportationTypeListDto>> response = new ResponseBase<List<TransportationTypeListDto>>();
            var transportationTypeList = await _mediator.Send(new TransportationTypeListQuery { });
            if (transportationTypeList != null)
            {

                response.Data = transportationTypeList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// API to Get Service Order Type Details
        /// </summary>
        /// <returns> LGet Details of fleet size   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<TransportationTypeDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetTransportationTypeDetails(long id)
        {
            ResponseBase<TransportationTypeDetailsDto> response = new ResponseBase<TransportationTypeDetailsDto>();
            var transportationTypeDetails = await _mediator.Send(new TransportationTypeDetailsQuery { id = id });
            if (transportationTypeDetails != null)
            {

                response.Data = transportationTypeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// Api to create Transportation Type
        /// </summary>
        /// <param name="createTransportationTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateTransportationType(CreateTransportationTypeCommandReq createTransportationTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateTransportationTypeCommand { createTransportationTypeCommandReq = createTransportationTypeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update Transportation type
        /// </summary>
        /// <param name="updateTransportationTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateTransportationType(UpdateTransportationTypeCommandReq updateTransportationTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateTransportationTypeCommand
            {
                updateTransportationTypeCommandReq = updateTransportationTypeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update service order type status
        /// </summary>
        /// <param name="updateServiceRequestTypeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateTransportationTypeStatus(UpdateTransportationTypeStatusReq updateTransportationTypeStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateTransportationTypeStatusCommand { id = updateTransportationTypeStatusReq.id, is_active = updateTransportationTypeStatusReq.is_active });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        #endregion END SERVICE ORDER TYPE API METHOD

        #region TRANSPORTATION PREFERENCE TYPE API METHOD


        // <summary>
        /// API to Get Transportation Preference Type List
        /// </summary>
        /// <returns> List of Transportation Preference Type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<TransportationPreferenceTypesListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetTransportationPreferenceTypesList()
        {
            ResponseBase<List<TransportationPreferenceTypesListDto>> response = new ResponseBase<List<TransportationPreferenceTypesListDto>>();
            var transportationPreferenceTypesList = await _mediator.Send(new TransportationPreferenceTypesListQuery { });
            if (transportationPreferenceTypesList != null)
            {

                response.Data = transportationPreferenceTypesList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// API to Get Transportation Preference Type Details
        /// </summary>
        /// <returns> Transportation Preference type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<TransportationPreferenceTypesDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetTransportationPreferenceTypesDetails(long id)
        {
            ResponseBase<TransportationPreferenceTypesDetailsDto> response = new ResponseBase<TransportationPreferenceTypesDetailsDto>();
            var transportationPreferenceTypeDetails = await _mediator.Send(new TransportationPreferenceTypesDetailsQuery { id = id });
            if (transportationPreferenceTypeDetails != null)
            {

                response.Data = transportationPreferenceTypeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// Api to create Transportation Preference Type
        /// </summary>
        /// <param name="createTransportationPreferenceTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateTransportationPreferenceType(CreateTransportationPreferenceTypeCommandReq createTransportationPreferenceTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateTransportationPreferenceTypeCommand { createTransportationPreferenceTypeCommandReq = createTransportationPreferenceTypeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update Transportation Preference type
        /// </summary>
        /// <param name="updateTransportationPreferenceTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateTransportationPreferenceType(UpdateTransportationPreferenceTypeCommandReq updateTransportationPreferenceTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateTransportationPreferenceTypeCommand
            {
                updateTransportationPreferenceTypeCommand = updateTransportationPreferenceTypeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update service order type status
        /// </summary>
        /// <param name="updateServiceRequestTypeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateTransportationPreferenceTypeStatus(UpdateTransportationPreferenceTypeStatusReq updateTransportationPreferenceTypeStatus)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateTransportationPreferenceTypeStatusCommand
            {
                id = updateTransportationPreferenceTypeStatus.id,
                is_active = updateTransportationPreferenceTypeStatus.is_active
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        #endregion END TRANSPORTATION PREFERENCE TYPE API METHOD

        #region PREFERENCE TYPE API METHOD


        // <summary>
        /// API to Get Preference Type List
        /// </summary>
        /// <returns> List of Preference Type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<PreferenceTypeListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPreferenceTypesList()
        {
            ResponseBase<List<PreferenceTypeListDto>> response = new ResponseBase<List<PreferenceTypeListDto>>();
            var preferenceTypesList = await _mediator.Send(new PreferenceTypeListQuery { });
            if (preferenceTypesList != null)
            {

                response.Data = preferenceTypesList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// API to Get Preference Type Details
        /// </summary>
        /// <returns> Preference type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<PreferenceTypeDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetPreferenceTypesDetails(long id)
        {
            ResponseBase<PreferenceTypeDetailsDto> response = new ResponseBase<PreferenceTypeDetailsDto>();
            var preferenceTypeDetails = await _mediator.Send(new PreferenceTypeDetailsQuery { id = id });
            if (preferenceTypeDetails != null)
            {

                response.Data = preferenceTypeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// Api to create Preference Type
        /// </summary>
        /// <param name="createPreferenceTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreatePreferenceType(CreatePreferenceTypeCommandReq createPreferenceTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreatePreferenceTypeCommand { createPreferenceTypeCommandReq = createPreferenceTypeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update Preference type
        /// </summary>
        /// <param name="updatePreferenceTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdatePreferenceType(UpdatePreferenceTypeCommandReq updatePreferenceTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdatePreferenceTypeCommand
            {
                updatePreferenceTypeCommandReq = updatePreferenceTypeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update preference type status
        /// </summary>
        /// <param name="updatePreferenceTypeStatus"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdatePreferenceTypeStatus(UpdatePreferenceTypeStatusReq updatePreferenceTypeStatus)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdatePreferenceTypeStatusCommand
            {
                id = updatePreferenceTypeStatus.id,
                is_active = updatePreferenceTypeStatus.is_active
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }



        #endregion

        #region RELEASE ORDER TYPE API METHOD


        // <summary>
        /// API to Get Release Order Type List
        /// </summary>
        /// <returns> List of Release Order Type   </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<ReleaseOrderTypeListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetReleaseOrderTypeList()
        {
            ResponseBase<List<ReleaseOrderTypeListDto>> response = new ResponseBase<List<ReleaseOrderTypeListDto>>();
            var releaseOrderTypeList = await _mediator.Send(new ReleaseOrderTypeListQuery { });
            if (releaseOrderTypeList != null)
            {

                response.Data = releaseOrderTypeList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// API to Get Release Order Type Details
        /// </summary>
        /// <returns> List of Release Order Type   </returns>
        /// <param name="id">
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<ReleaseOrderTypeDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetReleaseOrderTypeDetails(long id)
        {
            ResponseBase<ReleaseOrderTypeDetailsDto> response = new ResponseBase<ReleaseOrderTypeDetailsDto>();
            var releaseOrderTypeDetails = await _mediator.Send(new ReleaseOrderTypeDetailsQuery { id = id });
            if (releaseOrderTypeDetails != null)
            {

                response.Data = releaseOrderTypeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// Api to create Release Order Type
        /// </summary>
        /// <param name="createReleaseOrderTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateReleaseOrderType(CreateReleaseOrderTypeCommandReq createReleaseOrderTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateReleaseOrderTypeCommand { createReleaseOrderTypeCommandReq = createReleaseOrderTypeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update Release Order type
        /// </summary>
        /// <param name="updateReleaseOrderTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateReleaseOrderType(UpdateReleaseOrderTypeCommandReq updateReleaseOrderTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateReleaseOrderTypeCommand
            {
                updateReleaseOrderTypeCommandReq = updateReleaseOrderTypeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update release order type status
        /// </summary>
        /// <param name="updateReleaseOrderTypeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateReleaseOrderTypeStatus(UpdateReleaseOrderTypeStatusReq updateReleaseOrderTypeStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateReleaseOrderTypeStatusCommand
            {
                id = updateReleaseOrderTypeStatusReq.id,
                is_active = updateReleaseOrderTypeStatusReq.is_active
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        #endregion

        #region FUEL SUR CHARGES TYPE API METHOD


        // <summary>
        /// API to Get Fuel Sur Charges List
        /// </summary>
        /// <returns> List of fuelSurCharges  </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<FuelSurChargeListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFuelSurChargesList()
        {
            ResponseBase<List<FuelSurChargeListDto>> response = new ResponseBase<List<FuelSurChargeListDto>>();
            var fuelSurChargeList = await _mediator.Send(new FuelSurChargeListQuery { });
            if (fuelSurChargeList != null)
            {

                response.Data = fuelSurChargeList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        // <summary>
        /// API to Get Fuel Sur Charges Details
        /// </summary>
        /// <returns> List of Fuel Sur Charges   </returns>
        /// <param name="id">
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<FuelSurChargeDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFuelSurChargesDetails(long id)
        {
            ResponseBase<FuelSurChargeDetailsDto> response = new ResponseBase<FuelSurChargeDetailsDto>();
            var fuelSurChargeDetails = await _mediator.Send(new FuelSurChargeDetailsQuery { id = id });
            if (fuelSurChargeDetails != null)
            {

                response.Data = fuelSurChargeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// Api to create Fuel Type
        /// </summary>
        /// <param name="createFuelSurChargeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateFuelSurCharges(CreateFuelSurChargeCommandReq createFuelSurChargeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateFuelSurChargeCommand { createFuelSurChargeCommandReq = createFuelSurChargeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update Fuel Sur Charges
        /// </summary>
        /// <param name="updateFuelSurChargeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateFuelSurCharges(UpdateFuelSurChargeCommandReq updateFuelSurChargeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateFuelSurChargeCommand
            {
                updateFuelSurChargeCommandReq = updateFuelSurChargeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update fuel sur charges status
        /// </summary>
        /// <param name="updateFuelSurChargesStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateFuelSurChargesStatus(UpdateFuelSurChargesStatusReq updateFuelSurChargesStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateFuelSurChargesStatusCommand
            {
                id = updateFuelSurChargesStatusReq.id,
                is_active = updateFuelSurChargesStatusReq.is_active
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        #endregion

        #region FUEL TYPE API METHOD

        // <summary>
        /// API to Get Fuel Sur Charges List
        /// </summary>
        /// <returns> List of fuelSurCharges  </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<FuelTypeListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFuelTypeList()
        {
            ResponseBase<List<FuelTypeListDto>> response = new ResponseBase<List<FuelTypeListDto>>();
            var fuelTypeList = await _mediator.Send(new FuelTypeListQuery { });
            if (fuelTypeList != null)
            {

                response.Data = fuelTypeList;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// API to Get Fuel Type Details
        /// </summary>
        /// <returns> List of Fuel Type   </returns>
        /// <param name="id">
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<FuelTypeDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetFuelTypeDetails(long id)
        {
            ResponseBase<FuelTypeDetailsDto> response = new ResponseBase<FuelTypeDetailsDto>();
            var fuelTypeDetails = await _mediator.Send(new FuelTypeDetailsQuery { id = id });
            if (fuelTypeDetails != null)
            {

                response.Data = fuelTypeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// Api to create Fuel Type
        /// </summary>
        /// <param name="createFuelTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateFuelType(CreateFuelTypeCommandReq createFuelTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateFuelTypeCommand { createFuelTypeCommandReq = createFuelTypeCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update Fuel type
        /// </summary>
        /// <param name="updateFuelTypeCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateFuelType(UpdateFuelTypeCommandReq updateFuelTypeCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateFuelTypeCommand
            {
                updateFuelTypeCommandReq = updateFuelTypeCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update release order type status
        /// </summary>
        /// <param name="updateFuelTypeStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateFuelTypeStatus(UpdateFuelTypeStatusReq updateFuelTypeStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateFuelTypeStatusCommand
            {
                id = updateFuelTypeStatusReq.id,
                is_active = updateFuelTypeStatusReq.is_active
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        #endregion

        #region HUB LOCATION API METHOD

        // <summary>
        /// API to Get Hub Locations List
        /// </summary>
        /// <returns> List of Hub locations  </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<List<HubLocationListDto>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetHubLocationList()
        {
            ResponseBase<List<HubLocationListDto>> response = new ResponseBase<List<HubLocationListDto>>();
            var hubLocationLists = await _mediator.Send(new HubLocationListQuery { });
            if (hubLocationLists != null)
            {

                response.Data = hubLocationLists;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// API to Get hub location Details
        /// </summary>
        /// <returns> details of hub locations  </returns>
        /// <param name="id">
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<HubLocationDetailsDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetHubLocationDetails(long id)
        {
            ResponseBase<HubLocationDetailsDto> response = new ResponseBase<HubLocationDetailsDto>();
            var fuelTypeDetails = await _mediator.Send(new HubLocationDetailsQuery { id = id });
            if (fuelTypeDetails != null)
            {

                response.Data = fuelTypeDetails;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        // <summary>
        /// Api to create Hub Location
        /// </summary>
        /// <param name="createHubLocationCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateHubLocation(CreateHubLocationCommandReq createHubLocationCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();
            var result = await _mediator.Send(new CreateHubLocationCommand { createHubLocationCommandReq = createHubLocationCommandReq });
            if (result.Item2)
            {
                throw new BusinessException("PARS_DUPLICATE_ENTRY");
            }
            else if (result.Item1)
            {
                response.Data = result.Item1;
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update Hub Location
        /// </summary>
        /// <param name="updateHubLocationCommandReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>
        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateHubLocation(UpdateHubLocationCommandReq updateHubLocationCommandReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateHubLocationCommand
            {
                updateHubLocationCommandReq = updateHubLocationCommandReq
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }

        // <summary>
        /// Api to update HUB LOCATION status
        /// </summary>
        /// <param name="updateHubLocationStatusReq"></param>
        /// <returns></returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<bool>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UpdateHubLocationStatus(UpdateHubLocationStatusReq updateHubLocationStatusReq)
        {
            ResponseBase<bool> response = new ResponseBase<bool>();

            bool result = await _mediator.Send(new UpdateHubLocationStatusCommand
            {
                id = updateHubLocationStatusReq.id,
                is_active = updateHubLocationStatusReq.is_active
            });
            if (result)
            {
                response.MessageDetail = _customMsgSvc.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_UPDATION_FAILURE");
            }
        }


        #endregion

        #endregion

        #region API MODELS AND VALIDATIONS

        #region API EVENT TYPE API VALIDATIONS
        public class CreateEventTypeCommandReqValidator : AbstractValidator<CreateEventTypeCommandReq>
        {
            public CreateEventTypeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateEventTypeCommandReqValidator : AbstractValidator<UpdateEventTypeCommandReq>
        {
            public UpdateEventTypeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateEventTypeStatusReqValidator : AbstractValidator<UpdateEventTypeStatusReq>
        {
            public UpdateEventTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion END API EVENT TYPE API VALIDATIONS

        #region API FLEET SIZE VALIDATIONS

        public class CreateFleetSizeCommandReqValidator : AbstractValidator<CreateFleetSizeCommandReq>
        {
            public CreateFleetSizeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateFleetSizeCommandReqValidator : AbstractValidator<UpdateFleetSizeCommandReq>
        {
            public UpdateFleetSizeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateFleetSizeStatusReqValidator : AbstractValidator<UpdateFleetSizeStatusReq>
        {
            public UpdateFleetSizeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }



        #endregion END API FLEET SIZE VALIDATIONS

        #region API REQUEST TYPE API VALIDATION

        public class CreateRequestTypeCommandReqValidator : AbstractValidator<CreateMoveTypeCommandReq>
        {
            public CreateRequestTypeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateRequestTypeCommandReqValidator : AbstractValidator<UpdateMoveTypeCommandReq>
        {
            public UpdateRequestTypeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateRequestTypeStatusReqValidator : AbstractValidator<UpdateMoveTypeStatusReq>
        {
            public UpdateRequestTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion

        #region API SERVICE REQUEST TYPE API VALIDATION

        public class CreateServiceRequestTypeCommandReqValidator : AbstractValidator<CreateServiceRequestTypeCommandReq>
        {
            public CreateServiceRequestTypeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateServiceRequestTypeCommandReqValidator : AbstractValidator<UpdateServiceRequestTypeCommandReq>
        {
            public UpdateServiceRequestTypeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateServiceRequestTypeStatusReqValidator : AbstractValidator<UpdateServiceRequestTypeStatusReq>
        {
            public UpdateServiceRequestTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion

        #region API SERVICE ORDER TYPE API VALIDATION

        public class CreateServiceOrderTypeCommandReqValidator : AbstractValidator<CreateServiceOrderTypeCommandReq>
        {
            public CreateServiceOrderTypeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateServiceOrderTypeCommandReqValidator : AbstractValidator<UpdateServiceOrderTypeCommandReq>
        {
            public UpdateServiceOrderTypeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateServiceOrderTypeStatusReqValidator : AbstractValidator<UpdateServiceOrderTypeStatusReq>
        {
            public UpdateServiceOrderTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion

        #region API TRANSPORTATION TYPE API VALIDATION

        public class CreateTransportationTypeCommandReqValidator : AbstractValidator<CreateTransportationTypeCommandReq>
        {
            public CreateTransportationTypeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateTransportationTypeCommandReqValidator : AbstractValidator<UpdateTransportationTypeCommandReq>
        {
            public UpdateTransportationTypeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateTransportationTypeStatusReqValidator : AbstractValidator<UpdateServiceOrderTypeStatusReq>
        {
            public UpdateTransportationTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion

        #region API TRANSPORTATION PREFERNCE TYPE API VALIDATION

        public class CreateTransportationPreferenceTypeCommandReqValidator : AbstractValidator<CreateTransportationPreferenceTypeCommandReq>
        {
            public CreateTransportationPreferenceTypeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateTransportationPreferenceTypeCommandReqValidator : AbstractValidator<UpdateTransportationPreferenceTypeCommandReq>
        {
            public UpdateTransportationPreferenceTypeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateTransportationPreferenceTypeStatusReqValidator : AbstractValidator<UpdateTransportationPreferenceTypeStatusReq>
        {
            public UpdateTransportationPreferenceTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion

        #region API TRANSPORTATION TYPE API VALIDATION

        public class CreatePreferenceTypeCommandReqValidator : AbstractValidator<CreatePreferenceTypeCommandReq>
        {
            public CreatePreferenceTypeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdatePreferenceTypeCommandReqValidator : AbstractValidator<UpdatePreferenceTypeCommandReq>
        {
            public UpdatePreferenceTypeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdatePreferenceTypeStatusReqValidator : AbstractValidator<UpdatePreferenceTypeStatusReq>
        {
            public UpdatePreferenceTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion

        #region API RELEASE ORDER TYPE API VALIDATION

        public class CreateReleaseOrderTypeCommandReqValidator : AbstractValidator<CreateReleaseOrderTypeCommandReq>
        {
            public CreateReleaseOrderTypeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateReleaseOrderTypeCommandReqValidator : AbstractValidator<UpdateReleaseOrderTypeCommandReq>
        {
            public UpdateReleaseOrderTypeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateReleaseOrderTypeStatusReqValidator : AbstractValidator<UpdateReleaseOrderTypeStatusReq>
        {
            public UpdateReleaseOrderTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion

        #region API FUEL TYPE API VALIDATION

        public class CreateFuelTypeCommandReqValidator : AbstractValidator<CreateFuelTypeCommandReq>
        {
            public CreateFuelTypeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateFuelTypeCommandReqValidator : AbstractValidator<UpdateFuelTypeCommandReq>
        {
            public UpdateFuelTypeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateFuelTypeStatusReqValidator : AbstractValidator<UpdateFuelTypeStatusReq>
        {
            public UpdateFuelTypeStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion

        #region API FUEL SUR CHARGES API VALIDATION

        public class CreateFuelSurChargeCommandReqValidator : AbstractValidator<CreateFuelSurChargeCommandReq>
        {
            public CreateFuelSurChargeCommandReqValidator()
            {
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateFuelSurChargeCommandReqValidator : AbstractValidator<UpdateFuelSurChargeCommandReq>
        {
            public UpdateFuelSurChargeCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.name).NotNull().NotEmpty();

            }
        }

        public class UpdateFuelSurChargesStatusReqValidator : AbstractValidator<UpdateFuelSurChargesStatusReq>
        {
            public UpdateFuelSurChargesStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion

        #region API HUB LOCATION API VALIDATION

        public class CreateHubLocationCommandReqValidator : AbstractValidator<CreateHubLocationCommandReq>
        {
            public CreateHubLocationCommandReqValidator()
            {
                RuleFor(p => p.zip_code).NotNull().NotEmpty();

            }
        }

        public class UpdateHubLocationCommandReqValidator : AbstractValidator<UpdateHubLocationCommandReq>
        {
            public UpdateHubLocationCommandReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);
                RuleFor(p => p.zip_code).NotNull().NotEmpty();

            }
        }

        public class UpdateHubLocationStatusReqValidator : AbstractValidator<UpdateHubLocationStatusReq>
        {
            public UpdateHubLocationStatusReqValidator()
            {
                RuleFor(p => p.id).NotEqual(0);

            }
        }

        #endregion

        #endregion
    }
}
