using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.Storage.Command;
using PARSNextGen.Application.Storage.GetStorage.GetStorageDetails.Queries;
using PARSNextGen.Application.Storage.Queries;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PARSNextGen.API.Controllers
{

    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class StorageController : Controller
    {


        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMessageService;
        private readonly IAzureMapService _azureMapService;
        public StorageController(IMediator mediator, ICustomMessageService customMessageService, IAzureMapService azureMapService)
        {
            _mediator = mediator;
            _customMessageService = customMessageService;
            _azureMapService = azureMapService;
        }


        /// <summary>
        /// API to get storage list  
        /// </summary>
        /// <returns> storage list  detail. </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<StorageDetails>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetStorageList()
        {
            ResponseBase<StorageDetails> response = new ResponseBase<StorageDetails>();
            var storageDetail = await _mediator.Send(new GetStorageListQuery { });
            if (storageDetail is not null)
            {
                response.Data = storageDetail;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        /// <summary>
        /// API gets storage detail
        /// </summary>
        /// <returns> storage detail. </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<StoragedetailDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetStorageDetail(long id)
        {
            ResponseBase<StoragedetailDto> response = new ResponseBase<StoragedetailDto>();
            var storagedetail = await _mediator.Send(new GetStorageDetailQuery { id = id });
            if (storagedetail != null)
            {
                response.Data = storagedetail;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }

        [HttpPost]
        [ProducesResponseType(typeof(long), StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateStorage(StorageReq storage_req)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            var result = await _mediator.Send(new ManageStorageCommand { Req = storage_req });
            if (result > 0)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_CREATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_CREATION_FAILURE");
            }
        }

        [HttpPost]
        [ProducesResponseType(typeof(long), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> UpdateStorage(StorageReq update_storage_req)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            var result = await _mediator.Send(new ManageStorageCommand { Req = update_storage_req });
            if (result > 0)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        [HttpPost]
        [ProducesResponseType(typeof(long), StatusCodes.Status204NoContent)]
        public async Task<IActionResult> ChangeStorageStatus(long id, bool is_active)
        {
            ResponseBase<long> response = new ResponseBase<long>();
            var result = await _mediator.Send(new ChangeStorageStatusCommand { id = id, is_active = is_active });
            if (result > 0)
            {
                response.Data = result;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_UPDATE_SUCCESS");
                return new OkObjectResult(response);
            }
            else
                throw new BusinessException("PARS_UPDATION_FAILURE");
        }

        /// <summary>
        /// API gets Current location Of Vehicle
        /// </summary>
        /// <params>Vehicle id</params>
        /// <returns> location detail. </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<GetCurrentLocationDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetCurrentLocationOfVehicle(long vehicleId)
        {
            ResponseBase<GetCurrentLocationDto> response = new ResponseBase<GetCurrentLocationDto>();
            var locationDetail = await _mediator.Send(new GetCurrentLocationQuery { id = vehicleId });
            if (locationDetail != null)
            {
                response.Data = locationDetail;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }


        [HttpGet]
        [ProducesResponseType(typeof(ResponseBase<NearestLocationDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetNearestLocations(string zipCode, long stateId, long countryId)
        {

            ResponseBase<NearestLocationDto> response = new ResponseBase<NearestLocationDto>();
            VerifyAddressReq postalAddressDTO = new VerifyAddressReq();
            postalAddressDTO.PostalCode = zipCode;
            postalAddressDTO.CountryId = countryId;
            postalAddressDTO.StateId = stateId;
            var address = await _azureMapService.VerifyAddress(postalAddressDTO);
            double latitude = 0;
            double longitude = 0;
            if (!string.IsNullOrWhiteSpace(address.lat) && !string.IsNullOrWhiteSpace(address.lon))
            {
                double.TryParse(address.lat, out latitude);
                double.TryParse(address.lon, out longitude);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }

            var location = await _mediator.Send(new GetNearestLocationQuery { country_id = null, distanceRadius = null, lat = latitude, lon = longitude });
            if (location != null)
            {
                response.Data = location;
                response.MessageDetail = _customMessageService.GetCustomMessageByShortCode("PARS_RECORD_FOUND");
                return new OkObjectResult(response);
            }
            else
            {
                throw new BusinessException("PARS_RECORD_NOT_FOUND");
            }
        }
    }
}
