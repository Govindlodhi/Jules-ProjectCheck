﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PARSNextGen.Application.Service;
using System.Threading.Tasks;
using System;
using PARSNextGen.Application.DefaultServicesAndICsForCRMOrder;
using PARSNextGen.API.DataModel;
using PARSNextGen.Application.Preference.Agreement.Queries;
using PARSNextGen.Application.Utility;
using static PARSNextGen.Domain.Common.EnumTypes;
using Newtonsoft.Json;
using PARSNextGen.Application.Calculation.Queries;
using PARSNextGen.Application.Preference.Preference.Queries;
using PARSNextGen.Application.Preference.RuleEditor.Queries;
using PARSNextGen.Application.Quotes.QuickQuote.Queries;
using PARSNextGen.Application.VINValidation.Queries;
using System.Collections.Generic;
using PARSNextGen.Domain.Common;
using System.Linq;
using PARSNextGen.Application.ServiceRequest.Queries;
using PARSNextGen.API.Extensions.Exceptions;
using PARSNextGen.Application.Preference.Agreement.Command.UpdateAGServicesAndICFromCRM;
using RestSharp;
using PARSNextGen.Application.SmartWizard.QuestionSetup.Command;
using PARSNextGen.Application.SmartWizard.QuestionSetup.Query;
using PARSNextGen.Application.SQL;
using Dapper;
using Microsoft.Azure.Amqp.Framing;

namespace PARSNextGen.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/V{v:apiVersion}/[controller]/[action]")]
    [ApiController]
    public class PARSSupportController : ControllerBase
    {
        private readonly ILogger<QuoteController> _logger;
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMsgSvc;
        private readonly ISqlContext _dbCntx;
        public PARSSupportController(ILogger<QuoteController> logger, IMediator mediator, ICustomMessageService customMsgSvc, ISqlContext sqlContext)
        {
            _logger = logger;
            _mediator = mediator;
            _customMsgSvc = customMsgSvc;
            _dbCntx = sqlContext;
        }


        #region Get Default Services And IC Instruction For CRM
        /// <summary>
        /// API gets list of default services and IC instruction for CRM order.  
        /// </summary>
        /// <param name="defaultIcAndServiceReq"></param>
        /// <returns> List of  default services and IC instructions  </returns>
        /// <exception cref="BusinessException"></exception>

        [HttpPost]
        [ProducesResponseType(typeof(ResponseBase<DefaultServiceAndICinstructionDto>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetDefaultServicesAndIcInstructionsForCRMOrder(DefaultServiceAndIcReq defaultIcAndServiceReq)
        {
            ResponseBase<DefaultServiceAndICinstructionDto> response = new ResponseBase<DefaultServiceAndICinstructionDto>();

            #region GET AGREEMENT
            ApplicableCPSDtos applicableAgreementDto = null;

            using (var conn = _dbCntx.GetOpenConnection())
            {
                if (defaultIcAndServiceReq.applicable_parameter_set_id != null && defaultIcAndServiceReq.applicable_parameter_set_id != Guid.Empty)
                {
                    string agreementQuery = "Select ag.id as agreement_id,ag.name as agreement, ag.parameter_crm_id as agreement_crm_id" +
                        ",agreement_status_id from agreement ag where ag.parameter_crm_id = '" + defaultIcAndServiceReq.applicable_parameter_set_id + "';";
                    applicableAgreementDto = await conn.QuerySingleOrDefaultAsync<ApplicableCPSDtos>(agreementQuery);
                }
                else if (defaultIcAndServiceReq.account_parameter_set_id != null && defaultIcAndServiceReq.account_parameter_set_id != Guid.Empty)
                {
                    string agreementQuery = "Select ag.id as agreement_id,ag.name as agreement, ag.parameter_crm_id as agreement_crm_id" +
                        ",agreement_status_id from agreement ag where ag.parameter_crm_id = '" + defaultIcAndServiceReq.account_parameter_set_id + "';";
                    applicableAgreementDto = await conn.QuerySingleOrDefaultAsync<ApplicableCPSDtos>(agreementQuery);
                }
                else
                {
                    throw new BusinessException("PARS_PARAMETER_SET_NOT_AVAILABLE_IN_ORDER_ERROR");                    
                }

                if (applicableAgreementDto == null)
                {
                    throw new BusinessException("PARS_PARAMETER_SET_NOT_FOUND_ERROR");     
                }
                else
                {                   
                    if (applicableAgreementDto.agreement_status_id != (long)EnumTypes.Agreement_status.Active)
                        throw new BusinessException("PARS_PARAMETER_SET_INACTIVE_ERROR");
                }
            }
            #endregion END         

            #region Rule Execute Request Model 
            VehicleFuelType vehicleFuelType = VehicleFuelTypeMapping.getVehicleFuelType(defaultIcAndServiceReq.primary_fuel_type, defaultIcAndServiceReq.secondary_fuel_type);
            Application.Utility.Preference.Models.service_request sr_request = new Application.Utility.Preference.Models.service_request();
            if (defaultIcAndServiceReq.vehicle_type_id != null)
                sr_request.vehicle_type = (int)defaultIcAndServiceReq.vehicle_type_id;

            if (vehicleFuelType.primary_fuel_type_id != null)
                sr_request.primary_fuel_type = (int)vehicleFuelType.primary_fuel_type_id;

            if (vehicleFuelType.fuel_type_id != null)
                sr_request.fuel_type = (int)vehicleFuelType.fuel_type_id;

            sr_request.transportation_type_id = (int)defaultIcAndServiceReq.transportation_type_id;
            if (defaultIcAndServiceReq.pickup_address_type_id != null)
                sr_request.pickup_address_type = (int)defaultIcAndServiceReq.pickup_address_type_id;
            if (defaultIcAndServiceReq.delivery_address_type_id != null)
                sr_request.delivery_address_type = (int)defaultIcAndServiceReq.delivery_address_type_id;
            #endregion

            #region Electric vehicle or Non-electric Vehicle
            bool isElectricVehicle = false;
            if (vehicleFuelType.primary_fuel_type_id != null)
            {
                if (vehicleFuelType.primary_fuel_type_id == (long)NHTSAFuelType.Electric
                   || vehicleFuelType.primary_fuel_type_id == (long)NHTSAFuelType.PH_EV
                   || vehicleFuelType.primary_fuel_type_id == (long)NHTSAFuelType.Hybrid)
                {
                    isElectricVehicle = true;
                }
            }

            sr_request.is_electric_vehicle = isElectricVehicle;

            #endregion END

            #region GET Default Service List
            PreferenceReq preferenceReq = new PreferenceReq();
            preferenceReq.agreement_id = applicableAgreementDto.agreement_id;
            preferenceReq.category_id = (long)Category_Types.service_request;
            preferenceReq.event_type_id = (long)Event_Type.new_service_request;
            preferenceReq.rule_type_id = (long)Rule_Type.Evaluation;
            preferenceReq.isElectricVehicle = isElectricVehicle;
            List<PreferencesListDto> servicesListReq = await _mediator.Send(new GetPreferencesListQuery { preferenceReq = preferenceReq });

            //  servicesListReq = servicesListReq.Take(3).ToList();//REMOVE THIS LINE WHEN WILL BE RULE WORKING PROPERLY              
            foreach (var item in servicesListReq)
            {
                if (item.category_id == (long)Category_Types.service_request)
                {
                    item.modelJson = JsonConvert.SerializeObject(sr_request);
                    item.price_list_id = applicableAgreementDto.price_list_id;
                }
            }
            var jsonResults = await _mediator.Send(new EvaluateRulesQuery { preferencesListReq = servicesListReq });

            var applicableServices = await _mediator.Send(new GetDefaultServicesQuery
            {
                jsonResults = jsonResults,
                price_list_id = 1,//1-standard price list
                agreement_id = applicableAgreementDto.agreement_id,
                rule_type_id = preferenceReq.rule_type_id,
                event_type_id = preferenceReq.event_type_id,
                service_standard = (long)Service_Standard.Standard,
                applicableServiceDto = null,
            });

            #region Logic of EV or NON EV Services 

            //First_Service_EV
            ApplicableServiceDto applicableServiceObj = applicableServices.Where(x => x.service_id == (long)EnumTypes.default_services_for_crm.First_Service_EV).FirstOrDefault();

            if (applicableServiceObj != null)
            {
                applicableServiceObj.service_id = (long)default_services_for_crm.First_Service;
                applicableServiceObj.crm_id = Guid.Parse(GetEnumDescriptionMethod.GetEnumDescription(default_services_for_crm.First_Service));
                int index = applicableServices.FindIndex(x => x.service_id == applicableServiceObj.service_id);
                applicableServices.RemoveAt(index);

                applicableServices.Insert(0, applicableServiceObj);
            }
            //Last Service (EV)
            applicableServiceObj = applicableServices.Where(x => x.service_id == (long)default_services_for_crm.Last_Service_EV).FirstOrDefault();

            if (applicableServiceObj != null)
            {

                applicableServiceObj.service_id = (long)default_services_for_crm.Last_Service;
                applicableServiceObj.crm_id = Guid.Parse(GetEnumDescriptionMethod.GetEnumDescription(default_services_for_crm.Last_Service));
                int index = applicableServices.FindIndex(x => x.service_id == applicableServiceObj.service_id);
                applicableServices.RemoveAt(index);

                applicableServices.Insert(0, applicableServiceObj);
            }

            #endregion END           

            List<DefaultServicesForCRMOrderDto> defaultServicesList = applicableServices.Select(a => new DefaultServicesForCRMOrderDto
            {
                id = a.id,
                service_id = a.service_id,
                service_name = a.service,
                service_crm_id = (Guid)a.crm_id,
                unit_crm_id = (Guid)a.unit_crm_id,
                description = a.description,
                additional_info = a.additional_info,
                rate_type_id = a.rate_type_id,
                rate_type = a.rate_type,
                amount_modified_reason = a.amount_modified_reason,
                service_amount = a.amount,
                autherized_amount = a.authorized_amount
            }).ToList();
            #endregion END

            #region Get Default IC Instruction List
            List<PreferencesListDto> ICPreferenceList = await _mediator.Send(new GetICInstructionPreferencesListQuery { agreement_id = applicableAgreementDto.agreement_id, agreement_type_id = applicableAgreementDto.agreement_type_id, currency_id = (long)defaultIcAndServiceReq.currency_id, isElectricVehicle = isElectricVehicle });

            foreach (var item in ICPreferenceList)
            {
                if (item.category_id == (long)Category_Types.service_request)
                {
                    item.modelJson = JsonConvert.SerializeObject(sr_request);
                    item.price_list_id = applicableAgreementDto.price_list_id;
                }
            }
            var icjsonResults = await _mediator.Send(new EvaluateRulesQuery { preferencesListReq = ICPreferenceList });
            var icInstructionlist = await _mediator.Send(new GetApplicableICInstructionQuery { jsonResults = icjsonResults });

            #region Logic of EV or NON EV Services 

            //First_Service_EV
            ICIntructionForServiceOrderDto iCIntructionForServiceOrderObj = icInstructionlist.Where(x => x.service_id == (long)EnumTypes.default_services_for_crm.First_Service_EV).FirstOrDefault();

            if (iCIntructionForServiceOrderObj != null)
            {
                iCIntructionForServiceOrderObj.service_id = (long)EnumTypes.default_services_for_crm.First_Service;
                iCIntructionForServiceOrderObj.crm_id = Guid.Parse(GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.default_services_for_crm.First_Service));
                int index = icInstructionlist.FindIndex(x => x.service_id == iCIntructionForServiceOrderObj.service_id);
                icInstructionlist.RemoveAt(index);

                icInstructionlist.Insert(0, iCIntructionForServiceOrderObj);
            }

            //Last Service (EV)
            iCIntructionForServiceOrderObj = icInstructionlist.Where(x => x.service_id == (long)EnumTypes.default_services_for_crm.Last_Service_EV).FirstOrDefault();

            if (iCIntructionForServiceOrderObj != null)
            {
                iCIntructionForServiceOrderObj.service_id = (long)EnumTypes.default_services_for_crm.Last_Service;
                iCIntructionForServiceOrderObj.crm_id = Guid.Parse(GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.default_services_for_crm.Last_Service));
                int index = icInstructionlist.FindIndex(x => x.service_id == iCIntructionForServiceOrderObj.service_id);
                icInstructionlist.RemoveAt(index);

                icInstructionlist.Insert(0, iCIntructionForServiceOrderObj);
            }

            #endregion END

            #endregion END

            DefaultServiceAndICinstructionDto defaultServiceAndICResponse = new DefaultServiceAndICinstructionDto();
            ICIntructionForServiceOrderDto iCIntructionForServiceOrderDto = null;
            defaultServiceAndICResponse.defaultICInstructionList = new List<ICIntructionForServiceOrderDto>();

            // Set Up to amount in Full detail service.
            foreach (var item in icInstructionlist)
            {
                iCIntructionForServiceOrderDto = new ICIntructionForServiceOrderDto();
                iCIntructionForServiceOrderDto.id = item.id;
                iCIntructionForServiceOrderDto.service_id = item.service_id;
                if (iCIntructionForServiceOrderDto.service_id != null)
                {
                    var service = defaultServicesList.Where(x => x.rate_type_id == (int)EnumTypes.Rate_Type.Up_To).FirstOrDefault();
                    if (service != null)
                    {
                        if (service.service_id == item.service_id)
                            iCIntructionForServiceOrderDto.instruction = item.instruction; //+ " $ " +  service.autherized_amount;
                        else
                            iCIntructionForServiceOrderDto.instruction = item.instruction;
                    }
                    else
                    {

                        iCIntructionForServiceOrderDto.instruction = item.instruction;
                    }
                }
                else
                {
                    iCIntructionForServiceOrderDto.instruction = item.instruction;
                }
                iCIntructionForServiceOrderDto.service_name = item.service_name;
                iCIntructionForServiceOrderDto.order_type_id = item.order_type_id;
                iCIntructionForServiceOrderDto.crm_id = item.crm_id;
                iCIntructionForServiceOrderDto.sequence_number = item.sequence_number;
                defaultServiceAndICResponse.defaultICInstructionList.Add(iCIntructionForServiceOrderDto);
            }

            #region Default IC
            List<ICIntructionForServiceOrderDto> iCIntructionForServiceOrderDtos = new List<ICIntructionForServiceOrderDto>();
            iCIntructionForServiceOrderDtos.AddRange(defaultServiceAndICResponse.defaultICInstructionList);

            if (defaultServicesList != null)
            {
                var isDetailExist = defaultServicesList.Where(x => x.service_id == (long)EnumTypes.default_services_for_crm.Full_Detail).FirstOrDefault();
                if (isDetailExist == null)
                {
                    if (defaultServiceAndICResponse.defaultICInstructionList != null)
                    {
                        var obj = defaultServiceAndICResponse.defaultICInstructionList.Where(x => x.service_id == (long)EnumTypes.default_services_for_crm.Full_Detail).FirstOrDefault();
                        if (obj != null)
                        {
                            if (obj.instruction.Contains("Perform detail as required up to the pre authorized amount."))
                            {
                                defaultServiceAndICResponse.defaultICInstructionList.Remove(obj);
                            }
                        }
                    }
                }


            }
            /*
            if (defaultServicesList.Count > 0)
            {
                foreach (var item in iCIntructionForServiceOrderDtos)
                {
                    if (item.service_id != null)
                    {
                        var obj = defaultServicesList.Where(x => x.service_id == item.service_id).FirstOrDefault();

                        if (obj == null)
                        {
                            int? index = defaultServiceAndICResponse.defaultICInstructionList.FindIndex(x => x.id == item.id);
                            if (index != null && index != -1)
                            {
                                defaultServiceAndICResponse.defaultICInstructionList.RemoveAt((int)index);
                            }
                        }
                    }

                }
            }*/
            #endregion END

            //defaultServiceAndICResponse.defaultICInstructionList = icInstructionlist;
            defaultServiceAndICResponse.defaultServiceList = defaultServicesList;
            defaultServiceAndICResponse.agreement_id = applicableAgreementDto.agreement_id;
            defaultServiceAndICResponse.agreement_name = applicableAgreementDto.agreement;
            defaultServiceAndICResponse.price_list_id = applicableAgreementDto.price_list_id;
            defaultServiceAndICResponse.agreement_crm_id = applicableAgreementDto.agreement_crm_id;
            defaultServiceAndICResponse.supportContact = applicableAgreementDto.supportContactLists;

            response.IsSuccessful = true;
            response.Data = defaultServiceAndICResponse;
            return new OkObjectResult(response);
        }
        #endregion


        #region Get Service Details and Ic Instructions (Use for crm add Product)     

        [HttpPost]
        [ProducesResponseType(typeof(GetServiceAndIcInstructionsDto), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetServiceDetailAndICInstructionsFromNextGen(AddServiceAndIcDetailsForCRMReq serviceReq)
        {
            GetServiceAndIcInstructionsDto defaultServiceAndICResponse = new GetServiceAndIcInstructionsDto();
            ResponseBase<GetServiceAndIcInstructionsDto> response = new ResponseBase<GetServiceAndIcInstructionsDto>();

            //Check Agreement passed or not.
            #region GET AGREEMENT OF RELATED ACCOUNT FMC
            long? nextgen_agreement_id = null;
            long? nextgen_price_list_id = null;
            if (serviceReq.nextgen_agreement_id == null)
            {
                //ApplicableAgreementDto applicableAgreementDto = null;
                //if (serviceReq.fmc_nextgen_id != null || serviceReq.account_nextgen_id != null)
                //{

                //    applicableAgreementDto = await _mediator.Send(new GetApplicableAgreementForCRMQuery
                //    {
                //        fmc_id = serviceReq.fmc_nextgen_id,
                //        fleet_id = serviceReq.account_nextgen_id,
                //        fleet_number = serviceReq.fleet_number,
                //        currency_id = (long)serviceReq.currency_id,
                //    });
                //}
                //nextgen_agreement_id = applicableAgreementDto.agreement_id;
                //nextgen_price_list_id = applicableAgreementDto.price_list_id;
                throw new BusinessException("PARS_SYSTEM_FAILURE");
            }
            else
            {
                nextgen_agreement_id = serviceReq.nextgen_agreement_id;
                nextgen_price_list_id = 1;//serviceReq.nextgen_price_list_id;
            }
            #endregion END        



            #region GET SERVICE DETAIL
            #region Rule Execute Request Model 
            VehicleFuelType vehicleFuelType = VehicleFuelTypeMapping.getVehicleFuelType(serviceReq.primary_fuel_type, serviceReq.secondary_fuel_type);
            Application.Utility.Preference.Models.service_request sr_request = new Application.Utility.Preference.Models.service_request();
            if (serviceReq.vehicle_type_id != null)
                sr_request.vehicle_type = (int)serviceReq.vehicle_type_id;

            if (vehicleFuelType.primary_fuel_type_id != null)
                sr_request.primary_fuel_type = (int)vehicleFuelType.primary_fuel_type_id;

            if (vehicleFuelType.fuel_type_id != null)
                sr_request.fuel_type = (int)vehicleFuelType.fuel_type_id;

            sr_request.transportation_type_id = (int)serviceReq.transportation_type_id;
            if (serviceReq.pickup_address_type_id != null)
                sr_request.pickup_address_type = (int)serviceReq.pickup_address_type_id;
            if (serviceReq.delivery_address_type_id != null)
                sr_request.delivery_address_type = (int)serviceReq.delivery_address_type_id;

            #region Electric vehicle or Non-electric Vehicle
            bool isElectricVehicle = false;
            if (vehicleFuelType.primary_fuel_type_id != null)
            {
                if (vehicleFuelType.primary_fuel_type_id == (long)NHTSAFuelType.Electric
                   || vehicleFuelType.primary_fuel_type_id == (long)NHTSAFuelType.PH_EV
                   || vehicleFuelType.primary_fuel_type_id == (long)NHTSAFuelType.Hybrid)
                {
                    isElectricVehicle = true;
                }
            }

            sr_request.is_electric_vehicle = isElectricVehicle;

            #endregion END - Electric vehicle or Non-electric Vehicle

            #endregion END Rule Execute Request Model

            #region Prefrence Service List
            PreferenceReq preferenceReq = new PreferenceReq();
            preferenceReq.agreement_id = (long)nextgen_agreement_id;
            preferenceReq.category_id = (long)Category_Types.service_request;
            preferenceReq.event_type_id = (long)Event_Type.new_service_request;
            preferenceReq.rule_type_id = (long)Rule_Type.Evaluation;
            preferenceReq.crm_service_list = serviceReq.crm_service_list;
            preferenceReq.isElectricVehicle = isElectricVehicle;

            List<PreferencesListDto> servicesListReq = await _mediator.Send(new GetPreferencesListQuery { preferenceReq = preferenceReq });


            foreach (var item in servicesListReq)
            {
                if (item.category_id == (long)Category_Types.service_request)
                {
                    item.modelJson = JsonConvert.SerializeObject(sr_request);
                    item.price_list_id = nextgen_price_list_id;
                }
            }
            var jsonResults = await _mediator.Send(new EvaluateRulesQuery { preferencesListReq = servicesListReq });

            var applicableServices = await _mediator.Send(new GetDefaultServicesQuery
            {
                jsonResults = jsonResults,
                price_list_id = nextgen_price_list_id,
                agreement_id = nextgen_agreement_id,
                rule_type_id = preferenceReq.rule_type_id,
                event_type_id = preferenceReq.event_type_id,
                service_standard = (long)Service_Standard.Standard,
                applicableServiceDto = null,
            });

            int shippingIndex = applicableServices.FindIndex(p => p.service_id == (long)EnumTypes.Service.Shipping_Handling_Fee);
            if (shippingIndex > 0)
                applicableServices.RemoveAt(shippingIndex);
            #region Logic of EV or NON EV Services 

            //First_Service_EV
            ApplicableServiceDto applicableServiceObj = applicableServices.Where(x => x.service_id == (long)default_services_for_crm.First_Service_EV).FirstOrDefault();

            if (applicableServiceObj != null)
            {
                applicableServiceObj.service_id = (long)default_services_for_crm.First_Service;
                applicableServiceObj.crm_id = Guid.Parse(GetEnumDescriptionMethod.GetEnumDescription(default_services_for_crm.First_Service));
                int index = applicableServices.FindIndex(x => x.service_id == applicableServiceObj.service_id);
                applicableServices.RemoveAt(index);

                applicableServices.Insert(0, applicableServiceObj);
            }
            //Last Service (EV)
            applicableServiceObj = applicableServices.Where(x => x.service_id == (long)default_services_for_crm.Last_Service_EV).FirstOrDefault();

            if (applicableServiceObj != null)
            {
                applicableServiceObj.service_id = (long)default_services_for_crm.Last_Service;
                applicableServiceObj.crm_id = Guid.Parse(GetEnumDescriptionMethod.GetEnumDescription(default_services_for_crm.Last_Service));
                int index = applicableServices.FindIndex(x => x.service_id == applicableServiceObj.service_id);
                applicableServices.RemoveAt(index);

                applicableServices.Insert(0, applicableServiceObj);
            }

            #endregion END



            List<DefaultServicesForCRMOrderDto> defaultServicesList = applicableServices.Select(a => new DefaultServicesForCRMOrderDto
            {
                id = a.id,
                service_id = a.service_id,
                service_name = a.service,
                service_crm_id = (Guid)a.crm_id,
                unit_crm_id = (Guid)a.unit_crm_id,
                description = a.description,
                additional_info = a.additional_info,
                rate_type_id = a.rate_type_id,
                rate_type = a.rate_type,
                amount_modified_reason = a.amount_modified_reason,
                service_amount = a.amount,
                autherized_amount = a.authorized_amount,
                message = a.message
            }).ToList();
            #endregion END

            #endregion END- GET SERVICE DETAIL

            #region Get Default IC Instruction List
            // if service prefrence doesn't exist in agreement or are not eligible by
            // the rule then IC will be comes from Standards agreement.


            List<PreferencesListDto> ICPreferenceList = await _mediator.Send(new GetICInstructionPreferencesListQuery { agreement_id = (long)nextgen_agreement_id, agreement_type_id = (long)Agreement_Type.Hightouch, currency_id = (long)serviceReq.currency_id, crm_service_list = serviceReq.crm_service_list, isElectricVehicle = isElectricVehicle });

            List<JsonResult> icjsonResults = new List<JsonResult>();
            List<ICIntructionForServiceOrderDto> icInstructionlist = new List<ICIntructionForServiceOrderDto>();
            if (defaultServicesList.Count > 0)
            {
                // ICPreferenceList = ICPreferenceList.Take(3).ToList();//REMOVE THIS LINE WHEN WILL BE RULE WORKING PROPERLY           
                foreach (var item in ICPreferenceList)
                {
                    if (item.category_id == (long)Category_Types.service_request)
                    {
                        item.modelJson = JsonConvert.SerializeObject(sr_request);
                        item.price_list_id = nextgen_price_list_id;
                    }
                }
                icjsonResults = await _mediator.Send(new EvaluateRulesQuery { preferencesListReq = ICPreferenceList });
                icInstructionlist = await _mediator.Send(new GetApplicableICInstructionQuery { jsonResults = icjsonResults });
            }
            else
            {
                //By pass execution of Rules

                List<long> list = new List<long>();
                if (ICPreferenceList.Count > 0)
                    foreach (var item in ICPreferenceList)
                    {
                        long? id = null;
                        id = item.service_id;
                        list.Add((long)id);
                    }

                icInstructionlist = await _mediator.Send(new GetStandardICInstructionByServiceId { icPreferenceRuleList = list, currency_id = serviceReq.currency_id });
            }




            #region Logic of EV or NON EV Services 

            //First_Service_EV
            ICIntructionForServiceOrderDto iCIntructionForServiceOrderObj = icInstructionlist.Where(x => x.service_id == (long)EnumTypes.default_services_for_crm.First_Service_EV).FirstOrDefault();

            if (iCIntructionForServiceOrderObj != null)
            {
                iCIntructionForServiceOrderObj.service_id = (long)EnumTypes.default_services_for_crm.First_Service;
                iCIntructionForServiceOrderObj.crm_id = Guid.Parse(GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.default_services_for_crm.First_Service));
                int index = icInstructionlist.FindIndex(x => x.service_id == iCIntructionForServiceOrderObj.service_id);
                icInstructionlist.RemoveAt(index);

                icInstructionlist.Insert(0, iCIntructionForServiceOrderObj);
            }

            //Last Service (EV)
            iCIntructionForServiceOrderObj = icInstructionlist.Where(x => x.service_id == (long)EnumTypes.default_services_for_crm.Last_Service_EV).FirstOrDefault();

            if (iCIntructionForServiceOrderObj != null)
            {
                iCIntructionForServiceOrderObj.service_id = (long)EnumTypes.default_services_for_crm.Last_Service;
                iCIntructionForServiceOrderObj.crm_id = Guid.Parse(GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.default_services_for_crm.Last_Service));
                int index = icInstructionlist.FindIndex(x => x.service_id == iCIntructionForServiceOrderObj.service_id);
                icInstructionlist.RemoveAt(index);

                icInstructionlist.Insert(0, iCIntructionForServiceOrderObj);
            }

            #endregion END

            #endregion END


            ICIntructionForServiceOrderDto iCIntructionForServiceOrderDto = null;
            defaultServiceAndICResponse.ICInstructionList = new List<ICIntructionForServiceOrderDto>();

            // Set Up to amount in Full detail service.
            foreach (var item in icInstructionlist)
            {
                iCIntructionForServiceOrderDto = new ICIntructionForServiceOrderDto();
                iCIntructionForServiceOrderDto.id = item.id;
                iCIntructionForServiceOrderDto.service_id = item.service_id;
                if (iCIntructionForServiceOrderDto.service_id != null)
                {
                    var service = defaultServicesList.Where(x => x.rate_type_id == (int)Rate_Type.Up_To).FirstOrDefault();
                    if (service != null)
                    {
                        if (service.service_id == item.service_id)
                            iCIntructionForServiceOrderDto.instruction = item.instruction; //+ " $ " +  service.autherized_amount;
                        else
                            iCIntructionForServiceOrderDto.instruction = item.instruction;
                    }
                    else
                    {
                        iCIntructionForServiceOrderDto.instruction = item.instruction;
                    }
                }
                else
                {
                    iCIntructionForServiceOrderDto.instruction = item.instruction;
                }
                iCIntructionForServiceOrderDto.service_name = item.service_name;
                iCIntructionForServiceOrderDto.order_type_id = item.order_type_id;
                iCIntructionForServiceOrderDto.crm_id = item.crm_id;
                iCIntructionForServiceOrderDto.sequence_number = item.sequence_number;
                defaultServiceAndICResponse.ICInstructionList.Add(iCIntructionForServiceOrderDto);
            }

            #region Default IC

            List<ICIntructionForServiceOrderDto> iCIntructionForServiceOrderDtos = new List<ICIntructionForServiceOrderDto>();
            iCIntructionForServiceOrderDtos.AddRange(defaultServiceAndICResponse.ICInstructionList);

            //if (defaultServicesList.Count > 0)
            //{
            //    foreach (var item in iCIntructionForServiceOrderDtos)
            //    {
            //        if (item.service_id != null)
            //        {
            //            var obj = defaultServicesList.Where(x => x.service_id == item.service_id).FirstOrDefault();

            //            if (obj == null)
            //            {
            //                int? index = defaultServiceAndICResponse.ICInstructionList.FindIndex(x => x.id == item.id);
            //                if (index != null && index != -1)
            //                {
            //                    defaultServiceAndICResponse.ICInstructionList.RemoveAt((int)index);
            //                }
            //            }
            //        }
            //    }
            //}

            #endregion END Get Default IC Instruction List

            defaultServiceAndICResponse.serviceList = defaultServicesList;
            response.IsSuccessful = true;
            response.Data = defaultServiceAndICResponse;
            return new OkObjectResult(response);

        }

        #endregion


        /// <summary>
        /// Update Agreement Related Service And IC From CRM
        /// </summary>
        /// <param name="serviceReq"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        public async Task<ResponseBase<bool>> UpdateAgreementRelatedServiceAndICFromCRM(UpdateServicesAndICFromCRMReq updateServicesAndICFromCRMReq)
        {
            ResponseBase<bool> responseBase = new ResponseBase<bool>();
            bool result = false;
            try
            {
                result = await _mediator.Send(new UpdateServicesAndICFromCRMCommand { requestParameters = updateServicesAndICFromCRMReq });
            }
            catch (Exception ex)
            {
                responseBase.MessageDetail = new CustomMessage();
                responseBase.MessageDetail.message = ex.Message;
            }
            responseBase.Data = result;
            responseBase.IsSuccessful = result;
            return responseBase;
        }


        /// <summary>
        /// This method used for get wizard response for save data in crm.
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        public async Task<bool> UpdateWizardInformationInCrm(UpdateWizardReq req)
        {
            var result = await _mediator.Send(new ManageWizardInformationInCrmCommand { address_point_id = req.address_type_id, order_id = req.order_id });
            return result;
        }
    }
    public class ApplicableCPSDtos
    {
        public long agreement_id { get; set; }
        public long agreement_status_id { get; set; }
        public Guid agreement_crm_id { get; set; }
        public string agreement { get; set; }
        public long price_list_id { get; set; }
        public long agreement_type_id { get; set; }
        public List<SupportContactsOnServiceRequestDto> supportContactLists { get; set; }
    }
}
