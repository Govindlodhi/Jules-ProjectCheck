﻿namespace PARSNextGen.API
{
    public class ExceptionDetail
    {
        public string controller_name { get; set; }
        public string method_name { get; set; }
        public object request_parameter { get; set; }
    }
}
