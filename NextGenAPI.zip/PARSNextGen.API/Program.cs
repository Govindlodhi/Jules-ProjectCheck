using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

using Serilog;

using System;
using System.IO;

namespace PARSNextGen.API
{
    public class Program
    {
        public static IConfiguration Configuration { get; } = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings." + Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") + ".json", optional: false, reloadOnChange: true)
            .AddJsonFile("custommessages.json", optional: false, reloadOnChange: true)
            .AddEnvironmentVariables()
            .Build();

        public static void Main(string[] args)
        {
            //Install Serilog
            Log.Logger = new LoggerConfiguration()
                                .ReadFrom.Configuration(Configuration)
                                .CreateLogger();
            try
            {
                Log.Information("Starting PARSNXTGEN API");
                CreateHostBuilder(args).Build().Run();
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "PARSNXTGEN API terminated unexpectedly");
                return;
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
       =>
       Host.CreateDefaultBuilder(args)
           .ConfigureWebHostDefaults(webBuilder =>
           {
               webBuilder.UseStartup<Startup>();
               webBuilder.UseConfiguration(Configuration);

               webBuilder.ConfigureServices((context, services) =>
               {
                   var configuration = context.Configuration;
                   // Retrieve the Application Insights Instrumentation Key from configuration
                   var instrumentationKey = configuration["appSettings:InstrumentationKey"];
                   // If the key is found, add Application Insights telemetry
                   if (!string.IsNullOrEmpty(instrumentationKey))
                   {
                       services.AddApplicationInsightsTelemetry(instrumentationKey);
                   }
               });
           })
            .UseSerilog();
    }
}