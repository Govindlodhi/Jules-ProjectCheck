using FluentValidation.AspNetCore;
using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using PARSNextGen.API.DataModel;
using PARSNextGen.API.Extensions.Behaviours;
using PARSNextGen.API.Services;
using PARSNextGen.Application;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.Utility.Preference;
using PARSNextGen.Contracts;
using PARSNextGen.Infrastructure;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PARSNextGen.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton(_ => Configuration);
            services.AddScoped<ICurrentUserService, CurrentUserService>();

            var jwtSection = Configuration.GetSection("JwtConfig");
            var signingKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(jwtSection["Key"]));

            AppSettingHelper.AppSettingsConfigure(Configuration);

            services.AddAuthorization();
            services.AddHttpClient();
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(x =>
            {
                x.RequireHttpsMetadata = false;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = signingKey,
                    ValidateIssuer = true,
                    ValidIssuer = jwtSection["Issuer"],
                    ValidateAudience = true,
                    ValidAudience = jwtSection["Audience"],
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero,
                    RequireExpirationTime = true
                };
            });

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader());
            });
            services.AddApplication();
            services.AddInfrastructure();

            services.AddStackExchangeRedisCache(options =>
            {
                options.Configuration = Configuration["ConnectionStrings:RedisConnection"];               
            });

            services.AddControllers(opt =>
            {
                opt.Filters.Add(typeof(CustomExceptionFilterAttribute));
            })
            .AddFluentValidation(fvc => fvc.RegisterValidatorsFromAssemblyContaining<Startup>())
            .ConfigureApiBehaviorOptions(options =>
            {
                options.InvalidModelStateResponseFactory = context =>
                {
                    var messages = context.ModelState.Values
                        .Where(x => x.ValidationState == ModelValidationState.Invalid)
                        .SelectMany(x => x.Errors)
                        .Select(x => x.ErrorMessage)
                        .ToList();

                    ResponseBase<string> invalidResponse = new ResponseBase<string>();
                    invalidResponse.IsSuccessful = false;
                    invalidResponse.MessageDetail = new CustomMessage
                    {
                        message_code = "5999",
                        message_shortcode = "PARS_MODEL_VALIDATION_FAILED",
                        message_type = "Validation",
                        message = string.Join($"{Environment.NewLine}", messages)
                    };

                    return new BadRequestObjectResult(invalidResponse);
                };
            });
            //.SetCompatibilityVersion(CompatibilityVersion.Version_3_0);


            services.Configure<List<CustomMessage>>(Configuration.GetSection("custommessages"));

            /* COMMENTING AS USING SERILOG INSTEAD
             
           // Enable if we want to log API request.
            if (int.Parse(Configuration.GetSection("appSettings").GetSection("EnableRequestLogging").Value) == 1)
            {
                services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestPreProcessorBehavior<,>));
                services.AddTransient(typeof(IRequestPreProcessor<>), typeof(RequestLogger<>));
            }

           // Enable if we want to do performance measurement of API.
            if (int.Parse(Configuration.GetSection("appSettings").GetSection("EnablePerfLogging").Value) == 1)
                services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestPerformanceBehaviour<,>));

            // END OF REQUEST LOGGING
            */


            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestValidationBehavior<,>));

            #region Mass Transit Connection Rebbit MQ
            /*
            services.AddMassTransit(x =>
            {
                x.UsingRabbitMq((busCntx, configurator) =>
                {
                    RabbitMQSettings rabbitMQSettings = Configuration.GetSection("RabbitMQSettings").Get<RabbitMQSettings>();
                    configurator.Host(rabbitMQSettings.Host, (ushort)rabbitMQSettings.Port, rabbitMQSettings.VirtualHost, h =>
                    {

                        h.Username(rabbitMQSettings.UserName);
                        h.Password(rabbitMQSettings.Password);

                        h.UseSsl(s =>
                        {
                            s.Protocol = System.Security.Authentication.SslProtocols.Tls12;
                        });
                    });
                });
            }); */
            #endregion

            #region Mass Transit Connection Azure Bus
            services.AddMassTransit(x =>
            {
                x.UsingAzureServiceBus((busCntx, configurator) =>
                {
                    AzureBusSettings azureBusSettings = Configuration.GetSection("AzureBusSettings").Get<AzureBusSettings>();
                    configurator.Host(azureBusSettings.connectionString);
                    configurator.Message<SendEmail>(x => x.SetEntityName(azureBusSettings.topicName));
                });
            });

           

            #endregion

            services.AddApiVersioning(x =>
            {
                x.DefaultApiVersion = new ApiVersion(1, 0);
                x.AssumeDefaultVersionWhenUnspecified = true;
                x.ReportApiVersions = true;
            });

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "PARSNxtGen V360 API",
                    Description = "PARS next generation vehicle 360 (v360) web API service documentation."
                });
            });
            services.AddApplicationInsightsTelemetry();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILogger<Startup> logger)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSerilogRequestLogging();

            app.UseRouting();
            app.UseCors("CorsPolicy");
            app.UseAuthentication();
            app.UseAuthorization();

            //app.UseEndpoints(endpoints =>
            //{
            //    endpoints.MapControllers();
            //});

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller}/{action=Index}/{id?}");
            });


            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "ParsNextGen API V1");

            });
        }


    }
}
