﻿using FluentValidation;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using PARSNextGen.Application.Service;
using System.Reflection;

namespace PARSNextGen.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services)
        {
            services.AddAutoMapper(Assembly.GetExecutingAssembly());
            services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
            services.AddMediatR(Assembly.GetExecutingAssembly());
            services.AddTransient<IIdentityService, IdentityService>();
            services.AddTransient<ITemplateMapper, TemplateMapper>();
            services.AddSingleton<ICustomMessageService, CustomMessageService>();
            services.AddTransient<IAzureMapService, AzureMapService>();
            //services.AddTransient<IPriceCalculationService, PriceCalculationService>();
            services.AddScoped<IAzureDocumentService, AzureDocumentService>();
            return services;
        }
    }
}
