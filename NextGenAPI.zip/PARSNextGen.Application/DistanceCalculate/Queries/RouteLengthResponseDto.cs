﻿using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.DistanceCalculate.Queries
{
    public class RouteLengthResponseDto
    {
        public string full_json { get; set; }
        public string route_overview_json { get; set; }
        public decimal distance { get; set; }
        public decimal distance_with_traffic { get; set; }
        public int travel_duration { get; set; }
        public int travel_duration_in_traffic { get; set; }
        public string est_duration { get; set; }
        public string adj_est_duration { get; set; }
        public string adj_distance { get; set; }
        public int est_duration_min { get; set; }
        public int adj_est_duration_min { get; set; }
        public int adj_hours { get; set; }
        public DateTime departure_time { get; set; }
        public DateTime arriaval_time { get; set; }
        public GeoCoordinate start_location { get; set; }
        public GeoCoordinate end_location { get; set; }
    }
    public class GeoCoordinate
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }

        public GeoCoordinate()
        {

        }

        public GeoCoordinate(double lat, double lon)
        {
            Latitude = lat;
            Longitude = lon;
        }

        public GeoCoordinate(List<double> parts)
        {
            Latitude = parts[0];
            Longitude = parts[1];
        }

        public double GetDistanceTo(GeoCoordinate other)
        {
            if (other == null)
            {
                return Int32.MaxValue;
            }

            var lat1 = Latitude;
            var lon1 = Longitude;
            var lat2 = other.Latitude;
            var lon2 = other.Longitude;

            /*using HaversineAlgorithm for calculates the shortest distance between two points on a sphere
            using their latitudes and longitude measured along the surface */
            return HaversineAlgorithm.HaversineInM(lat1, lon1, lat2, lon2);
        }
    }
}
