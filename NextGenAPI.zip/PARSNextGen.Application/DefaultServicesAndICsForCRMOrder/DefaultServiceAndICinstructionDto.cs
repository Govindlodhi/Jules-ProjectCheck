﻿using PARSNextGen.Application.ServiceRequest.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.DefaultServicesAndICsForCRMOrder
{
    public class DefaultServiceAndICinstructionDto
    {
        public long agreement_id { get; set; }
        public string agreement_name { get; set; }
        public long? price_list_id { get; set; }
        public Guid? agreement_crm_id { get; set; }
        public List<DefaultServicesForCRMOrderDto> defaultServiceList { get; set; }
        public List<ICIntructionForServiceOrderDto> defaultICInstructionList { get; set; }
        public List<SupportContactsOnServiceRequestDto> supportContact { get; set; }
    }
}
