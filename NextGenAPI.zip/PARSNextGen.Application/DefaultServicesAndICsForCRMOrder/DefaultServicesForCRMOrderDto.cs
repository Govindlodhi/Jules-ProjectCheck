﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PARSNextGen.Application.DefaultServicesAndICsForCRMOrder
{
    public class DefaultServicesForCRMOrderDto
    {
        public long? id { get; set; }
        public long? service_id { get; set; }
        public string service_name { get; set; }
        public Guid? service_crm_id { get; set; }
        public Guid? unit_crm_id { get; set; }
        public string service { get; set; }
        public string description { get; set; }
        public string additional_info { get; set; }
        public long? rate_type_id { get; set; }
        public string rate_type { get; set; }
        public decimal? service_amount { get; set; }
        public decimal? autherized_amount { get; set; }
        public decimal? total_amount { get; set; }
        public string amount_modified_reason { get; set; }
        public string message { get; set; }

    }
}
