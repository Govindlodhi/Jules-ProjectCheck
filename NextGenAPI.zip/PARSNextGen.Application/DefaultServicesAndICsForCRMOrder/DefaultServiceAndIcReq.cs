﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.DefaultServicesAndICsForCRMOrder
{
    public class DefaultServiceAndIcReq
    {
        public Guid? applicable_parameter_set_id { get; set; }
        public Guid? fmc_parameter_set_id { get; set; }
        public Guid? account_parameter_set_id { get; set; }
        public long? transportation_type_id { get; set; }
        public long? requsted_by { get; set; }
        //public long? fmc_nextgen_id { get; set; }
        //public long? account_nextgen_id { get; set; }
        //public string fleet_number { get; set; }
        public long? currency_id { get; set; }
        public long? vehicle_type_id { get; set; }
        public string primary_fuel_type { get; set; }
        public string secondary_fuel_type { get; set; }
        public long? pickup_address_type_id { get; set; }
        public long? delivery_address_type_id { get; set; }
    }
}
