﻿using Dapper;
using MassTransit;
using MediatR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using PARSNextGen.Application.SQL;
using PARSNextGen.Contracts;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.OrderBatchImport
{
    public class ReSubmitOrderBatchRowCommand : IRequest<bool>
    {
        public long id { get; set; }
    }
    public class ReSubmitOrderBatchRowCommandHandler : IRequestHandler<ReSubmitOrderBatchRowCommand, bool>
    {
        private readonly ISqlContext _sqlContext;
        private readonly IBus _bus;
        private readonly IConfiguration _config;
        public ReSubmitOrderBatchRowCommandHandler(ISqlContext sqlContext, IBus bus, IConfiguration config)
        {
            _sqlContext = sqlContext;
            _bus = bus;
            _config = config;
        }
        public async Task<bool> Handle(ReSubmitOrderBatchRowCommand request, CancellationToken cancellationToken)
        {
            bool data = false;
            using (var conn = _sqlContext.GetOpenConnection())
            {
                string query = @"SELECT PickupVerificationStatus, DeliveryVerificationStatus,status Status,resubmit_request,error_container FROM order_batch_row WHERE id = @Id";
                var result = conn.QueryFirstOrDefault(query, new { Id = request.id });
                if (result != null)
                {
                    if (result.retry_count < 3)
                    {
                        if (result.resubmit_request == false)
                        {
                            // var errorContainer = JsonConvert.DeserializeObject<Dictionary<string, JObject>>(result.error_container);
                            if (result.error_container != null)
                            {
                                JObject errorContainer = JObject.Parse(result.error_container);
                                var errorFields = errorContainer.Properties().Where(p => p.Value["error_type"]?.ToString() == "Error")
                                         .Select(p => $"{p.Name}: {p.Value["message"]}").ToList();
                                if (errorFields.Any())
                                {
                                    //string errorMessage = "Order contains multiple errors:"+string.Join("", errorFields) +"Please resolve the errors and resubmit the request.";
                                    string errorMessage = "PARS_ROW_CONTAINS_ERROR";
                                    throw new Exception(errorMessage);
                                }
                            }
                            if (result.DeliveryVerificationStatus == 1 && result.PickupVerificationStatus == 1 && result.Status != "Success"
                                && (result.Status == "Partially Completed" || result.Status is null || result.Status == "Failed"))
                            {
                                var sendEndpoint = await _bus.GetSendEndpoint(new Uri($"{_config["AzureBusSettings:generateServiceRequestQueueURL"]}"));
                                await sendEndpoint.Send(new MessageBase { RecordId = request.id });
                                _ = conn.ExecuteAsync("UPDATE order_batch_row set resubmit_request= 1,status = NULL ,sr_not_genrate_reason=null WHERE id = @Id", new { Id = request.id });
                                data = true;
                            }
                        }
                        else
                            throw new Exception("PARS_RESUBMIT_REQ_ALREADY_EXISTS");
                    }
                    else
                        throw new Exception("RETRY_LIMIT_EXCEEDED");
                }
                return data;
            }
        }
    }
}
