﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.OrderBatchImport.OrderBatchMaster
{
    public class GetAccountFMCsForOrderBatchQuery : IRequest<List<OrderBatchMasterBaseEntity>>
    {
        public class FMCListForOrderBatchQueryHandler : IRequestHandler<GetAccountFMCsForOrderBatchQuery, List<OrderBatchMasterBaseEntity>>
        {
            private readonly ISqlContext _dbCntx;
            private readonly ICurrentUserService _currentUserService;
            public FMCListForOrderBatchQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
            {
                _dbCntx = dbCntx;
                _currentUserService = currentUserService;
            }
            public async Task<List<OrderBatchMasterBaseEntity>> Handle(GetAccountFMCsForOrderBatchQuery request, CancellationToken cancellationToken)
            {
                List<OrderBatchMasterBaseEntity> FMCList = new();
                if (_currentUserService.AccountTypeId != (long)EnumTypes.AccountTypes.PARS)                
                    return FMCList;

                using (var connection = _dbCntx.GetOpenConnection())
                {
                    string query = @"SELECT a.id , a.account_name name FROM account a                                           
                                     WHERE a.is_active = 1 AND a.account_type_id = 2 ;";
                    FMCList = (List<OrderBatchMasterBaseEntity>)await connection.QueryAsync<OrderBatchMasterBaseEntity>(query);
                }
                return FMCList;
            }
        }
    }
}
