﻿using MediatR;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using PARSNextGen.Application.SQL;
using Dapper;

namespace PARSNextGen.Application.OrderBatchImport.OrderBatchMaster
{
    public class ContactListForOrderBatchQuery : IRequest<List<OrderBatchMasterBaseEntity>>
    {
        public long id { get; set; }
    }
    public class ContactListForOrderBatchQueryHandler : IRequestHandler<ContactListForOrderBatchQuery, List<OrderBatchMasterBaseEntity>>
    {
        private readonly ISqlContext _dbCntx;
        public ContactListForOrderBatchQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<OrderBatchMasterBaseEntity>> Handle(ContactListForOrderBatchQuery request, CancellationToken cancellationToken)
        {
            List<OrderBatchMasterBaseEntity> fleetList = new();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"SELECT c.id, CONCAT_WS(' ', c.first_name, c.middle_name, c.last_name) AS name
                                 FROM contact c WHERE c.status = 1 AND c.contact_type_id = 2 AND c.account_id =" + request.id;
                fleetList = (List<OrderBatchMasterBaseEntity>)await connection.QueryAsync<OrderBatchMasterBaseEntity>(query);
            }
            return fleetList;
        }
    }
}
