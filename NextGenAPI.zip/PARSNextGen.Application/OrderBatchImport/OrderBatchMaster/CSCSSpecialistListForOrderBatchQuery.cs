﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.OrderBatchImport.OrderBatchMaster
{
    public class CSCSSpecialistListForOrderBatchQuery : IRequest<List<OrderBatchMasterBaseEntity>>
    { }
    public class CSCSSpecialistListForOrderBatchQueryHandler : IRequestHandler<CSCSSpecialistListForOrderBatchQuery, List<OrderBatchMasterBaseEntity>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public CSCSSpecialistListForOrderBatchQueryHandler(ISqlContext dbCntx , ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<List<OrderBatchMasterBaseEntity>> Handle(CSCSSpecialistListForOrderBatchQuery request, CancellationToken cancellationToken)
        {            

            List<OrderBatchMasterBaseEntity> csList = new();
            if (_currentUserService.AccountTypeId != (long)EnumTypes.AccountTypes.PARS)
                return csList;

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"SELECT c.id, CONCAT_WS(' ', c.first_name, c.middle_name, c.last_name) AS name
                                FROM contact c 
                                LEFT JOIN user_auth ua ON c.id = ua.contact_id
                                WHERE ua.user_status_id = 1 AND c.status = 1 
                                AND c.contact_type_id = 1 AND c.account_id = 1;";

                csList = (List<OrderBatchMasterBaseEntity>)await connection.QueryAsync<OrderBatchMasterBaseEntity>(query);
            }
            return csList;
        }
    }
}
