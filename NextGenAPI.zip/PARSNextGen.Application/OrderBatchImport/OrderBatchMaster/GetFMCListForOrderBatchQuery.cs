﻿using MediatR;
using PARSNextGen.Application.Service;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using PARSNextGen.Domain.Common;
using PARSNextGen.Application.SQL;
using Dapper;

namespace PARSNextGen.Application.OrderBatchImport.OrderBatchMaster
{
    public class GetFMCListForOrderBatchQuery : IRequest<List<OrderBatchMasterBaseEntity>>
    {
        public long account_id { get; set; }
    }
    public class GetFMCListForOrderBatchQueryHandler : IRequestHandler<GetFMCListForOrderBatchQuery, List<OrderBatchMasterBaseEntity>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetFMCListForOrderBatchQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<List<OrderBatchMasterBaseEntity>> Handle(GetFMCListForOrderBatchQuery request, CancellationToken cancellationToken)
        {
            List<OrderBatchMasterBaseEntity> fleetList = new();
            if (_currentUserService.AccountTypeId != (long)EnumTypes.AccountTypes.PARS)
                return fleetList;

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"SELECT fmc.id, fmc.account_name name FROM account acc LEFT JOIN account fmc ON acc.fmc_id = fmc.id
                                 WHERE fmc.account_type_id = 2 AND acc.linked_account_id = " + request.account_id;
                fleetList = (List<OrderBatchMasterBaseEntity>)await connection.QueryAsync<OrderBatchMasterBaseEntity>(query);
            }
            return fleetList;
        }
    }
}
