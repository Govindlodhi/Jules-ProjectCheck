﻿namespace PARSNextGen.Application.OrderBatchImport.OrderBatchMaster
{
    public class OrderBatchMasterBaseEntity
    {
        public long id { get; set; }
        public string name { get; set; }
    }
}
