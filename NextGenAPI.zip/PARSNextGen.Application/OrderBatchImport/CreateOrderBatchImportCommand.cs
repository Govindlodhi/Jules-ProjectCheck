﻿using MediatR;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
namespace PARSNextGen.Application.OrderBatchImport
{
    public class CreateOrderBatchImportCommand : IRequest<List<int>>
    {
        public CreateOrderBatchImportReq orderBatchImportReq { get; set; }
        public List<string> filesName { get; set; }
    }
    public class CreateOrderBatchImportCommandHandler : IRequestHandler<CreateOrderBatchImportCommand, List<int>>
    {
        private readonly IOrderBatchImportRepository _orderBatchImportRepository;
        public CreateOrderBatchImportCommandHandler(IOrderBatchImportRepository orderBatchImportRepository)
        {
            _orderBatchImportRepository = orderBatchImportRepository;
        }
        public async Task<List<int>> Handle(CreateOrderBatchImportCommand request, CancellationToken cancellationToken)
        {
            OrderBatchImportDto orderBatchImport = new();
            orderBatchImport.import_type_id = request.orderBatchImportReq.import_type_id;
            orderBatchImport.requested_by_id = request.orderBatchImportReq.requested_by_id;
            orderBatchImport.fmc_id = request.orderBatchImportReq.fmc_id;
            orderBatchImport.account_id = request.orderBatchImportReq.account_id;
            orderBatchImport.contact_id = request.orderBatchImportReq.contact_id;
            orderBatchImport.email = request.orderBatchImportReq.email;
            orderBatchImport.cs_specialist_id = request.orderBatchImportReq.cs_specialist_id;
            orderBatchImport.filesName = request.filesName;
            List<int> recordIds = await _orderBatchImportRepository.CreateOrderBatchImport(orderBatchImport);
            return recordIds;
        }
    }
}
