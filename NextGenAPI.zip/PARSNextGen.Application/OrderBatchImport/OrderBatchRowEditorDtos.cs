﻿using System.Collections.Generic;

namespace PARSNextGen.Application.OrderBatchImport
{
    public class OrderBatchRowEditorDtos
    {

        public AddressBaseEntity Addresses { get; set; }
        public List<CommonFieldAttributes> commonFieldsAttributes { get; set; }


    }   

    public class CommonFieldAttributes
    {
        public string ErrorMessage { get; set; }
        public string ErrorType { get; set; }
        public string FieldName { get; set; }
        public string FieldData { get; set; }
        public List<DropDownBaseAttributes> DropDown { get; set; }
    }

    public class DropDownBaseAttributes
    {
        public string Name { get; set; }
        public long Id { get; set; }
    }
    public class DropDownBaseAttributesForServices
    {
        public string Name { get; set; }
        public string SortCode { get; set; }
        public long Id { get; set; }
    }
    public class AddressBaseEntity
    {
        public PickupAddressBaseAttributes PickupAddress { get; set; }
        public DeliveryAddressBaseAttributes DeliveryAddress { get; set; }
    }
    public class PickupAddressBaseAttributes
    {
        public string PickupAptSuiteBldg { get; set; }
        public string PickupAddressLine3 { get; set; }
        public string PickupStreetAddress { get; set; }
        public bool IsVerifyPickupAddress { get; set; }
        public string PickupZIPPostalCode { get; set; }
        public bool IsVerifyPickupPostalCode { get; set; }
        public string PickupStateProvince { get; set; }
        public bool IsVerifyPickUpState { get; set; }
        public string PickupCity { get; set; }
        public bool IsVerifyPickupCity { get; set; }
        public string PickupCountryRegion { get; set; }
        public bool IsVerifyPickupCountry { get; set; }

    }
    public class DeliveryAddressBaseAttributes
    {
        public string DeliveryAptSuiteBldg { get; set; }
        public string DeliveryAddressLine3 { get; set; }
        public string DeliveryStreetAddress { get; set; }
        public bool IsVerifyDeliveryAddress { get; set; }
        public string DeliveryZIPPostalCode { get; set; }
        public bool IsVerifyDeliveryPostalCode { get; set; }
        public string DeliveryStateProvince { get; set; }
        public bool IsVerifyDeliveryState { get; set; }
        public string DeliveryCity { get; set; }
        public bool IsVerifyDeliveryCity { get; set; }
        public string DeliveryCountryRegion { get; set; }
        public bool IsVerifyDeliveryCountry { get; set; }

    }
   
}
