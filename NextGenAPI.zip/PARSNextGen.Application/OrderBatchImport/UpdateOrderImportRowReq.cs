﻿using System.Collections.Generic;

namespace PARSNextGen.Application.OrderBatchImport
{
    public class UpdateOrderImportRowReq
    {
        public long id { get; set; }
        public AddressBaseEntityReq Addresses { get; set; }
        public List<CommonFieldAttributesReq> commonFieldsAttributesReq { get; set; }
    }
    public class AddressBaseEntityReq
    {
        public PickupAddressBaseAttributesReq PickupAddress { get; set; }
        public DeliveryAddressBaseAttributesReq DeliveryAddress { get; set; }
    }
    public class PickupAddressBaseAttributesReq
    {
        public string PickupAptSuiteBldg { get; set; }
        public string PickupAddressLine3 { get; set; }
        public string PickupStreetAddress { get; set; }
        public bool IsVerifyPickupAddress { get; set; } = false;
        public string PickupZIPPostalCode { get; set; }
        public bool IsVerifyPickupPostalCode { get; set; } = false;
        public string PickupStateProvince { get; set; }
        public bool IsVerifyPickUpState { get; set; } = false;
        public long? pickup_state_id { get; set; }
        public string PickupCity { get; set; }
        public bool IsVerifyPickupCity { get; set; } = false;
        public string PickupCountryRegion { get; set; }
        public long? pickup_country_id { get; set; }
        public bool IsVerifyPickupCountry { get; set; } = false;
        public long? PickupVerificationStatus { get; set; }


    }
    public class DeliveryAddressBaseAttributesReq
    {
        public string DeliveryAptSuiteBldg { get; set; }
        public string DeliveryAddressLine3 { get; set; }
        public string DeliveryStreetAddress { get; set; }
        public bool IsVerifyDeliveryAddress { get; set; } = false;
        public string DeliveryZIPPostalCode { get; set; }
        public bool IsVerifyDeliveryPostalCode { get; set; } = false;
        public string DeliveryStateProvince { get; set; }
        public bool IsVerifyDeliveryState { get; set; } = false;
        public long? delivery_state_id { get; set; }
        public string DeliveryCity { get; set; }
        public bool IsVerifyDeliveryCity { get; set; } = false;
        public string DeliveryCountryRegion { get; set; }
        public long? delivery_country_id { get; set; }
        public bool IsVerifyDeliveryCountry { get; set; } = false;
        public long? deliveryVerificationStatus { get; set; }
    }
    public class CommonFieldAttributesReq
    {      
        public string FieldName { get; set; }
        public string FieldData { get; set; }
        public long? SelectedDropDownId { get; set; }
    }
}
