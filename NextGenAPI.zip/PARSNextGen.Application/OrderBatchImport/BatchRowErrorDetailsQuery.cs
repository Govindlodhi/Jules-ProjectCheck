﻿using Dapper;
using MediatR;
using Newtonsoft.Json;
using PARSNextGen.Application.SQL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.OrderBatchImport
{
    public class BatchRowErrorDetailsQuery : IRequest<OrderBatchRowEditorDtos>
    {
        public long id { get; set; }
    }
    public class BatchRowErrorDetailsQueryHandler : IRequestHandler<BatchRowErrorDetailsQuery, OrderBatchRowEditorDtos>
    {
        private readonly ISqlContext _dbContext;

        public BatchRowErrorDetailsQueryHandler(ISqlContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<OrderBatchRowEditorDtos> Handle(BatchRowErrorDetailsQuery req, CancellationToken cancellationToken)
        {
            OrderBatchRowEditorDtos orderBatchRowDetailList = new();
            using (var con = _dbContext.GetOpenConnection())
            {
                string query = @"SELECT id ,batch_id ,CustomerAccount ,customer_account_id ,CustomerContactName ,customer_contact_id 
                                ,CustomerContactPrimaryEmail ,CustomerContactSecondaryEmail ,AdditionalEmails ,CustomerContactPhone1Phone1Type 
                                ,customer_contact_phone1 ,customer_contact_phone_type1 ,CustomerContactPhone2Phone2Type ,customer_contact_phone2
                                ,customer_contact_phone_type2 ,CustomerContactPhone3Phone3Type ,customer_contact_phone3 ,customer_contact_phone_type3 
                                ,VehicleFleetNumber ,fleet_account_id ,VehicleUnitNumber ,VIN ,vehicle_id ,is_vin_verified ,AlternateVehicleIdentifier 
                                ,VehicleType ,vehicle_type_id ,VehicleBodyStyle ,FuelType ,fuel_type_id ,VehicleYear ,VehicleMake ,VehicleModel 
                                ,VehicleColor ,IsCurrentVehicleRegistration ,VehicleLicensePlate ,VehicleLicensePlateState ,LicensePlateExpirationDate 
                                ,PickupFrom ,pickup_address_type_id ,PickupContactName ,IsPickupContactVIP ,PickupPhone1Phone1Type ,pickup_phone1 
                                ,pickup_phone_type1 ,PickupPhone2Phone2Type ,pickup_phone2 ,pickup_phone_type2 ,PickupPhone3Phone3Type ,pickup_phone3 
                                ,pickup_phone_type3 ,PickupPhone4Phone4Type ,pickup_phone4 ,pickup_phone_type4 ,PickupPrimaryEmail ,PickupSecondaryEmail 
                                ,PickupContactTimeZone ,PickupNote ,PickupAlternateContact ,PickupAlternateContactPhone1Phone1Type ,pickup_alternate_phone1 
                                ,pickup_alternate_phone_type1 ,PickupAlternateContactPhone2Phone2Type ,pickup_alternate_phone2 ,pickup_alternate_phone_type2 
                                ,PickupAlternateContactEmail ,DoNotContactPickupBefore ,DescribePickupSensitivity ,PickupAddressDetails ,PickupStreetAddress 
                                ,PickupAptSuiteBldg ,PickupAddressLine3 ,PickupCity ,PickupStateProvince ,pickup_state_id ,PickupZIPPostalCode ,pickup_lat 
                                ,pickup_log ,PickupCountryRegion ,PickupStorageName ,pickup_storage_id ,is_pickup_address_verified ,IsVerifyPickUpAddress 
                                ,IsVerifyPickUpCountryCode ,IsVerifyPickUpCity ,IsVerifyPickUpState ,IsVerifyPickUpPostalCode ,IsVerifyPickUpCountry 
                                ,IsVerifyPickUpCounty ,PickupVerificationStatus ,RequestedPickupDateType ,requested_pickup_date_type_id ,PickupRequestedDate 
                                ,PickupUrgentReason ,IsTowingRequired ,TowingType ,towing_type_id ,TowingReason ,IsRepoAuthorized ,DescribeSituation 
                                ,DeliverTo ,delivery_address_type_id ,DeliveryContactName ,DeliveryPhone1Phone1Type ,delivery_phone1 ,delivery_phone_type1 
                                ,DeliveryPhone2Phone2Type ,delivery_phone2 ,delivery_phone_type2 ,DeliveryPhone3Phone3Type ,delivery_phone3 
                                ,delivery_phone_type3 ,DeliveryPrimaryEmail ,DeliverySecondaryEmail ,DeliveryContactTimeZone ,DeliveryNote 
                                ,DeliveryAlternateContact ,DeliveryAlternateContactPhone1Phone1Type ,delivery_alternate_phone1 ,delivery_alternate_phone_type1 
                                ,DeliveryAlternateContactPhone2Phone2Type ,delivery_alternate_phone2 ,delivery_alternate_phone_type2 
                                ,DeliveryAlternateContactEmail ,DoNotContactDeliveryBefore ,DescribeDeliverySensitivity ,DescribeAddressDetails 
                                ,DeliveryStreetAddress ,DeliveryAptSuiteBldg ,DeliveryAddressLine3 ,DeliveryCity ,DeliveryStateProvince 
                                ,delivery_state_id ,DeliveryZIPPostalCode ,DeliveryCountryRegion ,DeliveryStorageName ,delivery_storage_id 
                                ,delivery_lat ,delivery_lon ,is_delivery_address_verified ,IsVerifyDeliveryAddress ,IsVerifyDeliveryCountryCode 
                                ,IsVerifyDeliveryCity ,IsVerifyDeliveryState ,IsVerifyDeliveryPostalCode ,IsVerifyDeliveryCountry ,IsVerifyDeliveryCounty 
                                ,deliveryVerificationStatus ,ReleaseToAuction ,RequestedDeliveryDateType ,requested_delivery_date_type_id 
                                ,DeliveryUrgentReason ,DeliveryRequestedDate ,TransportationType ,transpotation_type ,Services ,service_ids 
                                ,KnownIssues ,SpecialHandling ,CustomerPO ,CustomerReference ,Project ,error_container ErrorContainer ,is_amount_calculated 
                                ,status from order_batch_row WHERE id = @id";
                var orderBatchRowDetails = con.QueryFirstOrDefault<BatchRowDataModel>(query, new { req.id }, commandType: CommandType.Text);

                if (orderBatchRowDetails != null)
                {
                    if (orderBatchRowDetails.ErrorContainer is not null)
                    {
                        List<CommonFieldAttributes> commonFieldsDataCollection = new();
                        var errorData = JsonConvert.DeserializeObject<Dictionary<string, dynamic>>(orderBatchRowDetails.ErrorContainer);

                        var dropDownDataDictionary = new Dictionary<string, string>
                        { { "VehicleType", "vehicle_type" }, { "FuelType", "fuel_type" }, { "VehicleLicensePlateState", "state" },
                            { "PickupFrom", "address_type" },{ "PickupStateProvince", "state" },{ "PickupCountryRegion", "country" },{ "PickupStorageName", "location" },
                            { "RequestedPickupDateType", "date_constraints" },{ "TowingType", "towing_type" },{ "DeliverTo", "address_type" },
                            { "DeliveryStateProvince", "state" }, { "DeliveryCountryRegion", "country" }, { "DeliveryStorageName", "location" },
                            { "RequestedDeliveryDateType", "date_constraints" }, { "TransportationType", "transportation_type" },{ "Services", "service" }

                    };

                        var addressDictionary = new Dictionary<string, List<string>> { { "PickupAddress", new List<string> {
                        "PickupAddressDetails","PickupStreetAddress","PickupAptSuiteBldg","PickupAddressLine3","PickupCity","PickupStateProvince",
                        "PickupStateId", "PickupZIPPostalCode","PickupCountryRegion","PickupStorageName", "PickupStorageId"} },{
                        "DeliveryAddress",new List<string> {
                        "DeliveryAddressDetails","DeliveryStreetAddress", "DeliveryAptSuiteBldg","DeliveryAddressLine3",
                        "DeliveryCity","DeliveryStateProvince","DeliveryStateId","DeliveryZIPPostalCode","DeliveryCountryRegion",
                        "DeliveryStorageName","DeliveryStorageId"}} };

                        foreach (var data in errorData)
                        {
                            CommonFieldAttributes commonFieldAttributes = new();
                            commonFieldAttributes.ErrorType = data.Value.error_type;
                            commonFieldAttributes.ErrorMessage = data.Value.message;
                            commonFieldAttributes.FieldData = DataMappingHelper.GetPropertyValue(orderBatchRowDetails, data.Key)?.ToString();
                            commonFieldAttributes.FieldName = data.Key;

                            if (dropDownDataDictionary.ContainsKey(data.Key))
                                commonFieldAttributes.DropDown = await DataMappingHelper.DropDownData(dropDownDataDictionary[data.Key], con);

                            else if (data.Key.Contains("Phone") && data.Key.Contains("Type"))
                                commonFieldAttributes.DropDown = await DataMappingHelper.DropDownData("phone_type", con);

                            else if (addressDictionary.ContainsKey(data.Key))
                            {
                                if (orderBatchRowDetailList.Addresses == null)
                                    orderBatchRowDetailList.Addresses = new AddressBaseEntity();
                                if (data.Key == "PickupAddress")
                                {
                                    PickupAddressBaseAttributes addressDetails = new();
                                    DataMappingHelper.PopulateAddressFields(addressDetails, addressDictionary[data.Key], orderBatchRowDetails);
                                    orderBatchRowDetailList.Addresses.PickupAddress = new PickupAddressBaseAttributes();
                                    orderBatchRowDetailList.Addresses.PickupAddress = addressDetails;
                                }
                                else if (data.Key == "DeliveryAddress")
                                {
                                    DeliveryAddressBaseAttributes addressDetails = new();
                                    DataMappingHelper.PopulateAddressFields(addressDetails, addressDictionary[data.Key], orderBatchRowDetails);
                                    orderBatchRowDetailList.Addresses.DeliveryAddress = new DeliveryAddressBaseAttributes();
                                    orderBatchRowDetailList.Addresses.DeliveryAddress = addressDetails;
                                }
                            }
                            commonFieldsDataCollection.Add(commonFieldAttributes);
                        }
                        orderBatchRowDetailList.commonFieldsAttributes = commonFieldsDataCollection;
                    }
                }
            }
            if (orderBatchRowDetailList.Addresses == null && (orderBatchRowDetailList.commonFieldsAttributes == null || !orderBatchRowDetailList.commonFieldsAttributes.Any()))
            {
                orderBatchRowDetailList = null;
            }
            return orderBatchRowDetailList;
        }
    }

    // Generic method for data mapping
    public static class DataMappingHelper
    {
        public static object GetPropertyValue(object obj, string propertyName)
        {
            var data = obj.GetType().GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance)?.GetValue(obj);
            return data;
        }
        public static void SetPropertyValue(object obj, string propertyName, string value)
        {
            var propertyInfo = obj.GetType().GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance);
            if (propertyInfo != null && propertyInfo.CanWrite)
            {
                if (propertyInfo.PropertyType == typeof(int))
                    propertyInfo.SetValue(obj, Convert.ToInt32(value));
                else if (propertyInfo.PropertyType == typeof(double))
                    propertyInfo.SetValue(obj, Convert.ToDouble(value));
                else
                    propertyInfo.SetValue(obj, value);
            }
        }
        public static void PopulateAddressFields(object address, List<string> fields, object data)
        {
            foreach (var field in fields)
            {
                if (data.GetType().GetProperty(field) != null)
                {
                    string value = GetPropertyValue(data, field)?.ToString();
                    if (!string.IsNullOrEmpty(value))
                        SetPropertyValue(address, field, value);
                }
            }
        }
        public static async Task<List<DropDownBaseAttributes>> DropDownData(string entity, IDbConnection conn)
        {
            List<DropDownBaseAttributes> response = new();

            string query = entity.ToLower() == "service" ? @$"SELECT id, CONCAT(name, CASE WHEN service_code IS NOT NULL AND TRIM(service_code) <> ''
                                             THEN CONCAT(',', service_code) ELSE ''  END ) as name FROM {entity} where service_code is not null" : $"SELECT id, name FROM {entity}";
            response = (List<DropDownBaseAttributes>)await conn.QueryAsync<DropDownBaseAttributes>(query, commandType: CommandType.Text);
            return response;
        }
    }
}