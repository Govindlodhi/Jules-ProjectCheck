﻿using Dapper;
using MediatR;
using Newtonsoft.Json;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.VINValidation.Queries;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using static PARSNextGen.Domain.Common.EnumTypes;

namespace PARSNextGen.Application.OrderBatchImport
{
    public class UpdateOrderBatchImportRowCommand : IRequest<bool>
    {
        public UpdateOrderImportRowReq updateOrderImportRowReq { get; set; }
    }
    public class UpdateOrderBatchImportRowCommandHandler : IRequestHandler<UpdateOrderBatchImportRowCommand, bool>
    {
        private readonly ISqlContext _sqlContext;
        public UpdateOrderBatchImportRowCommandHandler(ISqlContext sqlContext)
        {
            _sqlContext = sqlContext;
        }
        public async Task<bool> Handle(UpdateOrderBatchImportRowCommand request, CancellationToken cancellationToken)
        {
            List<string> errorListRemoveKey = new();
            var updateAttributes = new List<string>();

            updateAttributes = CommonMethods.AddressDataBinding(request.updateOrderImportRowReq.Addresses, ref errorListRemoveKey);

            using (var conn = _sqlContext.GetOpenConnection())
            {
                string query = "SELECT error_container FROM order_batch_row WHERE id = @id";
                string errorjson = conn.QuerySingleOrDefault<string>(query, new { request.updateOrderImportRowReq.id });

                StringBuilder queryBuilder = new StringBuilder();

                var errorContainer = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, Dictionary<string, string>>>(errorjson);

                //Additional Fields
                foreach (var rowItems in request.updateOrderImportRowReq.commonFieldsAttributesReq)
                {
                    if (rowItems.FieldName.Contains("CustomerAccount"))
                    {
                        var value = rowItems.FieldData?.ToString();
                        if (!string.IsNullOrEmpty(value))
                        {
                            string accountQuery = "SELECT id FROM account WHERE account_type_id = @account_type_id AND account_name = @accountName;";
                            int id = conn.QuerySingleOrDefault<int>(accountQuery, new { accountName = value, account_type_id = (int)EnumTypes.AccountTypes.Account });
                            if (id > 0)
                            {
                                updateAttributes.Add($"{rowItems.FieldName} = '{rowItems.FieldData}'" +
                                    $", customer_account_id = {id}");
                                errorListRemoveKey.Add("CustomerAccount");
                            }
                            else
                            {
                                if (!errorContainer.ContainsKey("CustomerAccount"))
                                {
                                    errorContainer["CustomerAccount"] = new Dictionary<string, string>{
                                    { "error_type", "Error" },{ "message", "Given CustomerAccount not available" } };
                                }
                            }
                        }
                        else
                        {
                            errorContainer["CustomerAccount"] = new Dictionary<string, string>{
                            { "error_type", "warning" },{ "message", "Given CustomerAccount cannot be empty" }};
                        }
                    }

                    else if (rowItems.FieldName.Contains("CustomerContactName"))
                    {
                        var item = rowItems.FieldData?.ToString();
                        if (!string.IsNullOrEmpty(item))
                        {
                            string[] nameParts = item.Split(' ');
                            string firstName = nameParts[0];
                            string lastName = nameParts[nameParts.Length - 1];
                            string accountQuery = "SELECT id FROM contact WHERE first_name =@firstName AND last_name = @lastName;";
                            int id = conn.QuerySingleOrDefault<int>(accountQuery, new { firstName, lastName });

                            if (id > 0)
                            {
                                updateAttributes.Add($"{rowItems.FieldName} = '{rowItems.FieldData}'" +
                                    $", customer_contact_id = {id}");
                                errorListRemoveKey.Add(rowItems.FieldName);
                            }
                            else
                            {
                                if (!errorContainer.ContainsKey("CustomerContactName"))
                                {
                                    errorContainer["CustomerContactName"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "message", "Given CustomerContactName not available" } };
                                }
                            }
                        }
                        else
                        {
                            errorContainer["CustomerContactName"] = new Dictionary<string, string>{
                            { "error_type", "warning" },{ "message", "Given CustomerContactName cannot be empty" }};
                        }
                    }

                    else if (rowItems.FieldName.Contains("VIN") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        string[] vinAndVerificationStatus = rowItems.FieldData?.Split(";");
                        updateAttributes.Add($"{"VIN"} = '{vinAndVerificationStatus[0]}'");
                        if (vinAndVerificationStatus.Length > 1)
                        {
                            int is_vin_verified = vinAndVerificationStatus[1].ToString().ToLower() == "true" ? 1 : 0;
                            updateAttributes.Add($"{"is_vin_verified"} = {is_vin_verified}");
                            if (is_vin_verified == 1)
                                errorListRemoveKey.Add(rowItems.FieldName);
                            else if (!errorContainer.ContainsKey("VIN"))
                                errorContainer["VIN"] = new Dictionary<string, string>{
                             { "error_type", "Warning" },{ "message", "Given VIN cannot be verified" } };
                        }
                        //queryBuilder
                    }

                    else if (rowItems.FieldName.Contains("VehicleType") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($"{"VehicleType"} = '{rowItems.FieldData}'");
                        if (rowItems.SelectedDropDownId != null)
                        {
                            updateAttributes.Add($"{"vehicle_type_id"} = {rowItems.SelectedDropDownId}");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                        else
                        {
                            var data = await CommonMethods.VehicleTypeMapping(rowItems.FieldData);
                            if (data is long?)
                            {
                                updateAttributes.Add($"{"vehicle_type_id"} = {data}");
                                errorListRemoveKey.Add(rowItems.FieldName);
                            }
                            else
                            {
                                if (!errorContainer.ContainsKey("servicesErrors"))
                                    errorContainer["VehicleType"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "message", "Given VehicleType not mapped" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("FuelType") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($"{"FuelType"} = '{rowItems.FieldData}'");
                        if (rowItems.SelectedDropDownId != null)
                        {
                            updateAttributes.Add($"{"fuel_type_id"} = {rowItems.SelectedDropDownId}");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                        else
                        {
                            var data = await CommonMethods.VehicleFuelTypeMapping(rowItems.FieldData);
                            if (data is long?)
                            {
                                updateAttributes.Add($"{"fuel_type_id"} = {data}");
                                errorListRemoveKey.Add(rowItems.FieldName);
                            }
                            else
                            {
                                if (!errorContainer.ContainsKey("servicesErrors"))
                                    errorContainer["FuelType"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "message", "Given FuelType not mapped" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("PickupFrom") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($"{"PickupFrom"} = '{rowItems.FieldData}'");
                        if (rowItems.SelectedDropDownId != null)
                        {
                            updateAttributes.Add($"{"pickup_address_type_id"} = {rowItems.SelectedDropDownId}");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                        else
                        {
                            var data = await CommonMethods.AddressTypeMapping(rowItems.FieldData);
                            if (data is long?)
                            {
                                updateAttributes.Add($"{"pickup_address_type_id"} = {data}");
                                errorListRemoveKey.Add(rowItems.FieldName);
                            }
                            else
                            {
                                if (!errorContainer.ContainsKey("servicesErrors"))
                                    errorContainer["PickupFrom"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "message", "Given PickupFrom not mapped" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("DeliverTo") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($"{"DeliverTo"} = '{rowItems.FieldData}'");
                        if (rowItems.SelectedDropDownId != null)
                        {
                            updateAttributes.Add($"{"delivery_address_type_id"} = {rowItems.SelectedDropDownId}");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                        else
                        {
                            var data = await CommonMethods.AddressTypeMapping(rowItems.FieldData);
                            if (data is long?)
                            {
                                updateAttributes.Add($"{"delivery_address_type_id"} = {data}");
                                errorListRemoveKey.Add(rowItems.FieldName);
                            }
                            else
                            {
                                if (!errorContainer.ContainsKey("servicesErrors"))
                                    errorContainer["DeliverTo"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "message", "Given DeliverTo not mapped" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("TransportationType") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($"{"TransportationType"} = '{rowItems.FieldData}'");
                        if (rowItems.SelectedDropDownId != null)
                        {
                            updateAttributes.Add($"{"transpotation_type"} = {rowItems.SelectedDropDownId}");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                        else
                        {
                            long? data = null;
                            if (rowItems.FieldData.ToString().ToLower().Replace(" ", "").Replace("_", "") == "driveaway")
                                data = (long?)transportation_type.Driveaway;
                            else if (rowItems.FieldData.ToString().ToLower().Replace(" ", "").Replace("_", "") == "autocarrier")
                                data = (long?)transportation_type.Auto_Carrier;
                            if (data is not null)
                            {
                                updateAttributes.Add($"{"transpotation_type"} = {data}");
                                errorListRemoveKey.Add(rowItems.FieldName);
                            }
                            else
                            {
                                if (!errorContainer.ContainsKey("servicesErrors"))
                                    errorContainer["TransportationType"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "message", "Given TransportationType not mapped" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("CustomerContactPhone1Phone1Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" CustomerContactPhone1Phone1Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string CustomerContactPhone1Phone1Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] CustomerContactPhone1Phone1TypeSplit = CustomerContactPhone1Phone1Type.Split(',');
                        updateAttributes.Add($" customer_contact_phone1 = '{CustomerContactPhone1Phone1TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(CustomerContactPhone1Phone1TypeSplit[CustomerContactPhone1Phone1TypeSplit.Length - 1],
                            ref errorContainer, "CustomerContactPhone1Phone1Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" customer_contact_phone_type1 = {phoneType}");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("CustomerContactPhone1Phone1Type"))
                            {
                                errorContainer["CustomerContactPhone1Phone1Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given CustomerContactPhone1Phone1Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("CustomerContactPhone2Phone2Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" CustomerContactPhone2Phone2Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string CustomerContactPhone2Phone2Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] CustomerContactPhone2Phone2TypeSplit = CustomerContactPhone2Phone2Type.Split(',');
                        updateAttributes.Add($" customer_contact_phone2 = '{CustomerContactPhone2Phone2TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(CustomerContactPhone2Phone2TypeSplit[CustomerContactPhone2Phone2TypeSplit.Length - 1],
                            ref errorContainer, "CustomerContactPhone2Phone2Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" customer_contact_phone_type2 = {phoneType}");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("CustomerContactPhone2Phone2Type"))
                            {
                                errorContainer["CustomerContactPhone2Phone2Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given CustomerContactPhone2Phone2Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("CustomerContactPhone3Phone3Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" CustomerContactPhone3Phone3Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string CustomerContactPhone3Phone3Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] CustomerContactPhone3Phone3TypeSplit = CustomerContactPhone3Phone3Type.Split(',');
                        updateAttributes.Add($" customer_contact_phone3 = '{CustomerContactPhone3Phone3TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(CustomerContactPhone3Phone3TypeSplit[CustomerContactPhone3Phone3TypeSplit.Length - 1],
                            ref errorContainer, "CustomerContactPhone3Phone3Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" customer_contact_phone_type3 = {phoneType}");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("CustomerContactPhone3Phone3Type"))
                            {
                                errorContainer["CustomerContactPhone3Phone3Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given CustomerContactPhone3Phone3Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("PickupPhone1Phone1Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" PickupPhone1Phone1Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string PickupPhone1Phone1Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] PickupPhone1Phone1TypeSplit = PickupPhone1Phone1Type.Split(',');
                        updateAttributes.Add($" pickup_phone1 = '{PickupPhone1Phone1TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(PickupPhone1Phone1TypeSplit[PickupPhone1Phone1TypeSplit.Length - 1],
                            ref errorContainer, "PickupPhone1Phone1Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" pickup_phone_type1 = {phoneType}");
                            errorListRemoveKey.Add("PickupPhone1Phone1Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("PickupPhone1Phone1Type"))
                            {
                                errorContainer["PickupPhone1Phone1Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given PickupPhone1Phone1Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("PickupPhone2Phone2Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" PickupPhone2Phone2Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string PickupPhone2Phone2Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] PickupPhone2Phone2TypeSplit = PickupPhone2Phone2Type.Split(',');
                        updateAttributes.Add($" pickup_phone2 = '{PickupPhone2Phone2TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(PickupPhone2Phone2TypeSplit[PickupPhone2Phone2TypeSplit.Length - 1],
                            ref errorContainer, "PickupPhone2Phone2Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" pickup_phone_type2 = {phoneType}");
                            errorListRemoveKey.Add("PickupPhone2Phone2Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("PickupPhone2Phone2Type"))
                            {
                                errorContainer["PickupPhone2Phone2Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given PickupPhone2Phone2Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("PickupPhone3Phone3Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" PickupPhone3Phone3Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string PickupPhone3Phone3Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] PickupPhone3Phone3TypeSplit = PickupPhone3Phone3Type.Split(',');
                        updateAttributes.Add($" pickup_phone3 = '{PickupPhone3Phone3TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(PickupPhone3Phone3TypeSplit[PickupPhone3Phone3TypeSplit.Length - 1],
                            ref errorContainer, "PickupPhone3Phone3Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" pickup_phone_type3 = {phoneType}");
                            errorListRemoveKey.Add("PickupPhone3Phone3Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("PickupPhone3Phone3Type"))
                            {
                                errorContainer["PickupPhone3Phone3Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given PickupPhone3Phone3Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("PickupPhone4Phone4Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" PickupPhone4Phone4Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string PickupPhone4Phone4Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] PickupPhone4Phone4TypeSplit = PickupPhone4Phone4Type.Split(',');
                        updateAttributes.Add($" pickup_phone4 = '{PickupPhone4Phone4TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(PickupPhone4Phone4TypeSplit[PickupPhone4Phone4TypeSplit.Length - 1],
                            ref errorContainer, "PickupPhone4Phone4Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" pickup_phone_type4 = {phoneType}");
                            errorListRemoveKey.Add("PickupPhone4Phone4Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("PickupPhone4Phone4Type"))
                            {
                                errorContainer["PickupPhone4Phone4Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given PickupPhone4Phone4Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("PickupAlternateContactPhone1Phone1Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" PickupAlternateContactPhone1Phone1Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string PickupAlternateContactPhone1Phone1Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] PickupAlternateContactPhone1Phone1TypeSplit = PickupAlternateContactPhone1Phone1Type.Split(',');
                        updateAttributes.Add($" pickup_alternate_phone1 = '{PickupAlternateContactPhone1Phone1TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(PickupAlternateContactPhone1Phone1TypeSplit[PickupAlternateContactPhone1Phone1TypeSplit.Length - 1],
                            ref errorContainer, "PickupAlternateContactPhone1Phone1Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" pickup_alternate_phone_type1 = {phoneType}");
                            errorListRemoveKey.Add("PickupAlternateContactPhone1Phone1Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("PickupAlternateContactPhone1Phone1Type"))
                            {
                                errorContainer["PickupAlternateContactPhone1Phone1Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given PickupAlternateContactPhone1Phone1Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("PickupAlternateContactPhone2Phone2Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" PickupAlternateContactPhone2Phone2Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string PickupAlternateContactPhone2Phone2Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] PickupAlternateContactPhone2Phone2TypeSplit = PickupAlternateContactPhone2Phone2Type.Split(',');
                        updateAttributes.Add($" pickup_alternate_phone2 = '{PickupAlternateContactPhone2Phone2TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(PickupAlternateContactPhone2Phone2TypeSplit[PickupAlternateContactPhone2Phone2TypeSplit.Length - 1],
                            ref errorContainer, "PickupAlternateContactPhone2Phone2Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" pickup_alternate_phone_type2 = {phoneType}");
                            errorListRemoveKey.Add("PickupAlternateContactPhone2Phone2Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("PickupAlternateContactPhone2Phone2Type"))
                            {
                                errorContainer["PickupAlternateContactPhone2Phone2Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given PickupAlternateContactPhone2Phone2Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("DeliveryPhone1Phone1Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" DeliveryPhone1Phone1Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string DeliveryPhone1Phone1Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] DeliveryPhone1Phone1TypeSplit = DeliveryPhone1Phone1Type.Split(',');
                        updateAttributes.Add($" delivery_phone1 = '{DeliveryPhone1Phone1TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(DeliveryPhone1Phone1TypeSplit[DeliveryPhone1Phone1TypeSplit.Length - 1],
                            ref errorContainer, "DeliveryPhone1Phone1Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" delivery_phone_type1 = {phoneType}");
                            errorListRemoveKey.Add("DeliveryPhone1Phone1Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("DeliveryPhone1Phone1Type"))
                            {
                                errorContainer["DeliveryPhone1Phone1Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given DeliveryPhone1Phone1Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("DeliveryPhone2Phone2Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" DeliveryPhone2Phone2Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string DeliveryPhone2Phone2Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] DeliveryPhone2Phone2TypeSplit = DeliveryPhone2Phone2Type.Split(',');
                        updateAttributes.Add($" delivery_phone2 = '{DeliveryPhone2Phone2TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(DeliveryPhone2Phone2TypeSplit[DeliveryPhone2Phone2TypeSplit.Length - 1],
                            ref errorContainer, "DeliveryPhone2Phone2Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" delivery_phone_type2 = {phoneType}");
                            errorListRemoveKey.Add("DeliveryPhone2Phone2Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("DeliveryPhone2Phone2Type"))
                            {
                                errorContainer["DeliveryPhone2Phone2Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given DeliveryPhone2Phone2Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("DeliveryPhone3Phone3Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" DeliveryPhone3Phone3Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string DeliveryPhone3Phone3Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] DeliveryPhone3Phone3TypeSplit = DeliveryPhone3Phone3Type.Split(',');
                        updateAttributes.Add($" delivery_phone3 = '{DeliveryPhone3Phone3TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(DeliveryPhone3Phone3TypeSplit[DeliveryPhone3Phone3TypeSplit.Length - 1],
                            ref errorContainer, "DeliveryPhone3Phone3Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" delivery_phone_type3 = {phoneType}");
                            errorListRemoveKey.Add("DeliveryPhone3Phone3Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("DeliveryPhone3Phone3Type"))
                            {
                                errorContainer["DeliveryPhone3Phone3Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given DeliveryPhone3Phone3Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("DeliveryAlternateContactPhone1Phone1Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" DeliveryAlternateContactPhone1Phone1Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string DeliveryAlternateContactPhone1Phone1Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] DeliveryAlternateContactPhone1Phone1TypeSplit = DeliveryAlternateContactPhone1Phone1Type.Split(',');
                        updateAttributes.Add($" delivery_alternate_phone1 = '{DeliveryAlternateContactPhone1Phone1TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(DeliveryAlternateContactPhone1Phone1TypeSplit[DeliveryAlternateContactPhone1Phone1TypeSplit.Length - 1],
                            ref errorContainer, "DeliveryAlternateContactPhone1Phone1Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" delivery_alternate_phone_type1 = {phoneType}");
                            errorListRemoveKey.Add("DeliveryAlternateContactPhone1Phone1Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("DeliveryAlternateContactPhone1Phone1Type"))
                            {
                                errorContainer["DeliveryAlternateContactPhone1Phone1Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given DeliveryAlternateContactPhone1Phone1Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("DeliveryAlternateContactPhone2Phone2Type") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($" DeliveryAlternateContactPhone2Phone2Type = '{rowItems.FieldData?.ToString() ?? string.Empty}'");
                        string DeliveryAlternateContactPhone2Phone2Type = rowItems.FieldData?.ToString() ?? string.Empty;
                        string[] DeliveryAlternateContactPhone2Phone2TypeSplit = DeliveryAlternateContactPhone2Phone2Type.Split(',');
                        updateAttributes.Add($" delivery_alternate_phone2 = '{DeliveryAlternateContactPhone2Phone2TypeSplit[0]}'");

                        var phoneType = CommonMethods.PhoneTypeMapping(DeliveryAlternateContactPhone2Phone2TypeSplit[DeliveryAlternateContactPhone2Phone2TypeSplit.Length - 1],
                            ref errorContainer, "DeliveryAlternateContactPhone2Phone2Type");
                        if (phoneType is long?)
                        {
                            updateAttributes.Add($" delivery_alternate_phone_type2 = {phoneType}");
                            errorListRemoveKey.Add("DeliveryAlternateContactPhone2Phone2Type");
                        }
                        else
                        {
                            if (!errorContainer.ContainsKey("DeliveryAlternateContactPhone2Phone2Type"))
                            {
                                errorContainer["DeliveryAlternateContactPhone2Phone2Type"] = new Dictionary<string, string>{
                                    { "error_type", "warning" },{ "age", "Given DeliveryAlternateContactPhone2Phone2Type not available" } };
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("Services") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        string[] serviceNameAndIds = rowItems.FieldData?.Split(";");
                        if (serviceNameAndIds.Length > 0)
                        {
                            updateAttributes.Add($"{rowItems.FieldName} = '{serviceNameAndIds[0]}'");
                            if (serviceNameAndIds.Length > 1)
                            {
                                if (serviceNameAndIds[1] != null)
                                {
                                    updateAttributes.Add($"{"service_ids"} = '{serviceNameAndIds[1]}'");
                                    errorListRemoveKey.Add(rowItems.FieldName);
                                }
                            }
                            else
                            {
                                var result = await CommonMethods.ServicesMapping(serviceNameAndIds[0]);
                                if (result.ContainsKey("servicesErrors"))
                                {
                                    errorContainer?.Remove("servicesErrors");
                                    errorContainer["Services"] = new Dictionary<string, string>{
                                            { "error_type", "Error" },{ "message", result["servicesErrors"].ToString() }};
                                }

                                if (result.ContainsKey("serviceIds"))
                                    updateAttributes.Add($"{"service_ids"} = '{result["serviceIds"].ToString()}'");
                            }
                        }
                    }

                    else if (rowItems.FieldName.Contains("PickupStorageName") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($"{"PickupStorageName"} = '{rowItems.FieldData?.ToString()}'");

                        StorageDetailsDto storageDetails = await CommonMethods.GetStorageDetails(conn, rowItems.FieldData?.ToString());
                        if (storageDetails == null)
                        {
                            if (!errorContainer.ContainsKey("PickupStorageName"))
                                errorContainer["PickupStorageName"] = new Dictionary<string, string>{
                                    { "error_type", "Error" },{ "message", "Given PickupStorageName not available" }};
                        }
                        if (storageDetails != null)
                        {
                            updateAttributes.Add($"pickup_storage_id = '{storageDetails.id}'");
                            updateAttributes.Add($"pickup_lat = '{storageDetails.latitude}'");
                            updateAttributes.Add($"pickup_log = '{storageDetails.longitude}'");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                    }

                    else if (rowItems.FieldName.Contains("DeliveryStorageName") && !string.IsNullOrEmpty(rowItems.FieldData?.ToString()))
                    {
                        updateAttributes.Add($"{"DeliveryStorageName"} = '{rowItems.FieldData?.ToString()}'");

                        StorageDetailsDto storageDetails = await CommonMethods.GetStorageDetails(conn, rowItems.FieldData?.ToString());
                        if (storageDetails == null)
                        {
                            if (!errorContainer.ContainsKey("DeliveryStorageName"))
                                errorContainer["DeliveryStorageName"] = new Dictionary<string, string>{
                                    { "error_type", "Error" },{ "message", "Given DeliveryStorageName not available" }};
                        }
                        if (storageDetails != null)
                        {
                            updateAttributes.Add($"delivery_storage_id = '{storageDetails.id}'");
                            updateAttributes.Add($"delivery_lon = '{storageDetails.latitude}'");
                            updateAttributes.Add($"delivery_lat = '{storageDetails.longitude}'");
                            updateAttributes.Add($"deliveryVerificationStatus = 1");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                    }

                    //Un-maped Field
                    else
                    {
                        var value = rowItems.FieldData?.ToString();
                        if (!string.IsNullOrEmpty(value))
                        {
                            updateAttributes.Add($"{rowItems.FieldName} = '{value}'");
                            errorListRemoveKey.Add(rowItems.FieldName);
                        }
                    }
                }

                //Remove attributes from error list
                foreach (var key in errorListRemoveKey)
                    errorContainer?.Remove(key);

                updateAttributes.Add($"error_container = @ErrorContainer");
                string ErrorContainer = JsonConvert.SerializeObject(errorContainer, Formatting.Indented);
                string values = string.Join(", ", updateAttributes);
                string query2 = $"UPDATE order_batch_row SET {values} WHERE id = @id";
                try
                {
                    var result = await conn.ExecuteAsync(query2, new { request.updateOrderImportRowReq.id, ErrorContainer },
                        commandType: CommandType.Text);
                }
                catch (Exception ex)
                {
                }
            }
            return true;
        }
    }
    public static class CommonMethods
    {
        /// <summary>
        /// Address data binding
        /// </summary>
        /// <param name="jsonObject"></param>
        /// <param name="errorListKey"></param>
        /// <returns></returns>
        public static List<string> AddressDataBinding(AddressBaseEntityReq jsonObject, ref List<string> errorListKey)
        {
            var stringQuery = new List<string>();
            if (jsonObject != null)
            {
                if (jsonObject?.PickupAddress?.PickupVerificationStatus == 1)
                    errorListKey.Add("PickupAddress");
                else if (jsonObject?.DeliveryAddress?.deliveryVerificationStatus == 1)
                    errorListKey.Add("DeliveryAddress");

                foreach (var data in jsonObject.GetType().GetProperties())
                {
                    var addressType = data.GetValue(jsonObject);
                    if (addressType == null)
                        continue;

                    var addressDetails = addressType.GetType().GetProperties();

                    foreach (var item in addressDetails)
                    {
                        var details = item.GetValue(addressType);

                        string value;

                        if (details == null)
                            value = "NULL";
                        else if (details is string stringType)
                            value = $"'{stringType.Replace("'", "''")}'";
                        else if (details is bool booltype)
                            value = booltype ? "1" : "0";
                        else
                            value = details.ToString();

                        stringQuery.Add($"{item.Name} = {value}");
                    }
                }
            }
            return stringQuery;
        }

        /// <summary>
        /// Remove attributes from json
        /// </summary>
        /// <param name="json"></param>
        /// <param name="attributesToRemove"></param>
        /// <returns></returns>
        public static string RemoveAttributesFromJson(string json, List<string> attributesToRemove)
        {
            var JsonObject = JsonNode.Parse(json) as JsonObject;

            if (JsonObject != null)
            {
                foreach (var attribute in attributesToRemove)
                    JsonObject.Remove(attribute);

                return JsonObject.ToJsonString(new JsonSerializerOptions { WriteIndented = true });
            }
            return json;
        }
        /// <summary>
        /// Phone type mapping
        /// </summary>
        /// <param name="phoneType"></param>
        /// <param name="errorContainer"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static object PhoneTypeMapping(string phoneType, ref Dictionary<string, Dictionary<string, string>> errorContainer, string fieldName)
        {
            long? phoneTypeId = null;

            if (phoneType == EnumTypes.phoneType.Mobile.ToString())
                phoneTypeId = (long)EnumTypes.phoneType.Mobile;
            else if (phoneType == EnumTypes.phoneType.Office.ToString())
                phoneTypeId = (long)EnumTypes.phoneType.Office;
            else if (phoneType == EnumTypes.phoneType.Home.ToString())
                phoneTypeId = (long)EnumTypes.phoneType.Home;
            else if (phoneType == EnumTypes.phoneType.Other.ToString())
                phoneTypeId = (long)EnumTypes.phoneType.Other;
            else if (phoneType == EnumTypes.phoneType.Phone.ToString())
                phoneTypeId = (long)EnumTypes.phoneType.Phone;
            else
            {
                errorContainer[fieldName] = new Dictionary<string, string> { { "error_type", "warning" }, { "message", $"Given {fieldName} not available" } };
                return errorContainer;
            }
            return phoneTypeId;
        }

        /// <summary>
        /// Services Mapping
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        public static Task<Dictionary<string, string>> ServicesMapping(string serviceItems)
        {
            var servicesDictionary = new Dictionary<string, int>
        {
            { "Base_Move_Auto_Carrier_IDdefaultuomid", 1 },
            { "Extra_Customer_Storage_Drop_Fee_ID", 2 },
            { "Extra_Car_Detailing_ID", 3 },
            { "Extra_Document/Item_Retention_ID", 4 },
            { "Extra_Duplicate_Title", 5 },
            { "Base_First Service_(EV)_ID", 6 },
            { "Extra_DMV_Duplicate_Registration_ID", 7 },
            { "Extra_DMV_Initial_LT_ID", 8 },
            { "Extra_DMV_Plate_Replacement_ID", 9 },
            { "Extra_DMV_Renewal_ID", 10 },
            { "Extra_DMV_State_Transfer_ID", 11 },
            { "Extra_DriverDelay_ID", 12 },
            { "Base_First_Service_ID", 13 },
            { "Extra_Import_Export_Service_Fee_ID", 14 },
            { "Extra_KeyReplacement_ID", 15 },
            { "Extra_DOT_Inspection_ID", 16 },
            { "Extra_Emission_Inspection_ID", 17 },
            { "Extra_Safety_Inspection_ID", 18 },
            { "Extra_VIN_Inspection_ID", 19 },
            { "Extra_Weight_Slip_ID", 20 },
            { "Extra_Maintentance_ID", 21 },
            { "Extra_Last_Service_ID", 22 },
            { "Extra_Inquiry_ID", 23 },
            { "Extra_Parking_or_Impound_Fees_ID", 24 },
            { "Extra_Permit_ID", 25 },
            { "Extra_Last Service_(EV)", 26 },
            { "Base_Move_Pro_Calculated_ID", 27 },
            { "Extra_Exterior_Repair_ID", 28 },
            { "Extra_OilChange_ID", 29 },
            { "Extra_Preventative_Maintenance", 30 },
            { "Extra_Repair_Recall_ID", 31 },
            { "Extra_Windshield_Repair_ID", 32 },
            { "Extra_Repossession_ID", 33 },
            { "Extra_Shipping_Fee_ID", 34 },
            { "Base_Storage_Out_ID", 35 },
            { "Extra_Temp_Tag_ID", 36 },
            { "Extra_Transit_Tag_ID", 37 },
            { "Extra_Tolls_ID", 38 },
            { "Base_Storage_Keep_ID", 39 },
            { "Base_Storage_Pickup_by_Customer", 42 },
            { "Extra_T&R_Inspection", 43 },
            { "Extra_T&R_Only", 44 },
            { "Extra_Title_Correction", 45 },
            { "Extra_Towing", 46 }
        };

            var result = new Dictionary<string, string>();
            string errorContainer = "";
            var keys = serviceItems.Split(',');
            var ids = new List<string>();
            bool hasError = false;

            foreach (var key in keys)
            {
                if (servicesDictionary.ContainsKey(key))
                    ids.Add(servicesDictionary[key].ToString());
                else
                {
                    hasError = true;
                    errorContainer += $"\n The service '{key}' is incorrect or does not exist in the mapping;";
                }
            }

            if (hasError)
                result.Add("servicesErrors", errorContainer);
            if (ids.Any())
                result.Add("serviceIds", string.Join(",", ids));

            return Task.FromResult(result);
        }

        /// <summary>
        /// Get Storage Details
        /// </summary>
        /// <param name="dbConnection"></param>
        /// <param name="storageName"></param>
        /// <returns></returns>
        public static async Task<StorageDetailsDto> GetStorageDetails(IDbConnection dbConnection, string storageName)
        {
            var query = @"SELECT id, latitude, longitude FROM location WHERE name =@storageName ";
            var storageDetails = await dbConnection.QueryFirstOrDefaultAsync<StorageDetailsDto>(query, new { storageName });
            return storageDetails;
        }

        /// <summary>
        /// Vehicle type mapping
        /// </summary>
        /// <param name="vehicleType"></param>
        /// <returns></returns>
        public static Task<long?> VehicleTypeMapping(string vehicleType)
        {
            long? vehicleTypeId = null;

            if (vehicleType == "SUV/Minivan")
                vehicleTypeId = (long)EnumTypes.VehicleType.SUVMinivan;
            else if (vehicleType == "Passenger Car")
                vehicleTypeId = (long)EnumTypes.VehicleType.PassengerCar;
            else if (vehicleType == "Truck/Van 10000 and less")
                vehicleTypeId = (long)EnumTypes.VehicleType.TruckVan10000AndLess;
            else if (vehicleType == "Truck/Van 10001 to 14000")
                vehicleTypeId = (long)EnumTypes.VehicleType.TruckVan10001To14000;
            else if (vehicleType == "Truck/Bus 14001 to 16000")
                vehicleTypeId = (long)EnumTypes.VehicleType.TruckVan14001To16000;
            else if (vehicleType == "Truck/Bus 16001 to 19500")
                vehicleTypeId = (long)EnumTypes.VehicleType.TruckVan16001To19500;
            else if (vehicleType == "Truck/Bus 19501 to 26000")
                vehicleTypeId = (long)EnumTypes.VehicleType.TruckVan19501To26000;
            else if (vehicleType == "Truck/Bus 26001 to 33000")
                vehicleTypeId = (long)EnumTypes.VehicleType.TruckBus26001To33000;
            else if (vehicleType == "Truck/Bus 33001 and More")
                vehicleTypeId = (long)EnumTypes.VehicleType.TruckBus33001AndMore;
            else if (vehicleType == "Other Vehicle-Powered")
                vehicleTypeId = (long)EnumTypes.VehicleType.OtherPowered;
            else if (vehicleType == "Other Vehicle-Unpowered")
                vehicleTypeId = (long)EnumTypes.VehicleType.OtherUnpowered;
            else
                vehicleTypeId = (long)EnumTypes.VehicleType.Unknown;

            return Task.FromResult(vehicleTypeId);
        }

        /// <summary>
        /// Vehicle fuel type mapping
        /// </summary>
        /// <param name="fuelType"></param>
        /// <returns></returns>
        public static Task<long?> VehicleFuelTypeMapping(string fuelType)
        {
            long? fuelTypeId = null;

            if (fuelType == NHTSAFuelType.Gasoline.ToString())
                fuelTypeId = (long)NHTSAFuelType.Gasoline;
            else if (fuelType == NHTSAFuelType.Electric.ToString())
                fuelTypeId = (long)NHTSAFuelType.Electric;
            else if (fuelType == NHTSAFuelType.Diesel.ToString())
                fuelTypeId = (long)NHTSAFuelType.Diesel;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.Compressed_Hydrogen))
                fuelTypeId = (long)NHTSAFuelType.Compressed_Hydrogen;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.Compressed_Natural_Gas))
                fuelTypeId = (long)NHTSAFuelType.Compressed_Natural_Gas;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.FuelCell))
                fuelTypeId = (long)NHTSAFuelType.FuelCell;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.Liquefied_Natural_Gas))
                fuelTypeId = (long)NHTSAFuelType.Liquefied_Natural_Gas;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.Liquefied_Petroleum_Gas))
                fuelTypeId = (long)NHTSAFuelType.Liquefied_Petroleum_Gas;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.Methanol))
                fuelTypeId = (long)NHTSAFuelType.Methanol;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.Natural_Gas))
                fuelTypeId = (long)NHTSAFuelType.Natural_Gas;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.Neat_Ethanol))
                fuelTypeId = (long)NHTSAFuelType.Neat_Ethanol;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.Neat_Methanol))
                fuelTypeId = (long)NHTSAFuelType.Neat_Methanol;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.Ethanol))
                fuelTypeId = (long)NHTSAFuelType.Ethanol;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.Flexible_Fuel))
                fuelTypeId = (long)NHTSAFuelType.Flexible_Fuel;
            else if (fuelType == GetEnumDescriptionMethod.GetEnumDescription(NHTSAFuelType.NotApplicable))
                fuelTypeId = (long)NHTSAFuelType.NotApplicable;
            return Task.FromResult(fuelTypeId);
        }

        /// <summary>
        /// Address Type Mapping
        /// </summary>
        /// <param name="addressType"></param>
        /// <returns></returns>
        public static Task<long?> AddressTypeMapping(string addressType)
        {
            long? addressTypeId = null;
            addressType = addressType.ToLower();
            if (addressType == address_type.Residence.ToString().ToLower())
                addressTypeId = (long)address_type.Residence;
            else if (addressType == address_type.Dealer.ToString().ToLower())
                addressTypeId = (long)address_type.Dealer;
            else if (addressType == address_type.Office.ToString().ToLower())
                addressTypeId = (long)address_type.Office;
            else if (addressType == address_type.Repair.ToString().ToLower())
                addressTypeId = (long)address_type.Repair;
            else if (addressType == address_type.Upfitter.ToString().ToLower())
                addressTypeId = (long)address_type.Upfitter;
            else if (addressType == address_type.Auction.ToString().ToLower())
                addressTypeId = (long)address_type.Auction;
            else if (addressType == address_type.Impound.ToString().ToLower())
                addressTypeId = (long)address_type.Impound;
            else if (addressType == GetEnumDescriptionMethod.GetEnumDescription(address_type.Unmanned_Location).ToLower())
                addressTypeId = (long)address_type.Unmanned_Location;
            else if (addressType == address_type.Other.ToString().ToLower())
                addressTypeId = (long)address_type.Other;
            else if (addressType == address_type.Business.ToString().ToLower())
                addressTypeId = (long)address_type.Business;
            else if (addressType == GetEnumDescriptionMethod.GetEnumDescription(address_type.PARS_Storage).ToLower())
                addressTypeId = (long)address_type.PARS_Storage;
            else if (addressType == GetEnumDescriptionMethod.GetEnumDescription(address_type.Other_Storage).ToLower())
                addressTypeId = (long)address_type.Other_Storage;
            return Task.FromResult(addressTypeId);
        }
    }
    public class StorageDetailsDto
    {
        public long id { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
    }
}
