﻿
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace PARSNextGen.Application.OrderBatchImport
{
    /// <summary>
    /// Common methods for bulk import operations
    /// </summary>
    public class CommonMethodsForBatchImport
    {
        public readonly IConfiguration _config;
        public readonly BlobContainerClient _storageContainer;
        public CommonMethodsForBatchImport(IConfiguration config)
        {
            _config = config;
            _storageContainer = new BlobServiceClient(_config["AzureStorage:AzureStorageConn"])
                .GetBlobContainerClient(_config["AzureStorage:ContainerName"]);
        }

        /// <summary>
        /// Save File To Azure Blob Storage
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public List<string> SaveFileToAzureStorage(IFormFileCollection files)
        {
            List<string> result = new();
            foreach (IFormFile fileItem in files)
            {
                using (var uploadFileStream = fileItem.OpenReadStream())
                {
                    var fileExtension = Path.GetExtension(fileItem.FileName).ToLower();
                    if (fileExtension == ".xlsx" || fileExtension == ".xls" || fileExtension == ".sheet" || fileExtension == ".csv")
                    {
                        string fileName = Guid.NewGuid() + fileExtension;
                        var data = _storageContainer.GetBlobClient(Path.GetFileName(fileName))
                            .Upload(uploadFileStream, overwrite: true);
                        result.Add(fileName + ";" + fileItem.FileName);
                    }
                    else
                        throw new Exception("PARS_INVALID_FILE_TYPE");
                }
            }
            return result;
        }

        /// <summary>
        /// Delete File from Azure Blob Storage
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public bool DeleteFileFromAzureStorage(List<string> filesName)
        {
            bool result = false;
            foreach (var fileItem in filesName)
            {
                result = _storageContainer.GetBlobClient(fileItem).DeleteIfExists();
            }
            return result;
        }

        /// <summary>
        /// Get base64 string file from azure storage
        /// </summary>
        /// <param name="filesName"></param>
        /// <returns></returns>
        public async Task<string> GetBase64FilesFromAzureStorage(string fileName)
        {
            string base64String = string.Empty;
            var blobClient = _storageContainer.GetBlobClient(fileName);
            if (blobClient.Exists())
            {
                using (var memoryStream = new MemoryStream())
                {
                   await blobClient.DownloadToAsync(memoryStream);
                    byte[] fileBytes = memoryStream.ToArray();
                    base64String = Convert.ToBase64String(fileBytes);
                }
            }
            else
                return string.Empty;
            return base64String;
        }
    }
}
