﻿using System;
using System.Collections.Generic;

namespace PARSNextGen.Application.OrderBatchImport
{
    public class OrderBatchRowData
    {
        public int AllRows { get; set; }
        public int SuccessRows { get; set; }
        public int ProcessingRows { get; set; }
        public int PendingRows { get; set; }
        public int PartiallyCompletedRows { get; set; }
        public int FailedRows { get; set; }        
        public List<OderBatchRowListDto> OrderBatchRowList { get; set; }
    }
    public class OderBatchRowListDto
    {
        public long Id { get; set; }
        public string ServiceRequestNumber { get; set; }
        public string RequestType { get; set; }
        public string VIN { get; set; }
        public bool? IsVINVerified { get; set; }
        public DateTime SubmittedDate { get; set; }
        public string PickupAddressType { get; set; }
        //public bool? IsPickUpAddressVerified { get; set; }
        public string PickupAddressVerificationStatus { get; set; }
        public string DeliveryAddressType { get; set; }
        //public bool? IsDeliveryAddressVerified { get; set; }        
        public string DeliveryAddressVerificationStatus { get; set; }        
        public bool? IsAmountCalculated { get; set; }        
        public string Status { get; set; }        
    }
}
