﻿using Dapper;
using MassTransit;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.SQL;
using PARSNextGen.Contracts;
using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.OrderBatchImport
{
    public class ReProcessOrderBatchRowCommand : IRequest<bool>
    {
        public long id { get; set; }
    }
    public class ReProcessOrderBatchRowCommandHandler : IRequestHandler<ReProcessOrderBatchRowCommand, bool>
    {
        private readonly ISqlContext _sqlContext;
        private readonly IBus _bus;
        private readonly IConfiguration _config;
        public ReProcessOrderBatchRowCommandHandler(ISqlContext sqlContext, IBus bus, IConfiguration config)
        {
            _sqlContext = sqlContext;
            _bus = bus;
            _config = config;
        }
        public async Task<bool> Handle(ReProcessOrderBatchRowCommand request, CancellationToken cancellationToken)
        {
            bool data = false;
            using (var conn = _sqlContext.GetOpenConnection())
            {
                DynamicParameters dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@batch_id", request.id);
                conn.Execute("sp_delete_batch_imported_data", dynamicParameters, commandType: CommandType.StoredProcedure);
                var sendEndpoint = await _bus.GetSendEndpoint(new Uri($"{_config["AzureBusSettings:batchImportQueueURL"]}"));
                await sendEndpoint.Send(new MessageBase { RecordId = request.id });
                data = true;
            }
            return data;
        }
    }
}