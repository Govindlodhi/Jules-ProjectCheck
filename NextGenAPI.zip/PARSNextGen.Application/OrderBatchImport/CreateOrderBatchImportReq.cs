﻿using Microsoft.AspNetCore.Http;

namespace PARSNextGen.Application.OrderBatchImport
{
    public class CreateOrderBatchImportReq
    {
        public long import_type_id { get; set; }
        public long requested_by_id { get; set; }
        public long? fmc_id { get; set; }
        public long? account_id { get; set; }
        public long? contact_id { get; set; }
        public string email { get; set; }
        public long? cs_specialist_id { get; set; }
        public IFormFileCollection file { get; set; }

        //public long? project_id { get; set; }
        //public string import_name { get; set; }        
        //public string fleet_number { get; set; }
        //public string unit_no { get; set; }
        //public long? price_list_id { get; set; }
        //public long? default_bill_to_id { get; set; }
        //public string ns_cust_id { get; set; }
        //public string processing { get; set; }
        //public int? batchrows_processed_count { get; set; }
    }
}
