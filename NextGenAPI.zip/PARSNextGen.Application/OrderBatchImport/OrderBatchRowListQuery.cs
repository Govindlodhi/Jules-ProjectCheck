﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.VINValidation.Queries;
using PARSNextGen.Domain.Common;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.OrderBatchImport
{
    public class OrderBatchRowListQuery : IRequest<OrderBatchRowData>
    {
        public long batchId { get; set; }
        public long? filterId { get; set; }
    }
    public class OrderBatchRowListQueryHandler : IRequestHandler<OrderBatchRowListQuery, OrderBatchRowData>
    {
        private readonly ISqlContext _dbContext;
        public OrderBatchRowListQueryHandler(ISqlContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<OrderBatchRowData> Handle(OrderBatchRowListQuery req, CancellationToken cancellationToken)
        {
            OrderBatchRowData orderBatchRowData = new();
            string filter = "";
            if (req.filterId != null)
            {
                if (req.filterId == (long)EnumTypes.OrderBatchRowStatus.Pending)
                    filter = $"AND status = '{EnumTypes.OrderBatchRowStatus.Pending}'";
                else if (req.filterId == (long)EnumTypes.OrderBatchRowStatus.Success)
                    filter = $"AND status = '{EnumTypes.OrderBatchRowStatus.Success}'";
                else if (req.filterId == (long)EnumTypes.OrderBatchRowStatus.PartiallyCompleted)
                    filter = $"AND status = '{GetEnumDescriptionMethod.GetEnumDescription(EnumTypes.OrderBatchRowStatus.PartiallyCompleted)}'";
                else if (req.filterId == (long)EnumTypes.OrderBatchRowStatus.Failed)
                    filter = $"AND status = '{EnumTypes.OrderBatchRowStatus.Failed}'";
                else if (req.filterId == (long)EnumTypes.OrderBatchRowStatus.Processing)
                    filter = $"AND status = '{EnumTypes.OrderBatchRowStatus.Processing}'";
            }
            using (var con = _dbContext.GetOpenConnection())
            {
                var commonQuery = @"WITH OrderBatchRow AS (
                                SELECT obr.id Id,batch_id, sr.service_request_number ServiceRequestNumber,                                
                                obr.VIN, obi.created_on SubmittedDate,
                                pat.name PickupAddressType , dat.name DeliveryAddressType,
                                CASE 
                                    WHEN obi.import_type_id = 2 THEN 'Service Request'
                                    WHEN obi.import_type_id = 1 THEN 'Quote Request'
                                    ELSE 'Unknown Request'	
                                    END AS RequestType,
                                CASE
                                    WHEN obr.status = 'Processing' THEN 'Processing'
                                    WHEN obr.status = 'Failed' THEN 'Failed'
                                    WHEN obr.status = 'Pending' THEN 'Pending'
                                    WHEN is_amount_calculated = 1 AND sr.service_request_number IS NOT NULL THEN 'Success'
                                    WHEN is_vin_verified = 1 AND is_pickup_address_verified = 1 AND is_delivery_address_verified = 1 AND is_amount_calculated = 1 THEN 'Success'
                                    WHEN is_vin_verified = 0 AND is_pickup_address_verified = 0 AND is_delivery_address_verified = 0 AND is_amount_calculated = 0 THEN 'Failed'
                                    WHEN is_vin_verified IS NULL AND is_pickup_address_verified IS NULL AND is_delivery_address_verified IS NULL AND is_amount_calculated IS NULL THEN 'Pending'
                                    ELSE 'Partially Completed'
                                    END AS status,                                
                                CASE 
                                    WHEN PickupVerificationStatus = 1 THEN 'Verified'
                                    WHEN PickupVerificationStatus = 2 THEN 'Partially Verified'
                                    ELSE 'Not Verified'
                                    END AS PickupAddressVerificationStatus,
                                CASE 
                                    WHEN deliveryVerificationStatus = 1 THEN 'Verified'
                                    WHEN deliveryVerificationStatus = 2 THEN 'Partially Verified'
                                    ELSE 'Not Verified'
                                    END AS DeliveryAddressVerificationStatus,
                                is_vin_verified IsVINVerified, is_pickup_address_verified IsPickUpAddressVerified,
                                is_delivery_address_verified IsDeliveryAddressVerified, is_amount_calculated IsAmountCalculated
                                FROM order_batch_row obr 
                                LEFT JOIN service_request sr ON sr.order_batch_row_id = obr.id
                                INNER JOIN order_batch_import obi ON obi.id = obr.batch_id
                                LEFT JOIN address_type pat ON pat.id = obr.pickup_address_type_id
                                LEFT JOIN address_type dat ON dat.id = obr.delivery_address_type_id )";
                string batchRowQuery = @"SELECT* FROM OrderBatchRow WHERE batch_id = @batchId " + filter;
                string countQuery = @"SELECT 
                                        COUNT(*) AS AllRows,
                                        SUM(CASE WHEN status = 'Success' THEN 1 ELSE 0 END) AS SuccessRows,
                                        SUM(CASE WHEN status = 'Processing' THEN 1 ELSE 0 END) AS ProcessingRows,
                                        SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS PendingRows,
                                        SUM(CASE WHEN status = 'Partially Completed' THEN 1 ELSE 0 END) AS PartiallyCompletedRows,
                                        SUM(CASE WHEN status = 'Failed' THEN 1 ELSE 0 END) AS FailedRows
                                        FROM OrderBatchRow  WHERE batch_id = @batchId ;";

                orderBatchRowData = await con.QueryFirstOrDefaultAsync<OrderBatchRowData>(commonQuery + countQuery, new { req.batchId }, commandType: CommandType.Text);
                orderBatchRowData.OrderBatchRowList = (List<OderBatchRowListDto>)await con.QueryAsyncWithRetry<OderBatchRowListDto>(commonQuery + batchRowQuery, new { req.batchId }, commandType: CommandType.Text);
            }
            return orderBatchRowData;
        }
    }
}
