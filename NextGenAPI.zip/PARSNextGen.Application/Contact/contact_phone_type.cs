﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Contact
{
    public class contact_phone_type
    {
        public string country_code { get; set; }
        public long? phone_type_id { get; set; }
        public string phone_type_name { get; set; }
        public string phone_number { get; set; }
        public string extension { get; set; }
    }
}
