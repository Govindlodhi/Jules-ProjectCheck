﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.User.Users.Queries.UserById;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Contact.CheckDuplicateContact
{
    public class CheckDuplicateContactQuery :IRequest<bool>
    {
        public string email { get; set; }
        //public long accountId { get; set; }
    }
    public class CheckDuplicateContactQueryHandler : IRequestHandler<CheckDuplicateContactQuery, bool>
    {
        private readonly ISqlContext _dbCntx;

        public CheckDuplicateContactQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<bool> Handle(CheckDuplicateContactQuery request, CancellationToken cancellationToken)
        {
            try
            {
                using (var connection = _dbCntx.GetOpenConnection())
                {
                    DynamicParameters dp = new DynamicParameters();
                    dp.Add("@email", request.email);
                    dp.Add("@contact_type_id", (long)EnumTypes.contact_type.User);
                    string query = @"select * from contact where primary_email = @email and contact_type_id = @contact_type_id ";
                    int contactExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                    var queryUser = @"select * from user_auth where user_name = @email ";
                    int userExists = await connection.ExecuteScalarAsync<int>(queryUser, dp, commandType: CommandType.Text);

                    if (contactExists == 0 || userExists==0)
                        return false;
                    else
                        return true;
                }
            }
            catch(Exception ex)
            {
                return false;
            }
            
        }
    }
}
