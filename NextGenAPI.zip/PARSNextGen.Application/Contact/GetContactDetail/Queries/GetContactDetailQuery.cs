﻿using Dapper;
using FluentValidation;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Contact.GetContactDetail.Queries
{
    public class GetContactDetailQuery : IRequest<ContactDetailDto>
    {
        public long id { get; set; }
    }
    public class GetContactDetailQueryHandler : IRequestHandler<GetContactDetailQuery, ContactDetailDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetContactDetailQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<ContactDetailDto> Handle(GetContactDetailQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            ContactDetailDto contactDetailDto = new ContactDetailDto();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"SELECT " +
                                   "contact.user_id " +
                                   ",contact.id " +
                                   ",contact.full_name " +
                                   ",contact.first_name " +
                                   ",contact.middle_name " +
                                   ",contact.last_name " +
                                   ",contact.primary_email " +
                                   ",contact.secondary_email " +
                                   ",contact.contact_type_id " +
                                   ",contact.contact_type_name " +
                                   ",contact.account_id " +
                                   ",contact.account_name  " +
                                   ",contact.is_primary " +
                                   ",contact.country_code_1 " +
                                   ",contact.country_code_2 " +
                                   ",contact.country_code_3 " +
                                   ",contact.country_code_4 " +
                                   ",contact.phone_1 " +
                                   ",contact.phone_2 " +
                                   ",contact.phone_3 " +
                                   ",contact.phone_4 " +
                                   ",contact.phone_type_1 " +
                                   ",contact.phone_type_1_name " +
                                   ",contact.phone_type_2 " +
                                   ",contact.phone_type_2_name " +
                                   ",contact.phone_type_3 " +
                                   ",contact.phone_type_3_name " +
                                   ",contact.phone_type_4 " +
                                   ",contact.phone_type_4_name " +
                                   ",contact.address_type_id " +
                                   ",contact.address_type_name " +
                                   ",contact.address_line_1 " +
                                   ",contact.address_line_2 " +
                                   ",contact.address_line_3 " +
                                   ",contact.county " +
                                   ",contact.city " +
                                   ",contact.state_id " +
                                   ",contact.state_name " +
                                   ",contact.country_id " +
                                   ",contact.country_name " +
                                   ",contact.zip_code  " +
                                   ",contact.time_zone_id  " +
                                   ",contact.time_zone  " +
                                   ",contact.field_office_id  " +
                                   ",contact.field_office_name  " +
                                   ",contact.description  " +
                                   ",contact.extension  " +
                                   ",contact.company_works_for  " +
                                   ",contact.user_image  " +
                                   ",contact.crm_id " +
                                   ",contact.status " +
                                   ",contact.updated_on " +
                                   ",contact.created_on " +
                                   ",contact.updated_by " +
                                   ",contact.created_by " +
                                   ",contact.created_by_name " +
                                   ",storage_id " +
                                   ",storage_name " +
                                   ",location_name " +
                                   "FROM vm_contactdetail contact WHERE contact.id=@contactId";
                dp.Add("@contactId", request.id);

                contactDetailDto = (ContactDetailDto)await connection.QueryFirstOrDefaultAsyncWithRetry<ContactDetailDto>(querycolumns, dp, commandType: CommandType.Text);

                contactDetailDto.contact_phone_types = new List<contact_phone_type>();

                #region  contact List


                //contact 1
                if (!string.IsNullOrEmpty(contactDetailDto.country_code_1) && !string.IsNullOrEmpty(contactDetailDto.phone_1))
                {
                    contact_phone_type contactPhoneType1 = new contact_phone_type();
                    contactPhoneType1.country_code = contactDetailDto.country_code_1;
                    contactPhoneType1.phone_number = contactDetailDto.phone_1;
                    contactPhoneType1.phone_type_id = contactDetailDto.phone_type_1;
                    contactPhoneType1.extension = contactDetailDto.extension;
                    contactDetailDto.contact_phone_types.Add(contactPhoneType1);
                }
                //contact 2
                if (!string.IsNullOrEmpty(contactDetailDto.country_code_2) && !string.IsNullOrEmpty(contactDetailDto.phone_2))
                {
                    contact_phone_type contactPhoneType2 = new contact_phone_type();
                    contactPhoneType2.country_code = contactDetailDto.country_code_2;
                    contactPhoneType2.phone_number = contactDetailDto.phone_2;
                    contactPhoneType2.phone_type_id = contactDetailDto.phone_type_2;
                    contactPhoneType2.extension = contactDetailDto.extension;
                    contactDetailDto.contact_phone_types.Add(contactPhoneType2);
                }
                //contact 3
                if (!string.IsNullOrEmpty(contactDetailDto.country_code_3) && !string.IsNullOrEmpty(contactDetailDto.phone_3))
                {
                    contact_phone_type contactPhoneType3 = new contact_phone_type();
                    contactPhoneType3.country_code = contactDetailDto.country_code_3;
                    contactPhoneType3.phone_number = contactDetailDto.phone_3;
                    contactPhoneType3.phone_type_id = contactDetailDto.phone_type_3;
                    contactPhoneType3.extension = contactDetailDto.extension;
                    contactDetailDto.contact_phone_types.Add(contactPhoneType3);
                }
                //contact 4
                if (!string.IsNullOrEmpty(contactDetailDto.country_code_4) && !string.IsNullOrEmpty(contactDetailDto.phone_4))
                {
                    contact_phone_type contactPhoneType4 = new contact_phone_type();
                    contactPhoneType4.country_code = contactDetailDto.country_code_4;
                    contactPhoneType4.phone_number = contactDetailDto.phone_4;
                    contactPhoneType4.phone_type_id = contactDetailDto.phone_type_4;
                    contactPhoneType4.extension = contactDetailDto.extension;
                    contactDetailDto.contact_phone_types.Add(contactPhoneType4);
                }
                #endregion


            }
            return contactDetailDto;
        }


        public class GetContactDetailQueryValidator : AbstractValidator<GetContactDetailQuery>
        {
            public GetContactDetailQueryValidator()
            {
                RuleFor(x => x.id).NotEmpty();
            }
        }
    }
}
