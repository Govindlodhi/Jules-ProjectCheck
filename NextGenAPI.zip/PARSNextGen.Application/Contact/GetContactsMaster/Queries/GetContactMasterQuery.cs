﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Contact.GetContactsMaster.Queries
{
    public class GetContactMasterQuery : IRequest<ContactMasterDto>
    {

    }

    public class GetContactsMasterQueryHandler : IRequestHandler<GetContactMasterQuery, ContactMasterDto>
    {
        private readonly ISqlContext _dbCntx;
        public GetContactsMasterQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }

        public async Task<ContactMasterDto> Handle(GetContactMasterQuery request, CancellationToken cancellationToken)
        {
            ContactMasterDto contactRelatedMasterdata = new ContactMasterDto();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string queryContacttype = @"select id,name  from contact_type where is_active = 1;";
                string queryCountryName = @"select id,name  from country where is_active = 1;";
                string queryStateName = @"select id,name  from state where is_active = 1;";
                string queryphoneType = @"select id,name  from phone_type where is_active = 1 order by name;"; 
                string querycontactAddressType = @"select id,name  from contact_address_type where is_active = 1 order by name;"; 
                
                string multiSQLQry = queryContacttype + queryCountryName + queryStateName+ queryphoneType + querycontactAddressType;

                using (var multiResultSet = await connection.QueryMultipleAsync(multiSQLQry))
                {
                    contactRelatedMasterdata.contact_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    contactRelatedMasterdata.country_name = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    contactRelatedMasterdata.state_name = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    contactRelatedMasterdata.phone_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    contactRelatedMasterdata.contact_address_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();


                }
            }
            return contactRelatedMasterdata;
        }

    }

}
