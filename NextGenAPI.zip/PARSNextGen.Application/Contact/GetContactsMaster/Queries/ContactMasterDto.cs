﻿using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Contact.GetContactsMaster.Queries
{
    public class ContactMasterDto
    {
        public List<EntityReference> contact_type { get; set; }
        public List<EntityReference> state_name { get; set; }
        public List<EntityReference> country_name { get; set; }
        public List<EntityReference> phone_type { get; set; }
        public List<EntityReference> contact_address_type { get; set; }

    }
}
