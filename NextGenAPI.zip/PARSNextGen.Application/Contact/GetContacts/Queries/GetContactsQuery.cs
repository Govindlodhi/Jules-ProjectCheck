﻿using System.Data;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using Dapper;
using PARSNextGen.Application.Service;
using FluentValidation;
using PARSNextGen.Domain.Common;
using Microsoft.Extensions.Configuration;
using System;

namespace PARSNextGen.Application.Contact.GetContacts.Queries
{

    public class GetContactsQuery : IRequest<List<ContactsDto>>
    {
        public long account_id;

    }

    public class GetContactsQueryHandler : IRequestHandler<GetContactsQuery, List<ContactsDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;


        public GetContactsQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;

        }

        public async Task<List<ContactsDto>> Handle(GetContactsQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            List<ContactsDto> contactsList = new List<ContactsDto>();
            dp.Add("@accountId", request.account_id);
            dp.Add("@contact_type_Id", (long)EnumTypes.contact_type.Contact);

            using (var connection = _dbCntx.GetOpenConnection())
            {

                var querycolumns = @"SELECT " +
                                   "contact.user_id " +
                                   ",contact.id " +
                                   ",contact.full_name " +
                                   ",contact.first_name " +
                                   ",contact.middle_name " +
                                   ",contact.last_name " +
                                   ",contact.primary_email " +
                                   ",contact.secondary_email " +
                                   ",contact.contact_type_id " +
                                   ",contact.contact_type_name " +
                                   ",contact.account_id " +
                                   ",contact.account_name  " +
                                   ",contact.is_primary " +
                                   ",contact.country_code_1 " +
                                   ",contact.country_code_2 " +
                                   ",contact.country_code_3 " +
                                   ",contact.country_code_4 " +
                                   ",contact.phone_1 " +
                                   ",contact.phone_2 " +
                                   ",contact.phone_3 " +
                                   ",contact.phone_4 " +
                                   ",contact.phone_type_1 " +
                                   ",contact.phone_type_1_name " +
                                   ",contact.phone_type_2 " +
                                   ",contact.phone_type_2_name " +
                                   ",contact.phone_type_3 " +
                                   ",contact.phone_type_3_name " +
                                   ",contact.phone_type_4 " +
                                   ",contact.phone_type_4_name " +
                                   ",contact.address_type_id " +
                                   ",contact.address_line_1 " +
                                   ",contact.address_line_2 " +
                                   ",contact.address_line_3 " +
                                   ",contact.county " +
                                   ",contact.city " +
                                   ",contact.state_id " +
                                   ",contact.state_name " +
                                   ",contact.country_id " +
                                   ",contact.country_name " +
                                   ",contact.zip_code  " +
                                   ",contact.field_office_id  " +
                                   ",contact.field_office_name  " +
                                   ",contact.description  " +
                                   ",contact.extension  " +
                                   ",contact.company_works_for  " +
                                   ",contact.user_image  " +
                                   ",contact.crm_id " +
                                   ",contact.status " +
                                   ",contact.updated_on " +
                                   ",contact.created_on " +
                                   ",contact.updated_by " +
                                   ",contact.created_by " +
                                   ",contact.created_by_name " +
                                   "FROM vm_contactdetail contact " +
                                   "inner join account lnkAccount on contact.account_id=lnkAccount.id " +
                                   " WHERE ( contact.account_id=@accountId or lnkAccount.linked_account_id=@accountId ) and contact.contact_type_id = @contact_type_Id " +
                                   " order by contact.created_on desc ";

                contactsList = (List<ContactsDto>)await connection.QueryAsyncWithRetry<ContactsDto>(querycolumns, dp, commandType: CommandType.Text);
            }
            return contactsList;
        }
    }


    public class GetContactsQueryValidator : AbstractValidator<GetContactsQuery>
    {
        public GetContactsQueryValidator()
        {
            RuleFor(x => x.account_id).NotEmpty();
        }
    }

}
