﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Contact.GetContacts.Command
{
    public class UpdateContactStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool status { get; set; }
    }
    public class UpdateContactStatusCommandHandler : IRequestHandler<UpdateContactStatusCommand, bool>
    {
        private readonly IContactRepository _contactRepository;

        public UpdateContactStatusCommandHandler(IContactRepository contactRepository)
        {
            _contactRepository = contactRepository;
        }
        public async Task<bool> Handle(UpdateContactStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _contactRepository.UpdateContactStatus(request.id, request.status);
            return result;
        }
    }
}
