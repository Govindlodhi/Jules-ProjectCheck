﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Contact.GetContacts.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.User.Users.Queries.AllUsers;
using PARSNextGen.Application.User.Users.Queries.UserById;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.Vehicle.VehicleAttributeConfiguration.Queries;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Contact.GetContacts.Command
{
    public class CreateContactCommand : IRequest<long>
    {
        public CreateContactReq createContactReq { get; set; }
    }
    public class CreateContactCommandHandler : IRequestHandler<CreateContactCommand, long>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IContactRepository _contactRepo;
        private readonly ICurrentUserService _currentUserService;

        public CreateContactCommandHandler(IContactRepository contactRepo, ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _contactRepo = contactRepo;
            _currentUserService = currentUserService;
        }

        public async Task<long> Handle(CreateContactCommand request, CancellationToken cancellationToken)
        {
            long contactId = 0;
            ContactsDto contactsDto = new ContactsDto();
            UserByIdDto userByIdDto = new UserByIdDto();
            DynamicParameters dp = new DynamicParameters();
            dp.Add("@email", request.createContactReq.primary_email.Trim());
            dp.Add("@account_id", request.createContactReq.account_id);
            // Check if record is already exist or not by email and accountId

            using (var connection = _dbCntx.GetOpenConnection())
            {
                var queryContact = @"select * from contact where primary_email = @email and account_id = @account_id ";
                contactsDto = await connection.QueryFirstOrDefaultAsyncWithRetry<ContactsDto>(queryContact, dp, commandType: CommandType.Text);

                var queryUser = @"select * from user_auth where user_name = @email ";
                userByIdDto = await connection.QueryFirstOrDefaultAsyncWithRetry<UserByIdDto>(queryUser, dp, commandType: CommandType.Text);
            }

            if (contactsDto != null && userByIdDto != null)
                return contactId;
            else
            {
                Contacts contact = new Contacts();

                #region CONTACT FIELDS

                contact.first_name = request.createContactReq.first_name;
                contact.last_name = request.createContactReq.last_name;
                contact.middle_name = request.createContactReq.middle_name;
                contact.account_id = request.createContactReq.account_id;


                #region map list phone of location1_contact 
                for (int i = 0; i < request.createContactReq.contact_phone_types.Count; i++)
                {
                    if (i == 0)
                    {
                        contact.contact_country_code_1 = request.createContactReq.contact_phone_types.ElementAt(i).country_code;
                        contact.contact_phone_type_1 = request.createContactReq.contact_phone_types.ElementAt(i).phone_type_id;
                        contact.contact_phone_1 = request.createContactReq.contact_phone_types.ElementAt(i).phone_number;
                        contact.extension = request.createContactReq.contact_phone_types.ElementAt(i).extension;

                    }
                    else if (i == 1)
                    {
                        contact.contact_country_code_2 = request.createContactReq.contact_phone_types.ElementAt(i).country_code;
                        contact.contact_phone_type_2 = request.createContactReq.contact_phone_types.ElementAt(i).phone_type_id;
                        contact.contact_phone_2 = request.createContactReq.contact_phone_types.ElementAt(i).phone_number;
                        contact.extension = request.createContactReq.contact_phone_types.ElementAt(i).extension;

                    }
                    else if (i == 2)
                    {
                        contact.contact_country_code_3 = request.createContactReq.contact_phone_types.ElementAt(i).country_code;
                        contact.contact_phone_type_3 = request.createContactReq.contact_phone_types.ElementAt(i).phone_type_id;
                        contact.contact_phone_3 = request.createContactReq.contact_phone_types.ElementAt(i).phone_number;
                        contact.extension = request.createContactReq.contact_phone_types.ElementAt(i).extension;

                    }
                    else if (i == 3)
                    {
                        contact.contact_country_code_4 = request.createContactReq.contact_phone_types.ElementAt(i).country_code;
                        contact.contact_phone_type_4 = request.createContactReq.contact_phone_types.ElementAt(i).phone_type_id;
                        contact.contact_phone_4 = request.createContactReq.contact_phone_types.ElementAt(i).phone_number;
                        contact.extension = request.createContactReq.contact_phone_types.ElementAt(i).extension;

                    }

                }
                #endregion


                contact.primary_email = request.createContactReq.primary_email.Trim();
                contact.user_image = request.createContactReq.user_image;
                contact.contact_type_id = (long)EnumTypes.contact_type.Contact;
                contact.secondary_email = request.createContactReq.secondary_email;
                contact.description = request.createContactReq.description;

                contact.is_primary = request.createContactReq.is_primary;
                contact.company_works_for = request.createContactReq.company_works_for;
                contact.address_line_1 = request.createContactReq.address_line_1;
                contact.address_line_2 = request.createContactReq.address_line_2;
                contact.address_line_3 = request.createContactReq.address_line_3;
                contact.address_type_id = request.createContactReq.address_type_id;
                contact.county = request.createContactReq.county;
                contact.city = request.createContactReq.city;
                contact.state_id = request.createContactReq.state_id;
                contact.zip_code = request.createContactReq.zip_code;
                contact.country_id = request.createContactReq.country_id;
                contact.time_zone_id = request.createContactReq.time_zone_id;
                contact.storage_id = request.createContactReq.storage_id;

                #endregion
                contactId = await _contactRepo.CreateContact(contact);
                return contactId;
            }

        }

    }
}
