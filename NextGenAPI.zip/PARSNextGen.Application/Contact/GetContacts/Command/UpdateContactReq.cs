﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Contact.GetContacts.Command
{
    public class UpdateContactReq
    {
        public long id { get; set; }
        public string first_name { get; set; }
        public string middle_name { get; set; }
        public string last_name { get; set; }
        public string primary_email { get; set; }
        public string user_image { get; set; }

        public List<contact_phone_type> contact_phone_types { get; set; }

        public string contact_country_code_1 { get; set; }
        public string contact_country_code_2 { get; set; }
        public string contact_country_code_3 { get; set; }
        public string contact_country_code_4 { get; set; }

        public string contact_phone_1 { get; set; }
        public string contact_phone_2 { get; set; }
        public string contact_phone_3 { get; set; }
        public string contact_phone_4 { get; set; }

        public long? contact_phone_type_1 { get; set; }
        public long? contact_phone_type_2 { get; set; }
        public long? contact_phone_type_3 { get; set; }
        public long? contact_phone_type_4 { get; set; }

        // public long contact_type_id { get; set; }
        public long account_id { get; set; }
        public bool is_primary { get; set; }
        //public bool status { get; set; }
        //public DateTime? updated_on { get; set; }
        //public DateTime? created_on { get; set; }
        //public string crm_id { get; set; }
        public string company_works_for { get; set; }
        public string address_line_1 { get; set; }
        public string address_line_2 { get; set; }
        public string address_line_3 { get; set; }
        public string county { get; set; }
        public long address_type_id { get; set; }
        public string city { get; set; }
        public long? state_id { get; set; }
        public string zip_code { get; set; }
        public long? country_id { get; set; }
        public long? time_zone_id { get; set; }
        public string secondary_email { get; set; }
        //public long? field_office_id { get; set; }
        public long? storage_id { get; set; }
        public string description { get; set; }
        public string extension { get; set; }
    }
}
