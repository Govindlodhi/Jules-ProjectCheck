﻿using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Contact.GetContacts.Command
{
    public class UpdateContactCommand : IRequest<bool>
    {
        public UpdateContactReq updateContactReq { get; set; }
    }
    public class UpdateContactCommandHandler : IRequestHandler<UpdateContactCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IContactRepository _contactRepo;
        private readonly ICurrentUserService _currentUserService;

        public UpdateContactCommandHandler(ISqlContext dbCntx, IContactRepository contactRepo, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _contactRepo = contactRepo;
            _currentUserService = currentUserService;
        }
        public async Task<bool> Handle(UpdateContactCommand request, CancellationToken cancellationToken)
        {
            Contacts contact = new Contacts();

            #region CONTACT FIELDS

            contact.id = request.updateContactReq.id;
            contact.first_name = request.updateContactReq.first_name;
            contact.last_name = request.updateContactReq.last_name;
            contact.middle_name = request.updateContactReq.middle_name;
            contact.account_id = request.updateContactReq.account_id;

            #region map list phone of location1_contact 
            for (int i = 0; i < request.updateContactReq.contact_phone_types.Count; i++)
            {
                if (i == 0)
                {
                    contact.contact_country_code_1 = request.updateContactReq.contact_phone_types.ElementAt(i).country_code;
                    contact.contact_phone_type_1 = request.updateContactReq.contact_phone_types.ElementAt(i).phone_type_id;
                    contact.contact_phone_1 = request.updateContactReq.contact_phone_types.ElementAt(i).phone_number;
                    contact.extension = request.updateContactReq.contact_phone_types.ElementAt(i).extension;

                }
                else if (i == 1)
                {
                    contact.contact_country_code_2 = request.updateContactReq.contact_phone_types.ElementAt(i).country_code;
                    contact.contact_phone_type_2 = request.updateContactReq.contact_phone_types.ElementAt(i).phone_type_id;
                    contact.contact_phone_2 = request.updateContactReq.contact_phone_types.ElementAt(i).phone_number;
                    contact.extension = request.updateContactReq.contact_phone_types.ElementAt(i).extension;

                }
                else if (i == 2)
                {
                    contact.contact_country_code_3 = request.updateContactReq.contact_phone_types.ElementAt(i).country_code;
                    contact.contact_phone_type_3 = request.updateContactReq.contact_phone_types.ElementAt(i).phone_type_id;
                    contact.contact_phone_3 = request.updateContactReq.contact_phone_types.ElementAt(i).phone_number;
                    contact.extension = request.updateContactReq.contact_phone_types.ElementAt(i).extension;

                }
                else if (i == 3)
                {
                    contact.contact_country_code_4 = request.updateContactReq.contact_phone_types.ElementAt(i).country_code;
                    contact.contact_phone_type_4 = request.updateContactReq.contact_phone_types.ElementAt(i).phone_type_id;
                    contact.contact_phone_4 = request.updateContactReq.contact_phone_types.ElementAt(i).phone_number;
                    contact.extension = request.updateContactReq.contact_phone_types.ElementAt(i).extension;

                }

            }
            #endregion

            contact.primary_email = request.updateContactReq.primary_email;
            contact.contact_type_id = (long)EnumTypes.contact_type.Contact;
            contact.secondary_email = request.updateContactReq.secondary_email;
            contact.description = request.updateContactReq.description;

            contact.is_primary = request.updateContactReq.is_primary;
            //contact.status = request.updateContactReq.status;
            contact.company_works_for = request.updateContactReq.company_works_for;
            contact.address_line_1 = request.updateContactReq.address_line_1;
            contact.address_line_2 = request.updateContactReq.address_line_2;
            contact.address_line_3 = request.updateContactReq.address_line_3;
            contact.address_type_id = request.updateContactReq.address_type_id;
            contact.county = request.updateContactReq.county;
            contact.city = request.updateContactReq.city;
            contact.state_id = request.updateContactReq.state_id;
            contact.zip_code = request.updateContactReq.zip_code;
            contact.country_id = request.updateContactReq.country_id;
            contact.time_zone_id = request.updateContactReq.time_zone_id;
            //contact.field_office_id = request.updateContactReq.field_office_id;
            contact.storage_id = request.updateContactReq.storage_id;

            bool status = await _contactRepo.UpdateContact(contact);

            return status;
            #endregion
        }
    }
}
