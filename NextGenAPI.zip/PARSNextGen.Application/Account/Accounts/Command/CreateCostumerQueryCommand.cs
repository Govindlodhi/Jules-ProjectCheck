﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Interface;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class CreateCostumerQueryCommand : IRequest<int?>
    {
        public CreateCustomerQueryReq contactUsQueryReq { get; set; }
    }
    public class CreateCostumerQueryCommandHandler : IRequestHandler<CreateCostumerQueryCommand, int?>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAccountRepository _accountRepository;
        public CreateCostumerQueryCommandHandler(ISqlContext dbCntx, IAccountRepository AccountRepository)
        {
            _dbCntx = dbCntx;
            _accountRepository = AccountRepository;
        }
        public async Task<int?> Handle(CreateCostumerQueryCommand request, CancellationToken cancellationToken)
        {
            Domain.Entities.Queries contactUs = new Domain.Entities.Queries();
            contactUs.name = request.contactUsQueryReq.name;
            contactUs.email = request.contactUsQueryReq.email;
            contactUs.subject = request.contactUsQueryReq.subject;
            contactUs.description = request.contactUsQueryReq.description;
            contactUs.to_account_id = request.contactUsQueryReq.to_account_id;
            contactUs.from_account_id = request.contactUsQueryReq.from_account_id;
            contactUs.query_status_id = (long)EnumTypes.contact_us_query_status.Pending;
            int? result = await _accountRepository.CreateCustomerQuery(contactUs);
            return result;
        }
    }
}
