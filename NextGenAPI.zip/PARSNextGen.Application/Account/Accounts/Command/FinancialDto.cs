﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class FinancialDto
    {
        public long? preferred_agreement_id { get; set; }
        public long? preferred_price_list_id { get; set; }
        public long? fallback_agreement_id { get; set; }
        public long? fallback_price_list_id { get; set; }
        public long? default_currency_id { get; set; }
        public decimal? admin_fee { get; set; }
        public decimal? rebate { get; set; }
        public bool? msa_signed { get; set; }
        public DateTime? msa_expiry_date { get; set; }
        public string default_ns_cust_id { get; set; }
    }
}
