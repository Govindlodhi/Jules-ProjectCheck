﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateDomainStatusDto
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
}
