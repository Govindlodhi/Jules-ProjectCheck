﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateCustomerQueryStatusCommand : IRequest<bool>
    {
        public UpdateCustomerQueryStatusReq updateCustomerQueryStatusReq { get; set; }
    }
    public class UpdateCustomerQueryStatusCommandHandler : IRequestHandler<UpdateCustomerQueryStatusCommand, bool>
    {
        private readonly IAccountRepository _accountRepository;
        public UpdateCustomerQueryStatusCommandHandler(IAccountRepository accountRepository)
        {
            _accountRepository = accountRepository;
        }
        public async Task<bool> Handle(UpdateCustomerQueryStatusCommand request, CancellationToken cancellationToken)
        {
            Domain.Entities.Queries contactUsQueryDetails = new Domain.Entities.Queries();
            contactUsQueryDetails.id = request.updateCustomerQueryStatusReq.id;
            contactUsQueryDetails.remark = request.updateCustomerQueryStatusReq.remark;
            contactUsQueryDetails.query_status_id = request.updateCustomerQueryStatusReq.query_status_id;
            bool result = await _accountRepository.UpdateCustomerQueryStatus(contactUsQueryDetails);
            return result;
        }
    }
}
