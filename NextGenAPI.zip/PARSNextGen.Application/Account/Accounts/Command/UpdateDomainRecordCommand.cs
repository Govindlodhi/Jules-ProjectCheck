﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Contact.GetContacts.Command;
using PARSNextGen.Application.Master.Roles.Queries.RoleDetail;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateDomainRecordCommand : IRequest<bool>
    {
        public long id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public long accountId { get; set; }
    }
    public class UpdateDomainRecordCommandHandler : IRequestHandler<UpdateDomainRecordCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IDomainRepository _domainRepo;
        private readonly ICurrentUserService _currentUserService;
        public UpdateDomainRecordCommandHandler(ISqlContext dbCntx, IDomainRepository domainRepo, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _domainRepo = domainRepo;
            _currentUserService = currentUserService;
        }
        public async Task<bool> Handle(UpdateDomainRecordCommand request, CancellationToken cancellationToken)
        {
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                Domains doomainDto = null;
                var querycolumns = @"SELECT id,name,description FROM domain WHERE name=@name AND account_id=@accountId AND id!=@id";
                parameters.Add("@name", request.name);
                parameters.Add("@id", request.id);
                parameters.Add("@accountId", request.accountId);         
                doomainDto = await connection.QueryFirstOrDefaultAsyncWithRetry<Domains>(querycolumns, parameters, commandType: CommandType.Text);
                if (doomainDto != null)
                    return false;
                bool result = await _domainRepo.UpdateDomains(request.id,request.name,request.description);
                return result;
            }
        }
    }
}
