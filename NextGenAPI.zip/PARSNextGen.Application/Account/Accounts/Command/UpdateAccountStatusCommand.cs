﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System.Threading;
using System.Threading.Tasks;
namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateAccountStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool status { get; set; }
    }
    public class UpdateContactStatusCommandHandler : IRequestHandler<UpdateAccountStatusCommand, bool>
    {
        private readonly IAccountRepository _accountRepository;
        public UpdateContactStatusCommandHandler(IAccountRepository accountRepository)
        {
            _accountRepository = accountRepository;
        }
        public async Task<bool> Handle(UpdateAccountStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _accountRepository.UpdateAccountStatus(request.id, request.status);
            return result;
        }
    }
}