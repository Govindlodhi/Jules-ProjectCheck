﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Threading;
using System.Threading.Tasks;
using PARSNextGen.Domain.Entities;
using System.Collections.Generic;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateAccountFinancialDetailCommand : IRequest<bool>
    {
        public UpdateAccountFinancialDetailReq updateAccountFinancialDetailReq { get; set; }
    }
    public class UpdateAccountFinancialDetailCommandHandler : IRequestHandler<UpdateAccountFinancialDetailCommand, bool>
    {
        private readonly IAccountRepository _AccountRepo;
        public UpdateAccountFinancialDetailCommandHandler(IAccountRepository AccountRepo)
        {
            _AccountRepo = AccountRepo;
        }
        public async Task<bool> Handle(UpdateAccountFinancialDetailCommand request, CancellationToken cancellationToken)
        {
            account accountObj = new account();
            #region Account Financial Fields
            accountObj.id = request.updateAccountFinancialDetailReq.id;
            accountObj.preferred_agreement_id = request.updateAccountFinancialDetailReq.preferred_agreement_id;
            accountObj.preferred_price_list_id = request.updateAccountFinancialDetailReq.preferred_price_list_id;
            accountObj.default_currency_id = request.updateAccountFinancialDetailReq.default_currency_id;
            accountObj.default_ns_cust_id = request.updateAccountFinancialDetailReq.default_ns_cust_id;
            accountObj.msa_signed = request.updateAccountFinancialDetailReq.msa_signed;
            accountObj.rebate = request.updateAccountFinancialDetailReq.rebate;
            accountObj.msa_expiry_date = request.updateAccountFinancialDetailReq.msa_expiry_date;
            accountObj.fallback_agreement_id = request.updateAccountFinancialDetailReq.fallback_agreement_id;
            accountObj.fallback_price_list_id = request.updateAccountFinancialDetailReq.fallback_price_list_id;
            accountObj.admin_fee = request.updateAccountFinancialDetailReq.admin_fee;

            #endregion Account Financial Fields


            bool status = await _AccountRepo.UpdateAccountFinancialDetail(accountObj);

            return status;
        }
    }
}