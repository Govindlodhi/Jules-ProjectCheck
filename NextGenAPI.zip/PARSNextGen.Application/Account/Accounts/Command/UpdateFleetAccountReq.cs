﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateFleetAccountReq
    {
        public long id { get; set; }
       
        public long? fleet_size_id { get; set; }

        public long? preferred_agreement_id { get; set; }
        public long? fmc_id { get; set; }
        //public long? default_currency_id { get; set; }
        //public long? preferred_price_list_id { get; set; }
        //public string default_ns_cust_id { get; set; }

        ////ESCALATION contact For FMC/Account
        //public long contact_id { get; set; }
        //public string first_name { get; set; }
        //public string middle_name { get; set; }
        //public string last_name { get; set; }
        //public string phone_1 { get; set; }
        //public string primary_email { get; set; }
        public UpdateSupportContact updateSupportContact { get; set; }

    }
    public class UpdateSupportContact
    {
        public long? support_contact_id { get; set; }
        public string escalation_first_name { get; set; }
        public string escalation_middle_name { get; set; }
        public string escalation_last_name { get; set; }
        public string escalation_phone { get; set; }
        public string escalation_email { get; set; }
    }
}
