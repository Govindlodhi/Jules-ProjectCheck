﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class CreateAccountReq
    {
        #region Fleet Creation fields
        public string fleet_no { get; set; }
        public long? linked_account_id { get; set; }
        public long? fmc_id { get; set; }
        public string account_name { get; set; }
        public long? fleet_size_id { get; set; }
        #endregion END

        #region Related Fields for FMC/Account Creation
        public string website { get; set; }

        public string address_line_1 { get; set; }
        public string address_line_2 { get; set; }
        public string address_line_3 { get; set; }
        public string city { get; set; }
        public string zip_code { get; set; }
        public long? state_id { get; set; }
        public long? country_id { get; set; }

        public long? preferred_price_list_id { get; set; }
        public string default_ns_cust_id { get; set; }

        #endregion END
        public long? preferred_agreement_id { get; set; }
        public long account_type_id { get; set; }

        // Primary contact For FMC/Account
        public string first_name { get; set; }
        public string middle_name { get; set; }
        public string last_name { get; set; }
        public string phone { get; set; }
        public string email { get; set; }

        #region Set values internally these fileds will not be the part of screen
        public long? default_currency_id { get; set; }
        public long? fallback_agreement_id { get; set; }
        public long? fallback_price_list_id { get; set; }
        #endregion End Financial Fields
        public CreateSupportContact supportContactReq { get; set; }


    }
    public class CreateSupportContact
    {
        public string escalation_first_name { get; set; }
        public string escalation_middle_name { get; set; }
        public string escalation_last_name { get; set; }
        public string escalation_phone { get; set; }
        public string escalation_email { get; set; }
    }

}
