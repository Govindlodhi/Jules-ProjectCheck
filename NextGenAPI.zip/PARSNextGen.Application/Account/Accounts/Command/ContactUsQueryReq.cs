﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class CreateCustomerQueryReq
    {
        public string name { get; set; }
        public string email { get; set; }
        public string subject { get; set; }
        public string description { get; set; }
        public long to_account_id { get; set; }
        public long from_account_id { get; set; }

    }
}
