﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Threading;
using System.Threading.Tasks;
using PARSNextGen.Domain.Entities;
using System.Collections.Generic;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateFleetAccountCommand : IRequest<bool>
    {
        public UpdateFleetAccountReq updateAccountReq { get; set; }
    }
    public class UpdateFleetAccountCommandHandler : IRequestHandler<UpdateFleetAccountCommand, bool>
    {
        private readonly IAccountRepository _AccountRepo;
        public UpdateFleetAccountCommandHandler(IAccountRepository AccountRepo)
        {
            _AccountRepo = AccountRepo;
        }
        public async Task<bool> Handle(UpdateFleetAccountCommand request, CancellationToken cancellationToken)
        {
            account accountObj = new account();
            #region Fleet Account Fields
            accountObj.id = request.updateAccountReq.id;       
            accountObj.fleet_size_id = request.updateAccountReq.fleet_size_id;
            accountObj.preferred_agreement_id = request.updateAccountReq.preferred_agreement_id;
            accountObj.fmc_id = request.updateAccountReq.fmc_id;

            #endregion Fleet Account Fields

            #region Escalation Contact Fields

            SupportContactsRequest supportContactReqs = null;
            if (request.updateAccountReq.updateSupportContact != null)
            {
                supportContactReqs = new SupportContactsRequest();
                supportContactReqs.id = request.updateAccountReq.updateSupportContact.support_contact_id;
                supportContactReqs.escalation_first_name = request.updateAccountReq.updateSupportContact.escalation_first_name;
                supportContactReqs.escalation_middle_name = request.updateAccountReq.updateSupportContact.escalation_middle_name;
                supportContactReqs.escalation_last_name = request.updateAccountReq.updateSupportContact.escalation_last_name;
                supportContactReqs.escalation_phone = request.updateAccountReq.updateSupportContact.escalation_phone;
                supportContactReqs.escalation_email = request.updateAccountReq.updateSupportContact.escalation_email;
                accountObj.supportContactReq = supportContactReqs;
            }

            #endregion End 


            bool status = await _AccountRepo.UpdateFleetAccount(accountObj);

            return status;
        }
    }
}
