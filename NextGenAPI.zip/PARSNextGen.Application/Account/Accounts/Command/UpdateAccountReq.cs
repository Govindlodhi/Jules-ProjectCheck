﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateAccountReq
    {
        public long id { get; set; }
        public string account_name { get; set; }
        public long? parent_account_id { get; set; }
        public long? pars_account_manager_id { get; set; }
        public long? pars_cs_specialist_id { get; set; }
        public string website { get; set; }
        public long? primary_contact_id { get; set; }
        public string address_line_1 { get; set; }
        public string address_line_2 { get; set; }
        public string address_line_3 { get; set; }
        public string city { get; set; }
        public string zip_code { get; set; }
        public long? state_id { get; set; }
        public long? country_id { get; set; }
        public long? industry_id { get; set; }

        public long? preferred_agreement_id { get; set; }
        public long? default_currency_id { get; set; }
        public long? preferred_price_list_id { get; set; }
        public string default_ns_cust_id { get; set; }

        //Primary contact For FMC/Account
        public long contact_id { get; set; }
        public string first_name { get; set; }
        public string middle_name { get; set; }
        public string last_name { get; set; }
        public string phone_1 { get; set; }
        public string primary_email { get; set; }
    }
}
