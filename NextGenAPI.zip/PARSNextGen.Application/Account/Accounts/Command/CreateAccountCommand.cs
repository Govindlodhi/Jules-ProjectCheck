﻿using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class CreateAccountCommand : IRequest<Tuple<bool,bool, long>>
    {
        public CreateAccountReq createAccountReq { get; set; }
    }
    public class CreateAccountCommandHandler : IRequestHandler<CreateAccountCommand, Tuple<bool,bool, long>>
    {
        private readonly IAccountRepository _accountRepo;
        private readonly IConfiguration _config;
        public CreateAccountCommandHandler(IAccountRepository accountRepo, IConfiguration config)
        {
            _accountRepo = accountRepo;
            _config = config;
        }
        public async Task<Tuple<bool,bool, long>> Handle(CreateAccountCommand request, CancellationToken cancellationToken)
        {
            bool result = false;

            AddNewAccountReq accountObj = new AddNewAccountReq();

            #region Fleet Creation fields
            accountObj.fleet_no = request.createAccountReq.fleet_no;
            accountObj.linked_account_id = request.createAccountReq.linked_account_id;
            accountObj.fmc_id = request.createAccountReq.fmc_id;
            accountObj.account_name = request.createAccountReq.account_name;
            accountObj.fleet_size_id = request.createAccountReq.fleet_size_id;
            #endregion END

            #region Related Fields for FMC/Account Creation
            accountObj.website = request.createAccountReq.website;
            accountObj.address_line_1 = request.createAccountReq.address_line_1;
            accountObj.address_line_2 = request.createAccountReq.address_line_2;
            accountObj.address_line_3 = request.createAccountReq.address_line_3;
            accountObj.city = request.createAccountReq.city;
            accountObj.zip_code = request.createAccountReq.zip_code;
            accountObj.state_id = request.createAccountReq.state_id;
            accountObj.country_id = request.createAccountReq.country_id;
            accountObj.preferred_price_list_id = request.createAccountReq.preferred_price_list_id;
            accountObj.default_ns_cust_id = request.createAccountReq.default_ns_cust_id;
            #endregion END

            accountObj.preferred_agreement_id = request.createAccountReq.preferred_agreement_id;
            accountObj.account_type_id = request.createAccountReq.account_type_id;
            accountObj.first_name = request.createAccountReq.first_name;
            accountObj.middle_name = request.createAccountReq.middle_name;
            accountObj.last_name = request.createAccountReq.last_name;
            accountObj.phone = request.createAccountReq.phone;
            accountObj.email = request.createAccountReq.email;

            #region Escalation_Contact_Fields
            SupportContactRequest supportContactReqs = null;
            if (request.createAccountReq.supportContactReq != null)
            {
                supportContactReqs = new SupportContactRequest();
                supportContactReqs.escalation_first_name = request.createAccountReq.supportContactReq.escalation_first_name;
                supportContactReqs.escalation_middle_name = request.createAccountReq.supportContactReq.escalation_middle_name;
                supportContactReqs.escalation_last_name = request.createAccountReq.supportContactReq.escalation_last_name;
                supportContactReqs.escalation_phone = request.createAccountReq.supportContactReq.escalation_phone;
                supportContactReqs.escalation_email = request.createAccountReq.supportContactReq.escalation_email;
                accountObj.supportContactReq = supportContactReqs;
            }

            #endregion

            #region Set values internally these fileds will not be the part of screen

            #region Set Fallback Agreement


            #endregion


            if(request.createAccountReq.default_currency_id == (long)EnumTypes.CurrencyType.US)
            {
                accountObj.default_currency_id = request.createAccountReq.default_currency_id;
                accountObj.fallback_agreement_id = Convert.ToInt64(_config["appSettings:PARSStandardAgreementUSD"]); 
                accountObj.fallback_price_list_id = Convert.ToInt64(_config["appSettings:DefaultPriceListIdUS"]);
            }
            else if (request.createAccountReq.default_currency_id == (long)EnumTypes.CurrencyType.CA)
            {
                accountObj.default_currency_id = request.createAccountReq.default_currency_id;
                accountObj.fallback_agreement_id = Convert.ToInt64(_config["appSettings:PARSStandardAgreementCAD"]);
                accountObj.fallback_price_list_id = Convert.ToInt64(_config["appSettings:DefaultPriceListIdCA"]);
            }

            #endregion End Financial Fields

            Tuple<bool,bool, long> accId = await _accountRepo.CreateAccount(accountObj);
           
            return accId;
        }
    }
}
