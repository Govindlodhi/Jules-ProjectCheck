﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Threading;
using System.Threading.Tasks;
using PARSNextGen.Domain.Entities;
using System.Collections.Generic;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateFMCAccountCommand : IRequest<Tuple<bool, bool,bool>>
    {
        public UpdateFMCAccountReq updateAccountReq { get; set; }
    }
    public class UpdateAccountCommandHandler : IRequestHandler<UpdateFMCAccountCommand, Tuple<bool, bool,bool>>
    {
        private readonly IAccountRepository _AccountRepo;
        public UpdateAccountCommandHandler(IAccountRepository AccountRepo)
        {
            _AccountRepo = AccountRepo;
        }
        public async Task<Tuple<bool, bool,bool>> Handle(UpdateFMCAccountCommand req, CancellationToken cancellationToken)
        {
            account accountObj = new account();
            #region FMC Fields
            accountObj.id = req.updateAccountReq.id;
            accountObj.account_name = req.updateAccountReq.account_name;
            accountObj.parent_account_id = req.updateAccountReq.parent_account_id;
            accountObj.pars_account_manager_id = req.updateAccountReq.pars_account_manager_id;
            accountObj.pars_cs_specialist_id = req.updateAccountReq.pars_cs_specialist_id;
            accountObj.website = req.updateAccountReq.website;
            accountObj.primary_contact_id = req.updateAccountReq.primary_contact_id;
            accountObj.address_line_1 = req.updateAccountReq.address_line_1;
            accountObj.address_line_2 = req.updateAccountReq.address_line_2;
            accountObj.address_line_3 = req.updateAccountReq.address_line_3;
            accountObj.city = req.updateAccountReq.city;
            accountObj.zip_code = req.updateAccountReq.zip_code;
            accountObj.state_id = req.updateAccountReq.state_id;
            accountObj.country_id = req.updateAccountReq.country_id;

            accountObj.preferred_agreement_id = req.updateAccountReq.preferred_agreement_id;
            accountObj.default_currency_id = req.updateAccountReq.default_currency_id;
            accountObj.preferred_price_list_id = req.updateAccountReq.preferred_price_list_id;
            accountObj.default_ns_cust_id = req.updateAccountReq.default_ns_cust_id;


            #endregion FMC Fields

            #region PrimaryContactFields

            accountObj.contact_id = req.updateAccountReq.contact_id;
            accountObj.first_name = req.updateAccountReq.first_name;
            accountObj.middle_name = req.updateAccountReq.middle_name;
            accountObj.last_name = req.updateAccountReq.last_name;
            accountObj.phone1 = req.updateAccountReq.phone_1;
            accountObj.email = req.updateAccountReq.primary_email;

            #endregion EndPrimaryContactFields


            Tuple<bool, bool,bool>  status = await _AccountRepo.UpdateFMCAccount(accountObj);

            return status;
        }
    }
}
