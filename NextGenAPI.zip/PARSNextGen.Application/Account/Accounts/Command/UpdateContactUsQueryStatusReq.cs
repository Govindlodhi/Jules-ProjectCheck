﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateCustomerQueryStatusReq
    {
        public long id {  get; set; }
        public long query_status_id { get; set; }
        public string remark { get; set; }
    }
}
