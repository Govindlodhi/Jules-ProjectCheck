﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class CustomerAccountMappedCommand : IRequest<bool>
    {
    
       public List<CustomerAccountMappedReq> linked_account_mapped { get; set; }
    }
    public class AccountMappedCommandHandler : IRequestHandler<CustomerAccountMappedCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        public AccountMappedCommandHandler(ISqlContext sqlContext)
        {
            _dbCntx = sqlContext;   
        }
       
        public async Task<bool> Handle(CustomerAccountMappedCommand request, CancellationToken cancellationToken)
        {
            using (var connection = _dbCntx.GetOpenConnection())
            {
                bool result = false;
                DynamicParameters dp = new DynamicParameters();
                var procedure = "sp_update_customer_account_mapped";
                foreach (var linked_account in request.linked_account_mapped)
                {
                    {
                        dp.Add("@linked_account_id", linked_account.linked_account_id);
                        dp.Add("@fleet_id",linked_account.fleet_id);
                    }
                    int rowsInserted = await connection.ExecuteAsyncWithRetry(procedure, dp, commandType: CommandType.StoredProcedure);
                    result = rowsInserted > 0 ? true : false;
                }
                return result;

            }
        }
    }
}
