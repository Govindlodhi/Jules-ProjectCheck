﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class CustomerAccountMappedReq
    {
     
        public long fleet_id { get; set; }
        public long? linked_account_id { get; set; }

    }

}
