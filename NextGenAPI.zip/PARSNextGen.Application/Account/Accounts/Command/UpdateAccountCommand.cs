﻿using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateAccountCommand : IRequest<Tuple<bool, bool,bool>>
    {
        public UpdateAccountReq updateAccountReq { get; set; }
    }
    public class UpdateAccountsCommandHandler : IRequestHandler<UpdateAccountCommand, Tuple<bool, bool, bool>>
    {
        private readonly IAccountRepository _accountRepo;
        private readonly ICurrentUserService _currentUserService;
        private readonly ISqlContext _dbContext;
        public UpdateAccountsCommandHandler(IAccountRepository accountRepo, ICurrentUserService currentUser, ISqlContext dbContext)
        {
            _accountRepo = accountRepo;
            _currentUserService = currentUser;
            _dbContext = dbContext;
        }
        public async Task<Tuple<bool, bool, bool>> Handle(UpdateAccountCommand req, CancellationToken cancellationToken)
        {
            account accountObj = new account();
            #region Account Fields
            accountObj.id = req.updateAccountReq.id;
            accountObj.account_name = req.updateAccountReq.account_name;
            accountObj.parent_account_id = req.updateAccountReq.parent_account_id;
            accountObj.pars_account_manager_id = req.updateAccountReq.pars_account_manager_id;
            accountObj.pars_cs_specialist_id = req.updateAccountReq.pars_cs_specialist_id;
            accountObj.website = req.updateAccountReq.website;
            accountObj.primary_contact_id = req.updateAccountReq.primary_contact_id;
            accountObj.address_line_1 = req.updateAccountReq.address_line_1;
            accountObj.address_line_2 = req.updateAccountReq.address_line_2;
            accountObj.address_line_3 = req.updateAccountReq.address_line_3;
            accountObj.city = req.updateAccountReq.city;
            accountObj.zip_code = req.updateAccountReq.zip_code;
            accountObj.state_id = req.updateAccountReq.state_id;
            accountObj.country_id = req.updateAccountReq.country_id;
            accountObj.industry_id = req.updateAccountReq.industry_id;
            accountObj.preferred_agreement_id = req.updateAccountReq.preferred_agreement_id;
            accountObj.default_currency_id = req.updateAccountReq.default_currency_id;
            accountObj.preferred_price_list_id = req.updateAccountReq.preferred_price_list_id;
            accountObj.default_ns_cust_id = req.updateAccountReq.default_ns_cust_id;
            #endregion Account Fields
            #region PrimaryContactFields
            accountObj.contact_id = req.updateAccountReq.contact_id;
            accountObj.first_name = req.updateAccountReq.first_name;
            accountObj.middle_name = req.updateAccountReq.middle_name;
            accountObj.last_name = req.updateAccountReq.last_name;
            accountObj.phone1 = req.updateAccountReq.phone_1;
            accountObj.email = req.updateAccountReq.primary_email;
            #endregion End PrimaryContactFields
            Tuple<bool, bool, bool> status = await _accountRepo.UpdateAccount(accountObj);
            return status;
        }
    }
}

