﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class UpdateDomainStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class UpdateDomainStatusCommandHandler : IRequestHandler<UpdateDomainStatusCommand, bool>
    {
        private readonly IDomainRepository _domainRepo;
        public UpdateDomainStatusCommandHandler(IDomainRepository domainRepo)
        {
            _domainRepo = domainRepo;
        }
        public async Task<bool> Handle(UpdateDomainStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _domainRepo.UpdateDomainStatus(request.id, request.is_active);
            return result;
        }
    }
}
