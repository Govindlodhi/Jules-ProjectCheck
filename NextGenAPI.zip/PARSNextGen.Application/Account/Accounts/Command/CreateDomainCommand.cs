﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class CreateDomainCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateDomainCommandDto createDomainReq { get; set; }
    }
    public class CreateDomainCommandHandler : IRequestHandler<CreateDomainCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        private readonly IDomainRepository _domainRepository;
        private readonly IIdentityService _identityService;
        private readonly IMediator _mediator;
        public CreateDomainCommandHandler(ISqlContext dbCntx, ICurrentUserService currentUserService, IDomainRepository domainRepository,
            IIdentityService identityService, IMediator mediator)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
            _domainRepository = domainRepository;
            _identityService = identityService;
            _mediator = mediator;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateDomainCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            Domains domains = new Domains();
            // DOMAIN MASTER TABLE FIELDS
            domains.name = request.createDomainReq.name;
            domains.description = request.createDomainReq.description;
            domains.account_id = request.createDomainReq.account_id;
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createDomainReq.name);
                string query = @"SELECT id FROM domain WHERE name = @name";
                int domainExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);
                if (domainExists > 0)
                    isDulicateData = true;
            }
            if (isDulicateData)
                return responseT = Tuple.Create(false, isDulicateData);
            else
            {
                bool contactUser = await _domainRepository.CreateDomain(domains);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }
        }
    }
}
