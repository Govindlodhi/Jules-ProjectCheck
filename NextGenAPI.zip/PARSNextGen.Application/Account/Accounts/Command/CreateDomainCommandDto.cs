﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Command
{
    public class CreateDomainCommandDto
    {
        public string name { get; set; }
        public string? description { get; set; }
        public long account_id { get; set; }
    }
}
