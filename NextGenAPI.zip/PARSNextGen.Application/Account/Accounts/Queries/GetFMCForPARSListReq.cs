﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class FilterCondition
    {
        public string Field { get; set; }
        public string Operation { get; set; }
        public string Value { get; set; }
        public List<FilterCondition> Conditions { get; set; }
    }
    public class AccountAdvancedFilter
    {
        public long? accountId { get; set; }
        public int? listFilter { get; set; }
        public string advancedFilter { get; set; }
    }
}
