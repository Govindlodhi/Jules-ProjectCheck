﻿using Dapper;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetFMCFleetQuery : IRequest<FMCFleet>
    {
       public AccountAdvancedFilter reqParm { get; set; }
    }
    public class GetFMCFleetQueryHandler : IRequestHandler<GetFMCFleetQuery, FMCFleet>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserContext;
        private readonly IConfiguration _config;
        public GetFMCFleetQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserContext, IConfiguration config)
        {
            _dbCntx = dbCntx;
            _currentUserContext = currentUserContext;
            _config = config;
        }

        public async Task<FMCFleet> Handle(GetFMCFleetQuery request, CancellationToken cancellationToken)
        {
            FMCFleet fMCFleet = new FMCFleet();

            string orderBy = " ORDER BY created_on desc";
            var topRecord = _config["appSettings:TopRecordCount"];
            var sqlQuery = new StringBuilder();            

            sqlQuery.Append("SELECT TOP " + topRecord + " id, CASE WHEN fleet_no is NULL THEN account_name ELSE fleet_no +' | '+ account_name END  account_name, phone," +
                " city, zip_code, state_name, owner_account_name,primary_contact_name,pars_cs_specialist_name,pars_cs_specialist_email,pars_cs_specialist_mobile," +
                "pars_account_manager_phone,pars_account_manager_email,primary_contact_business_phone,primary_contact_email,vehicle_in_storage,fleet_makeup," +
                "fleet_no,annual_moves_name,is_active FROM vw_accountdetail WHERE ");


            SQLQueryBuilder builder = new SQLQueryBuilder();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                if (!string.IsNullOrEmpty(request.reqParm.advancedFilter))//Advanced Filter
                {
                    //Apply account-level filters based on logged-in user's account type
                    if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
                        sqlQuery.Append("account_type_id =@account_type_id AND fmc_id = @fmc_id ");
                    else if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.Fleet)
                        sqlQuery.Append("(id = @fmc_id) ");
                    else if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.PARS)
                        sqlQuery.Append(" fmc_id = @fmc_id ");
                    
                    try
                    {
                        string queryfilter = builder.BuildQuery(request.reqParm.advancedFilter);
                        if (!string.IsNullOrWhiteSpace(queryfilter))
                            queryfilter = "AND " + queryfilter;
                        sqlQuery.Append(queryfilter);
                    }
                    catch { throw new Exception("PARS_ADVANCED_FILTER_ERROR"); }
                }
                else
                {
                    //FMC-Fleet Side Filter
                    if (request.reqParm.listFilter != null)
                    {
                        //Apply account-level filters based on logged-in user's account type

                        if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
                            sqlQuery.Append("account_type_id =@account_type_id AND fmc_id = @fmc_id ");
                        else if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.Fleet)
                            sqlQuery.Append("(id = @fmc_id) ");
                        else if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.PARS)
                            sqlQuery.Append(" fmc_id = @fmc_id ");

                        if (request.reqParm.listFilter == (int)EnumTypes.AccountSideFilter.ActiveAccount)
                            sqlQuery.Append(" AND is_active = 1");
                        else if (request.reqParm.listFilter == (int)EnumTypes.AccountSideFilter.InactiveAccount)
                            sqlQuery.Append("  AND is_active = 0");
                        
                    }
                    else
                    {
                        // Use saved default filter if available
                        if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
                            sqlQuery.Append("account_type_id =@account_type_id AND fmc_id = @fmc_id ");
                        else if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.Fleet)
                            sqlQuery.Append("(id = @fmc_id) ");
                        else if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.PARS)
                            sqlQuery.Append(" fmc_id = @fmc_id ");


                        //Get saved default filter JSON for the user and apply
                        string defaultFilter = await connection.QuerySingleOrDefaultAsync<string>(
                                            @"SELECT TOP 1 filter_json FROM advanced_filter_management  WHERE is_set_default = 1 
                                              AND created_by = @LoggedInUserId  AND entity_name = @EntityName",
                                            new { LoggedInUserId = _currentUserContext.LoggedInUserId, EntityName = "fleet" });
                        if (!string.IsNullOrEmpty(defaultFilter))
                        {
                            try
                            {
                                string queryfilter = builder.BuildQuery(defaultFilter.Replace("\\", ""));
                                if (!string.IsNullOrWhiteSpace(queryfilter))
                                    queryfilter = "AND " + queryfilter;
                                sqlQuery.Append(queryfilter);
                            }
                            catch (Exception) { throw new Exception("PARS_DEFULT_ADVANCED_FILTER_ERROR"); }
                        }
                        else
                            sqlQuery.Append(" AND is_active = 1");
                    }
                }
                sqlQuery.Append(orderBy);

                //Generate dynamic query parameter based on searchFilters
                DynamicParameters dynamicParam = new DynamicParameters();
                dynamicParam.Add("@account_type_id", EnumTypes.AccountTypes.Fleet);
                dynamicParam.Add("@fmc_id", request.reqParm.accountId);
                fMCFleet.fMCFleets = new List<FMCFleetDto>();

                var result = (await connection.QueryAsync<FMCFleetDto>(sqlQuery.ToString(), dynamicParam, commandType: CommandType.Text)).ToList();
                fMCFleet.fMCFleets = result;
                fMCFleet.totalCount = result.Count;

            }
            return fMCFleet;
        }
    }
}








