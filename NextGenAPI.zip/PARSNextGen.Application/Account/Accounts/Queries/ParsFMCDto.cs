﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class ParsFMC
    {
        public List<ParsFMCDto> fmcList { get; set; }
        public int totalCount { get; set; }

    }
    public class ParsFMCDto
    {
        public long id { get; set; }
        public string account_name { get; set; }
        public string fleet_no { get; set; }
        public string account_type_name { get; set; }
        public string pars_account_manager_name { get; set; }
        public string pars_cs_specialist_name { get; set; }
        public string parent_account_name { get; set; }
        public string phone { get; set; }
        public string website { get; set; }
        public string rebate { get; set; }
        public string market_ranking_name { get; set; }
        public string fleet_size_name { get; set; }
        public string annual_moves_name { get; set; }
        public string pay_attention_name { get; set; }
        public long? fmc_id { get; set; }
        public string account_email { get; set; }
        public string fleet_makeup { get; set; }
        public string fleet_makeup_cars_or_light_trucks { get; set; }
        public string fleet_makeup_dot { get; set; }
        public string fleet_makeup_cdl { get; set; }
        public string default_bill_to_name { get; set; }
        public string msa_signed { get; set; }
        public string address_line_3 { get; set; }
        public string city { get; set; }
        public long? state_id { get; set; }
        public string state_name { get; set; }
        public string zip_code { get; set; }
        public long? country_id { get; set; }
        public string country_name { get; set; }
        public string owner_account_name { get; set; }
        public string primary_contact_name { get; set; }
        public string pars_cs_specialist_email { get; set; }
        public string pars_cs_specialist_mobile { get; set; }
        public string pars_account_manager_phone { get; set; }
        public string pars_account_manager_email { get; set; }
        public string primary_contact_business_phone { get; set; }
        public string primary_contact_email { get; set; }
        public long? vehicle_in_storage { get; set; }
        public long? preferred_agreement_id { get; set; }
        public string preferred_agreement { get; set; }
        public long? preferred_price_list_id { get; set; }
        public string preferred_price_list { get; set; }
        public long? default_currency_id { get; set; }
        public string currency { get; set; }
        public bool is_active { get; set; }
        public Guid? crm_id { get; set; }

        //public List<FMCParsDto> FMCParsDto { get; internal set; }
    }
}

 