﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetPrimaryContactMasterQuery : IRequest<List<PrimaryContactMasterDto>>
    {
        public long account_id { get; set; }
    }
    public class GetPrimaryContactMasterQueryHandler : IRequestHandler<GetPrimaryContactMasterQuery, List<PrimaryContactMasterDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetPrimaryContactMasterQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<PrimaryContactMasterDto>> Handle(GetPrimaryContactMasterQuery request, CancellationToken cancellationToken)
        {
            List<PrimaryContactMasterDto> primarycontactRelatedMasterdata = new List<PrimaryContactMasterDto>();
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string queryPrimaryContact = @"SELECT id,CONCAT(first_name,' ', middle_name,' ', last_name) as name FROM contact where account_id = @accountId;";
                parameters.Add("@accountId", request.account_id);
                primarycontactRelatedMasterdata = (List<PrimaryContactMasterDto>)await connection.QueryAsyncWithRetry<PrimaryContactMasterDto>(queryPrimaryContact, parameters, commandType: CommandType.Text);
            }
            return primarycontactRelatedMasterdata;
        }
    }
}
