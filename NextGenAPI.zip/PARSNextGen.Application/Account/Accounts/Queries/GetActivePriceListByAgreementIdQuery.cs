﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetActivePriceListByAgreementIdQuery : IRequest<List<ActivePriceListByAgreementIdDto>>
    {
        public long agreement_id { get; set; }
    }
    public class GetPriceListByAgreementIdQueryHandler : IRequestHandler<GetActivePriceListByAgreementIdQuery, List<ActivePriceListByAgreementIdDto>>
    {
        private readonly ISqlContext _dbCntx;


        public GetPriceListByAgreementIdQueryHandler(ISqlContext sqlContext)
        {
            _dbCntx = sqlContext;
        }


        public async Task<List<ActivePriceListByAgreementIdDto>> Handle(GetActivePriceListByAgreementIdQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            List<ActivePriceListByAgreementIdDto> priceLists = new List<ActivePriceListByAgreementIdDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@agreement_id", request.agreement_id);
                dp.Add("@priceListStatusId",(long) EnumTypes.Price_List_Status.Active);
                string query = @"SELECT id,name FROM price_list WHERE price_list_status_id=@priceListStatusId AND agreement_id=@agreement_id";
                priceLists = (List<ActivePriceListByAgreementIdDto>)await connection.QueryAsyncWithRetry<ActivePriceListByAgreementIdDto>(query, dp, commandType: CommandType.Text);
            }

            return priceLists;
        }
    }
}
