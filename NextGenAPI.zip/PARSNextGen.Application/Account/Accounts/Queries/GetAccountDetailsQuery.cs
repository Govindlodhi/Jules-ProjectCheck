﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetAccountDetailsQuery : IRequest<AccountDetailsDto>
    {
        public int account_id { get; set; }
    }
    public class GetAccountDetailsByIdQueryHandler : IRequestHandler<GetAccountDetailsQuery, AccountDetailsDto>
    {
        private readonly ISqlContext _dbCntx;
        public GetAccountDetailsByIdQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<AccountDetailsDto> Handle(GetAccountDetailsQuery request, CancellationToken cancellationToken)
        {
            var accounts = new AccountDetailsDto();
            DynamicParameters dp = new DynamicParameters();
            dp.Add("@accountId", request.account_id);
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var query = @"SELECT top 1
                a.id,a.account_name,a.account_type_id,a.account_type_name,a.pars_account_manager_id,a.pars_account_manager_name,
                a.pars_cs_specialist_id,a.pars_cs_specialist_name,a.parent_account_id,a.parent_account_name,a.website,a.rebate,
                a.admin_fee,a.fleet_size_id,a.fleet_size_name,a.annual_moves_id,
                a.annual_moves_name,a.fmc_id,a.fmc_account_name fmc_name,a.default_inspection_mailing_address,a.account_email,
                a.industry_id,a.industry_name,a.fleet_makeup_cars_or_light_trucks,a.fleet_makeup_dot,a.fleet_makeup_cdl,a.default_bill_to_id,
                a.default_bill_to_name,a.default_ns_cust_id,a.msa_signed,a.msa_signed_on,a.msa_expiry_date,a.address_line_1,a.address_line_2,
                a.address_line_3,a.city,a.state_id,a.state_name,a.zip_code,a.country_id,a.country_name,a.primary_contact_id,a.primary_contact_name,
                a.pars_account_manager_phone,a.primary_contact_business_phone,a.primary_contact_email,a.vehicle_in_storage,
                a.fleet_makeup,a.fleet_no,a.preferred_agreement_id,a.preferred_agreement,a.preferred_price_list_id,a.preferred_price_list,
                a.default_currency_id,a.currency,a.fallback_agreement_id,a.fallback_price_list_id,a.fallback_agreement,a.fallback_price_list,
                a.crm_id,ct.id AS contact_id,ct.first_name,ct.middle_name,ct.last_name,a.phone phone_1,ct.primary_email,
                COALESCE(asct.id, fsct.id) AS support_contact_id
                FROM vw_accountdetail a
                LEFT JOIN contact ct ON a.id = ct.account_id
                LEFT JOIN support_contact asct ON a.id = asct.account_id
                LEFT JOIN support_contact fsct ON a.id = fsct.fmc_id
                WHERE a.id = @accountId ORDER BY COALESCE(asct.created_on, fsct.created_on) DESC";
                
                accounts = await connection.QueryFirstOrDefaultAsync<AccountDetailsDto>(query, dp, commandType: CommandType.Text);

            }
            return accounts;
        }
    }
}
