﻿using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class AccountMasterDto
    {
        public List<EntityReference> account_types { get; set; }
        public List<EntityReference> market_rankings { get; set; }
        public List<EntityReference> fleet_size_options { get; set; }
        public List<EntityReference> annual_moves_ranges { get; set; }
        public List<EntityReference> state_name { get; set; }
        public List<EntityReference> country_name { get; set; }
        public List<EntityReference> industry_name { get; set; }
        public List<EntityReference> currency_name { get; set; }
        public List<EntityReference> user_status { get; set; }
        public List<EntityReference> account_list { get; set; }

    }  
}
