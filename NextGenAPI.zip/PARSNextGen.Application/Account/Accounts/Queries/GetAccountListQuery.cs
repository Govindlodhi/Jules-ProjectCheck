﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetAccountListQuery : IRequest<List<GetAccountListDto>>
    {
        public long accountTypeId { get; set; }
        public long id { get; set; }
    }
    public class GetAccountListQueryHandler : IRequestHandler<GetAccountListQuery, List<GetAccountListDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetAccountListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<GetAccountListDto>> Handle(GetAccountListQuery request, CancellationToken cancellationToken)
        {
            List<GetAccountListDto> accountListDto = new List<GetAccountListDto>();
            if (request.accountTypeId == 0 || request.id == 0)
                return null;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string condi = string.Empty;
                if (request.accountTypeId !=0 && request.id != 0)
                    condi = " AND a.account_type_id = " + request.accountTypeId + "and a.id != " + request.id;
                else
                    condi = "AND a.account_type_id <>1 ";
                string queryAccountList = @"SELECT a.id account_id, a.account_name account_name,at.name account_type
                                            FROM account a
                                            INNER JOIN account_type at ON a.account_type_id = at.id
                                            WHERE a.is_active = 1 and a.id!=1 " + condi ;
               accountListDto = (List<GetAccountListDto>)await connection.QueryAsyncWithRetry<GetAccountListDto>(queryAccountList, commandType: CommandType.Text);
            }
            return accountListDto;
        }
    }
}