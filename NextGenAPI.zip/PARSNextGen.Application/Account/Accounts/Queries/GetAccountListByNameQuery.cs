﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetAccountListByNameQuery :IRequest<List<GetAccountListDto>>
    {
        public long account_type_id { get; set; }
        public string searchFilter { get; set; }
    }
    public class GetAccountListByNameQueryHandler : IRequestHandler<GetAccountListByNameQuery, List<GetAccountListDto>>
    {
        private readonly ISqlContext _dbContext;
        public GetAccountListByNameQueryHandler(ISqlContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<List<GetAccountListDto>> Handle(GetAccountListByNameQuery req, CancellationToken cancellationToken)
        {
            List<GetAccountListDto> result = new List<GetAccountListDto>();
            if (req.account_type_id == 0 || string.IsNullOrEmpty(req.searchFilter))
                return result;
            else
            {
                using(var con = _dbContext.GetOpenConnection())
                {
                    DynamicParameters dp = new DynamicParameters();
                    dp.Add("@account_type_id", req.account_type_id);                    
                    dp.Add("@searchFilter", "%" + req.searchFilter + "%");// Include wildcards in the parameter
                    string query = @"SELECT ac.id AS account_id, ac.account_name, at.name AS account_type 
                                     FROM account ac
                                     LEFT JOIN account_type at ON ac.account_type_id = at.id
                                     WHERE ac.account_type_id = @account_type_id AND ac.account_name LIKE @searchFilter";
                    result = (List<GetAccountListDto>)await con.QueryAsyncWithRetry<GetAccountListDto>(query,dp,commandType: CommandType.Text);
                }
                return result;
            }
        }
    }
}
