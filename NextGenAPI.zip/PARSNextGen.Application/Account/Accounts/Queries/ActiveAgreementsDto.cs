﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class AgreementsDto
    {
        public List<ActiveAgreementsDto> preferred_agreement { get; set; }
        public List<ActiveAgreementsDto> fallback_agreement { get; set; }
    }
    public class ActiveAgreementsDto
    {
        public long id { get; set; }
        public long? fmc_id { get; set; }
        public long? fleet_id { get; set; }
        public string name { get; set; }
        public string agreement_type { get; set; }
        
    }
}
