﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetAllDomainListByAccountIdQuery : IRequest<List<GetAllDomainListByAccountIdDto>>
    {
        public long account_id { get; set; }
    }
    public class GetAllDomainListAccountIdQueryHandler : IRequestHandler<GetAllDomainListByAccountIdQuery, List<GetAllDomainListByAccountIdDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetAllDomainListAccountIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<List<GetAllDomainListByAccountIdDto>> Handle(GetAllDomainListByAccountIdQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dl = new DynamicParameters();
            List<GetAllDomainListByAccountIdDto> domainlistbyaccountid = new List<GetAllDomainListByAccountIdDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"SELECT d.id as id ,d.name as name,d.description as description,d.is_active as is_active,
                                d.account_id as account_id FROM domain as d 
                                WHERE account_id =@accountId;";
                dl.Add("@accountId", request.account_id);
                domainlistbyaccountid = (List<GetAllDomainListByAccountIdDto>)await connection.QueryAsyncWithRetry<GetAllDomainListByAccountIdDto>(query, dl, commandType: CommandType.Text);
            }
            return domainlistbyaccountid;
        }
    }
}
