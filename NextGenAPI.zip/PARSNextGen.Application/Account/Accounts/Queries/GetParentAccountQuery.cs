﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetParentAccountQuery : IRequest<List<ParentAccountDto>>
    {
        public long account_id { get; set; }
       
    }
    public class GetParentAccountQueryHandler : IRequestHandler<GetParentAccountQuery, List<ParentAccountDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;

        public GetParentAccountQueryHandler(ISqlContext sqlContext, ICurrentUserService currentUserService)
        {
            _dbCntx = sqlContext;
            _currentUserService = currentUserService;
        }
        public async Task<List<ParentAccountDto>> Handle(GetParentAccountQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            List<ParentAccountDto> parentAccounts= new List<ParentAccountDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {

                dp.Add("@accountId", request.account_id);
                string query = "";
                query = @"SELECT pa.id,pa.account_name name FROM account  a INNER JOIN account pa ON a.parent_account_id=pa.id "+
                            " WHERE a.id =@accountId";


                parentAccounts = (List<ParentAccountDto>)await connection.QueryAsyncWithRetry<ParentAccountDto>(query, dp, commandType: CommandType.Text);
            }
            return parentAccounts;
        }
    }
}