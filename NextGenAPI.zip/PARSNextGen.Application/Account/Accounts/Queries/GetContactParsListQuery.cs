﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetCustomerQueryListQuery : IRequest<List<GetCustomerQueriesListDto>>
    {
        public long id { get; set; }
    }
    public class GetCustomerQueryListQueryHandler : IRequestHandler<GetCustomerQueryListQuery, List<GetCustomerQueriesListDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetCustomerQueryListQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<List<GetCustomerQueriesListDto>> Handle(GetCustomerQueryListQuery request, CancellationToken cancellationToken)
        {
            List<GetCustomerQueriesListDto> result = new List<GetCustomerQueriesListDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string condition = string.Empty;
                if (request.id == (long)EnumTypes.Account.PARS) //For PARS account
                    condition = " OR q.from_account_id IS NULL";
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@id", request.id);
                dp.Add("@condition", condition);

                string query = @"SELECT 
                                q.id,q.name,q.email, q.subject, q.description, q.to_account_id,acc.account_name AS to_account_name,                                        
                                q.from_account_id,a.account_name as from_account_name, q.remark,q.query_status_id,qs.name as query_status,
                                q.created_by, CONCAT(c.first_name,c.middle_name,c.last_name) as created_by_name
                                FROM queries q 
                                LEFT JOIN account acc ON q.to_account_id = acc.id
                                LEFT JOIN account a On q.from_account_id = a.id
                                LEFT JOIN query_status qs ON q.query_status_id = qs.id
                                LEFT JOIN user_auth ua ON q.created_by = ua.id
                                LEFT JOIN contact c ON ua.contact_id = c.id
                                WHERE q.from_account_id = @id" + condition;
                result = (List<GetCustomerQueriesListDto>)await connection.QueryAsyncWithRetry<GetCustomerQueriesListDto>(query, dp, commandType: CommandType.Text);
            }
            return result;
        }
    }
}
