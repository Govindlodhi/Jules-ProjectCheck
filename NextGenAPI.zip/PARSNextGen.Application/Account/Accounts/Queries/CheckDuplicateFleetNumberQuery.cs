﻿using Dapper;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Server.IIS.Core;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class CheckDuplicateFleetNumberQuery : IRequest<bool>
    {
        public string fleetNumber { get; set; }
        public long fmcId { get; set; }
    }
    public class CheckDuplicateFleetNumberQueryHandler : IRequestHandler<CheckDuplicateFleetNumberQuery, bool>
    {
        private readonly ISqlContext _sqlContext;
        public CheckDuplicateFleetNumberQueryHandler(ISqlContext sqlContext)
        {
            _sqlContext = sqlContext;
        }
        public async Task<bool> Handle(CheckDuplicateFleetNumberQuery req, CancellationToken cancellationToken)
        {
            bool result = false;

            using (var conn = _sqlContext.GetOpenConnection())
            {
                string query = @"SELECT id FROM account WHERE fleet_no = @FleetNumber AND fmc_id = @FmcId;";

                var id = await conn.QueryFirstOrDefaultAsync<int?>(query, new { FleetNumber = req.fleetNumber, FmcId = req.fmcId });

                if (id.HasValue && id > 0)
                    result = true;
            }

            return result;


        }

    }
    public class CheckDuplicateFleetNumberQueryValidator : AbstractValidator<CheckDuplicateFleetNumberQuery>
    {
        public CheckDuplicateFleetNumberQueryValidator()
        {
            RuleFor(p => p.fmcId).NotNull();
            RuleFor(p => p.fmcId).NotEqual(0);
        }
    }

}
