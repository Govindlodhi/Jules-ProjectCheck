﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetAccountListDto
    {
        public string account_name { get; set; }
        public string account_id { get; set; }
        public string account_type { get; set; }
    }
}
