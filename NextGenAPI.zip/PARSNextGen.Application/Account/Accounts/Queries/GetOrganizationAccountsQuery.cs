﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetOrganizationAccountsQuery : IRequest<List<OrganizationAccountsDto>>
    {
       
    }
    public class GetOrganizationAccountsQueryHandler : IRequestHandler<GetOrganizationAccountsQuery, List<OrganizationAccountsDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetOrganizationAccountsQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<List<OrganizationAccountsDto>> Handle(GetOrganizationAccountsQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            List<OrganizationAccountsDto> OrganizationAccountslst = new List<OrganizationAccountsDto>();
            var procedure = "sp_get_organization_accounts";
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@accountId", _currentUserService.AccountId);
                OrganizationAccountslst = (List<OrganizationAccountsDto>)await connection.QueryAsyncWithRetry<OrganizationAccountsDto>(procedure, dp, commandType: CommandType.StoredProcedure);
            }
            return OrganizationAccountslst;
        }
    }
}
