﻿using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Domain.Common;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetFleetFMCQuery : IRequest<FleetFMC>
    {
        //public long account_id { get; set; }
        //public string entity_name { get; set; }
        //public string account_name { get; set; }
        //public SearchFilter searchFilters { get; set; }
        public AccountAdvancedFilter reqParm { get; set; }
    }
    public class GetFleetFMCQueryHandler : IRequestHandler<GetFleetFMCQuery, FleetFMC>
    {

        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserContext;
        private readonly IConfiguration _config;
        public GetFleetFMCQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserContext, IConfiguration config)
        {
            _dbCntx = dbCntx;
            _currentUserContext = currentUserContext;
            _config = config;
        }
        public async Task<FleetFMC> Handle(GetFleetFMCQuery request, CancellationToken cancellationToken)
        {
            FleetFMC fleetFMC = new FleetFMC();
            //Generate dynamic query parameter based on searchFilters
            string orderBy = " order by created_on desc";
            var topRecord = _config["appSettings:TopRecordCount"];
            var sqlQuery = new StringBuilder();

            //sqlQuery.Append("select distinct fmc.id,fmc.account_name" +
            //            ", fmc.account_type_name,fmc.pars_account_manager_name,fmc.pars_cs_specialist_name,fmc.pars_cs_specialist_email,fmc.pars_cs_specialist_mobile,fmc.parent_account_name,fmc.phone,fmc.website, fmc.rebate" +
            //            ",fmc.market_ranking_name,fmc.fleet_size_name,fmc.annual_moves_name,fmc.pay_attention_name  ,fmc.account_email" +
            //            ",fmc.fleet_makeup_cars_or_light_trucks,fmc.fleet_makeup_dot, fmc.fleet_makeup_cdl,fmc.default_bill_to_name,fmc.msa_signed" +
            //            ",fmc.address_line_1,fmc.address_line_2,fmc.address_line_3,fmc.city,fmc.state_id ,fmc.state_name,fmc.zip_code,fmc.country_id,fmc.country_name,fmc.owner_account_name" +
            //            ",fmc.primary_contact_name,fmc.pars_account_manager_phone,fmc.pars_account_manager_email" +
            //            ",fmc.primary_contact_business_phone,fmc.primary_contact_email,fmc.vehicle_in_storage,fmc.fleet_makeup" +
            //            ",fmc.fleet_no,fmc.preferred_agreement_id,fmc.preferred_agreement,fmc.preferred_price_list_id,fmc.preferred_price_list,fmc.default_currency_id,fmc.currency,fmc.is_active,vmaccount.created_on" +
            //            " from vw_accountdetail vmaccount " +
            //            " inner join vw_accountdetail fmc on vmaccount.fmc_id = fmc.id WHERE  ");








            sqlQuery.Append("WITH RankedAccounts AS ( " +
    "SELECT fmc.id, fmc.account_name, fmc.account_type_name, " +
    "fmc.pars_account_manager_name, fmc.pars_cs_specialist_name, fmc.pars_cs_specialist_email, fmc.pars_cs_specialist_mobile, " +
    "fmc.parent_account_name, fmc.phone, fmc.website, fmc.rebate, fmc.market_ranking_name, fmc.fleet_size_name, " +
    "fmc.annual_moves_name, fmc.pay_attention_name, fmc.account_email, fmc.fleet_makeup_cars_or_light_trucks, " +
    "fmc.fleet_makeup_dot, fmc.fleet_makeup_cdl, fmc.default_bill_to_name, fmc.msa_signed, fmc.address_line_1, " +
    "fmc.address_line_2, fmc.address_line_3, fmc.city, fmc.state_id, fmc.state_name, fmc.zip_code, fmc.country_id, " +
    "fmc.country_name, fmc.owner_account_name, fmc.primary_contact_name, fmc.pars_account_manager_phone, " +
    "fmc.pars_account_manager_email, fmc.primary_contact_business_phone, fmc.primary_contact_email, " +
    "fmc.vehicle_in_storage, fmc.fleet_makeup, fmc.fleet_no, fmc.preferred_agreement_id, fmc.preferred_agreement, " +
    "fmc.preferred_price_list_id, fmc.preferred_price_list, fmc.default_currency_id, fmc.currency, fmc.is_active, " +
    "vmaccount.created_on, " +
    "ROW_NUMBER() OVER (PARTITION BY fmc.id ORDER BY vmaccount.created_on DESC) AS RowNum " +
    "FROM vw_accountdetail vmaccount " +
    "INNER JOIN vw_accountdetail fmc ON vmaccount.fmc_id = fmc.id " +
    "WHERE vmaccount.linked_account_id=@linked_account_id ");




            SQLQueryBuilder builder = new SQLQueryBuilder();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                if (!string.IsNullOrEmpty(request.reqParm.advancedFilter))//Advanced Filter
                {
                    try
                    {
                        string queryfilter = builder.BuildQuery(request.reqParm.advancedFilter);
                        if (!string.IsNullOrWhiteSpace(queryfilter))
                            queryfilter = "AND fmc." + queryfilter;
                        sqlQuery.Append(queryfilter);
                    }
                    catch { throw new Exception("PARS_ADVANCED_FILTER_ERROR"); }
                }
                else
                {
                    //FMC-Fleet Side Filter
                    if (request.reqParm.listFilter != null)
                    {
                        if (request.reqParm.listFilter == (int)EnumTypes.AccountSideFilter.ActiveAccount)
                            sqlQuery.Append(" AND fmc.is_active = 1");
                        else if (request.reqParm.listFilter == (int)EnumTypes.AccountSideFilter.InactiveAccount)
                            sqlQuery.Append(" AND fmc.is_active = 0");
                        
                    }
                    else
                    {
                        // Saved Advanced Filter
                       

                        string defaultFilter = await connection.QuerySingleOrDefaultAsync<string>(
                                            @"SELECT TOP 1 filter_json FROM advanced_filter_management  WHERE is_set_default = 1 
                                              AND created_by = @LoggedInUserId  AND entity_name = @EntityName",
                                            new { LoggedInUserId = _currentUserContext.LoggedInUserId, EntityName = "fleet" });
                        if (!string.IsNullOrEmpty(defaultFilter))
                        {
                            try
                            {
                                string queryfilter = builder.BuildQuery(defaultFilter.Replace("\\", ""));
                                if (!string.IsNullOrWhiteSpace(queryfilter))
                                    queryfilter = " AND fmc." + queryfilter;
                                sqlQuery.Append(queryfilter);
                            }
                            catch (Exception) { throw new Exception("PARS_DEFULT_ADVANCED_FILTER_ERROR"); }
                        }
                        else
                            sqlQuery.Append(" AND fmc.is_active = 1");
                    }
                }
                sqlQuery.Append(")SELECT * FROM RankedAccounts WHERE RowNum = 1 ORDER BY created_on DESC;");

                //Generate dynamic query parameter based on searchFilters
                DynamicParameters dynamicParam = new DynamicParameters();
                dynamicParam.Add("@linked_account_id", request.reqParm.accountId);
                fleetFMC.fMCFleets = new List<FleetFMCDto>();
                var result = (await connection.QueryAsync<FleetFMCDto>(sqlQuery.ToString(), dynamicParam, commandType: CommandType.Text)).ToList();
                fleetFMC.fMCFleets = result;
                fleetFMC.totalCount = result.Count;
                
            }
            return fleetFMC;
        }
        /*
        public async Task<FleetFMC> Handle(GetFleetFMCQuery request, CancellationToken cancellationToken)
        {
            FleetFMC fleetFMC = new FleetFMC();
            //Generate dynamic query parameter based on searchFilters
            var dynamicParam = DBHelper.GenerateDynamicParameters(request.searchFilters);
            string whereQry = DBHelper.GenerateDynamicWhereClause(request.searchFilters);
            string andText = string.IsNullOrWhiteSpace(whereQry) ? string.Empty : " AND ";
            dynamicParam.Add("@linked_account_id", request.account_id);
            dynamicParam.Add("@account_name", request.account_name);
            var topRecord = _config["appSettings:TopRecordCount"];
            var parameters = new DynamicParameters(dynamicParam);
            string account = "";
            string where = "";
            string filter = string.Empty;
            if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.Fleet)
                account = " vmaccount.linked_account_id=@linked_account_id ";
            else if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.PARS)
                account = " vmaccount.linked_account_id=@linked_account_id ";
            else if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.Account)
                account = " vmaccount.linked_account_id=@linked_account_id ";

            if (!string.IsNullOrWhiteSpace(account) || !string.IsNullOrWhiteSpace(andText) || !string.IsNullOrWhiteSpace(whereQry))
                where = "where";

            if (!string.IsNullOrEmpty(request.account_name))
            {
                if (!string.IsNullOrEmpty(account))
                    filter = "  and fmc.account_name like  '%' + @account_name + '%' ";
                else
                    filter = " where fmc.account_name like  '%' + @account_name + '%' ";
            }

            var query = @"select distinct TOP " + topRecord + "  fmc.id,fmc.account_name" +
                        ", fmc.account_type_name,fmc.pars_account_manager_name,fmc.pars_cs_specialist_name,fmc.pars_cs_specialist_email,fmc.pars_cs_specialist_mobile,fmc.parent_account_name,fmc.phone,fmc.website, fmc.rebate" +
                        ",fmc.market_ranking_name,fmc.fleet_size_name,fmc.annual_moves_name,fmc.pay_attention_name  ,fmc.account_email" +
                        ",fmc.fleet_makeup_cars_or_light_trucks,fmc.fleet_makeup_dot, fmc.fleet_makeup_cdl,fmc.default_bill_to_name,fmc.msa_signed" +
                        ",fmc.address_line_1,fmc.address_line_2,fmc.address_line_3,fmc.city,fmc.state_id ,fmc.state_name,fmc.zip_code,fmc.country_id,fmc.country_name,fmc.owner_account_name" +
                        ",fmc.primary_contact_name,fmc.pars_account_manager_phone,fmc.pars_account_manager_email" +
                        ",fmc.primary_contact_business_phone,fmc.primary_contact_email,fmc.vehicle_in_storage,fmc.fleet_makeup" +
                        ",fmc.fleet_no,fmc.preferred_agreement_id,fmc.preferred_agreement,fmc.preferred_price_list_id,fmc.preferred_price_list,fmc.default_currency_id,fmc.currency,fmc.is_active from vw_accountdetail vmaccount " +
                        " inner join vw_accountdetail fmc on vmaccount.fmc_id = fmc.id" +
                        " " + where + account + andText + whereQry + filter + "; select count(fmc.id) " +
                         " from vw_accountdetail vmaccount " +
                        " inner join vw_accountdetail fmc on vmaccount.fmc_id = fmc.id" +
                        " " + where + account + andText + whereQry + filter;

            using (var connection = _dbCntx.GetOpenConnection())
            {
                var result = connection.QueryMultiple(query, parameters, commandType: CommandType.Text);
                fleetFMC.fMCFleets = new List<FleetFMCDto>();
                fleetFMC.fMCFleets = (List<FleetFMCDto>)result.Read<FleetFMCDto>().ToList();
                fleetFMC.totalCount = result.Read<int>().First();
            }
            return fleetFMC;
        }
        */

    }
}
