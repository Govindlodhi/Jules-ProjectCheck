﻿using Dapper;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetParsFleetQuery : IRequest<ParsFleet>
    {
        //public string entity_name { get; set; }
        //public string account_name { get; set; }
        //public SearchFilter searchFilters { get; set; }

        public AccountAdvancedFilter reqParm { get; set; }
    }

    public class GetFleetForParsQueryHandler : IRequestHandler<GetParsFleetQuery, ParsFleet>
    {

        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserContext;
        private readonly IConfiguration _config;
        public GetFleetForParsQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserContext, IConfiguration config)
        {
            _dbCntx = dbCntx;
            _currentUserContext = currentUserContext;
            _config = config;
        }

        public async Task<ParsFleet> Handle(GetParsFleetQuery request, CancellationToken cancellationToken)
        {

            ParsFleet parsFleets = new ParsFleet();
            string orderBy = " order by created_on desc";
            var topRecord = _config["appSettings:TopRecordCount"];
            var sqlQuery = new StringBuilder();

            sqlQuery.Append("SELECT top " + topRecord + " id,account_name,fleet_no,account_type_name,pars_account_manager_name," +
                       "pars_cs_specialist_name,pars_cs_specialist_email,pars_cs_specialist_mobile,parent_account_name,phone,website,rebate,market_ranking_name,fleet_size_name," +
                       "annual_moves_name,pay_attention_name,fmc_id,account_email,fleet_makeup,fleet_makeup_cars_or_light_trucks," +
                       "fleet_makeup_dot,fleet_makeup_cdl,default_bill_to_name,msa_signed,address_line_3,city,state_id,state_name,zip_code,country_id," +
                       "country_name,owner_account_name,primary_contact_name,pars_account_manager_phone,pars_account_manager_email,primary_contact_business_phone," +
                       "primary_contact_email,vehicle_in_storage" +
                       ",preferred_agreement_id,preferred_agreement,preferred_price_list_id,preferred_price_list,default_currency_id,currency,is_active" +
                       " from vw_accountdetail" +
                       " where (account_type_id=@account_type_id and linked_account_id is null)  ");


            //Get connection from sql database 
            SQLQueryBuilder builder = new SQLQueryBuilder();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                if (!string.IsNullOrEmpty(request.reqParm.advancedFilter))//Advanced Filter
                {
                    try
                    {
                        string queryfilter = builder.BuildQuery(request.reqParm.advancedFilter);
                        if (!string.IsNullOrWhiteSpace(queryfilter))
                            queryfilter = "AND " + queryfilter;
                        sqlQuery.Append(queryfilter);
                    }
                    catch { throw new Exception("PARS_ADVANCED_FILTER_ERROR"); }
                }
                else
                {
                    //PARS_Fleet Side Filter
                    if (request.reqParm.listFilter != null)
                    {
                        if (request.reqParm.listFilter == (int)EnumTypes.AccountSideFilter.ActiveAccount)
                            sqlQuery.Append(" AND is_active = 1");
                        else if (request.reqParm.listFilter == (int)EnumTypes.AccountSideFilter.InactiveAccount)
                            sqlQuery.Append(" AND is_active = 0");
                    }
                    else
                    {
                        // Saved Advanced Filter
                        string defaultFilter = await connection.QuerySingleOrDefaultAsync<string>(
                                            @"SELECT TOP 1 filter_json FROM advanced_filter_management  WHERE is_set_default = 1 
                                              AND created_by = @LoggedInUserId  AND entity_name = @EntityName",
                                            new { LoggedInUserId = _currentUserContext.LoggedInUserId, EntityName = "fleet" });
                        if (!string.IsNullOrEmpty(defaultFilter))
                        {
                            try
                            {
                                string queryfilter = builder.BuildQuery(defaultFilter.Replace("\\", ""));
                                if (!string.IsNullOrWhiteSpace(queryfilter))
                                    queryfilter = "AND " + queryfilter;
                                sqlQuery.Append(queryfilter);
                            }
                            catch (Exception) { throw new Exception("PARS_DEFULT_ADVANCED_FILTER_ERROR"); }
                        }
                        else
                            sqlQuery.Append(" AND is_active = 1");
                    }
                }
                sqlQuery.Append(orderBy);

                DynamicParameters dynamicParam = new DynamicParameters();
                dynamicParam.Add("@account_type_id", EnumTypes.AccountTypes.Account);
                dynamicParam.Add("@fmc_id", _currentUserContext.AccountId);
                parsFleets.fleetList = new List<ParsFleetDto>();

                var result = (await connection.QueryAsync<ParsFleetDto>(sqlQuery.ToString(),dynamicParam,commandType:CommandType.Text)).ToList();
                parsFleets.fleetList = result;
                parsFleets.totalCount = result.Count;

            }
            return parsFleets;
        }       

  /*
        public async Task<ParsFleet> Handle(GetParsFleetQuery request, CancellationToken cancellationToken)
        {

            ParsFleet parsFleets = new ParsFleet();
            //Generate dynamic query parameter based on searchFilters
            var dynamicParam = DBHelper.GenerateDynamicParameters(request.searchFilters);
            dynamicParam.Add("@account_type_id", EnumTypes.AccountTypes.Account);
            dynamicParam.Add("@fmc_id", _currentUserContext.AccountId);
            dynamicParam.Add("@account_name", request.account_name);

            string whereQry = DBHelper.GenerateDynamicWhereClause(request.searchFilters);
            string andText = string.IsNullOrWhiteSpace(whereQry) ? string.Empty : " AND ";
            string orderBy = " order by created_on desc" ;
            var topRecord = _config["appSettings:TopRecordCount"];
            var parameters = new DynamicParameters(dynamicParam);

            string accountFilt = " ";

                if (!string.IsNullOrWhiteSpace(request.account_name))
            {
                accountFilt = " and account_name like  '%' + @account_name + '%' ";
            }


            var query = @"SELECT top " + topRecord + " id,account_name,fleet_no,account_type_name,pars_account_manager_name," +
                       "pars_cs_specialist_name,pars_cs_specialist_email,pars_cs_specialist_mobile,parent_account_name,phone,website,rebate,market_ranking_name,fleet_size_name," +
                       "annual_moves_name,pay_attention_name,fmc_id,account_email,fleet_makeup,fleet_makeup_cars_or_light_trucks," +
                       "fleet_makeup_dot,fleet_makeup_cdl,default_bill_to_name,msa_signed,address_line_3,city,state_id,state_name,zip_code,country_id," +
                       "country_name,owner_account_name,primary_contact_name,pars_account_manager_phone,pars_account_manager_email,primary_contact_business_phone," +
                       "primary_contact_email,vehicle_in_storage"+
                       ",preferred_agreement_id,preferred_agreement,preferred_price_list_id,preferred_price_list,default_currency_id,currency,is_active" + 
                       " from vw_accountdetail" +
                       " where account_type_id=@account_type_id and linked_account_id is null  " + andText + whereQry + accountFilt + orderBy + " ;" +
                       " select count(vmaccount.id) " +
                       " from vw_accountdetail vmaccount " +
                        " where vmaccount.account_type_id=@account_type_id and linked_account_id is null  " + andText + whereQry + accountFilt +  "";

            //and parent_account_id is  null

            using (var connection = _dbCntx.GetOpenConnection())
            {
                var result = connection.QueryMultiple(query, parameters, commandType: CommandType.Text);
                parsFleets.fleetList = new List<ParsFleetDto>();
                parsFleets.fleetList = (List<ParsFleetDto>)result.Read<ParsFleetDto>().ToList();
                parsFleets.totalCount = result.Read<int>().First();

            }

            return parsFleets;
        }


        */

    }

}
