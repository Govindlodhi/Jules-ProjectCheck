﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetFleetAccountMappedQuery : IRequest<List<FleetAccountMappedDto>>
    {
     public long account_id { get; set; }   
     public long fmc_id { get; set; }
    }
    public class GetFleetAccountMappedQueryHandler : IRequestHandler<GetFleetAccountMappedQuery, List<FleetAccountMappedDto>>
    {
        private readonly ISqlContext _dbCntx;

        public GetFleetAccountMappedQueryHandler(ISqlContext sqlContext)
        {
            _dbCntx = sqlContext;
        }
        public async Task<List<FleetAccountMappedDto>> Handle(GetFleetAccountMappedQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            List<FleetAccountMappedDto> Accounts = new List<FleetAccountMappedDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string where = string.Empty;
                if (request.account_id == 0)
                {
                    where = " where fmc_id=@fmc_id and account_type_id =@account_type and(linked_account_id is null) and a.is_active = 1 ";
                    dp.Add("@fmc_id", request.fmc_id);
                    dp.Add("@account_type", (long)EnumTypes.AccountTypes.Fleet);
                }
                else
                {
                    where = " where fmc_id=@fmc_id and account_type_id =@account_type and(linked_account_id =@accountId or linked_account_id is null) and a.is_active = 1 ";
                    dp.Add("@accountId", request.account_id);
                    dp.Add("@fmc_id", request.fmc_id);
                    dp.Add("@account_type", (long)EnumTypes.AccountTypes.Fleet);
                }
                var query = @"SELECT " +
                                  " a.id,case when a.fleet_no is null then a.account_name else a.fleet_no +' | '+ a.account_name end  name, " +
                                  "case  WHEN linked_account_id IS NULL THEN 0 ELSE 1 end as is_mapped  from vw_accountdetail a "
                                  + where ;


              
                Accounts = (List<FleetAccountMappedDto>)await connection.QueryAsyncWithRetry<FleetAccountMappedDto>(query, dp, commandType: CommandType.Text);
                if (Accounts.Count == 0)
                    Accounts = null;


            }
            return Accounts;
        }
    }
}
