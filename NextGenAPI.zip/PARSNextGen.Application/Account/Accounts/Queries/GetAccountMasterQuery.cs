﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetAccountMasterQuery : IRequest<AccountMasterDto>
    {
        public long? fmc_id { get; set; }
    }
    public class GetAccountMasterDataQueryHandler : IRequestHandler<GetAccountMasterQuery, AccountMasterDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetAccountMasterDataQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<AccountMasterDto> Handle(GetAccountMasterQuery request, CancellationToken cancellationToken)
        {
            AccountMasterDto accountRelatedMasterdata = new AccountMasterDto();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string queryAccounttype = @"SELECT id,name  FROM account_type WHERE is_active = 1;";
                string queryMarketRanking = @"SELECT id,name FROM market_ranking WHERE is_active = 1;";
                string queryFleetSize = @"SELECT id,name FROM fleet_size WHERE is_active = 1;";
                string queryAnnualMoves = @"SELECT id,name FROM annual_moves WHERE is_active = 1;";
                string queryStateName = @"SELECT id,name FROM state WHERE is_active = 1;";
                string queryCountryName = @"SELECT id,name FROM country WHERE is_active = 1;";
                string queryIndustryName = @"SELECT id,name FROM industry WHERE is_active = 1;";
                string querycurrencyName = @"SELECT id,name FROM currency WHERE is_active = 1;";
                string queryUserStatus = @"SELECT id,name FROM user_status WHERE is_active = 1;";
                string queryAccounts = string.Empty;
                string multiSQLQry = queryAccounttype + queryAnnualMoves + queryMarketRanking + queryFleetSize + queryStateName + queryCountryName + queryIndustryName + querycurrencyName + queryUserStatus;
                if (request.fmc_id != null)
                {
                    queryAccounts = @"SELECT MIN(id) AS id,account_name name FROM account
                                      WHERE fmc_id=" + request.fmc_id + "  GROUP BY account_name ORDER BY account_name ;";
                    multiSQLQry = queryAccounttype + queryAnnualMoves + queryMarketRanking + queryFleetSize + queryStateName + queryCountryName + queryIndustryName + querycurrencyName + queryUserStatus + queryAccounts;
                }

                using (var multiResultSet = await connection.QueryMultipleAsync(multiSQLQry))
                {
                    accountRelatedMasterdata.account_types = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    accountRelatedMasterdata.annual_moves_ranges = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    accountRelatedMasterdata.market_rankings = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    accountRelatedMasterdata.fleet_size_options = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    accountRelatedMasterdata.state_name = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    accountRelatedMasterdata.country_name = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    accountRelatedMasterdata.industry_name = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    accountRelatedMasterdata.currency_name = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    accountRelatedMasterdata.user_status = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    if (!string.IsNullOrWhiteSpace(queryAccounts))
                    {
                        accountRelatedMasterdata.account_list = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                        if (accountRelatedMasterdata.account_list != null)
                        {
                            EntityReference entityReference = new EntityReference();
                            entityReference.name = EnumTypes.New_Account.New.ToString() + ' ' + "Company";
                            entityReference.id = (long)EnumTypes.New_Account.New;
                            accountRelatedMasterdata.account_list.Add(entityReference);
                        }
                        else
                        {
                            EntityReference entityReference = new EntityReference();
                            entityReference.name = EnumTypes.New_Account.New.ToString() + ' ' + "Company";
                            entityReference.id = (long)EnumTypes.New_Account.New;
                            accountRelatedMasterdata.account_list.Add(entityReference);
                        }
                    }
                }
            }
            return accountRelatedMasterdata;
        }

    }

}
