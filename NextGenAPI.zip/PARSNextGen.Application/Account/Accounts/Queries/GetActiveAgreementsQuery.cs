﻿using Dapper;
using MediatR;
using Microsoft.Extensions.Azure;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetActiveAgreementsQuery : IRequest<AgreementsDto>
    {
        public long currency_id { get; set; }
    }
    public class GetActiveAgreementsQueryHandler : IRequestHandler<GetActiveAgreementsQuery, AgreementsDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;

        public GetActiveAgreementsQueryHandler(ISqlContext sqlContext, ICurrentUserService currentUserService)
        {
            _dbCntx = sqlContext;
            _currentUserService = currentUserService;
        }
        public async Task<AgreementsDto> Handle(GetActiveAgreementsQuery request, CancellationToken cancellationToken)
        {
            List<ActiveAgreementsDto> activeAgreements = new List<ActiveAgreementsDto>();
            AgreementsDto agreements = new AgreementsDto();
            agreements.preferred_agreement = new List<ActiveAgreementsDto>();
            agreements.fallback_agreement = new List<ActiveAgreementsDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {

                string query = "";
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@accountId", _currentUserService.AccountId);
                dp.Add("@parsAccountId", EnumTypes.Account.PARS);
                dp.Add("@currencyId", request.currency_id);

                query = @"SELECT ag.id,ag.name,agType.name agreement_type,ag.fmc_id, ag.fleet_id from agreement ag " +
                        " inner join user_auth userAuth on ag.created_by=userAuth.id "+
                        " inner join contact userCont on userAuth.contact_id=userCont.id "+
                        " inner join agreement_type agType on ag.agreement_type_id = agType.id " +
                        " where (userCont.account_id=@accountId or userCont.account_id=@parsAccountId) and ag.currency_id=@currencyId and ag.agreement_status_id=1";

                activeAgreements = (List<ActiveAgreementsDto>)await connection.QueryAsyncWithRetry<ActiveAgreementsDto>(query, dp, commandType: CommandType.Text);
                if (activeAgreements.Count>0)
                {

                    agreements.preferred_agreement = new List<ActiveAgreementsDto>();
                    agreements.preferred_agreement = activeAgreements;//.Where(x => x.fmc_id == null).Where(x => x.fleet_id == null).ToList();
                    agreements.fallback_agreement = new List<ActiveAgreementsDto>();
                    agreements.fallback_agreement = activeAgreements.Where(x => x.fmc_id == null).Where(x => x.fleet_id == null).ToList();                               
                }
                

                //#region OLD CONCEPT

                //#region FMC or Fleet currency
                //DynamicParameters dpcurrency = new DynamicParameters();
                ////Get FMC default currency
                //if (request.fmc_id>0)
                //{
                //    dpcurrency.Add("@accountId", request.fmc_id);
                //    string currencyquery = @"SELECT default_currency_id FROM account WHERE id=@accountId";
                //    var fmccurrency = await connection.QueryFirstOrDefaultAsyncWithRetry<Object>(currencyquery, dpcurrency, commandType: CommandType.Text);

                //    if (fmccurrency != null)
                //    {
                //        var attribute = ((IDictionary<String, Object>)fmccurrency);
                //        var currencyId = attribute["default_currency_id"];
                //        if (currencyId != null)
                //        {
                //            fmc_currency_id = Convert.ToInt64(attribute["default_currency_id"].ToString());
                //        }
                //    }
                //}
                ////Get Fleet default currency
                //if (request.fleet_id>0)
                //{
                //    dpcurrency.Add("@accountId", request.fleet_id);
                //    string currencyquery = @"SELECT default_currency_id FROM account WHERE id=@accountId";
                //    var fmccurrency = await connection.QueryFirstOrDefaultAsyncWithRetry<Object>(currencyquery, dpcurrency, commandType: CommandType.Text);

                //    if (fmccurrency != null)
                //    {
                //        var attribute = ((IDictionary<String, Object>)fmccurrency);
                //        var currencyId = attribute["default_currency_id"];
                //        if (currencyId != null)
                //        {
                //            fleet_currency_id = Convert.ToInt64(attribute["default_currency_id"].ToString());
                //        }
                //    }
                //}
                //#endregion End FMC or Fleet currency



                //dp = new DynamicParameters();
                //dp.Add("@fmc_id", request.fmc_id);
                //dp.Add("@fleet_id", request.fleet_id);
                //dp.Add("@agreementStatusId", (long)EnumTypes.Agreement_Status.Active);
                //dp.Add("@fleet_currency_id", fleet_currency_id);
                //dp.Add("@fmc_currency_id", fmc_currency_id);
                //string query = "";
                //if (request.fmc_id > 0 && request.fleet_id > 0)
                //    query = @"SELECT id,name FROM agreement WHERE agreement_status_id=@agreementStatusId AND fmc_id=@fmc_id AND fleet_id=@fleet_id and currency_id=@fleet_currency_id and (end_date>=convert(varchar, getutcdate(), 23) or end_date IS NULL )";
                //if (request.fmc_id > 0 && request.fleet_id == 0)
                //    query = @"SELECT id,name FROM agreement WHERE agreement_status_id=@agreementStatusId AND fmc_id=@fmc_id AND fleet_id is null and currency_id=@fmc_currency_id and (end_date>=convert(varchar, getutcdate(), 23) or end_date IS NULL )";
                //if (request.fmc_id == 0 && request.fleet_id > 0)
                //    query = @"SELECT id,name FROM agreement WHERE agreement_status_id=@agreementStatusId AND fmc_id is null AND fleet_id=@fleet_id and currency_id=@fleet_currency_id and (end_date>=convert(varchar, getutcdate(), 23) or end_date IS NULL )";


                //activeAgreements = (List<ActiveAgreementsDto>)await connection.QueryAsyncWithRetry<ActiveAgreementsDto>(query, dp, commandType: CommandType.Text);

                //#endregion END

            }
            return agreements;
        }
    }
}