﻿using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetAccountUserListForSwitchAccountQuery : IRequest<List<GetAccountUserListForSwitchAccountDto>>
    {
        public long account_id { get; set; }
    }
    public class GetAccountUserListForSwitchAccountQueryHandler : IRequestHandler<GetAccountUserListForSwitchAccountQuery, List<GetAccountUserListForSwitchAccountDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetAccountUserListForSwitchAccountQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<List<GetAccountUserListForSwitchAccountDto>> Handle(GetAccountUserListForSwitchAccountQuery request, CancellationToken cancellationToken)
        {
            List<GetAccountUserListForSwitchAccountDto> accountListDto = new List<GetAccountUserListForSwitchAccountDto>();
            if (_currentUserService.AccountTypeId != (long)EnumTypes.AccountTypes.PARS || request.account_id == 0)
                return null;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string queryAccountList = @"SELECT DISTINCT ua.id AS user_id, CONCAT(c.first_name, ' ', c.middle_name, ' ', c.last_name) AS user_name,
                                            a.account_name,(SELECT STRING_AGG(r2.name, ', ') 
                                            FROM user_role AS ur2
                                            INNER JOIN role r2 ON ur2.role_id = r2.id
                                            WHERE ur2.user_id = ua.id) AS user_role
                                            FROM user_auth ua
                                            LEFT OUTER JOIN contact c ON ua.contact_id = c.id 
                                            INNER JOIN account a ON c.account_id = a.id 
                                            INNER JOIN user_role ur ON ur.user_id = ua.id
                                            INNER JOIN role r ON ur.role_id = r.id
                                            WHERE ua.user_status_id=1 AND c.contact_type_id=1 AND c.is_email_verify=1 AND a.id = " + request.account_id;
                accountListDto = (List<GetAccountUserListForSwitchAccountDto>) await connection.QueryAsyncWithRetry<GetAccountUserListForSwitchAccountDto>(queryAccountList);
            }
            return accountListDto;
        }
    }
}
