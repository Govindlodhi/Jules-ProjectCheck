﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetAccountAddressQuery : IRequest<List<AccountAddressDto>>
    {
        public long account_id { get; set; }
    }
    public class GetAccountAddressByIdQueryHandler : IRequestHandler<GetAccountAddressQuery, List<AccountAddressDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetAccountAddressByIdQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;   
        }
        public async Task<List<AccountAddressDto>> Handle(GetAccountAddressQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            List<AccountAddressDto> addressDTOs = new List<AccountAddressDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var query = @"SELECT " +
                    " a.id AS account_id,a.fleet_no AS fleet_no, a.account_name,a.phone,a.composit_address, a.address_line_1,a.address_line_2,a.address_line_3,a.city," +
                    "a.state_id,st.name AS state_name,st.code AS state_code,a.zip_code,a.country_id," +
                    "coun.name AS country_name FROM  account AS a " +
                    "LEFT JOIN state st ON  a.state_id = st.id " +
                    "LEFT JOIN country coun ON a.country_id = coun.id WHERE a.id=@accountId ";
                dp.Add("@accountId", request.account_id);
                addressDTOs = (List<AccountAddressDto>)await connection.QueryAsyncWithRetry<AccountAddressDto>(query, dp, commandType: CommandType.Text);
            }
            return addressDTOs;
        }
    }
}
