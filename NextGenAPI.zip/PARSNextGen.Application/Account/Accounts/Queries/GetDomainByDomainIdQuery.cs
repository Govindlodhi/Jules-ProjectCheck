﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetDomainByDomainIdQuery : IRequest<List<GetDomainByDomainIdDto>>
    {
        public long id { get; set; }
    }

    public class GetDomainByDomainIdQueryHandler : IRequestHandler<GetDomainByDomainIdQuery, List<GetDomainByDomainIdDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetDomainByDomainIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<List<GetDomainByDomainIdDto>> Handle(GetDomainByDomainIdQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters domain = new DynamicParameters();
            List<GetDomainByDomainIdDto> domainbyid = new List<GetDomainByDomainIdDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"SELECT d.id as id ,d.name as name,d.description as description,
                                d.is_active as is_active,d.account_id as account_id FROM domain as d 
                                WHERE id =@id;";
                domain.Add("@id", request.id);
                domainbyid = (List<GetDomainByDomainIdDto>)await connection.QueryAsyncWithRetry<GetDomainByDomainIdDto>(query, domain, commandType: CommandType.Text);                
            }
            return domainbyid;
        }
    }
}
