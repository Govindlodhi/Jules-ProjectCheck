﻿using PARSNextGen.Application.Master.SupportContact.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class AccountDetailsDto
    {
        public long id { get; set; } 
        public string account_name { get; set; }

        public long? primary_contact_id { get; set; }
        public string primary_contact_name { get; set; }
        public string pars_account_manager_phone { get; set; }
        public string pars_account_manager_email { get; set; }

        public string fleet_no { get; set; }

        public long? account_type_id { get; set; }
        public string account_type_name { get; set; }
        public long? pars_account_manager_id { get; set; }
        public string pars_account_manager_name { get; set; }
        public long? pars_cs_specialist_id { get; set; }
        public string pars_cs_specialist_name { get; set; }

        public long? parent_account_id { get; set; }
        public string parent_account_name { get; set; }
        public string website { get; set; }
        public decimal rebate { get; set; }
        public decimal admin_fee { get; set; }
        public long? market_ranking_id { get; set; }
        public string market_ranking_name { get; set; }
        public long? fleet_size_id { get; set; }
        public string fleet_size_name { get; set; }
        public long? annual_moves_id { get; set; }
        public string annual_moves_name { get; set; }
        public long? pay_attention_id { get; set; }
        public string pay_attention_name { get; set; }
        public long? fmc_id { get; set; }
        public string fmc_name { get; set; }


        public string default_inspection_mailing_address { get; set; }
        public string account_email { get; set; }
        public string fleet_makeup { get; set; }
        public string fleet_makeup_cars_or_light_trucks { get; set; }
        public string fleet_makeup_dot { get; set; }
        public string fleet_makeup_cdl { get; set; }
        public long? default_bill_to_id { get; set; }
        public string default_bill_to_name { get; set; }
        public string default_ns_cust_id { get; set; }
        public bool? msa_signed { get; set; }
        public DateTime? msa_signed_on { get; set; }
        public DateTime? msa_expiry_date { get; set; }
        public string address_line_1 { get; set; }
        public string address_line_2 { get; set; }
        public string address_line_3 { get; set; }
        public string city { get; set; }
        public long? state_id { get; set; }
        public string state_name { get; set; }
        public string zip_code { get; set; }
        public long? country_id { get; set; }
        public string country_name { get; set; }
        public long? industry_id { get; set; }
        public string industry_name { get; set; }
        public string owner_account_name { get; set; }

        
        public string primary_contact_business_phone { get; set; }
        public string primary_contact_email { get; set; }
        public long? vehicle_in_storage { get; set; }

        public long? preferred_agreement_id { get; set; }
        public string preferred_agreement { get; set; }
        public long? preferred_price_list_id { get; set; }
        public string preferred_price_list { get; set; }
        public long? fallback_agreement_id { get; set; }
        public string fallback_agreement { get; set; }
        public long? fallback_price_list_id { get; set; }
        public string fallback_price_list { get; set; }
        public long? default_currency_id { get; set; }
        public string currency { get; set; }
        public Guid? crm_id { get; set; }

        public long? contact_id { get; set; }
        public long? support_contact_id { get; set; }
        public string first_name { get; set; }
        public string middle_name { get; set; }
        public string last_name { get; set; }
        public string phone_1 { get; set; }
        public string primary_email { get; set; }
    }
   
}
