﻿namespace PARSNextGen.Application.Account.Accounts.Queries
{
    public class GetCustomerQueriesListDto
    {
        public long id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string subject { get; set; }
        public string description { get; set; }
        public string remark { get; set; }
        public long to_account_id { get; set; }
        public string to_account_name { get; set; }
        public long from_account_id { get; set; }
        public string from_account_name { get; set; }
        public long query_status_id { get; set; }
        public string query_status { get; set; }
    }
}
