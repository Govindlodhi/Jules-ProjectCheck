﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Contact.GetContacts.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdvancedFilterManagements.Query
{
    public class GetAdvancedFilterListQuery : IRequest<List<AdvancedFilterListDto>>
    {
        public string entity_name;
    }
    public class GetAdvancedFilterListQueryHandler : IRequestHandler<GetAdvancedFilterListQuery, List<AdvancedFilterListDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetAdvancedFilterListQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<List<AdvancedFilterListDto>> Handle(GetAdvancedFilterListQuery request, CancellationToken cancellationToken)
        {
            List<AdvancedFilterListDto> filterList = new List<AdvancedFilterListDto>();
            DynamicParameters dp = new DynamicParameters();
            dp.Add("@created_by", _currentUserService.LoggedInUserId);
            dp.Add("@entity_name", request.entity_name);
            string query = @"SELECT id,entity_name,name filter_name,is_set_default,filter_json ,
                             CASE WHEN updated_on IS NOT NULL THEN updated_on ELSE created_on END AS created_onn
                             FROM advanced_filter_management
                             WHERE entity_name = @entity_name AND created_by = @created_by order by created_onn desc";
            using (var connection = _dbCntx.GetOpenConnection())
            {
                filterList = (List<AdvancedFilterListDto>)await connection.QueryAsyncWithRetry<AdvancedFilterListDto>(query, dp, commandType: CommandType.Text);
            }
            return filterList;
        }
    }
}
