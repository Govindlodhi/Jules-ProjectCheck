﻿namespace PARSNextGen.Application.AdvancedFilterManagements.Query
{
    public class AdvancedFilterListDto
    {
        public long id { get; set; }
        public string filter_name { get; set; }
        public string entity_name { get; set; }
        public string filter_json { get; set; }
        public bool is_set_default { get; set; }       
    }
}
