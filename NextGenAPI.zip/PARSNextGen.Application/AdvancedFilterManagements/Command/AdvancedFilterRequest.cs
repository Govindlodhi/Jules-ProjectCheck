﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdvancedFilterManagement.Command
{
    public class AdvancedFilterRequest
    {
        public long? id { get; set; }
        public string filter_name { get; set; }
        public string entity_name { get; set; }
        public string filter_json { get; set; }
        public bool is_set_default { get; set; } = false;
    }
}
