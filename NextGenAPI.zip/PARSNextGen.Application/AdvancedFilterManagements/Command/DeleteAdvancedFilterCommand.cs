﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdvancedFilterManagements.Command
{
    public class DeleteAdvancedFilterCommand : IRequest<bool>
    {
        public long id { get; set; }
    }
    public class DeleteAdvancedFilterCommandHandler : IRequestHandler<DeleteAdvancedFilterCommand, bool>
    {
        public ICurrentUserService _currentUserService { get; set; }
        public ISqlContext _sqlContext { get; set; }
        public DeleteAdvancedFilterCommandHandler(ICurrentUserService currentUserService, ISqlContext sqlContext)
        {
            _currentUserService = currentUserService;
            _sqlContext = sqlContext;
        }
        public async Task<bool> Handle(DeleteAdvancedFilterCommand request, CancellationToken cancellationToken)
        {
            bool result = false;
            using (var connection = _sqlContext.GetOpenConnection())
            {
                string query = @$"DELETE advanced_filter_management where id = {request.id} AND created_by = {_currentUserService.LoggedInUserId}";
                var data = await connection.ExecuteAsync(query, commandType: CommandType.Text);
                result = data > 0 ? true : false;
            }
            return result;
        }
    }
}
