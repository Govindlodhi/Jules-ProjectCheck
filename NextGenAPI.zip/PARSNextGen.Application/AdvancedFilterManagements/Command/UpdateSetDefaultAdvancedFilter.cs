﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdvancedFilterManagements.Command
{
    public class UpdateSetDefaultAdvancedFilter : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_set_default { get; set; }
    }
    public class UpdateSetDefaultAdvancedFilterHandler : IRequestHandler<UpdateSetDefaultAdvancedFilter, bool>
    {
        public ICurrentUserService _currentUserService { get; set; }
        public ISqlContext _sqlContext { get; set; }
        public UpdateSetDefaultAdvancedFilterHandler(ICurrentUserService currentUserService, ISqlContext sqlContext)
        {
            _currentUserService = currentUserService;
            _sqlContext = sqlContext;
        }
        public async Task<bool> Handle(UpdateSetDefaultAdvancedFilter request, CancellationToken cancellationToken)
        {
            bool result = false;
            using (var connection = _sqlContext.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@id", request.id);
                dp.Add("@is_set_default", request.is_set_default ? 1 : 0);
                dp.Add("@updated_by", _currentUserService.LoggedInUserId);
                var data = await connection.ExecuteAsync("sp_update_advanced_filter_status", dp, commandType: CommandType.StoredProcedure);
                result = data > 0 ? true : false;
            }
            return result;
        }
    }
}
