﻿using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdvancedFilterManagement.Command
{
    public class CreateFilterCommand : IRequest<bool>
    {
        public AdvancedFilterRequest requestParam { get; set; }
    }
    public class CreateFilterCommandHandler : IRequestHandler<CreateFilterCommand, bool>
    {
        private readonly IAdvancedFilterRepository _filterRepo;
        public CreateFilterCommandHandler(IAdvancedFilterRepository filterRepo)
        {
            _filterRepo = filterRepo;
        }
        public async Task<bool> Handle(CreateFilterCommand request, CancellationToken cancellationToken)
        {
            AdvancedFilterDto advancedFilterManage = new AdvancedFilterDto
            {
                id = request.requestParam.id == null ? 0 : (long)request.requestParam.id,
                filter_name = request.requestParam.filter_name,
                entity_name = request.requestParam.entity_name,
                filter_json = request.requestParam.filter_json,
                is_set_default = request.requestParam.is_set_default
            };
            bool result = await _filterRepo.CreateAdvancedFilter(advancedFilterManage);
            return result;
        }
    }
}
