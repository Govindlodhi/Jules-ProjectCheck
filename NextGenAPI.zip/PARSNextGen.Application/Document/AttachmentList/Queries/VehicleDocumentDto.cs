﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Vehicle.AttachmentList.Queries
{
    public class VehicleDocumentDto
    {
        public long id { get; set; }
        public long vehicle_id { get; set; }
        public long vehicle_condition_id { get; set; }
        public long attachment_account_id { get; set; }
        public long attachment_contact_id { get; set; }
        public long client_id { get; set; }
        public long document_type_id { get; set; }
        public string document_type { get; set; }
        public string document_name { get; set; }
        public string base64string { get; set; }
        public string document_uri { get; set; }
        public bool is_active { get; set; }
        public bool is_deleted { get; set; }
        public DateTime created_on { get; set; }
        public long created_by { get; set; }
        public DateTime updated_on { get; set; }
        public long updated_by { get; set; }
    }
}
