﻿using Dapper;
using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Queries
{
    public class DownloadDocumentByIdQuery : IRequest<DownloadDocumentDto>
    {
        public long id { get; set; }
    }
    public class DownloadDocumentByIdQueryHandler : IRequestHandler<DownloadDocumentByIdQuery, DownloadDocumentDto>
    {
        private readonly IConfiguration _config;
        private readonly ISqlContext _dbCntx;

        public DownloadDocumentByIdQueryHandler(IConfiguration config, ISqlContext dbCntx)
        {
            _config = config;
            _dbCntx = dbCntx;
        }

        public async Task<DownloadDocumentDto> Handle(DownloadDocumentByIdQuery request, CancellationToken cancellation)
        {
            DownloadDocumentDto doc = new DownloadDocumentDto();
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"SELECT * from attachment where id = @Id ";
                parameters.Add("@Id", request.id);

                doc = await connection.QueryFirstOrDefaultAsyncWithRetry<DownloadDocumentDto>(querycolumns, parameters, commandType: CommandType.Text);
            }
            return doc;
        }

        public class DownloadDocumentByIdQueryValidator : AbstractValidator<DownloadDocumentByIdQuery>
        {
            public DownloadDocumentByIdQueryValidator()
            {
                RuleFor(x => x.id).NotEmpty();
            }

        }
    }
}
