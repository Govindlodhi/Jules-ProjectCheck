﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Queries
{
    public class GetDocumentMasterQuery : IRequest<DocumentMasterDto>
    {

    }

    public class GetDocumentTypeMasterQueryHandler : IRequestHandler<GetDocumentMasterQuery, DocumentMasterDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetDocumentTypeMasterQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<DocumentMasterDto> Handle(GetDocumentMasterQuery request, CancellationToken cancellationToken)
        {
            DocumentMasterDto documentType = new DocumentMasterDto();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string queryDocumenttype = @"select id,name from document_type where is_active = 1;";

                string multiSQLQry = queryDocumenttype;

                using (var multiResultSet = await connection.QueryMultipleAsync(multiSQLQry))
                {
                    documentType.document_types = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                }
            }
            return documentType;
        }

    }
}

