﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Queries
{
    public class DocumentDto
    {
        public string document_uri { get; set; }
    }
}
