﻿using Dapper;
using FluentValidation;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Queries
{
    public class GetBatchTemplateByIdQuery: IRequest<BatchTemplateDetailsDto>
    {
        public long id { get; set; }
    }
    public class GetBatchTemplateByIdQueryHandler : IRequestHandler<GetBatchTemplateByIdQuery,BatchTemplateDetailsDto>
    {
        private readonly ISqlContext _context;

        public GetBatchTemplateByIdQueryHandler(ISqlContext context)
        {
            _context = context;
        }
        public async Task<BatchTemplateDetailsDto> Handle(GetBatchTemplateByIdQuery req, CancellationToken cancellationToken)
        {
            BatchTemplateDetailsDto batchTemplateDetailsDto = null;
            using (var con = _context.GetOpenConnection())
            {
                var sqlQuery = @"SELECT id, document_name, 
                                    CASE WHEN document_type_id = '1' THEN 'Template-I'
                                    WHEN document_type_id = '2' THEN 'Template-II'
                                    ELSE NULL END AS document_type,document_uri document_url, 
                                    is_active, created_on FROM batch_templates where id = " + req.id + " order by created_on desc;";

                batchTemplateDetailsDto = await con.QueryFirstOrDefaultAsync<BatchTemplateDetailsDto>(sqlQuery,commandType: CommandType.Text);

            }
            return batchTemplateDetailsDto;
        }
        public class GetBatchTemplateByIdQueryValidator : AbstractValidator<GetBatchTemplateByIdQuery>
        {
            public GetBatchTemplateByIdQueryValidator()
            {
                RuleFor(x => x.id).NotEmpty();
            }
        }
    }
}
