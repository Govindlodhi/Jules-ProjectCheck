﻿using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Queries
{
    public class DocumentMasterDto
    {
        public List<EntityReference> document_types { get; set; }
    }
}
