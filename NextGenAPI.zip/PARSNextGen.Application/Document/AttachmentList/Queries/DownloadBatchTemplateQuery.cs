﻿using Dapper;
using FluentValidation;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Queries
{
    public class DownloadBatchTemplateQuery : IRequest<DownloadBatchTemplateDto>
    {
        public long id {  get; set; }
    }
    public class DownloadBatchTemplateQueryHandler : IRequestHandler<DownloadBatchTemplateQuery, DownloadBatchTemplateDto>
    {
        private readonly ISqlContext _dbCntx;

        public DownloadBatchTemplateQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<DownloadBatchTemplateDto> Handle(DownloadBatchTemplateQuery req, CancellationToken cancellationToken)
        {
            DownloadBatchTemplateDto downloadBatchTemplateDto = new DownloadBatchTemplateDto();
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"SELECT * from batch_templates where id = @Id ";
                parameters.Add("@Id", req.id);

                downloadBatchTemplateDto = await connection.QueryFirstOrDefaultAsyncWithRetry<DownloadBatchTemplateDto>(querycolumns, parameters, commandType: CommandType.Text);
            }
            return downloadBatchTemplateDto;
        }
        public class DownloadDocumentByIdQueryValidator : AbstractValidator<DownloadBatchTemplateQuery>
        {
            public DownloadDocumentByIdQueryValidator()
            {
                RuleFor(x => x.id).NotEmpty();
            }
        }
    }
}
