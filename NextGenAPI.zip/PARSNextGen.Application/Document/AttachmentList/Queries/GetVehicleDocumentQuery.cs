﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Vehicle.AttachmentList.Queries
{
    public class GetVehicleDocumentQuery : IRequest<List<VehicleDocumentDto>>
    {
        public long vehicle_id { get; set; }
    }
    public class GetAttachmentListQueryHandler : IRequestHandler<GetVehicleDocumentQuery, List<VehicleDocumentDto>>
    {
        private readonly ISqlContext _sqlCtx;
        public GetAttachmentListQueryHandler(ISqlContext sqlCtx)
        {
            _sqlCtx = sqlCtx;
        }

        public async Task<List<VehicleDocumentDto>>Handle(GetVehicleDocumentQuery request, CancellationToken cancellationToken)
        {
            List<VehicleDocumentDto> attachmentLists = new List<VehicleDocumentDto>();
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _sqlCtx.GetOpenConnection())
            {
                var query = @" SELECT " +
                             " v.id,v.vehicle_id,v.vehicle_condition_id, v.attachment_account_id,v.attachment_contact_id,v.client_id,v.document_type_id,v.document_type,v.document_name,v.base64string, v.document_uri,v.is_active,v.is_deleted,v.created_on,v.created_by,v.updated_on,v.updated_by " +
                             " from vw_attachmentdetail as v where v.vehicle_id = @vehicleId";

                parameters.Add("@vehicleId", request.vehicle_id);

                attachmentLists = (List<VehicleDocumentDto>)await connection.QueryAsyncWithRetry<VehicleDocumentDto>(query, parameters, commandType: CommandType.Text);
            }
            return attachmentLists;
        }
    }
}
