﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Queries
{
    public class DownloadBatchTemplateDto
    {
        public string base64string { get; set; }
        public string document_name { get; set; }
        public string document_uri { get; set; }
    }
}
