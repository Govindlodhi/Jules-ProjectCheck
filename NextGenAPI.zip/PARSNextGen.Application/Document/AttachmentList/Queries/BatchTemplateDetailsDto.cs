﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Queries
{
    public class BatchTemplateDetailsDto
    {
        public long id { get; set; }
        public string document_name { get; set; }
        public string document_type { get; set; }
        public string document_url { get; set; }
        public bool is_active { get; set; }
        public DateTime created_on { get; set; }
    }
}
