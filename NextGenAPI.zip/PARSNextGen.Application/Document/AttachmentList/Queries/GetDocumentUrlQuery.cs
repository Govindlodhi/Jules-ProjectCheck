﻿using Dapper;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Queries
{
    public class GetDocumentUrlQuery : IRequest<DocumentDto>
    {
        public long id { get; set; }
    }
    public class GetDocumentUrlQueryHandler : IRequestHandler<GetDocumentUrlQuery, DocumentDto>
    {
        private readonly IConfiguration _config;
        private readonly ISqlContext _dbCntx;

        public GetDocumentUrlQueryHandler(IConfiguration config, ISqlContext dbCntx)
        {
            _config = config;
            _dbCntx = dbCntx;
        }

        public async Task<DocumentDto> Handle(GetDocumentUrlQuery request, CancellationToken cancellation)
        {
            DocumentDto doc = new DocumentDto();
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"SELECT document_uri from attachment where id = @Id ";
                parameters.Add("@Id", request.id);

                doc = await connection.QueryFirstOrDefaultAsyncWithRetry<DocumentDto>(querycolumns, parameters, commandType: CommandType.Text);
            }
            return doc;
        }

       
    }
}
