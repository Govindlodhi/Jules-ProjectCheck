﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Queries
{
    public class GetBatchTemplateListQuery : IRequest<List<BatchTemplateListDto>>
    {
    }
    public class GetBatchTemplateListQueryHandler : IRequestHandler<GetBatchTemplateListQuery,List<BatchTemplateListDto>>
    {
        public ISqlContext _sqlContext;

        public GetBatchTemplateListQueryHandler(ISqlContext sqlContext)
        {
            _sqlContext = sqlContext;
        }
        public async Task<List<BatchTemplateListDto>> Handle(GetBatchTemplateListQuery request, CancellationToken cancellation)
        {
            List<BatchTemplateListDto> batchTemplateLists = new List<BatchTemplateListDto>();
            using(var con = _sqlContext.GetOpenConnection())
            {
                string query = @"SELECT id, document_name, 
                                    CASE WHEN document_type_id = '1' THEN 'Template-I'
                                    WHEN document_type_id = '2' THEN 'Template-II'
                                    ELSE NULL END AS document_type,document_uri document_url, 
                                    is_active, created_on FROM batch_templates order by created_on desc;";

                batchTemplateLists = (List<BatchTemplateListDto>)await con.QueryAsyncWithRetry<BatchTemplateListDto>(query, commandType: CommandType.Text);
            }
            return batchTemplateLists;
        }
    }
}
