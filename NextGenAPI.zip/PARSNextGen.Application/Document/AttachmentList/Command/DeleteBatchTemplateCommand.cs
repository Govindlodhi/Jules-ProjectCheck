﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Document.AttachmentList.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Command
{
    public class DeleteBatchTemplateCommand : IRequest<bool>
    {
        public long id { get; set; }
    }
    public class DeleteBatchTemplateCommandHandler : IRequestHandler<DeleteBatchTemplateCommand, bool>
    {
        private ISqlContext _sqlContext;
        private readonly IDocumentRepository _documentRepo;

        public DeleteBatchTemplateCommandHandler(ISqlContext sqlContext, IDocumentRepository documentRepo)
        {
            _sqlContext = sqlContext;
            _documentRepo = documentRepo;
        }
        public async Task<bool> Handle(DeleteBatchTemplateCommand req, CancellationToken cancellationToken)
        {
            bool result = false;
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _sqlContext.GetOpenConnection())
            {
                var querycolumns = @"SELECT document_uri from batch_templates where id = @Id ";
                parameters.Add("@Id", req.id);

                var data =  connection.QueryFirstOrDefault<Object>(querycolumns, parameters, commandType: CommandType.Text);
                var attribute = (IDictionary<String, Object>)data;
                if (attribute != null && attribute.ContainsKey("document_uri"))
                {
                    string url = attribute["document_uri"].ToString();
                    result = await _documentRepo.DeleteBatchTemplate(req.id, url);
                }
            }
            return result;
        }
    }
}
