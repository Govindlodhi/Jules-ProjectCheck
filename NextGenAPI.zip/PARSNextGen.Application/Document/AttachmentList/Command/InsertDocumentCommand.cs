﻿using Amazon.Runtime.Internal.Util;
using Azure.Storage.Blobs;
using Dapper;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Command
{
    public class InsertDocumentCommand : IRequest<long>
    {
        public long id { get; set; }
        public long? vehicle_id { get; set; }
        public long? vehicle_condition_id { get; set; }
        public long? contact_id { get; set; }
        public long? account_id { get; set; }
        public long? client_id { get; set; }
        public string? document_name { get; set; }
        public long document_type_id { get; set; }
        public string base64String { get; set; }
   
    }
    public class CreateDocumentHandler : IRequestHandler<InsertDocumentCommand, long>
    {
        private readonly IDocumentRepository _documentRepo;

        public CreateDocumentHandler(IDocumentRepository documentRepo)
        {
            _documentRepo = documentRepo;
        }

        public async Task<long> Handle(InsertDocumentCommand request, CancellationToken cancellationToken)
        {
            var result = await _documentRepo.InsertDocument(request.vehicle_id, request.vehicle_condition_id, request.contact_id, request.account_id, request.client_id,request.document_name, request.document_type_id, request.base64String);
            return result;
        }
    }
}


