﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Command
{
    public class DeleteDocumentCommand : IRequest<bool>
    {
        public long id { get; set; }
    }
    public class DeleteDocumentCommandHandler : IRequestHandler<DeleteDocumentCommand, bool>
    {
        private readonly IDocumentRepository _documentRepo;
        public DeleteDocumentCommandHandler(IDocumentRepository documentRepo)
        {
            _documentRepo = documentRepo;
        }

        public async Task<bool> Handle(DeleteDocumentCommand request, CancellationToken cancellationToken)
        {
            bool result = await _documentRepo.DeleteDocument(request.id);
            return result;
        }
    }
}
