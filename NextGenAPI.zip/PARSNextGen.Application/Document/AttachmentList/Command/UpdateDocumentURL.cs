﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Command
{
    public class UpdateDocumentURL : IRequest<bool>
    {
        public long id { get; set; }
        public string base64String { get; set; }
        public string document_uri { get; set; }
        
    }
    public class UpdateDocumentURLHandler : IRequestHandler<UpdateDocumentURL, bool>
    {
        private readonly IDocumentRepository _documentRepo;
        public UpdateDocumentURLHandler(IDocumentRepository documentRepo)
        {
            _documentRepo = documentRepo;
        }

        public async Task<bool> Handle(UpdateDocumentURL request, CancellationToken cancellationToken)
        {
            bool result = await _documentRepo.UpdateDocumentURL(request.id, request.base64String, request.document_uri);
            return result;
        }
    }
}
