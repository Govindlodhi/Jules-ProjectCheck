﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Command
{
    public class UpdateBatchTemplateCommand : IRequest<bool>
    {
        public UpdateBatchTemplateReq TemplateReq;
    }
    public class UpdateBatchTemplateCommandHandler : IRequestHandler<UpdateBatchTemplateCommand, bool>
    {
        private readonly IDocumentRepository _documentRepo;
        private ISqlContext _sqlContext;

        public UpdateBatchTemplateCommandHandler(IDocumentRepository documentRepo, ISqlContext sqlContext)
        {
            _documentRepo = documentRepo;
            _sqlContext = sqlContext;
        }
        public async Task<bool> Handle(UpdateBatchTemplateCommand req, CancellationToken cancellationToken)
        {
            bool result = false;
            result = await _documentRepo.UpdateBatchTemplate(req.TemplateReq.id,req.TemplateReq.DocumentName, req.TemplateReq.DocumentTypeId, req.TemplateReq.base64String,req.TemplateReq.status,req.TemplateReq.fileUrl);

            return result;
        }
    }
}
