﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Command
{
    public class UpdateDocumentCommand : IRequest<bool>
    {
        public long id { get; set; }
        public long? vehicle_id { get; set; }
        public long? vehicle_condition_id { get; set; }
        public long? contact_id { get; set; }
        public long? account_id { get; set; }
        public long? client_id { get; set; }
        public long document_id { get; set; }
        public string base64String { get; set; }
        public string document_uri { get; set; }
        public bool is_active { get; set; }
        public bool is_deleted { get; set; }
        public DateTime created_on { get; set; }
        public long created_by { get; set; }
        public DateTime? updated_on { get; set; }
        public long? updated_by { get; set; }
    }
    public class UpdateUserStatusCommandHandler : IRequestHandler<UpdateDocumentCommand, bool>
    {
        private readonly IDocumentRepository _documentRepo;
        public UpdateUserStatusCommandHandler(IDocumentRepository documentRepo)
        {
            _documentRepo = documentRepo;
        }

        public async Task<bool> Handle(UpdateDocumentCommand request, CancellationToken cancellationToken)
        {
            bool status = await _documentRepo.UpdateDocument(request.id, request.vehicle_id, request.vehicle_condition_id, request.contact_id, request.account_id, request.client_id, request.document_id, request.base64String, request.document_uri, request.is_active, request.is_deleted, request.created_on, request.created_by, request.updated_on, request.updated_by);
            return status;
        }
    }
}
