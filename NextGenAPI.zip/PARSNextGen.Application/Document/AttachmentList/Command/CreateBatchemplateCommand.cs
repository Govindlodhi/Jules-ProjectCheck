﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Command
{
    public class CreateBatchemplateCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateBatchTemplateReq TemplateReq {  get; set; }
    }
    public class CreateBatchTemplateCommandHandler : IRequestHandler<CreateBatchemplateCommand, Tuple<bool, bool>>
    {
        private readonly IDocumentRepository _documentRepo;
        private ISqlContext _sqlContext;

        public CreateBatchTemplateCommandHandler(IDocumentRepository documentRepo, ISqlContext sqlContext)
        {
            _documentRepo = documentRepo;
            _sqlContext = sqlContext;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateBatchemplateCommand req, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _sqlContext.GetOpenConnection())
            {
                var querycolumns = @"SELECT id from batch_templates where document_type_id = @Id ";
                parameters.Add("@Id", req.TemplateReq.DocumentTypeId);

                var data = connection.QueryFirstOrDefault<Object>(querycolumns, parameters, commandType: CommandType.Text);
                var attribute = (IDictionary<String, Object>)data;
                if (attribute != null && attribute.ContainsKey("id"))
                    return responseT = Tuple.Create(true, false);
                else
                {
                    bool result = await _documentRepo.CreateBatchTemplate(req.TemplateReq.DocumentName, req.TemplateReq.DocumentTypeId, req.TemplateReq.base64String);
                    responseT = Tuple.Create(false, result);
                }
            }

            return responseT;
        }
    }

}
