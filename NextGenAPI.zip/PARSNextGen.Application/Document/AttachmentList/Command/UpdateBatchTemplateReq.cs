﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Command
{
    public class UpdateBatchTemplateReq
    {
        public long id { get; set; }
        public string DocumentName { get; set; }
        public long? DocumentTypeId { get; set; }
        public string base64String { get; set; }
        public string fileUrl { get; set; }
        public bool status { get; set; }
    }
}
