﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Document.AttachmentList.Command
{
    public class UpdateBatchTemplateStatusCommand: IRequest<bool>
    {
        public long id { get; set; }
        public bool status { get; set; }
    }
    public class UpdateBatchTemplateStatusCommandHandler : IRequestHandler<UpdateBatchTemplateStatusCommand, bool>
    {
        private readonly IDocumentRepository _documentRepo;

        public UpdateBatchTemplateStatusCommandHandler(IDocumentRepository documentRepo)
        {
            _documentRepo = documentRepo;
        }
        public async Task<bool> Handle(UpdateBatchTemplateStatusCommand request, CancellationToken cancellationToken)
        {
            var result = await _documentRepo.UpdateBatchTemplateStatus(request.id, request.status);
            return result;
        }
    }
}
    