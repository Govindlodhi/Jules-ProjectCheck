﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.EmailTemplate.Queries
{
    public class GetEmailTemplateDetailsQuery : IRequest<EmailTemplateDetailsDto>
    {
        public long id { get; set; }
    }
    public class GetEmailTemplateDetailsQueryHandler : IRequestHandler<GetEmailTemplateDetailsQuery, EmailTemplateDetailsDto>
    {
        private readonly ISqlContext _dbContext;

        public GetEmailTemplateDetailsQueryHandler(ISqlContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<EmailTemplateDetailsDto> Handle(GetEmailTemplateDetailsQuery req, CancellationToken cancellationToken)
        {
            EmailTemplateDetailsDto emailTemplateDetails = new EmailTemplateDetailsDto();
            using(var conn = _dbContext.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@id", req.id);
                var query = @"select tm.template_id, tm.template_code, tm.description,tm.template_type template_type_id, tt.name template_type,
                                tm.subject,tm.template_text,tm.is_active from template tm
                                left join template_type tt on tm.template_type = tt.id
                                where tm.template_id = @id ";
                emailTemplateDetails = await conn.QueryFirstOrDefaultAsyncWithRetry<EmailTemplateDetailsDto>(query, dp, commandType:CommandType.Text);
            }
            return emailTemplateDetails;
        }
    }
}
