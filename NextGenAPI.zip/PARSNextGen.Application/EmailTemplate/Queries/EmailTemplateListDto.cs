﻿using Amazon.Auth.AccessControlPolicy.ActionIdentifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.EmailTemplate.Queries
{
    public class EmailTemplateListDto
    {
        public long? template_id { get; set; }
        public string template_code { get; set; }
        public string description { get; set; }
        public long? template_type_id { get; set; }
        public string template_type { get; set; }
        public string subject { get; set; }
        public string template_text { get; set; }
        public bool? is_active { get; set; }
      
    }
}
