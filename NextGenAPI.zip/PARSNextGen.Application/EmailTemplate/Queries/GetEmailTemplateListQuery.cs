﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.EmailTemplate.Queries
{
    public class GetEmailTemplateListQuery : IRequest<List<EmailTemplateListDto>>
    {
    }
    public class GetEmailTemplateListQueryHandler : IRequestHandler<GetEmailTemplateListQuery, List<EmailTemplateListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public GetEmailTemplateListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<EmailTemplateListDto>> Handle(GetEmailTemplateListQuery request, CancellationToken cancellationToken)
        {
            List<EmailTemplateListDto> emailTemplateList= new List<EmailTemplateListDto>();
            using(var connection = _dbCntx.GetOpenConnection())
            {
                var query = @"select tm.template_id, tm.template_code, tm.description,tm.template_type template_type_id, tt.name template_type,
                                tm.subject,tm.template_text,tm.is_active
                                from template tm
                                left join template_type tt on tm.template_type = tt.id ";

                emailTemplateList = (List<EmailTemplateListDto>)await connection.QueryAsyncWithRetry<EmailTemplateListDto>(query, commandType:CommandType.Text);
            }
            return emailTemplateList;
        }
    }
}
