﻿using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.EmailTemplate.Queries
{
    public class TemplateTypeMasterListDto
    {
        public List<EntityReference> template_type { get; set; }
    }
}
