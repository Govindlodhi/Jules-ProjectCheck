﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.EmailTemplate.Queries
{
    public class TemplateTypeMasterListQuery : IRequest<TemplateTypeMasterListDto>
    {
    }
    public class TemplateTypeMasterListQueryHandler : IRequestHandler<TemplateTypeMasterListQuery, TemplateTypeMasterListDto>
    {
        private readonly ISqlContext _dbCntx;

        public TemplateTypeMasterListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<TemplateTypeMasterListDto> Handle(TemplateTypeMasterListQuery req, CancellationToken cancellationToken)
        {
            TemplateTypeMasterListDto templateTypeMasterList = new TemplateTypeMasterListDto();
            using(var conn = _dbCntx.GetOpenConnection())
            {
                string queryTemplateType = @"Select id, name from template_type where is_active = 1 ; ";
                string multiSQLQry = queryTemplateType;
                using (var multiResultSet = await conn.QueryMultipleAsync(multiSQLQry))
                {
                    templateTypeMasterList.template_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                }
            }
            return templateTypeMasterList;
        }
    }
}
