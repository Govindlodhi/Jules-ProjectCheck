﻿using MediatR;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.EmailTemplate.Command
{
    public class CreateEmailTemplateCommand : IRequest<bool>
    {
        public CreateEmailTemplateReq createEmailTemplateReq { get; set; }
    }
    public class CreateEmailTemplateCommandHandler : IRequestHandler<CreateEmailTemplateCommand, bool>
    {
        private readonly IEmailTemplateRepository _emailTemplateRepository;

        public CreateEmailTemplateCommandHandler(IEmailTemplateRepository emailTemplateRepository)
        {
            _emailTemplateRepository = emailTemplateRepository;
        }
        public async Task<bool> Handle(CreateEmailTemplateCommand req, CancellationToken cancellationToken)
        {
            bool result = false;
            #region Template_Feilds

            Template template = new Template();
            template.template_code = req.createEmailTemplateReq.template_code;
            template.description = req.createEmailTemplateReq.description;
            template.template_type_id = req.createEmailTemplateReq.template_type_id;
            template.subject = req.createEmailTemplateReq.subject;
            template.template_text = req.createEmailTemplateReq.template_text;

            #endregion End_Template_Feilds

            result = await _emailTemplateRepository.CreateEmailTemplate(template);

            return result;

        }
    }
}
