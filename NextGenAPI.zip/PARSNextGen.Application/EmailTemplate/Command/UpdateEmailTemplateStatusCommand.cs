﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.EmailTemplate.Command
{
    public class UpdateEmailTemplateStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool status { get; set; }
    }
    public class UpdateEmailTemplateStatusCommandHandler : IRequestHandler<UpdateEmailTemplateStatusCommand,bool>
    {
        private readonly IEmailTemplateRepository _emailTemplateRepository;

        public UpdateEmailTemplateStatusCommandHandler(IEmailTemplateRepository emailTemplateRepository)
        {
            _emailTemplateRepository = emailTemplateRepository;
        }
        public async Task<bool> Handle(UpdateEmailTemplateStatusCommand req, CancellationToken cancellationToken)
        {
            bool result = await _emailTemplateRepository.UpdateEmailTemplateStatus(req.id, req.status);
            return result;
        }
    }
}
