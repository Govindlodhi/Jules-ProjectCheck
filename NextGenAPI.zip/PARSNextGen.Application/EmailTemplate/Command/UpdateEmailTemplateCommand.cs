﻿using MediatR;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.EmailTemplate.Command
{
    public class UpdateEmailTemplateCommand : IRequest<bool>
    {
        public UpdateEmailTemplateReq updateEmailTemplateReq;
    }
    public class UpdateEmailTemplateCommandHandler : IRequestHandler<UpdateEmailTemplateCommand, bool>
    {
        private readonly IEmailTemplateRepository _emailTemplateRepository;

        public UpdateEmailTemplateCommandHandler(IEmailTemplateRepository emailTemplateRepository)
        {
            _emailTemplateRepository = emailTemplateRepository;
        }
        public async Task<bool> Handle(UpdateEmailTemplateCommand req, CancellationToken cancellation)
        {
            bool result = false;
            #region Template_Feilds

            Template template = new Template();
            template.template_id = req.updateEmailTemplateReq.id;
            template.template_code = req.updateEmailTemplateReq.template_code;
            template.description = req.updateEmailTemplateReq.description;
            template.template_type_id = req.updateEmailTemplateReq.template_type_id;
            template.subject = req.updateEmailTemplateReq.subject;
            template.template_text = req.updateEmailTemplateReq.template_text;

            #endregion End_Template_Feilds

            result = await _emailTemplateRepository.UpdateEmailTemplate(template);

            return result;
        }
    }
}
