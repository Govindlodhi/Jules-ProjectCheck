﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.PreferenceTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Command
{
    public class CreateReleaseOrderTypeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateReleaseOrderTypeCommandReq createReleaseOrderTypeCommandReq;
    }
    public class CreateReleaseOrderTypeCommandHandler : IRequestHandler<CreateReleaseOrderTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreateReleaseOrderTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateReleaseOrderTypeCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Release_Order_Type_Fields

            ReleaseOrderType releaseOrderType = new ReleaseOrderType();
            releaseOrderType.name = request.createReleaseOrderTypeCommandReq.name.Trim();
            releaseOrderType.description = request.createReleaseOrderTypeCommandReq.description;
            releaseOrderType.is_active = (bool)request.createReleaseOrderTypeCommandReq.is_active;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createReleaseOrderTypeCommandReq.name.Trim());
                string query = @"select id from release_order_type where name = @name";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }

            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreateReleaseOrderType(releaseOrderType);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
