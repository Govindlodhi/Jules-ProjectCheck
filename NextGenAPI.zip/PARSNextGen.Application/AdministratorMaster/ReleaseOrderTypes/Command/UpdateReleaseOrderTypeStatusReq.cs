﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Command
{
    public class UpdateReleaseOrderTypeStatusReq
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
}
