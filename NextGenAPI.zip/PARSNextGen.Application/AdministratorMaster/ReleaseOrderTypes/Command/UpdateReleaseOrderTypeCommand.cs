﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.PreferenceTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Command
{
    public class UpdateReleaseOrderTypeCommand : IRequest<bool>
    {
        public UpdateReleaseOrderTypeCommandReq updateReleaseOrderTypeCommandReq;
    }
    public class UpdateReleaseOrderTypeCommandHandler : IRequestHandler<UpdateReleaseOrderTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateReleaseOrderTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateReleaseOrderTypeCommand request, CancellationToken cancellationToken)
        {

            #region Release_Order_Type_Fields

            ReleaseOrderType releaseOrderType = new ReleaseOrderType();
            releaseOrderType.id = request.updateReleaseOrderTypeCommandReq.id;
            releaseOrderType.name = request.updateReleaseOrderTypeCommandReq.name.Trim();
            releaseOrderType.description = request.updateReleaseOrderTypeCommandReq.description;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from release_order_type where name=@name and id!=@id";
                parameters.Add("@id", request.updateReleaseOrderTypeCommandReq.id);
                parameters.Add("@name", request.updateReleaseOrderTypeCommandReq.name.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateReleaseOrderType(releaseOrderType);
                    return result;
                }

            }
        }
    }
}
