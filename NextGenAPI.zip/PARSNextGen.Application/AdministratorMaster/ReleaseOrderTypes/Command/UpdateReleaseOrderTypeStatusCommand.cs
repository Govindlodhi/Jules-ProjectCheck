﻿using MediatR;
using PARSNextGen.Application.AdministratorMaster.PreferenceTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Command
{
    public class UpdateReleaseOrderTypeStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class UpdateTransportationPreferenceTypeStatusCommandHandler : IRequestHandler<UpdateReleaseOrderTypeStatusCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateTransportationPreferenceTypeStatusCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateReleaseOrderTypeStatusCommand request, CancellationToken cancellationToken)
        {

            bool result = await _administratorRepository.UpdateReleaseOrderTypeStatus(request.id, request.is_active);
            return result;
        }
    }
}
