﻿using MediatR;
using PARSNextGen.Application.AdministratorMaster.PreferenceTypes.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Queries
{
    public class ReleaseOrderTypeListQuery : IRequest<List<ReleaseOrderTypeListDto>>
    {
    }
    public class ReleaseOrderTypeListQueryHandler : IRequestHandler<ReleaseOrderTypeListQuery, List<ReleaseOrderTypeListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public ReleaseOrderTypeListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<ReleaseOrderTypeListDto>> Handle(ReleaseOrderTypeListQuery request, CancellationToken cancellationToken)
        {
            List<ReleaseOrderTypeListDto> preferenceTypeLists = new List<ReleaseOrderTypeListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select id,name as release_order_type, description,is_active from release_order_type  where is_active = 1";
                preferenceTypeLists = (List<ReleaseOrderTypeListDto>)await connection.QueryAsyncWithRetry<ReleaseOrderTypeListDto>(query, null, commandType: CommandType.Text);
            }
            return preferenceTypeLists;
        }
    }
}
