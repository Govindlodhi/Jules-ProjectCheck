﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceRequestTypes.Command
{
    public class CreateServiceRequestTypeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateServiceRequestTypeCommandReq createServiceRequestTypeCommandReq;
    }
    public class CreateRequestTypeCommandHandler : IRequestHandler<CreateServiceRequestTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreateRequestTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateServiceRequestTypeCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Service_Request_Type_Fields

            ServiceRequestType serviceRequestType = new ServiceRequestType();
            serviceRequestType.name = request.createServiceRequestTypeCommandReq.name.Trim();
            serviceRequestType.description = request.createServiceRequestTypeCommandReq.description;
            serviceRequestType.is_active = (bool)request.createServiceRequestTypeCommandReq.is_active;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createServiceRequestTypeCommandReq.name.Trim());
                string query = @"select id from service_request_type where name = @name";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }

            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreateServiceRequestType(serviceRequestType);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
