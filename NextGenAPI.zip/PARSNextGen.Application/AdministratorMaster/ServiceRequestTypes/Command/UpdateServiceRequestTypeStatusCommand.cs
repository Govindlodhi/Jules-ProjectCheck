﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceRequestTypes.Command
{
    public class UpdateServiceRequestTypeStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class UpdateRequestTypeStatusCommandHandler : IRequestHandler<UpdateServiceRequestTypeStatusCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateRequestTypeStatusCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateServiceRequestTypeStatusCommand request, CancellationToken cancellationToken)
        {

            bool result = await _administratorRepository.UpdateServiceRequestTypeStatus(request.id, request.is_active);
            return result;
        }
    }
}
