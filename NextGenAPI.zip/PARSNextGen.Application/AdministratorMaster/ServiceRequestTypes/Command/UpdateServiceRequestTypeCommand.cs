﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceRequestTypes.Command
{
    public class UpdateServiceRequestTypeCommand : IRequest<bool>
    {
        public UpdateServiceRequestTypeCommandReq updateServiceRequestTypeCommandReq;
    }
    public class UpdateServiceRequestTypeCommandHandler : IRequestHandler<UpdateServiceRequestTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateServiceRequestTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateServiceRequestTypeCommand request, CancellationToken cancellationToken)
        {

            #region Service_Request_Type_Fields

            ServiceRequestType serviceRequestType = new ServiceRequestType();
            serviceRequestType.id = request.updateServiceRequestTypeCommandReq.id;
            serviceRequestType.name = request.updateServiceRequestTypeCommandReq.name.Trim();
            serviceRequestType.description = request.updateServiceRequestTypeCommandReq.description;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from service_request_type where name=@name and id!=@id";
                parameters.Add("@id", request.updateServiceRequestTypeCommandReq.id);
                parameters.Add("@name", request.updateServiceRequestTypeCommandReq.name.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateServiceRequestType(serviceRequestType);
                    return result;
                }

            }
        }
    }
}
