﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceRequestTypes.Queries
{
    public class ServiceRequestTypeListQuery : IRequest<List<ServiceRequestTypeListDto>>
    {
    }
    public class ServiceRequestTypeListQueryHandler : IRequestHandler<ServiceRequestTypeListQuery, List<ServiceRequestTypeListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public ServiceRequestTypeListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<ServiceRequestTypeListDto>> Handle(ServiceRequestTypeListQuery request, CancellationToken cancellationToken)
        {
            List<ServiceRequestTypeListDto> serviceRequestTypeLists = new List<ServiceRequestTypeListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select id,name as service_request_type, description,is_active from service_request_type  where is_active = 1";
                serviceRequestTypeLists = (List<ServiceRequestTypeListDto>)await connection.QueryAsyncWithRetry<ServiceRequestTypeListDto>(query, null, commandType: CommandType.Text);
            }
            return serviceRequestTypeLists;
        }
    }
}
