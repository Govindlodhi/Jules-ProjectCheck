﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceRequestTypes.Queries
{
    public class ServiceRequestTypeDetailsDto
    {
        public long id { get; set; }
        public string service_request_type { get; set; }
        public string description { get; set; }
        public bool? is_active { get; set; }
    }
}
