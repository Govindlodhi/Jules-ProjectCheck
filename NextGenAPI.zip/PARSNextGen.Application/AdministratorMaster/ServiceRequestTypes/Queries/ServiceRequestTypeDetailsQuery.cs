﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceRequestTypes.Queries
{
    public class ServiceRequestTypeDetailsQuery : IRequest<ServiceRequestTypeDetailsDto>
    {
        public long id { get; set; }
    }
    public class ServiceRequestTypeDetailsQueryHandler : IRequestHandler<ServiceRequestTypeDetailsQuery, ServiceRequestTypeDetailsDto>
    {
        private readonly ISqlContext _dbCntx;

        public ServiceRequestTypeDetailsQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<ServiceRequestTypeDetailsDto> Handle(ServiceRequestTypeDetailsQuery request, CancellationToken cancellationToken)
        {
            ServiceRequestTypeDetailsDto serviceRequestTypeDetails = new ServiceRequestTypeDetailsDto();
            DynamicParameters dp = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@id", request.id);
                string query = @"select id,name as service_request_type, description,is_active from service_request_type  where id = @id";
                serviceRequestTypeDetails = await connection.QueryFirstOrDefaultAsyncWithRetry<ServiceRequestTypeDetailsDto>(query, dp, commandType: CommandType.Text);
            }
            return serviceRequestTypeDetails;
        }
    }
}
