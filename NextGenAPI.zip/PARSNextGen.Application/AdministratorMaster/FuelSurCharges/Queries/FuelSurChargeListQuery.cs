﻿using MediatR;
using PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FuelSurCharges.Queries
{
    public class FuelSurChargeListQuery : IRequest<List<FuelSurChargeListDto>>
    {
    }
    public class ReleaseOrderTypeListQueryHandler : IRequestHandler<FuelSurChargeListQuery, List<FuelSurChargeListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public ReleaseOrderTypeListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<FuelSurChargeListDto>> Handle(FuelSurChargeListQuery request, CancellationToken cancellationToken)
        {
            List<FuelSurChargeListDto> fuelSurChargeLists = new List<FuelSurChargeListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select fs.id,fs.name as fuel_sur_charge, fs.passenger_car,fs.suv_van,fs.truck_10000_and_less,fs.truck_van_10001_to_14000,
                                fs.truck_van_14001_to_16000,fs.truck_van_16001_to_19500,fs.truck_van_19501_to_26000,fs.truck_bus_26001_to_33000,fs.truck_bus_33001_and_more,
                                fs.other_powered,other_unpowered,fs.unknown,currency_id,cr.name as currency_name,fs.is_active,fs.description from fuel_sur_charges fs
                                LEFT JOIN currency cr on fs.currency_id = cr.id where fs.is_active = 1 ";
                fuelSurChargeLists = (List<FuelSurChargeListDto>)await connection.QueryAsyncWithRetry<FuelSurChargeListDto>(query, null, commandType: CommandType.Text);
            }
            return fuelSurChargeLists;
        }
    }
}
