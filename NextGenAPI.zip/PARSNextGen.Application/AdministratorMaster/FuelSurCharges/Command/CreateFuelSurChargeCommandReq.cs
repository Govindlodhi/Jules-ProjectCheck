﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FuelSurCharges.Command
{
    public class CreateFuelSurChargeCommandReq
    {
        public string name { get; set; }
        public decimal passenger_car { get; set; }
        public decimal suv_van { get; set; }
        public decimal truck_10000_and_less { get; set; }
        public decimal truck_van_10001_to_14000 { get; set; }
        public decimal truck_van_14001_to_16000 { get; set; }
        public decimal truck_van_16001_to_19500 { get; set; }
        public decimal truck_van_19501_to_26000 { get; set; }
        public decimal truck_bus_26001_to_33000 { get; set; }
        public decimal truck_bus_33001_and_more { get; set; }
        public decimal other_powered { get; set; }
        public decimal other_unpowered { get; set; }
        public decimal unknown { get; set; }
        public long currency_id { get; set; }
        public bool is_active { get; set; }
        public string description { get; set; }
    }
}
