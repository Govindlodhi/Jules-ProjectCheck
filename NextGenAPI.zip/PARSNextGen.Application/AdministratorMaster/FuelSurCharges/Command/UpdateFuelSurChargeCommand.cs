﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.FuelTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FuelSurCharges.Command
{
    public class UpdateFuelSurChargeCommand : IRequest<bool>
    {
        public UpdateFuelSurChargeCommandReq updateFuelSurChargeCommandReq;
    }
    public class UpdateFuelSurChargeCommandHandler : IRequestHandler<UpdateFuelSurChargeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateFuelSurChargeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateFuelSurChargeCommand request, CancellationToken cancellationToken)
        {

            #region Fuel_Sur_Charge_Type_Fields

            FuelSurCharge fuelSurCharge = new FuelSurCharge();

            fuelSurCharge.id = request.updateFuelSurChargeCommandReq.id;
            fuelSurCharge.name = request.updateFuelSurChargeCommandReq.name.Trim();
            fuelSurCharge.passenger_car = request.updateFuelSurChargeCommandReq.passenger_car;
            fuelSurCharge.suv_van = request.updateFuelSurChargeCommandReq.suv_van;
            fuelSurCharge.truck_10000_and_less = request.updateFuelSurChargeCommandReq.truck_10000_and_less;
            fuelSurCharge.truck_van_10001_to_14000 = request.updateFuelSurChargeCommandReq.truck_van_10001_to_14000;
            fuelSurCharge.truck_van_14001_to_16000 = request.updateFuelSurChargeCommandReq.truck_van_14001_to_16000;
            fuelSurCharge.truck_van_16001_to_19500 = request.updateFuelSurChargeCommandReq.truck_van_16001_to_19500;
            fuelSurCharge.truck_van_19501_to_26000 = request.updateFuelSurChargeCommandReq.truck_van_19501_to_26000;
            fuelSurCharge.truck_bus_26001_to_33000 = request.updateFuelSurChargeCommandReq.truck_bus_26001_to_33000;
            fuelSurCharge.truck_bus_33001_and_more = request.updateFuelSurChargeCommandReq.truck_bus_33001_and_more;
            fuelSurCharge.other_powered = request.updateFuelSurChargeCommandReq.other_powered;
            fuelSurCharge.other_unpowered = request.updateFuelSurChargeCommandReq.other_unpowered;
            fuelSurCharge.unknown = request.updateFuelSurChargeCommandReq.unknown;
            fuelSurCharge.currency_id = request.updateFuelSurChargeCommandReq.currency_id;
            fuelSurCharge.description = request.updateFuelSurChargeCommandReq.description;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from fuel_sur_charges where name=@name and id!=@id";
                parameters.Add("@id", request.updateFuelSurChargeCommandReq.id);
                parameters.Add("@name", request.updateFuelSurChargeCommandReq.name.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateFuelSurCharges(fuelSurCharge);
                    return result;
                }

            }
        }
    }
}
