﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.FuelTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FuelSurCharges.Command
{
    public class CreateFuelSurChargeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateFuelSurChargeCommandReq createFuelSurChargeCommandReq;
    }
    public class CreateFuelSurChargeCommandHandler : IRequestHandler<CreateFuelSurChargeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreateFuelSurChargeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateFuelSurChargeCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Fuel_Sur_Charge_Type_Fields

            FuelSurCharge fuelSurCharge = new FuelSurCharge();

            fuelSurCharge.name = request.createFuelSurChargeCommandReq.name.Trim();
            fuelSurCharge.passenger_car = request.createFuelSurChargeCommandReq.passenger_car;
            fuelSurCharge.suv_van = request.createFuelSurChargeCommandReq.suv_van;
            fuelSurCharge.truck_10000_and_less = request.createFuelSurChargeCommandReq.truck_10000_and_less;
            fuelSurCharge.truck_van_10001_to_14000 = request.createFuelSurChargeCommandReq.truck_van_10001_to_14000;
            fuelSurCharge.truck_van_14001_to_16000 = request.createFuelSurChargeCommandReq.truck_van_14001_to_16000;
            fuelSurCharge.truck_van_16001_to_19500 = request.createFuelSurChargeCommandReq.truck_van_16001_to_19500;
            fuelSurCharge.truck_van_19501_to_26000 = request.createFuelSurChargeCommandReq.truck_van_19501_to_26000;
            fuelSurCharge.truck_bus_26001_to_33000 = request.createFuelSurChargeCommandReq.truck_bus_26001_to_33000;
            fuelSurCharge.truck_bus_33001_and_more = request.createFuelSurChargeCommandReq.truck_bus_33001_and_more;
            fuelSurCharge.other_powered = request.createFuelSurChargeCommandReq.other_powered;
            fuelSurCharge.other_unpowered = request.createFuelSurChargeCommandReq.other_unpowered;
            fuelSurCharge.unknown = request.createFuelSurChargeCommandReq.unknown;
            fuelSurCharge.currency_id = request.createFuelSurChargeCommandReq.currency_id;
            fuelSurCharge.description = request.createFuelSurChargeCommandReq.description;
            fuelSurCharge.is_active = request.createFuelSurChargeCommandReq.is_active;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createFuelSurChargeCommandReq.name.Trim());
                string query = @"select id from fuel_sur_charges where name = @name";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }

            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreateFuelSurCharges(fuelSurCharge);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
