﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FuelTypes.Queries
{
    public class FuelTypeListDto
    {
        public long id { get; set; }
        public string fuel_type { get; set; }
        public string description { get; set; }
        public bool? is_active { get; set; }
    }
}
