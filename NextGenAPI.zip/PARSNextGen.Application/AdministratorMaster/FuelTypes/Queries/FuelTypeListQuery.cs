﻿using MediatR;
using PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FuelTypes.Queries
{
    public class FuelTypeListQuery : IRequest<List<FuelTypeListDto>>
    {
    }
    public class FuelTypeListQueryHandler : IRequestHandler<FuelTypeListQuery, List<FuelTypeListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public FuelTypeListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<FuelTypeListDto>> Handle(FuelTypeListQuery request, CancellationToken cancellationToken)
        {
            List<FuelTypeListDto> fuelTypeLists = new List<FuelTypeListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select id,name as fuel_type, description,is_active from fuel_type  where is_active = 1";
                fuelTypeLists = (List<FuelTypeListDto>)await connection.QueryAsyncWithRetry<FuelTypeListDto>(query, null, commandType: CommandType.Text);
            }
            return fuelTypeLists;
        }
    }
}
