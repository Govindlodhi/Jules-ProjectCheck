﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FuelTypes.Command
{
    public class CreateFuelTypeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateFuelTypeCommandReq createFuelTypeCommandReq;
    }
    public class CreateFuelTypeCommandHandler : IRequestHandler<CreateFuelTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreateFuelTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateFuelTypeCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Fuel_Type_Fields

            FuelType fuelType = new FuelType();
            fuelType.name = request.createFuelTypeCommandReq.name.Trim();
            fuelType.description = request.createFuelTypeCommandReq.description;
            fuelType.is_active = (bool)request.createFuelTypeCommandReq.is_active;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createFuelTypeCommandReq.name.Trim());
                string query = @"select id from fuel_type where name = @name";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }

            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreateFuelType(fuelType);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
