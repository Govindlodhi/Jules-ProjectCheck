﻿using MediatR;
using PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FuelTypes.Command
{
    public class UpdateFuelTypeStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class UpdateFuelTypeStatusCommandHandler : IRequestHandler<UpdateFuelTypeStatusCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateFuelTypeStatusCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateFuelTypeStatusCommand request, CancellationToken cancellationToken)
        {

            bool result = await _administratorRepository.UpdateFuelTypeStatus(request.id, request.is_active);
            return result;
        }
    }
}
