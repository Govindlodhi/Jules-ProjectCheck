﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.ReleaseOrderTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FuelTypes.Command
{
    public class UpdateFuelTypeCommand : IRequest<bool>
    {
        public UpdateFuelTypeCommandReq updateFuelTypeCommandReq;
    }
    public class UpdateFuelTypeCommandHandler : IRequestHandler<UpdateFuelTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateFuelTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateFuelTypeCommand request, CancellationToken cancellationToken)
        {

            #region Fuel_Type_Fields

            FuelType fuelType = new FuelType();
            fuelType.id = request.updateFuelTypeCommandReq.id;
            fuelType.name = request.updateFuelTypeCommandReq.name;
            fuelType.description = request.updateFuelTypeCommandReq.description;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from fuel_type where name=@name and id!=@id";
                parameters.Add("@id", request.updateFuelTypeCommandReq.id);
                parameters.Add("@name", request.updateFuelTypeCommandReq);
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateFuelType(fuelType);
                    return result;
                }

            }
        }
    }
}
