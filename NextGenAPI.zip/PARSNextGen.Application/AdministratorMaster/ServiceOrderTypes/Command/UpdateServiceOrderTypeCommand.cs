﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Command
{
    public class UpdateServiceOrderTypeCommand : IRequest<bool>
    {
        public UpdateServiceOrderTypeCommandReq updateServiceOrderTypeCommandReq;
    }
    public class UpdateServiceOrderTypeCommandHandler : IRequestHandler<UpdateServiceOrderTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateServiceOrderTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateServiceOrderTypeCommand request, CancellationToken cancellationToken)
        {

            #region Service_Order_Type_Fields

            ServiceOrderType serviceOrderType = new ServiceOrderType();
            serviceOrderType.id = request.updateServiceOrderTypeCommandReq.id;
            serviceOrderType.name = request.updateServiceOrderTypeCommandReq.name.Trim();
            serviceOrderType.description = request.updateServiceOrderTypeCommandReq.description;
            serviceOrderType.icon = request.updateServiceOrderTypeCommandReq.icon;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from service_order_type where name=@name and id!=@id";
                parameters.Add("@id", request.updateServiceOrderTypeCommandReq.id);
                parameters.Add("@name", request.updateServiceOrderTypeCommandReq.name.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateServiceOrderType(serviceOrderType);
                    return result;
                }

            }
        }
    }
}
