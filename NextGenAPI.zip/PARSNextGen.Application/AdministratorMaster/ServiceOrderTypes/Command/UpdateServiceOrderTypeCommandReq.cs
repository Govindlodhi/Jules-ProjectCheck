﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Command
{
    public class UpdateServiceOrderTypeCommandReq
    {
        public long id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string icon { get; set; }
    }
}
