﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Command
{
    public class CreateServiceOrderTypeCommand : IRequest<Tuple<bool,bool>>
    {
        public CreateServiceOrderTypeCommandReq createServiceOrderTypeCommandReq;
    }
    public class CreateRequestTypeCommandHandler : IRequestHandler<CreateServiceOrderTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreateRequestTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateServiceOrderTypeCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Service_Order_Type_Fields

            ServiceOrderType serviceOrderType = new ServiceOrderType();
            serviceOrderType.name = request.createServiceOrderTypeCommandReq.name.Trim();
            serviceOrderType.description = request.createServiceOrderTypeCommandReq.description;
            serviceOrderType.is_active = (bool)request.createServiceOrderTypeCommandReq.is_active;
            serviceOrderType.icon = request.createServiceOrderTypeCommandReq.icon;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createServiceOrderTypeCommandReq.name.Trim());
                string query = @"select id from service_order_type where name = @name";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }

            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreateServiceOrderType(serviceOrderType);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
