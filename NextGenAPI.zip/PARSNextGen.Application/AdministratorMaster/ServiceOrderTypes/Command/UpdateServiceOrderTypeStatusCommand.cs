﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Command
{
    public class UpdateServiceOrderTypeStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class UpdateServiceOrderTypeStatusCommandHandler : IRequestHandler<UpdateServiceOrderTypeStatusCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateServiceOrderTypeStatusCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateServiceOrderTypeStatusCommand request, CancellationToken cancellationToken)
        {

            bool result = await _administratorRepository.UpdateServiceOrderTypeStatus(request.id, request.is_active);
            return result;
        }
    }
}
