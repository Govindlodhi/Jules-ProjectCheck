﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Queries
{
    public class ServiceOrderTypeListDto
    {
        public long id { get; set; }
        public string service_order_type { get; set; }
        public string description { get; set; }
        public bool? is_active { get; set; }
        public string icon { get; set; }
    }
}
