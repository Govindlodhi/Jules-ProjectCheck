﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Queries
{
    public class ServiceOrderTypeDetailsQuery : IRequest<ServiceOrderTypeDetailsDto>
    {
        public long id { get; set; }
    }
    public class ServiceOrderTypeDetailsQueryHandler : IRequestHandler<ServiceOrderTypeDetailsQuery, ServiceOrderTypeDetailsDto>
    {
        private readonly ISqlContext _dbCntx;

        public ServiceOrderTypeDetailsQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<ServiceOrderTypeDetailsDto> Handle(ServiceOrderTypeDetailsQuery request, CancellationToken cancellationToken)
        {
            ServiceOrderTypeDetailsDto serviceOrderTypeDetailsDto = new ServiceOrderTypeDetailsDto();
            DynamicParameters dp = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@id", request.id);
                string query = @"select id,name as service_order_type, description,is_active,icon from service_order_type  where id = @id";
                serviceOrderTypeDetailsDto = await connection.QueryFirstOrDefaultAsyncWithRetry<ServiceOrderTypeDetailsDto>(query, dp, commandType: CommandType.Text);
            }
            return serviceOrderTypeDetailsDto;
        }
    }
}
