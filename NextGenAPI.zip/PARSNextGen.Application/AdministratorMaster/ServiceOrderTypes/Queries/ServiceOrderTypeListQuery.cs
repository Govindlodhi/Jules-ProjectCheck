﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Queries
{
    public class ServiceOrderTypeListQuery : IRequest<List<ServiceOrderTypeListDto>>
    {
    }
    public class ServiceOrderTypeListQueryHandler : IRequestHandler<ServiceOrderTypeListQuery, List<ServiceOrderTypeListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public ServiceOrderTypeListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<ServiceOrderTypeListDto>> Handle(ServiceOrderTypeListQuery request, CancellationToken cancellationToken)
        {
            List<ServiceOrderTypeListDto> serviceOrderTypeLists = new List<ServiceOrderTypeListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select id,name as service_order_type, description,is_active,icon from service_order_type  where is_active = 1";
                serviceOrderTypeLists = (List<ServiceOrderTypeListDto>)await connection.QueryAsyncWithRetry<ServiceOrderTypeListDto>(query, null, commandType: CommandType.Text);
            }
            return serviceOrderTypeLists;
        }
    }
}

