﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.FuelTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.HubLocations.Command
{
    public class CreateHubLocationCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateHubLocationCommandReq createHubLocationCommandReq { get; set; }
    }
    public class CreateHubLocationCommandHandler : IRequestHandler<CreateHubLocationCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreateHubLocationCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateHubLocationCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Hub_Location_Fields

            HubLocation hubLocation = new HubLocation();
            hubLocation.zip_code = request.createHubLocationCommandReq.zip_code.Trim();
            hubLocation.country_id = request.createHubLocationCommandReq.country_id;
            hubLocation.state_id = request.createHubLocationCommandReq.state_id;
            hubLocation.city = request.createHubLocationCommandReq.city;
            hubLocation.currency_id = request.createHubLocationCommandReq.currency_id;
            hubLocation.rate = request.createHubLocationCommandReq.rate;
            hubLocation.additional_hub_fee = request.createHubLocationCommandReq.additional_hub_fee;
            hubLocation.is_active = request.createHubLocationCommandReq.is_active;
            hubLocation.description = request.createHubLocationCommandReq.description;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@zipCode", request.createHubLocationCommandReq.zip_code.Trim());
                string query = @"select id from hub_location where zip_code = @zipCode";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }

            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreateHubLocation(hubLocation);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
