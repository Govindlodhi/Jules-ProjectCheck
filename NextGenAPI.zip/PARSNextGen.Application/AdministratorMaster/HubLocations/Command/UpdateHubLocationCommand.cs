﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.FuelTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.HubLocations.Command
{
    public class UpdateHubLocationCommand : IRequest<bool>
    {
        public UpdateHubLocationCommandReq updateHubLocationCommandReq;
    }
    public class UpdateHubLocationCommandHandler : IRequestHandler<UpdateHubLocationCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateHubLocationCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateHubLocationCommand request, CancellationToken cancellationToken)
        {

            #region Hub_Location_Fields

            HubLocation hubLocation = new HubLocation();
            hubLocation.id = request.updateHubLocationCommandReq.id;
            hubLocation.zip_code = request.updateHubLocationCommandReq.zip_code.Trim();
            hubLocation.country_id = request.updateHubLocationCommandReq.country_id;
            hubLocation.state_id = request.updateHubLocationCommandReq.state_id;
            hubLocation.city = request.updateHubLocationCommandReq.city;
            hubLocation.currency_id = request.updateHubLocationCommandReq.currency_id;
            hubLocation.rate = request.updateHubLocationCommandReq.rate;
            hubLocation.additional_hub_fee = request.updateHubLocationCommandReq.additional_hub_fee;
            hubLocation.description = request.updateHubLocationCommandReq.description;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from hub_location where zip_code=@zip_code and id!=@id";
                parameters.Add("@id", request.updateHubLocationCommandReq.id);
                parameters.Add("@zip_code", request.updateHubLocationCommandReq.zip_code.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateHubLocation(hubLocation);
                    return result;
                }

            }
        }
    }
}
