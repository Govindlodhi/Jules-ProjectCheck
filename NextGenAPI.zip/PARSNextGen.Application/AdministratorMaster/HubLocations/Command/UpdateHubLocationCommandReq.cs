﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.HubLocations.Command
{
    public class UpdateHubLocationCommandReq
    {
        public long id { get; set; }
        public string zip_code { get; set; }
        public long country_id { get; set; }
        public long state_id { get; set; }
        public string city { get; set; }
        public long currency_id { get; set; }
        public decimal rate { get; set; }
        public decimal additional_hub_fee { get; set; }
        public string description { get; set; }
    }
}
