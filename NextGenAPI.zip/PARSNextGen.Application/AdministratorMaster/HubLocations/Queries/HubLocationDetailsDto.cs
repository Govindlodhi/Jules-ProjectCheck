﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.HubLocations.Queries
{
    public class HubLocationDetailsDto
    {
        public long id { get; set; }
        public string zip_code { get; set; }
        public long country_id { get; set; }
        public string country { get; set; }
        public long state_id { get; set; }
        public string state { get; set; }
        public string city { get; set; }
        public long currency_id { get; set; }
        public string currency { get; set; }
        public decimal rate { get; set; }
        public decimal additional_hub_fee { get; set; }
        public bool is_active { get; set; }
        public DateTime created_on { get; set; }
    }
}
