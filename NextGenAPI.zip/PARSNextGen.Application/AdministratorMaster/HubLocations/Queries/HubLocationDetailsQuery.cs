﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.HubLocations.Queries
{
    public class HubLocationDetailsQuery : IRequest<HubLocationDetailsDto>
    {
        public long id { get; set; }
    }
    public class HubLocationDetailsQueryHandler : IRequestHandler<HubLocationDetailsQuery, HubLocationDetailsDto>
    {
        private readonly ISqlContext _dbCntx;

        public HubLocationDetailsQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<HubLocationDetailsDto> Handle(HubLocationDetailsQuery request, CancellationToken cancellationToken)
        {
            HubLocationDetailsDto hubLocationDetails = new HubLocationDetailsDto();
            DynamicParameters dp = new DynamicParameters();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@id", request.id);
                string query = @"select hl.id,hl.zip_code,hl.country_id,ct.name as country,hl.state_id,st.name as state,hl.city,hl.currency_id,
                                cr.name as currency, hl.rate,hl.additional_hub_fee,hl.is_active,hl.created_on
                                from hub_location hl
                                LEFT JOIN country ct on hl.country_id = ct.id
                                LEFT JOIN state st on hl.state_id = st.id
                                LEFT JOIN currency cr on hl.currency_id = cr.id
                                where hl.id = @id ";
                hubLocationDetails = await connection.QueryFirstOrDefaultAsyncWithRetry<HubLocationDetailsDto>(query, dp, commandType: CommandType.Text);
            }
            return hubLocationDetails;
        }
    }
}
