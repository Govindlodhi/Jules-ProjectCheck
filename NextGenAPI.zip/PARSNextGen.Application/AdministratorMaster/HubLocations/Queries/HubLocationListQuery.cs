﻿using MediatR;
using PARSNextGen.Application.AdministratorMaster.FuelTypes.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.HubLocations.Queries
{
    public class HubLocationListQuery : IRequest<List<HubLocationListDto>>
    {
    }
    public class HubLocationListQueryHandler : IRequestHandler<HubLocationListQuery, List<HubLocationListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public HubLocationListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<HubLocationListDto>> Handle(HubLocationListQuery request, CancellationToken cancellationToken)
        {
            List<HubLocationListDto> hubLocationLists = new List<HubLocationListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select hl.id,hl.zip_code,hl.country_id,ct.name as country,hl.state_id,st.name as state,hl.city,hl.currency_id,
                                cr.name as currency, hl.rate,hl.additional_hub_fee,hl.is_active,hl.created_on
                                from hub_location hl
                                LEFT JOIN country ct on hl.country_id = ct.id
                                LEFT JOIN state st on hl.state_id = st.id
                                LEFT JOIN currency cr on hl.currency_id = cr.id
                                where hl.is_active = 1 ";
                hubLocationLists = (List<HubLocationListDto>)await connection.QueryAsyncWithRetry<HubLocationListDto>(query, null, commandType: CommandType.Text);
            }
            return hubLocationLists;
        }
    }
}
