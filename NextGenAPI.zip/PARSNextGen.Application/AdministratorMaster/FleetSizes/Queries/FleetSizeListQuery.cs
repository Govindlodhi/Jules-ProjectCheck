﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FleetSizes.Queries
{
    public class FleetSizeListQuery : IRequest<List<FleetSizeListDto>>
    {
    }
    public class FleetSizeListQueryHandler : IRequestHandler<FleetSizeListQuery, List<FleetSizeListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public FleetSizeListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<FleetSizeListDto>> Handle(FleetSizeListQuery request, CancellationToken cancellationToken)
        {
            List<FleetSizeListDto> fleetSizeList = new List<FleetSizeListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select id,name as fleet_size, description,is_active from fleet_size  where is_active = 1";
                fleetSizeList = (List<FleetSizeListDto>)await connection.QueryAsyncWithRetry<FleetSizeListDto>(query, null, commandType: CommandType.Text);
            }
            return fleetSizeList;
        }
    }
}
