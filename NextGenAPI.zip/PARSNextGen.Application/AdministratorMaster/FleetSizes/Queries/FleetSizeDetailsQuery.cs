﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FleetSizes.Queries
{
    public class FleetSizeDetailsQuery : IRequest<FleetSizeDetailsDto>
    {
        public long id { get; set; }
    }
    public class FleetSizeDetailsQueryHandler : IRequestHandler<FleetSizeDetailsQuery, FleetSizeDetailsDto>
    {
        private readonly ISqlContext _dbCntx;

        public FleetSizeDetailsQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<FleetSizeDetailsDto> Handle(FleetSizeDetailsQuery request, CancellationToken cancellationToken)
        {
            FleetSizeDetailsDto fleetSizeDetailsDto = new FleetSizeDetailsDto();
            DynamicParameters dp = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@id", request.id);
                string query = @"select id,name as fleet_size, description,is_active from fleet_size  where id = @id";
                fleetSizeDetailsDto = await connection.QueryFirstOrDefaultAsyncWithRetry<FleetSizeDetailsDto>(query, dp, commandType: CommandType.Text);
            }
            return fleetSizeDetailsDto;
        }
    }

}
