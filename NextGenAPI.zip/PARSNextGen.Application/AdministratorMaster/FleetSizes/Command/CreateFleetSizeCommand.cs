﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FleetSizes.Command
{
    public class CreateFleetSizeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateFleetSizeCommandReq createFleetSizeCommandReq;
    }
    public class CreateFleetSizeCommandHandler : IRequestHandler<CreateFleetSizeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreateFleetSizeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateFleetSizeCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Fleet_Size_Fields

            FleetSize fleetSize = new FleetSize();
            fleetSize.name = request.createFleetSizeCommandReq.name.Trim();
            fleetSize.description = request.createFleetSizeCommandReq.description;
            fleetSize.is_active = (bool)request.createFleetSizeCommandReq.is_active;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createFleetSizeCommandReq.name.Trim());
                string query = @"select id from fleet_size where name = @name";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }

            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreateFleetSize(fleetSize);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
