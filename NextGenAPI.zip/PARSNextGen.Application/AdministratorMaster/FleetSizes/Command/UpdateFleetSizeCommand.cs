﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FleetSizes.Command
{
    public class UpdateFleetSizeCommand : IRequest<bool>
    {
        public UpdateFleetSizeCommandReq updateFleetSizeCommandReq;
    }
    public class UpdateFleetSizeCommandHandler : IRequestHandler<UpdateFleetSizeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateFleetSizeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateFleetSizeCommand request, CancellationToken cancellationToken)
        {

            #region Fleet_Size_Fields

            FleetSize fleetSize = new FleetSize();
            fleetSize.id = request.updateFleetSizeCommandReq.id;
            fleetSize.name = request.updateFleetSizeCommandReq.name.Trim();
            fleetSize.description = request.updateFleetSizeCommandReq.description;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from fleet_size where name=@name and id!=@id";
                parameters.Add("@id", request.updateFleetSizeCommandReq.id);
                parameters.Add("@name", request.updateFleetSizeCommandReq.name.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateFleetSize(fleetSize);
                    return result;
                }

            }
        }
    }
}
