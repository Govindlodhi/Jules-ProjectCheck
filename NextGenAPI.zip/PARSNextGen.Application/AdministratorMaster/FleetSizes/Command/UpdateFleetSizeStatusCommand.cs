﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.FleetSizes.Command
{
    public class UpdateFleetSizeStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class UpdateFleetSizeStatusCommandHandler : IRequestHandler<UpdateFleetSizeStatusCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateFleetSizeStatusCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateFleetSizeStatusCommand request, CancellationToken cancellationToken)
        {

            bool result = await _administratorRepository.UpdateFleetSizeStatus(request.id, request.is_active);
            return result;
        }
    }
}
