﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.TransportationPreferenceTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.PreferenceTypes.Command
{
    public class CreatePreferenceTypeCommand : IRequest<Tuple<bool,bool>>
    {
        public CreatePreferenceTypeCommandReq createPreferenceTypeCommandReq;
    }
    public class CreatePreferenceTypeCommandHandler : IRequestHandler<CreatePreferenceTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreatePreferenceTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreatePreferenceTypeCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Preference_Type_Fields

            PreferenceType tpreferenceType = new PreferenceType();
            tpreferenceType.name = request.createPreferenceTypeCommandReq.name.Trim();
            tpreferenceType.description = request.createPreferenceTypeCommandReq.description;
            tpreferenceType.is_active = (bool)request.createPreferenceTypeCommandReq.is_active;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createPreferenceTypeCommandReq.name.Trim());
                string query = @"select id from preference_type where name = @name";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }

            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreatePreferenceType(tpreferenceType);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
