﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.TransportationPreferenceTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.PreferenceTypes.Command
{
    public class UpdatePreferenceTypeCommand : IRequest<bool>
    {
        public UpdatePreferenceTypeCommandReq updatePreferenceTypeCommandReq;
    }
    public class UpdatePreferenceTypeCommandHandler : IRequestHandler<UpdatePreferenceTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdatePreferenceTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdatePreferenceTypeCommand request, CancellationToken cancellationToken)
        {

            #region Preference_Type_Fields

            PreferenceType preferenceType = new PreferenceType();
            preferenceType.id = request.updatePreferenceTypeCommandReq.id;
            preferenceType.name = request.updatePreferenceTypeCommandReq.name.Trim();
            preferenceType.description = request.updatePreferenceTypeCommandReq.description;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from preference_type where name=@name and id!=@id";
                parameters.Add("@id", request.updatePreferenceTypeCommandReq.id);
                parameters.Add("@name", request.updatePreferenceTypeCommandReq.name.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdatePreferenceType(preferenceType);
                    return result;
                }

            }
        }
    }
}
