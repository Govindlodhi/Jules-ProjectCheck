﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.TransportationPreferenceTypes.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.PreferenceTypes.Queries
{
    public class PreferenceTypeDetailsQuery : IRequest<PreferenceTypeDetailsDto>
    {
        public long id { get; set; }
    }
    public class PreferenceTypeDetailsQueryHandler : IRequestHandler<PreferenceTypeDetailsQuery, PreferenceTypeDetailsDto>
    {
        private readonly ISqlContext _dbCntx;

        public PreferenceTypeDetailsQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<PreferenceTypeDetailsDto> Handle(PreferenceTypeDetailsQuery request, CancellationToken cancellationToken)
        {
            PreferenceTypeDetailsDto preferenceTypeDetailsDto = new PreferenceTypeDetailsDto();
            DynamicParameters dp = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@id", request.id);
                string query = @"select id,name as preference_type, description,is_active from preference_type  where id = @id";
                preferenceTypeDetailsDto = await connection.QueryFirstOrDefaultAsyncWithRetry<PreferenceTypeDetailsDto>(query, dp, commandType: CommandType.Text);
            }
            return preferenceTypeDetailsDto;
        }
    }
}
