﻿using MediatR;
using PARSNextGen.Application.AdministratorMaster.TransportationPreferenceTypes.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.PreferenceTypes.Queries
{
    public class PreferenceTypeListQuery : IRequest<List<PreferenceTypeListDto>>
    {
    }
    public class PreferenceTypeListQueryHandler : IRequestHandler<PreferenceTypeListQuery, List<PreferenceTypeListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public PreferenceTypeListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<PreferenceTypeListDto>> Handle(PreferenceTypeListQuery request, CancellationToken cancellationToken)
        {
            List<PreferenceTypeListDto> preferenceTypeLists = new List<PreferenceTypeListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select id,name as preference_type, description,is_active from preference_type  where is_active = 1";
                preferenceTypeLists = (List<PreferenceTypeListDto>)await connection.QueryAsyncWithRetry<PreferenceTypeListDto>(query, null, commandType: CommandType.Text);
            }
            return preferenceTypeLists;
        }
    }
}
