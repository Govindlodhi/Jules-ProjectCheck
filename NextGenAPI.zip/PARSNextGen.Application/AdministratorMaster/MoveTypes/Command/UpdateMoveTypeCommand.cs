﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.MoveTypes.Command
{
    public class UpdateMoveTypeCommand : IRequest<bool>
    {
        public UpdateMoveTypeCommandReq updateMoveTypeCommandReq;
    }
    public class UpdateRequestTypeCommandHandler : IRequestHandler<UpdateMoveTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateRequestTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateMoveTypeCommand request, CancellationToken cancellationToken)
        {

            #region Move_Type_Fields

            MoveType requestType = new MoveType();
            requestType.id = request.updateMoveTypeCommandReq.id;
            requestType.name = request.updateMoveTypeCommandReq.name.Trim();
            requestType.description = request.updateMoveTypeCommandReq.description;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from move_type where name=@name and id!=@id";
                parameters.Add("@id", request.updateMoveTypeCommandReq.id);
                parameters.Add("@name", request.updateMoveTypeCommandReq.name.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateMoveType(requestType);
                    return result;
                }

            }
        }
    }
}
