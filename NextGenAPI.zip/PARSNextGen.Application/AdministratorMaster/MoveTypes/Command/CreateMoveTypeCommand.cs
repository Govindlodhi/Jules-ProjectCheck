﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.MoveTypes.Command
{
    public class CreateMoveTypeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateMoveTypeCommandReq createMoveTypeCommandReq;
    }
    public class CreateRequestTypeCommandHandler : IRequestHandler<CreateMoveTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreateRequestTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateMoveTypeCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Move_Type_Fields

            MoveType moveType = new MoveType();
            moveType.name = request.createMoveTypeCommandReq.name.Trim();
            moveType.description = request.createMoveTypeCommandReq.description;
            moveType.is_active = (bool)request.createMoveTypeCommandReq.is_active;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createMoveTypeCommandReq.name.Trim());
                string query = @"select id from move_type where name = @name";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }

            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreateMoveType(moveType);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
