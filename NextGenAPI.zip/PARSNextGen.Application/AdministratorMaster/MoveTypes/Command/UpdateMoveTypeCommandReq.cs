﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.MoveTypes.Command
{
    public class UpdateMoveTypeCommandReq
    {
        public long id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
    }
}
