﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.MoveTypes.Queries
{
    public class MoveTypeDetailsQuery : IRequest<MoveTypeDetailsDto>
    {
        public long id { get; set; }
    }
    public class RequestTypeDetailsQueryHandler : IRequestHandler<MoveTypeDetailsQuery, MoveTypeDetailsDto>
    {
        private readonly ISqlContext _dbCntx;

        public RequestTypeDetailsQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<MoveTypeDetailsDto> Handle(MoveTypeDetailsQuery request, CancellationToken cancellationToken)
        {
            MoveTypeDetailsDto requestTypeDetails = new MoveTypeDetailsDto();
            DynamicParameters dp = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@id", request.id);
                string query = @"select id,name as move_type, description,is_active from move_type  where id = @id";
                requestTypeDetails = await connection.QueryFirstOrDefaultAsyncWithRetry<MoveTypeDetailsDto>(query, dp, commandType: CommandType.Text);
            }
            return requestTypeDetails;
        }
    }
}
