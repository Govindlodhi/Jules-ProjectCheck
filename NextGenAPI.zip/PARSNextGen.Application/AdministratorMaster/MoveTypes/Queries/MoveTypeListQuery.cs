﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.MoveTypes.Queries
{
    public class MoveTypeListQuery : IRequest<List<MoveTypeListDto>>
    {
    }
    public class RequestTypeListQueryHandler : IRequestHandler<MoveTypeListQuery, List<MoveTypeListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public RequestTypeListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<MoveTypeListDto>> Handle(MoveTypeListQuery request, CancellationToken cancellationToken)
        {
            List<MoveTypeListDto> requestTypeLists = new List<MoveTypeListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select id,name as move_type, description,is_active from move_type  where is_active = 1";
                requestTypeLists = (List<MoveTypeListDto>)await connection.QueryAsyncWithRetry<MoveTypeListDto>(query, null, commandType: CommandType.Text);
            }
            return requestTypeLists;
        }
    }
}
