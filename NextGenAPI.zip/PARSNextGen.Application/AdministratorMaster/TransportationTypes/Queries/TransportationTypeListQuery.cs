﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.TransportationTypes.Queries
{
    public class TransportationTypeListQuery : IRequest<List<TransportationTypeListDto>>
    {
    }
    public class TransportationTypeListQueryHandler : IRequestHandler<TransportationTypeListQuery, List<TransportationTypeListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public TransportationTypeListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<TransportationTypeListDto>> Handle(TransportationTypeListQuery request, CancellationToken cancellationToken)
        {
            List<TransportationTypeListDto> transportationTypeLists = new List<TransportationTypeListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select id,name as transportationType, description,is_active from transportation_type  where is_active = 1";
                transportationTypeLists = (List<TransportationTypeListDto>)await connection.QueryAsyncWithRetry<TransportationTypeListDto>(query, null, commandType: CommandType.Text);
            }
            return transportationTypeLists;
        }
    }
}
