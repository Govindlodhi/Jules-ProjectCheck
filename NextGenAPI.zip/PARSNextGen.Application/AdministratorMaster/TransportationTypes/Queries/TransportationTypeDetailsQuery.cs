﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.TransportationTypes.Queries
{
    public class TransportationTypeDetailsQuery : IRequest<TransportationTypeDetailsDto>
    {
        public long id { get; set; }
    }
    public class TransportationTypeTypeDetailsQueryHandler : IRequestHandler<TransportationTypeDetailsQuery, TransportationTypeDetailsDto>
    {
        private readonly ISqlContext _dbCntx;

        public TransportationTypeTypeDetailsQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<TransportationTypeDetailsDto> Handle(TransportationTypeDetailsQuery request, CancellationToken cancellationToken)
        {
            TransportationTypeDetailsDto transportationTypeDetailsDto = new TransportationTypeDetailsDto();
            DynamicParameters dp = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@id", request.id);
                string query = @"select id,name as transportationType, description,is_active from transportation_type  where id = @id";
                transportationTypeDetailsDto = await connection.QueryFirstOrDefaultAsyncWithRetry<TransportationTypeDetailsDto>(query, dp, commandType: CommandType.Text);
            }
            return transportationTypeDetailsDto;
        }
    }
}
