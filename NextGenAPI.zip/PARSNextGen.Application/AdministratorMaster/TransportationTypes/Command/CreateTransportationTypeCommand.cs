﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.TransportationTypes.Command
{
    public class CreateTransportationTypeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateTransportationTypeCommandReq createTransportationTypeCommandReq;
    }
    public class CreateTransportationTypeCommandHandler : IRequestHandler<CreateTransportationTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreateTransportationTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateTransportationTypeCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Transporation_Type_Fields

            TransportationType transportation_Type = new TransportationType();
            transportation_Type.name = request.createTransportationTypeCommandReq.name.Trim();
            transportation_Type.description = request.createTransportationTypeCommandReq.description;
            transportation_Type.is_active = (bool)request.createTransportationTypeCommandReq.is_active;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createTransportationTypeCommandReq.name.Trim());
                string query = @"select id from transportation_type where name = @name";
                int evenTypeExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (evenTypeExists > 0)
                {
                    isDulicateData = true;
                }

            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreateTransportationType(transportation_Type);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
