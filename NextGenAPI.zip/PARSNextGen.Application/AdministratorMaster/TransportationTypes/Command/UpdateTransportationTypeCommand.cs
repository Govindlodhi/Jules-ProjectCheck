﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.ServiceOrderTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.TransportationTypes.Command
{
    public class UpdateTransportationTypeCommand : IRequest<bool>
    {
        public UpdateTransportationTypeCommandReq updateTransportationTypeCommandReq;
    }
    public class UpdateTransportationTypeCommandHandler : IRequestHandler<UpdateTransportationTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateTransportationTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateTransportationTypeCommand request, CancellationToken cancellationToken)
        {

            #region Transporation_Type_Fields

            TransportationType transportation_Type = new TransportationType();
            transportation_Type.id = request.updateTransportationTypeCommandReq.id;
            transportation_Type.name = request.updateTransportationTypeCommandReq.name.Trim();
            transportation_Type.description = request.updateTransportationTypeCommandReq.description;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from transportation_type where name=@name and id!=@id";
                parameters.Add("@id", request.updateTransportationTypeCommandReq.id);
                parameters.Add("@name", request.updateTransportationTypeCommandReq.name.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateTransportationType(transportation_Type);
                    return result;
                }

            }
        }
    }
}
