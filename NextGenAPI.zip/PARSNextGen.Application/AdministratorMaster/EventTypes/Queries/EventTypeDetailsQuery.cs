﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.EventTypes.Queries
{
    public class EventTypeDetailsQuery : IRequest<EventTypeDetailsDto>
    {
        public long id { get; set; }
    }
    public class EventTypeDetailsQueryHandler : IRequestHandler<EventTypeDetailsQuery, EventTypeDetailsDto>
    {
        private readonly ISqlContext _dbCntx;

        public EventTypeDetailsQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<EventTypeDetailsDto> Handle(EventTypeDetailsQuery request, CancellationToken cancellationToken)
        {
            EventTypeDetailsDto eventTypeDetails = new EventTypeDetailsDto();
            DynamicParameters dp = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@id", request.id);
                string event_List = @"select id,name as event_type, description, is_public,is_active from event_type  where id = @id";
                eventTypeDetails = await connection.QueryFirstOrDefaultAsyncWithRetry<EventTypeDetailsDto>(event_List, dp, commandType: CommandType.Text);
            }
            return eventTypeDetails;
        }
    }
}
