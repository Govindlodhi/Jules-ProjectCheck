﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.EventTypes.Queries
{
    public class EventTypeListQuery : IRequest<List<EventTypeListDto>>
    {
    }
    public class EventListQueryHandler : IRequestHandler<EventTypeListQuery, List<EventTypeListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public EventListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<EventTypeListDto>> Handle(EventTypeListQuery request, CancellationToken cancellationToken)
        {
            List<EventTypeListDto> eventLists = new List<EventTypeListDto>();

            using(var connection = _dbCntx.GetOpenConnection())
            {
                string event_List = @"select id,name as event_type, description, is_public,is_active from event_type  where is_active = 1";
                eventLists = (List<EventTypeListDto>)await connection.QueryAsyncWithRetry<EventTypeListDto>(event_List, null, commandType:CommandType.Text);
            }
            return eventLists;
        }
    }
}
