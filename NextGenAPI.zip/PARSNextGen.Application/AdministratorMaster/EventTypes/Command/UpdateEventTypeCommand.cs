﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.EventTypes.Command
{
    public class UpdateEventTypeCommand : IRequest<bool>
    {
        public UpdateEventTypeCommandReq updateEventTypeCommandReq;
    }
    public class UpdateEventTypeCommandHandler : IRequestHandler<UpdateEventTypeCommand,bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateEventTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateEventTypeCommand request, CancellationToken cancellationToken)
        {

            #region Event_Type_Fields

            EventType eventType = new EventType();
            eventType.id = request.updateEventTypeCommandReq.id;
            eventType.name = request.updateEventTypeCommandReq.name.Trim();
            eventType.description = request.updateEventTypeCommandReq.description;
            eventType.is_public = (bool)request.updateEventTypeCommandReq.is_public;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using(var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from event_type where name=@name and id!=@id";
                parameters.Add("@id", request.updateEventTypeCommandReq.id);
                parameters.Add("@name", request.updateEventTypeCommandReq.name.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateEventType(eventType);
                    return result;
                }

            }
        }
    }
}
