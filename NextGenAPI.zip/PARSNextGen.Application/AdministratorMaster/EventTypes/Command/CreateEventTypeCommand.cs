﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.EventTypes.Command
{
    public class CreateEventTypeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateEventTypeCommandReq createEventTypeCommandReq;
    }
    public class CreateEventTypeCommandHandler : IRequestHandler<CreateEventTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public CreateEventTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateEventTypeCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            #region Event_Type_Fields

            EventType eventType = new EventType();
            eventType.name = request.createEventTypeCommandReq.name.Trim();
            eventType.description = request.createEventTypeCommandReq.description;
            eventType.is_public = request.createEventTypeCommandReq.is_public;
            eventType.is_active = request.createEventTypeCommandReq.is_active;

            #endregion
            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@name", request.createEventTypeCommandReq.name.Trim());
                string query = @"select id from event_type where name = @name ";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }
                
            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _administratorRepository.CreateEventType(eventType);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }


        }
    }
}
