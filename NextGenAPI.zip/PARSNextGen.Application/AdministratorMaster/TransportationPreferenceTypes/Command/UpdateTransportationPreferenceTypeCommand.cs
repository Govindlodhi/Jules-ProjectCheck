﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.TransportationTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.TransportationPreferenceTypes.Command
{
    public class UpdateTransportationPreferenceTypeCommand : IRequest<bool>
    {
        public UpdateTransportationPreferenceTypeCommandReq updateTransportationPreferenceTypeCommand;
    }
    public class UpdateTransportationPreferenceTypeCommandHandler : IRequestHandler<UpdateTransportationPreferenceTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateTransportationPreferenceTypeCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateTransportationPreferenceTypeCommand request, CancellationToken cancellationToken)
        {

            #region Transporation_Preference_Type_Fields

            TransportationPreferenceType transportationPreferenceType = new TransportationPreferenceType();
            transportationPreferenceType.id = request.updateTransportationPreferenceTypeCommand.id;
            transportationPreferenceType.name = request.updateTransportationPreferenceTypeCommand.name.Trim();
            transportationPreferenceType.description = request.updateTransportationPreferenceTypeCommand.description;

            #endregion
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from transportation_preference_type where name=@name and id!=@id";
                parameters.Add("@id", request.updateTransportationPreferenceTypeCommand.id);
                parameters.Add("@name", request.updateTransportationPreferenceTypeCommand.name.Trim());
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                {
                    bool result = await _administratorRepository.UpdateTransportationPreferenceType(transportationPreferenceType);
                    return result;
                }

            }
        }
    }
}
