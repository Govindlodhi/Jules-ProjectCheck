﻿using MediatR;
using PARSNextGen.Application.AdministratorMaster.TransportationTypes.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.TransportationPreferenceTypes.Command
{
    public class UpdateTransportationPreferenceTypeStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class UpdateTransportationPreferenceTypeStatusCommandHandler : IRequestHandler<UpdateTransportationPreferenceTypeStatusCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAdministratorRepository _administratorRepository;

        public UpdateTransportationPreferenceTypeStatusCommandHandler(ISqlContext dbCntx, IAdministratorRepository administratorRepository)
        {
            _dbCntx = dbCntx;
            _administratorRepository = administratorRepository;
        }
        public async Task<bool> Handle(UpdateTransportationPreferenceTypeStatusCommand request, CancellationToken cancellationToken)
        {

            bool result = await _administratorRepository.UpdateTransportationPreferenceTypeStatus(request.id, request.is_active);
            return result;
        }
    }
}
