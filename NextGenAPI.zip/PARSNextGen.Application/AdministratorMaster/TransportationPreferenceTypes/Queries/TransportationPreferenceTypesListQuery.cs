﻿using MediatR;
using PARSNextGen.Application.AdministratorMaster.TransportationTypes.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.TransportationPreferenceTypes.Queries
{
    public class TransportationPreferenceTypesListQuery : IRequest<List<TransportationPreferenceTypesListDto>>
    {
    }
    public class TransportationPreferenceTypesListQueryHandler : IRequestHandler<TransportationPreferenceTypesListQuery, List<TransportationPreferenceTypesListDto>>
    {
        private readonly ISqlContext _dbCntx;

        public TransportationPreferenceTypesListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<TransportationPreferenceTypesListDto>> Handle(TransportationPreferenceTypesListQuery request, CancellationToken cancellationToken)
        {
            List<TransportationPreferenceTypesListDto> transportationTypeLists = new List<TransportationPreferenceTypesListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select id,name as transportation_preference_type, description,is_active from transportation_preference_type  where is_active = 1";
                transportationTypeLists = (List<TransportationPreferenceTypesListDto>)await connection.QueryAsyncWithRetry<TransportationPreferenceTypesListDto>(query, null, commandType: CommandType.Text);
            }
            return transportationTypeLists;
        }
    }

}
