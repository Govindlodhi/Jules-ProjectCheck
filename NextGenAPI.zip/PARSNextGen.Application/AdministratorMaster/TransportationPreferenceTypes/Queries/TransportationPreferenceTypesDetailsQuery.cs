﻿using Dapper;
using MediatR;
using PARSNextGen.Application.AdministratorMaster.TransportationTypes.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.AdministratorMaster.TransportationPreferenceTypes.Queries
{
    public class TransportationPreferenceTypesDetailsQuery : IRequest<TransportationPreferenceTypesDetailsDto>
    {
        public long id { get; set; }
    }
    public class TransportationPreferenceTypesDetailsQueryHandler : IRequestHandler<TransportationPreferenceTypesDetailsQuery, TransportationPreferenceTypesDetailsDto>
    {
        private readonly ISqlContext _dbCntx;

        public TransportationPreferenceTypesDetailsQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<TransportationPreferenceTypesDetailsDto> Handle(TransportationPreferenceTypesDetailsQuery request, CancellationToken cancellationToken)
        {
            TransportationPreferenceTypesDetailsDto transportationTypeDetailsDto = new TransportationPreferenceTypesDetailsDto();
            DynamicParameters dp = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@id", request.id);
                string query = @"select id,name as transportation_preference_type, description,is_active from transportation_preference_type  where id = @id";
                transportationTypeDetailsDto = await connection.QueryFirstOrDefaultAsyncWithRetry<TransportationPreferenceTypesDetailsDto>(query, dp, commandType: CommandType.Text);
            }
            return transportationTypeDetailsDto;
        }
    }
}
