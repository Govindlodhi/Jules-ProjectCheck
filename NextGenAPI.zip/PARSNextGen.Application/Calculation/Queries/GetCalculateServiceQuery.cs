﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.VINValidation.Queries;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class GetCalculateServiceQuery : IRequest<List<CalculateServicePriceRangeDto>>
    {
        public string columnName { get; set; }
        public int rangeNumber { get; set; }
        public long fuelType { get; set; }
    }
    public class GetCalculateServiceQueryHandler : IRequestHandler<GetCalculateServiceQuery, List<CalculateServicePriceRangeDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetCalculateServiceQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<CalculateServicePriceRangeDto>> Handle(GetCalculateServiceQuery request, CancellationToken cancellationToken)
        {

            DynamicParameters dp = new DynamicParameters();
            List<CalculateServicePriceRangeDto> calculateServicePrices = new List<CalculateServicePriceRangeDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                //var query = @"SELECT " +
                //    "id,range,currency_id,range_number,pl,suv,tr1,tr2,tr3,tr4,tr5,tr6,tr7,tr8" +
                //     " from pro_service_calculated_price_range where range_number =@rangeNumber";
                //fuelSurcharges = (List<CalculateServicePriceRangeDto>)await connection.QueryAsyncWithRetry<CalculateServicePriceRangeDto>(query, dp, commandType: CommandType.Text);

                var sp = "sp_get_calculate_service_price_range_by_range_number";
                dp.Add("@column_name", request.columnName);
                dp.Add("@range_number", request.rangeNumber);
                dp.Add("@fuel_type", request.fuelType);
                calculateServicePrices = (List<CalculateServicePriceRangeDto>)await connection.QueryAsyncWithRetry<CalculateServicePriceRangeDto>(sp, dp, commandType: CommandType.StoredProcedure);
            }
            return calculateServicePrices;
        }
    }
}
