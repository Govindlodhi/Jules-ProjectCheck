﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class GetAdminFeeQuery : IRequest<AccountAdminDto>
    {
        public long? Id { get; set; }
    }
    public class GetAdminFeeQueryHandler : IRequestHandler<GetAdminFeeQuery, AccountAdminDto>
    {
        private readonly ISqlContext _dbCntx;
        public GetAdminFeeQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<AccountAdminDto> Handle(GetAdminFeeQuery request, CancellationToken cancellationToken)
        {

            DynamicParameters dp = new DynamicParameters();
            AccountAdminDto accountAdmine = new AccountAdminDto();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var query = @"SELECT " + "ac.id, ac.fmc_bill_to,default_bill_to_id, ac.admin_fee , ac.rebate" +
                    " from account ac" + 
                    " left join  default_bill_to db on db.id = ac.default_bill_to_id " +
                    " where ac.id =@fmcId";
                dp.Add("@fmcId", request.Id);
                accountAdmine = (AccountAdminDto)await connection.QueryFirstOrDefaultAsyncWithRetry<AccountAdminDto>(query, dp, commandType: CommandType.Text);
            }
            return accountAdmine;
        }
    }
}
