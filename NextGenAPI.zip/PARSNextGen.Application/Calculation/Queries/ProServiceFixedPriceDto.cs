﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class ProServiceFixedPriceDto
    {
        public long id { get; set; }   
        public long vehicle_type_id { get; set; }   
        public long fuel_type_id { get; set; }   
        public decimal flat_fee { get; set; }   
        public decimal per_mile_rate { get; set; }   
    }
}
