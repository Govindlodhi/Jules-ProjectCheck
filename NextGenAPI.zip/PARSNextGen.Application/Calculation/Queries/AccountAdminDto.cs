﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class AccountAdminDto
    {
        public int id { get; set; }
        //public int default_bill_to_id { get; set; }
        public decimal admin_fee { get; set; }
        public decimal rebate { get; set; }

    }
}
