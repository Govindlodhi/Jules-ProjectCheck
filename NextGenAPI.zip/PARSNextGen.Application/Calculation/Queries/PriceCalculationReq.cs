﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class PriceCalculationReq
    {
        public long transportation_type_id { get; set; }
        public long? fleet_id { get; set; }
        public long? fmc_id { get; set; }
        public long vehicle_type_id { get; set; }
        public long fuel_type_id { get; set; }
        public long primary_fuel_type_id { get; set; }
        public string pick_postal_code { get; set; }
        public string del_postal_code { get; set; }

        public string pickup_latitude { get; set; }
        public string pickup_longitude { get; set; }
        public string delivery_latitude { get; set; }
        public string delivery_longitude { get; set; }

        public long? pickup_storage_id { get; set; }
        public long? location2_country_id { get; set; }
        public long? delivery_storage_id { get; set; }
        public long? location1_country_id { get; set; }
        public long? price_list_id { get; set; }
        public long? currency_id { get; set; }
        public long? agreement_id { get; set; }
        public decimal? distance { get; set; }
        public decimal? adj_duration { get; set; }
        public bool is_plate_exist { get; set; }
        public DateTime? vehicle_plate_expiration_date { get; set; }
        public bool has_vehicle_ever_been_titled { get; set; }
        public long? state_transfer_agent_type_id { get; set; }
        public long? renewal_agent_type_id { get; set; }
        public long? issuing_agent_type_id { get; set; }
        public bool can_pars_issue_a_temp_tag { get; set; }
        public bool is_inspection_be_needed { get; set; }

        public bool pickup_towing_required { get; set; }
        public bool vehicle_repossession_required { get; set; }
        public bool is_vehicle_at_impound { get; set; }

        #region VEHICLE PLATE STATUS RELATED PARAMETERS
        public int? plate_status { get; set; }
      
        public bool? do_you_want_pars_to_handle_t_n_r { get; set; } //do_you_want_pars_to_handle_t_n_r== pars_handle_TandR
        public bool? is_pars_to_issue_a_temp_tag { get; set; }//is_pars_to_issue_a_temp_tag==is_pars_to_issue_a_30_day_temp_tag
        public bool? will_you_send_the_plates_to_fleet_driver { get; set; }//will_you_send_the_plates_to_fleet_driver==will_you_send_plates_to_fleet_driver
        public bool? want_pars_to_deliver_on_current_plates { get; set; } //want_pars_to_deliver_on_current_plates      
        public bool? is_prerequisite_inspections_in_delivery_state_required { get; set; }//is_prerequisite_inspections_in_delivery_state_required

        #endregion

        public List<ApplicableServiceDto> servicereqs { get; set; }
    }
    public class ApplicableServiceDto
    {
        public long? id { get; set; }
        public long? sub_category_id { get; set; }
        public string sub_category { get; set; }
        public string sub_category_description { get; set; }
        public long? service_id { get; set; }
        public Guid? crm_id { get; set; }
        public Guid? unit_crm_id { get; set; }
        public long? dependent_service_id { get; set; }
        public long? service_order_type_id { get; set; }
        public string service { get; set; }
        public string description { get; set; }
        public long rate_type_id { get; set; }
        public string rate_type { get; set; }

        public bool is_ic_instruction { get; set; }
        public decimal amount { get; set; }
        public decimal? authorized_amount { get; set; }
        public decimal? actual_amount { get; set; }
        public string amount_modified_reason { get; set; }
        public bool? is_price_modifiable { get; set; }
        public string actual_service { get; set; }

        
        public decimal? per_mile_rate { get; set; }
        public decimal? distance { get; set; }
        public decimal? adj_duration { get; set; }

        public decimal? fuel_surcharge_rate { get; set; }
        public decimal? fuel_surcharge_amount { get; set; }
        public decimal? pickup_hub_fee { get; set; }
        public decimal? delivery_hub_fee { get; set; }

        public decimal? admin_fee { get; set; }
        public long? surcharge_type_id { get; set; }
        public decimal? surcharge_rate { get; set; }
        public decimal? surcharge_amount { get; set; }
        public decimal? markup_number { get; set; }
        public long? markup_type_id { get; set; }
        public decimal? markup_amount { get; set; }

        public decimal? discount_rate { get; set; }
        public long? discount_type_id { get; set; }
        public decimal? discount_amount { get; set; }

        public decimal? rebate_rate { get; set; }
        public long? rebate_type_id { get; set; }
        public decimal? rebate_amount { get; set; }
        public decimal? total_amount { get; set; }

        //public long? agreement_id { get; set; }
        //public long? pricelist_id { get; set; }
        public bool? can_modify { get; set; }

        public bool is_alert_message { get; set; }
        public string message { get; set; }

        public string additional_info { get; set; }
        public bool have_more_info { get; set; }
        public bool? is_major_service { get; set; }

        public bool? is_read_only { get; set; }
        public bool is_public { get; set; }

        public bool impacts_timeline { get; set; }
        public int? service_notification_icon { get; set; }
        public long rule_type_id { get; set; }


        public int? service_standard { get; set; }

        public int? inspection_type_id { get; set; }
        public string document_for_inspection { get; set; }
        public string inspection_at { get; set; }
        public string inspection_note { get; set; }
        public int? inspection_to_be_done { get; set; }

        public string ic_instruction_for_inspection_service { get; set; }
        public bool is_inspection_service { get; set; }
    } 

    #region Calculation Response
    public class CalculationResponseDto
    {

        public decimal total_calculated_amount { get; set; }
        public decimal? total_amount { get; set; }
        public decimal? rebate_discount { get; set; }
        public decimal? discounted_amount { get; set; }
        //Custmer not assure about over_head_holdback_amount
        public decimal? over_head_holdback_amount { get; set; }

        public decimal? suggested_ic_pay { get; set; }
        public decimal? distance { get; set; }
        public decimal? adj_duration { get; set; }

        public string pick_postal_code { get; set; }
        public string del_postal_code { get; set; }

        public string pick_latitude { get; set; }
        public string pick_longitude { get; set; }
        public string del_latitude { get; set; }
        public string del_longitude { get; set; }
        public List<ApplicableServiceDto> serviceresp { get; set; }


    }
    #endregion

}
