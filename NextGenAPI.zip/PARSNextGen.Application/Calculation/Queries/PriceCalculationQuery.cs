﻿using Dapper;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.Preference.Agreement.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Storage.GetStorage.GetStorageDetails.Queries;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.VINValidation.Queries;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static PARSNextGen.Domain.Common.EnumTypes;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class PriceCalculationQuery : IRequest<CalculationResponseDto>
    {
        public PriceCalculationReq priceCalculationReq { get; set; }

    }

    public class QuickQuotePriceCalculationQueryHandler : IRequestHandler<PriceCalculationQuery, CalculationResponseDto>
    {
        private readonly IConfiguration _config;
        private readonly IAzureMapService _azureMapService;
        private readonly ISqlContext _dbCntx;
        private readonly IMediator _mediator;
        private readonly ICustomMessageService _customMessageService;
        public QuickQuotePriceCalculationQueryHandler(IConfiguration configuration, IAzureMapService azureMapService, ISqlContext dbCntx, IMediator mediator, ICustomMessageService customMessageService)
        {
            _config = configuration;
            _azureMapService = azureMapService;
            _dbCntx = dbCntx;
            _mediator = mediator;
            _customMessageService = customMessageService;

        }

        public async Task<CalculationResponseDto> Handle(PriceCalculationQuery request, CancellationToken cancellationToken)
        {
            long fuelType = (long)Fuel_Type.Non_Electric;
            List<ApplicableServiceDto> applicableServiceList = new List<ApplicableServiceDto>();
            var moveType = request.priceCalculationReq.transportation_type_id;
            var vehicleType = request.priceCalculationReq.vehicle_type_id;
            var pick_postal_code = request.priceCalculationReq.pick_postal_code;
            var del_postal_code = request.priceCalculationReq?.del_postal_code;
            var del_storage_Id = request.priceCalculationReq.delivery_storage_id;
            var pick_storage_Id = request.priceCalculationReq.pickup_storage_id;
            var pick_country_Id = request.priceCalculationReq.location1_country_id;
            var del_country_id = request.priceCalculationReq.location2_country_id;
            var pikup_latitude = request.priceCalculationReq.pickup_latitude;
            var pickup_longitude = request.priceCalculationReq.pickup_longitude;
            var delivery_latitude = request.priceCalculationReq.delivery_latitude;
            var delivery_longitude = request.priceCalculationReq.delivery_longitude;
            var fleetId = request.priceCalculationReq.fleet_id;
            //var fuelType = request.priceCalculationReq.fuel_type;
            long primaryFuelType = request.priceCalculationReq.primary_fuel_type_id;
            var fmcId = request.priceCalculationReq.fmc_id;
            var priceListId = request.priceCalculationReq.price_list_id;
            var aggrementId = request.priceCalculationReq.agreement_id;
            decimal Calculatedistance = 0;
            if(request.priceCalculationReq.distance!=null)
                Calculatedistance = (decimal)request.priceCalculationReq.distance;
            decimal? adj_hours = request.priceCalculationReq.adj_duration;
            applicableServiceList = request.priceCalculationReq.servicereqs;
            List<string> specialHandlingServices = new List<string>();
            #region Add Special Handling Services
            
            //transportation preference
            if (request.priceCalculationReq.transportation_type_id == (long)EnumTypes.transportation_type.Driveaway)
            {
                ApplicableServiceDto obj = applicableServiceList.Where(x => x.service_id == (long)EnumTypes.Transport_service.Drive_Away_Tariff).FirstOrDefault();
                if (obj == null)
                {
                    //Drive Away Tariff - 27
                    specialHandlingServices.Add(((long)EnumTypes.Transport_service.Drive_Away_Tariff).ToString());
                }
            }

            if (request.priceCalculationReq.transportation_type_id == (long)EnumTypes.transportation_type.Auto_Carrier)
            {
                ApplicableServiceDto obj = applicableServiceList.Where(x => x.service_id == (long)EnumTypes.Transport_service.Auto_Carrier_Tariff).FirstOrDefault();
                if (obj == null)
                {
                    //Auto Carrier Tariff -1
                    specialHandlingServices.Add(((long)EnumTypes.Transport_service.Auto_Carrier_Tariff).ToString());
                }
            }


            if (request.priceCalculationReq.transportation_type_id == (long)EnumTypes.transportation_type.Both)
            {
                ApplicableServiceDto obj = applicableServiceList.Where(x => x.service_id == (long)EnumTypes.Transport_service.Auto_Carrier_Tariff).FirstOrDefault();
                if (obj == null)
                {
                    //Auto_Carrier_Tariff
                    specialHandlingServices.Add(((long)EnumTypes.Transport_service.Auto_Carrier_Tariff).ToString());
                }
                ApplicableServiceDto obj1 = applicableServiceList.Where(x => x.service_id == (long)EnumTypes.Transport_service.Drive_Away_Tariff).FirstOrDefault();
                if (obj1 == null)
                {
                    //Drive_Away_Tariff
                    specialHandlingServices.Add(((long)EnumTypes.Transport_service.Drive_Away_Tariff).ToString());
                }
            }

            if (request.priceCalculationReq.transportation_type_id == (long)EnumTypes.transportation_type.Either)
            {
                ApplicableServiceDto obj = applicableServiceList.Where(x => x.service_id == (long)EnumTypes.Transport_service.Either).FirstOrDefault();
                if (obj == null)
                {
                    //Drive_Away_Tariff
                    specialHandlingServices.Add(((long)EnumTypes.Transport_service.Drive_Away_Tariff).ToString());
                }
            }

            //#region VEHICLE REGISTRATION STATUS RELATED SERVICES

            //if (!request.priceCalculationReq.is_plate_exist)
            //{
            //    // Include State Transfer and Shipping Handling Fee Services 
            //    if (request.priceCalculationReq.has_vehicle_ever_been_titled)
            //    {
            //        if (request.priceCalculationReq.state_transfer_agent_type_id != null)
            //        {
            //            if (request.priceCalculationReq.state_transfer_agent_type_id == (long)EnumTypes.Agent_Type.PARS)
            //            {
            //                specialHandlingServices.Add(((long)EnumTypes.Service.Transfer).ToString());
            //                specialHandlingServices.Add(((long)EnumTypes.Service.Shipping_Handling_Fee).ToString());
            //            }
            //        }
            //    }
            //    else
            //    {
            //        // Include Initial L&T and Shipping Handling Fee Services 
            //        if (request.priceCalculationReq.state_transfer_agent_type_id != null)
            //        {
            //            if (request.priceCalculationReq.state_transfer_agent_type_id == (long)EnumTypes.Agent_Type.PARS)
            //            {
            //                specialHandlingServices.Add(((long)EnumTypes.Service.Initial_T_and_R).ToString());
            //                specialHandlingServices.Add(((long)EnumTypes.Service.Shipping_Handling_Fee).ToString());
            //            }

            //        }
            //    }
            //}
            //else
            //{
            //    // vehicle plate expired or vehicle plate expire with in 30 days
            //    if (request.priceCalculationReq.vehicle_plate_expiration_date < System.DateTime.UtcNow || request.priceCalculationReq.vehicle_plate_expiration_date < System.DateTime.UtcNow.AddDays(30))
            //    {
            //        //Include Tags In Transit Service
            //        specialHandlingServices.Add(((long)EnumTypes.Service.In_Transit_Tag).ToString());

            //        //Include Temp Tags Service and Shipping Handling Fee Services
            //        if (request.priceCalculationReq.can_pars_issue_a_temp_tag)
            //        {
            //            specialHandlingServices.Add(((long)EnumTypes.Service.Tags_30_Day_Temp).ToString());
            //            specialHandlingServices.Add(((long)EnumTypes.Service.Shipping_Handling_Fee).ToString());
            //        }
            //        else
            //        {
            //            if (request.priceCalculationReq.state_transfer_agent_type_id == (long)EnumTypes.Agent_Type.PARS)
            //            {
            //                specialHandlingServices.Add(((long)EnumTypes.Service.Registration_Renewal).ToString());
            //                specialHandlingServices.Add(((long)EnumTypes.Service.Shipping_Handling_Fee).ToString());
            //            }
            //        }
            //    }
            //}

            //#endregion END


            if (specialHandlingServices.Count > 0)
            {
                List<ApplicableServiceDto> specialHandlingServiceList = new List<ApplicableServiceDto>();
                DynamicParameters specialServicesdp = new DynamicParameters();
                var serviceIds = string.Join(",", specialHandlingServices.ToArray());
                specialServicesdp.Add("@serviceId", serviceIds);
                specialServicesdp.Add("@PriceListId", request.priceCalculationReq.price_list_id);
                specialServicesdp.Add("@AgreementId", request.priceCalculationReq.agreement_id);
                // If service not exsit in preference
                using (var connection = _dbCntx.GetOpenConnection())
                {
                    string query = @"select priceListItem.id" +
                                 " ,priceListItem.service_id,priceListItem.price_list_id,sr.name as service,sr.description,sr.service_order_type_id," +
                                 "sr.sub_category_id,sc.name as sub_category, sc.description as sub_category_description,sr.have_more_info,sr.is_major_service, " +
                                 " priceListItem.amount service_amount," +
                                 " priceListItem.rate_type_id, priceListItem.sur_charge, priceListItem.markup_number, priceListItem.markup_type, priceListItem.discount discount_rate," +
                                 " priceListItem.discount_type discount_type_id , priceListItem.rebate, priceListItem.rebate_type, priceListItem.is_active,1 as can_modify" +
                                 " from price_list_item priceListItem " +
                                 " left join  service sr on priceListItem.service_id = sr.id " +
                                 " left join sub_category sc on sr.sub_category_id = sc.id" +
                                 " inner join  price_list pl on priceListItem.price_list_id = pl.id " +
                                 " where priceListItem.service_id in ((select value from FnSpliteParameterVals(@serviceId,','))) " +
                                 " and price_list_id=@PriceListId ";
                    specialHandlingServiceList = (List<ApplicableServiceDto>)await connection.QueryAsyncWithRetry<ApplicableServiceDto>(query, specialServicesdp, commandType: CommandType.Text);
                    if (specialHandlingServiceList.Count > 0)
                    {
                        foreach (var serviceItem in specialHandlingServiceList)
                        {
                            ApplicableServiceDto serviceObj = new ApplicableServiceDto();
                            serviceObj.id = serviceItem.id;
                            serviceObj.service_id = serviceItem.service_id;
                            serviceObj.service = serviceItem.service;
                            serviceObj.description = serviceItem.description;
                            serviceObj.service_order_type_id = serviceItem.service_order_type_id;
                            serviceObj.sub_category_id = serviceItem.sub_category_id;
                            serviceObj.sub_category = serviceItem.sub_category;
                            serviceObj.sub_category_description = serviceItem.sub_category_description;
                            serviceObj.rate_type_id = serviceItem.rate_type_id;
                            serviceObj.rate_type = serviceItem.rate_type;
                            serviceObj.is_price_modifiable = serviceItem.is_price_modifiable;
                            serviceObj.amount = serviceItem.amount;
                            serviceObj.authorized_amount = serviceItem.authorized_amount;
                            serviceObj.amount_modified_reason = serviceItem.amount_modified_reason;
                            serviceObj.per_mile_rate = serviceItem.per_mile_rate;
                            serviceObj.distance = serviceItem.distance;
                            serviceObj.fuel_surcharge_rate = serviceItem.fuel_surcharge_rate;
                            serviceObj.fuel_surcharge_amount = serviceItem.fuel_surcharge_amount;
                            serviceObj.pickup_hub_fee = serviceItem.pickup_hub_fee;
                            serviceObj.delivery_hub_fee = serviceItem.delivery_hub_fee;
                            serviceObj.admin_fee = serviceItem.admin_fee;
                            serviceObj.surcharge_type_id = serviceItem.surcharge_type_id;
                            serviceObj.surcharge_rate = serviceItem.surcharge_rate;
                            serviceObj.surcharge_amount = serviceItem.surcharge_amount;
                            serviceObj.markup_number = serviceItem.markup_number;
                            serviceObj.markup_type_id = serviceItem.markup_type_id;
                            serviceObj.markup_amount = serviceItem.markup_amount;
                            serviceObj.discount_rate = serviceItem.discount_rate;
                            serviceObj.discount_type_id = serviceItem.discount_type_id;
                            serviceObj.discount_amount = serviceItem.discount_amount;
                            serviceObj.rebate_rate = serviceItem.rebate_rate;
                            serviceObj.rebate_type_id = serviceItem.rebate_type_id;
                            serviceObj.rebate_amount = serviceItem.rebate_amount;
                            serviceObj.total_amount = serviceItem.total_amount;
                            serviceObj.can_modify = false;


                            serviceObj.have_more_info = serviceItem.have_more_info;
                            serviceObj.is_major_service = serviceItem.is_major_service;

                            applicableServiceList.Add(serviceObj);
                        }
                    }
                }
            }

            #endregion End 

            CalculationResponseDto response = new CalculationResponseDto();
            response.serviceresp = new List<ApplicableServiceDto>();
            response.total_amount = 0;
            response.discounted_amount = 0;
            response.rebate_discount = 0;
            response.suggested_ic_pay = 0;
            response.distance = Calculatedistance;
            response.adj_duration = adj_hours;
            response.pick_postal_code = pick_postal_code;
            response.del_postal_code = del_postal_code;
            response.pick_latitude = pikup_latitude;
            response.pick_longitude = pickup_longitude;
            response.del_latitude = delivery_latitude;
            response.del_longitude = delivery_longitude;


            //In Old Calculation - calculate on driveaway service
            //If Move Type Drive Away then go ahead
            //if (moveType == (long)Move_Type.Not_Matched || moveType == (long)Move_Type.Auto_Carrier || vehicleType == (long)VehicleType.NotMatched)//2- Auto Carrier
            //    return null;

            //if (vehicleType == (long)VehicleType.NotMatched || vehicleType == (long)VehicleType.Unknown || vehicleType == (long)VehicleType.OtherPowered || vehicleType == (long)VehicleType.OtherUnpowered)//2- Auto Carrier
            //    return response;

            decimal adminFee = 0;
            decimal fleetRebate = 0;
            decimal baseTariff = 0;
            decimal minimum = 0;
            int distance = 0;
            decimal pickupHubFee = 0;
            decimal deliveryHubFee = 0;
            decimal fuelSur = 0;
            decimal overheadHoldback = 0;
            decimal suggestedIcPay = 0;

            #region get values from appSettings

            decimal storageoutcost = 0;

            // Out of Storage Discount will be applicable when vehicle goes out from storage
            var isexist = applicableServiceList.Where(x => x.service_id == (long)EnumTypes.Service.Out_of_Storage_Discount).FirstOrDefault();
           if (isexist != null)
            {
                var storageoutCos = _config["appSettings:StorageOutCost"];
                storageoutcost = Convert.ToDecimal(storageoutCos);
            }


            var suggestedIcPercent = _config["appSettings:SuggestedIcPercent"];
            var suggestedIcCoeff = Convert.ToDecimal(suggestedIcPercent);
            suggestedIcCoeff = suggestedIcCoeff / 100;

            var overheadHoldbackRate = _config["appSettings:OverHeadHoldbackRate"];

            var insurancecoff = _config["appSettings:InsurancecOff"];
            decimal insuranceCost = Convert.ToDecimal(insurancecoff);

            var calHubFee = _config["appSettings:HubFee"];

            var message = _config["appSettings:ActualService"];

            #endregion

          


            decimal total_line_item_amount = 0;

            foreach (var applicableService in applicableServiceList)
            {
                if (applicableService.service_id == (long)Transport_service.Auto_Carrier_Tariff)
                {
                    applicableService.total_amount = 0;
                    response.serviceresp.Add(applicableService);
                }
                else
                {
                    #region Calculation for Actual Rate Type
                    if (applicableService.rate_type_id == (int)Rate_Type.Actual ||
                        applicableService.rate_type_id == (int)Rate_Type.Actual_Processing_Fee ||
                        applicableService.rate_type_id == (int)Rate_Type.Processing_Fee)
                    {

                        applicableService.total_amount = applicableService.amount;
                        //response.total_amount = Math.Ceiling((decimal)(response.total_amount + applicableService.service_amount));
                        applicableService.actual_service = message;
                        response.serviceresp.Add(applicableService);
                    }
                    #endregion End Actual

                    #region Calculation for Flat Rate Type

                    else if (applicableService.rate_type_id == (int)Rate_Type.Flat_Fee)
                    {

                        applicableService.total_amount = applicableService.amount;

                        //Add flat rate service amount and drive away tariff amount.
                        total_line_item_amount += applicableService.amount;
                        //response.total_amount = Math.Ceiling((decimal)(response.total_amount + applicableService.service_amount));
                        response.serviceresp.Add(applicableService);
                    }

                    #endregion End Calculation for Flat Rate Service Type

                    #region Calculation for Upto Service Type

                    else if (applicableService.rate_type_id == (int)Rate_Type.Up_To)
                    {
                        decimal authorized_amount = 0;
                        if (applicableService.is_price_modifiable.HasValue == true)
                        {
                            if (applicableService.authorized_amount != null)
                            {
                                authorized_amount = (decimal)applicableService.authorized_amount;
                            }
                            else
                                applicableService.total_amount = authorized_amount;
                            //response.total_amount = Math.Ceiling((decimal)(response.total_amount + applicableService.service_amount));
                            total_line_item_amount += authorized_amount;
                            response.serviceresp.Add(applicableService);
                        }
                        else
                        {
                            applicableService.total_amount = applicableService.amount;
                            total_line_item_amount += applicableService.amount;
                            //response.total_amount = Math.Ceiling((decimal)(response.total_amount + applicableService.modified_amount));
                            response.serviceresp.Add(applicableService);
                        }

                    }

                    #endregion End Calculation for Upto Service Type

                    #region Calculation for Calculated Service 

                    //calculated only for Drive Away Tarrif service
                    else if (applicableService.rate_type_id == (int)Rate_Type.Calculated)
                    {

                        #region Get Flat_Fee and per mile fee from pro service fixed price table


                        //Check Fuel Type is ev or nonev

                        if (primaryFuelType == (long)NHTSAFuelType.Electric
                               || primaryFuelType == (long)NHTSAFuelType.PH_EV
                               || primaryFuelType == (long)NHTSAFuelType.Hybrid)
                        {
                            fuelType = (long)EnumTypes.Fuel_Type.Electric;

                        }




                        //Get Flat_Fee and per mile fee from pro service fixed price  
                        DynamicParameters dp = new DynamicParameters();
                        ProServiceFixedPriceDto proServiceFixedPrice = new ProServiceFixedPriceDto();
                        using (var connection = _dbCntx.GetOpenConnection())
                        {

                            var query = @"SELECT " +
                            "id,vehicle_type_id,fuel_type_id,flat_fee,per_mile_rate" +
                            " from pro_service_fixed_price where  vehicle_type_id =@vehicleTypeId and fuel_type_id =@fuelTypeId";
                            dp.Add("@vehicleTypeId", vehicleType);
                            dp.Add("@fuelTypeId", fuelType);
                            proServiceFixedPrice = (ProServiceFixedPriceDto)await connection.QueryFirstOrDefaultAsyncWithRetry<ProServiceFixedPriceDto>(query, dp, commandType: CommandType.Text);

                        }
                        #endregion End Get Flat_Fee and per mile fee from pro service fixed price 


                        #region Get Flat_Fee and per mile fee from pro service fixed price table

                        //Get tariff calulation type for EV and NEV from pricelist
                        PriceListReq priceListReq = new PriceListReq();
                        long type_id = 0;
                        using (var connection = _dbCntx.GetOpenConnection())
                        {
                            var query = @"SELECT " +
                            "id,price_list_type_id,tarrif_calculation_type_ev,tarrif_calculation_type_nev" +
                            " from price_list where id =@priceListId ";
                            dp.Add("@priceListId", priceListId);
                            priceListReq = (PriceListReq)await connection.QueryFirstOrDefaultAsyncWithRetry<PriceListReq>(query, dp, commandType: CommandType.Text);

                        }
                        if (priceListReq != null)
                        {
                            if (primaryFuelType == (long)NHTSAFuelType.Electric
                                || primaryFuelType == (long)NHTSAFuelType.PH_EV
                                || primaryFuelType == (long)NHTSAFuelType.Hybrid)
                            {
                                type_id = (long)priceListReq.tarrif_calculation_type_ev;
                            }
                            else
                            {
                                type_id = (long)priceListReq.tarrif_calculation_type_nev;
                            }
                        }

                        #endregion End Get Flat_Fee and per mile fee from pro service fixed price 








                        if (Calculatedistance > 0)
                        {
                            #region Calculation for Calculated - Pro Service
                            if (type_id == (int)Rate_Type.Pro_Service)
                            {

                                #region To Calculate HubFee for Pickup
                                string pickCountry = String.Empty;
                                if (pick_country_Id != null && (pick_country_Id == (long)EnumTypes.Country.United_States))
                                {
                                    pickCountry = Convert.ToString((long)EnumTypes.Country.United_States);

                                }
                                if (pick_country_Id != null && (pick_country_Id == (long)EnumTypes.Country.Canada))
                                {
                                    pickCountry = Convert.ToString((long)EnumTypes.Country.Canada);
                                }
                                string pick_latitude1 = pikup_latitude;
                                string pick_longitude1 = pickup_longitude;
                                string pick_latitude2 = String.Empty;
                                string pick_longitude2 = String.Empty;

                                //Get zip code, latitude and longitude for HubFee
                                var pickup_hub = await _mediator.Send(new GetHubFeeQuery { latitude = pick_latitude1, longitude = pick_longitude1, Country = pickCountry });
                                if (pickup_hub != null)
                                {
                                    pick_latitude2 = pickup_hub.latitude.ToString();
                                    pick_longitude2 = pickup_hub.longitude.ToString();
                                }
                                else
                                {
                                    throw new Exception("PARS_PICKUP_COORDINATE_NOT_FOUND");
                                }
                                var pick_zip_code = pickup_hub.zips;
                                var str = pick_zip_code.Replace(@"""", "");
                                var zips = str.Split(':');
                                string pick_coordinates = string.Format("{0},{1}:{2},{3}", pikup_latitude.ToString(CultureInfo.InvariantCulture), pickup_longitude.ToString(CultureInfo.InvariantCulture), pick_latitude2.ToString(CultureInfo.InvariantCulture), pick_longitude2.ToString(CultureInfo.InvariantCulture));

                                // Get distance for calculation of Pickup HubFee
                                var pickRouteLength = await _azureMapService.CalculateDistanceBetweenCoordinates(pick_coordinates);

                                if (pickRouteLength != null)
                                {
                                    if (pickRouteLength.distance > 0)
                                    {
                                        distance = Convert.ToInt32(Convert.ToDouble(pickRouteLength.distance));
                                    }
                                    else
                                    {
                                        distance = (int)Convert.ToDecimal(zips[1]);
                                    }
                                }
                                //Get fuel rate, additionalHubFee, and currencyId for HubFee
                                decimal pickup_fee = 0;
                                decimal pick_additionalHubFee = 0;
                                int? currencyId = null;
                                var pickHubLocationDto = await _mediator.Send(new HubLocationQuery { zips = zips[0] });
                                if (pickHubLocationDto != null)
                                {
                                    pickup_fee = pickHubLocationDto.rate;
                                    pick_additionalHubFee = pickHubLocationDto.additional_hub_fee;
                                    currencyId = (int)pickHubLocationDto.currency_id;
                                }

                                distance = (int)(distance - Convert.ToInt64(calHubFee));
                                if (distance > 0)
                                    pickup_fee += distance * pick_additionalHubFee;
                                pickupHubFee = pickup_fee;
                                #endregion

                                #region To Calculate HubFee for Delivery

                                string delCountry = String.Empty;
                                if (del_country_id == null|| del_country_id == (long)EnumTypes.Country.United_States)
                                {
                                    delCountry = Convert.ToString((long)EnumTypes.Country.United_States);

                                }
                                if (del_country_id != null && del_country_id == (long)EnumTypes.Country.Canada)
                                {
                                    delCountry = Convert.ToString((long)EnumTypes.Country.Canada);
                                }

                                string del_latitude1 = delivery_latitude;
                                string del_longitude1 = delivery_longitude;
                                string del_latitude2 = string.Empty;
                                string del_longitude2 = string.Empty;
                                //Get zip code, latitude and longitude for HubFee
                                var delivery_hub = await _mediator.Send(new GetHubFeeQuery { latitude = del_latitude1, longitude = del_longitude1, Country = delCountry });
                                if (delivery_hub != null)
                                {
                                    del_latitude2 = delivery_hub.latitude.ToString();
                                    del_longitude2 = delivery_hub.longitude.ToString();
                                }
                                else
                                {
                                    throw new Exception("PARS_DELIVERY_COORDINATE_NOT_FOUND");
                                }
                                var del_zip_code = delivery_hub.zips;
                                var str1 = del_zip_code.Replace(@"""", "");
                                var zips1 = str1.Split(':');
                                string del_coordinates = string.Format("{0},{1}:{2},{3}", delivery_latitude.ToString(CultureInfo.InvariantCulture), delivery_longitude.ToString(CultureInfo.InvariantCulture), del_latitude2.ToString(CultureInfo.InvariantCulture), del_longitude2.ToString(CultureInfo.InvariantCulture));

                                // Get distance for calculation of Pickup HubFee
                                var delRouteLength = await _azureMapService.CalculateDistanceBetweenCoordinates(del_coordinates);
                                if (delRouteLength != null)
                                {
                                    if (delRouteLength.distance > 0)
                                    {
                                        distance = Convert.ToInt32(Convert.ToDouble(delRouteLength.distance));
                                    }
                                    else
                                    {
                                        distance = (int)Convert.ToDecimal(zips1[1]);
                                    }
                                }
                                // Get fuel rate, additionalHubFee, and currencyId for HubFee
                                decimal delvery_fuel = 0;
                                decimal del_additionalHubFee = 0;
                                var delHubLocationDto = await _mediator.Send(new HubLocationQuery { zips = zips1[0] });
                                if (delHubLocationDto != null)
                                {
                                    delvery_fuel = delHubLocationDto.rate;
                                    del_additionalHubFee = delHubLocationDto.additional_hub_fee;
                                }

                                distance = (int)(distance - Convert.ToInt64(calHubFee));
                                if (distance > 0)
                                    delvery_fuel += distance * del_additionalHubFee;
                                deliveryHubFee = delvery_fuel;//Commented - 13/02/24 for testing because we are not calculating Delivery Hub Fee in PARS-Support
                                deliveryHubFee = 0;
                                #endregion

                                #region Get FuelSurCharges based on vehicle type

                                string attributeLogicalName;
                                switch (vehicleType)
                                {
                                    case (long)VehicleType.PassengerCar:
                                        attributeLogicalName = "passenger_car";
                                        break;
                                    case (long)VehicleType.SUVMinivan:
                                        attributeLogicalName = "suv_van";
                                        break;
                                    case (long)VehicleType.TruckVan10000AndLess:
                                        attributeLogicalName = "truck_10000_and_less";
                                        break;
                                    case (long)VehicleType.TruckVan10001To14000: // Was TruckVan10001To26000
                                        attributeLogicalName = "truck_van_10001_to_14000";
                                        break;
                                    case (long)VehicleType.TruckVan14001To16000: // Was TruckVan26001AndUp
                                        attributeLogicalName = "truck_van_14001_to_16000";
                                        break;
                                    case (long)VehicleType.TruckVan16001To19500:
                                        attributeLogicalName = "truck_van_16001_to_19500";
                                        break;
                                    case (long)VehicleType.TruckVan19501To26000:
                                        attributeLogicalName = "truck_van_19501_to_26000";
                                        break;
                                    case (long)VehicleType.TruckBus26001To33000:
                                        attributeLogicalName = "truck_bus_26001_to_33000";
                                        break;
                                    case (long)VehicleType.TruckBus33001AndMore:
                                        attributeLogicalName = "truck_bus_33001_and_more";
                                        break;
                                    case (long)VehicleType.OtherPowered:
                                        attributeLogicalName = "other_powered";
                                        break;
                                    case (long)VehicleType.OtherUnpowered:
                                        attributeLogicalName = "other_unpowered";
                                        break;
                                    case (long)VehicleType.Unknown:
                                        attributeLogicalName = "unknown";
                                        break;
                                    default:
                                        throw new ArgumentOutOfRangeException("type");
                                }

                                //Get Fuel Sur Charges  for all vehicle type to price calculation 

                                long currency_Id = 0;
                                //Get Currency from aggrement by aggrement id
                                var agreementDetails = await _mediator.Send(new GetAgreementByIdQuery { id = aggrementId });
                                if (agreementDetails != null)
                                {
                                    currency_Id = (long)agreementDetails.currency_id;
                                }
                                var fuelSurCharges = await _mediator.Send(new FuelSurChargesQuery { columnName = attributeLogicalName, currencyId = currency_Id });
                                if (fuelSurCharges != null)
                                {
                                    fuelSur = fuelSurCharges.attributeName;
                                }
                                else
                                {
                                    fuelSur = 0;
                                }

                                #endregion

                                #region Get AdminFee

                                //Get Admin Fee for fleet
                                AccountAdminDto accountAdminDto = null;
                                if (agreementDetails != null && agreementDetails.default_bill_to_id == (long)Default_Bill_To.FMC)
                                {
                                    accountAdminDto = await _mediator.Send(new GetAdminFeeQuery { Id = fmcId });
                                }
                                if (accountAdminDto != null)
                                {
                                    adminFee = accountAdminDto.admin_fee;
                                }
                                else { adminFee = 0; }

                                #endregion

                                #region Get basePrice by pro_service_calculated_price_range  based on vehicle type

                                string fieldNameForBasePriceValue;
                                switch (vehicleType)
                                {
                                    case (long)VehicleType.PassengerCar:
                                        fieldNameForBasePriceValue = "pl";
                                        break;
                                    case (long)VehicleType.SUVMinivan:
                                        fieldNameForBasePriceValue = "suv";
                                        break;
                                    case (long)VehicleType.TruckVan10000AndLess:
                                        fieldNameForBasePriceValue = "tr1";
                                        break;
                                    case (long)VehicleType.TruckVan10001To14000:
                                        fieldNameForBasePriceValue = "tr2";
                                        break;
                                    case (long)VehicleType.TruckVan14001To16000:
                                        fieldNameForBasePriceValue = "tr3";
                                        break;
                                    case (long)VehicleType.TruckVan16001To19500:
                                        fieldNameForBasePriceValue = "tr4";
                                        break;
                                    case (long)VehicleType.TruckVan19501To26000:
                                        fieldNameForBasePriceValue = "tr5";
                                        break;
                                    case (long)VehicleType.TruckBus26001To33000:
                                        fieldNameForBasePriceValue = "tr6";
                                        break;
                                    case (long)VehicleType.TruckBus33001AndMore:
                                        fieldNameForBasePriceValue = "tr7";
                                        break;
                                    case (long)VehicleType.OtherPowered:
                                    case (long)VehicleType.OtherUnpowered:
                                    case (long)VehicleType.Unknown:
                                        return response;
                                    default:
                                        return null;
                                }

                                //Get mileage and use as a rangeNumber 
                                int mileage = ((Convert.ToInt32(Convert.ToDouble(Calculatedistance)) / 25) + 1) * 25;
                                //fuelType = 2;//Electric
                                //Get base price value for all vehicle type to baseteriff
                                var basePrice = await _mediator.Send(new GetCalculateServiceQuery { columnName = fieldNameForBasePriceValue, rangeNumber = mileage, fuelType = fuelType });
                                decimal basePriceValue = 0;
                                basePriceValue = Convert.ToDecimal(basePrice[0].attributeName);
                                if (basePrice != null)
                                {
                                    if (basePrice.Count > 0)
                                        basePriceValue = Convert.ToDecimal(basePrice[0].attributeName);
                                }


                                #endregion

                                #region BaseTariff and Minimum
                                decimal discountAmount;
                                if (basePriceValue != 0 && applicableService.discount_type_id != null)
                                {
                                    if (applicableService.discount_type_id == (long)Discount_Type.Number)
                                    {
                                        discountAmount = (decimal)applicableService.discount_rate;
                                        baseTariff = basePriceValue - discountAmount;
                                    }
                                    else
                                    {
                                        baseTariff = (decimal)(applicableService.discount_rate / 100 * basePriceValue);//(percentage ?? 0M) / 100 * basePriceValue; based on the product
                                        baseTariff = basePriceValue - baseTariff;
                                    }

                                }
                                else
                                {
                                    baseTariff = basePriceValue;
                                }

                                //add markup in base value  
                                decimal markupAmount;
                                if (applicableService.markup_type_id != null)
                                {
                                    if (applicableService.markup_type_id == (long)Discount_Type.Number)
                                    {
                                        markupAmount = (int)applicableService.markup_number;
                                        baseTariff = (decimal)(basePriceValue + applicableService.markup_number);
                                    }
                                    else
                                    {
                                        markupAmount = (decimal)(basePriceValue / 100 * applicableService.markup_number);
                                        baseTariff = (decimal)(basePriceValue + markupAmount);
                                    }
                                }
                                else
                                {
                                    baseTariff = basePriceValue;
                                }





                                #endregion BaseTariff 

                                minimum = (decimal)applicableService.amount;// get by service

                                #region Get FleetRebate

                                //Get Fleet Rebate percentage for FMC
                                //var fleet_rebate = await _mediator.Send(new GetFleetRebateQuery { fmcId = fmcId });
                                if (accountAdminDto != null && agreementDetails.default_bill_to_id == (long)Default_Bill_To.FMC)
                                {
                                    //fleetRebate = baseTariff * (accountAdminDto.rebate / 100);
                                    fleetRebate = Math.Ceiling(baseTariff * (accountAdminDto.rebate / 100));
                                    //fleetRebate = Math.Round(fleetRebate, 2);
                                }
                                else { fleetRebate = 0; }

                                #endregion

                                #region Get overheadHoldback by extralines, and extralines get by pricelevelid
                                overheadHoldback = Convert.ToDecimal(overheadHoldbackRate);
                                if (overheadHoldbackRate != null)
                                {
                                    overheadHoldback = Convert.ToDecimal(baseTariff * (overheadHoldback / 100M));

                                    //if (accountAdminDto != null)
                                    //{
                                    //    overheadHoldback = Math.Round(Convert.ToDecimal(baseTariff * (accountAdminDto.rebate / 100M)), 2);
                                    //}
                                }

                                #endregion

                                #region Business Logic
                                var unit = Math.Round((baseTariff + (Convert.ToDecimal(Calculatedistance) * fuelSur) + pickupHubFee + deliveryHubFee + adminFee), 2);
                                insuranceCost = Convert.ToInt32(Convert.ToDouble(Calculatedistance)) * insuranceCost;

                                if (minimum > 0M && unit < minimum)
                                    unit = minimum;
                                var baseVal = unit - fleetRebate;

                                

                                //var suggestedIcPay = (baseVal - storageoutcost - adminFee - overheadHoldback) * suggestedIcCoeff;
                                suggestedIcPay = Math.Ceiling((baseVal - insuranceCost - storageoutcost - adminFee - overheadHoldback) * suggestedIcCoeff);
                                decimal hubFee = pickupHubFee + deliveryHubFee;
                                #endregion Business Logic

                                #region Update ResponseDto



                                applicableService.fuel_surcharge_amount = fuelSur;
                                applicableService.admin_fee = adminFee;
                                applicableService.per_mile_rate = Math.Ceiling(baseTariff);

                                // Default Service Amount
                                applicableService.amount = 0;
                                applicableService.pickup_hub_fee = pickupHubFee;
                                applicableService.delivery_hub_fee = deliveryHubFee;
                                applicableService.distance = Calculatedistance;
                                applicableService.adj_duration = adj_hours;
                                applicableService.total_amount = Math.Ceiling(unit);
                                if (request.priceCalculationReq.transportation_type_id == (long)EnumTypes.transportation_type.Both || request.priceCalculationReq.transportation_type_id == (long)EnumTypes.transportation_type.Either)
                                    applicableService.total_amount = 0;
                                else
                                    applicableService.total_amount = Math.Ceiling(unit);
                                total_line_item_amount += Math.Ceiling(unit);
                                response.serviceresp.Add(applicableService);
                                #endregion Update ResponseDto

                            }
                            #endregion Calculation for Calculated - Pro Service

                            #region Calculation for Calculated - Flat Fee
                            else if (type_id == (int)Rate_Type.Flat_Fee)
                            {
                                decimal flatFeeAmount = 0;
                                if (proServiceFixedPrice != null)
                                    flatFeeAmount = proServiceFixedPrice.flat_fee;
                                applicableService.total_amount = flatFeeAmount;
                                response.serviceresp.Add(applicableService);
                                total_line_item_amount += flatFeeAmount;
                            }
                            #endregion End  Flat fee

                            #region Calculation for Calculated - Per_Mile 
                            else if (type_id == (int)Rate_Type.Per_Mile)
                            {
                                decimal amount = 0;
                                if (proServiceFixedPrice != null)
                                    amount = (decimal)(Calculatedistance * proServiceFixedPrice.per_mile_rate);

                                if (applicableService.discount_type_id != null)
                                {
                                    if (applicableService.discount_type_id == (long)Discount_Type.Number)
                                    {
                                        amount = (decimal)(amount - applicableService.discount_rate);
                                    }
                                    else
                                    {
                                        amount = (decimal)(amount - (amount / 100 * applicableService.discount_rate));
                                    }
                                }


                                response.total_amount = Math.Ceiling((decimal)(response.total_amount + amount));

                                if (proServiceFixedPrice != null)
                                    applicableService.per_mile_rate = proServiceFixedPrice.per_mile_rate;
                                applicableService.distance = Calculatedistance;
                                applicableService.adj_duration = adj_hours;
                                applicableService.total_amount = amount;
                                total_line_item_amount += amount;
                                response.serviceresp.Add(applicableService);
                            }
                            #endregion End Per_Mile
                        }
                        else
                        {
                            applicableService.total_amount = applicableService.amount;
                            response.serviceresp.Add(applicableService);
                        }
                    }

                    #endregion Calculation for Calculated Service Type
                }
            }
            if (request.priceCalculationReq.transportation_type_id == (long)EnumTypes.transportation_type.Both || request.priceCalculationReq.transportation_type_id == (long)EnumTypes.transportation_type.Either)
            {
                response.total_calculated_amount = 0;
                //fleet_rebate_amount
                response.rebate_discount = 0;
                //Custmer not assure about over_head_holdback_amount
                //response.over_head_holdback_amount = overheadHoldback;
                overheadHoldback = 0;
                response.discounted_amount = 0;
                response.suggested_ic_pay = 0;

                response.total_amount = 0;
            }
            else
            {
                response.total_calculated_amount = total_line_item_amount;
                //fleet_rebate_amount
                response.rebate_discount = fleetRebate;
                //Custmer not assure about over_head_holdback_amount
                //response.over_head_holdback_amount = overheadHoldback;
                overheadHoldback = 0;
                response.discounted_amount = fleetRebate + overheadHoldback;
                response.suggested_ic_pay = suggestedIcPay;

                response.total_amount = Math.Ceiling((decimal)(total_line_item_amount - response.rebate_discount));

            }



            //response.serviceresp.Add(applicableService);

            #region Ordering Transport Service Service 
            var tempObj = response.serviceresp.Where(x => x.service_id == (long)EnumTypes.Transport_service.Drive_Away_Tariff).FirstOrDefault();
            if (tempObj == null)
                tempObj = response.serviceresp.Where(x => x.service_id == (long)EnumTypes.Transport_service.Auto_Carrier_Tariff).FirstOrDefault();
            //if (tempObj == null)
            //    tempObj = response.serviceresp.Where(x => x.service_id == (long)EnumTypes.Transport_service.PARS_Discretion).FirstOrDefault();

            if (tempObj == null)
                tempObj = response.serviceresp.Where(x => x.service_id == (long)EnumTypes.Transport_service.Both).FirstOrDefault();
            if (tempObj == null)
                tempObj = response.serviceresp.Where(x => x.service_id == (long)EnumTypes.Transport_service.Either).FirstOrDefault();
            if (tempObj != null)
            {

                int? index = null;
                index = response.serviceresp.FindIndex(x => x.service_id == tempObj.service_id);
                if (index != null && index != -1)
                {
                    response.serviceresp.RemoveAt((int)index);
                    response.serviceresp.Insert(0, tempObj);
                }
            }
            #endregion END

            return response;
        }

    }
}
