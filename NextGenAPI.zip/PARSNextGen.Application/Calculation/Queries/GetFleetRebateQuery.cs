﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class GetFleetRebateQuery : IRequest<AccountFleetRebate>
    {
        public long? fmcId { get; set; }
    }
    public class GetFleetRebateQueryHandler : IRequestHandler<GetFleetRebateQuery, AccountFleetRebate>
    {
        private readonly ISqlContext _dbCntx;
        public GetFleetRebateQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<AccountFleetRebate> Handle(GetFleetRebateQuery request, CancellationToken cancellationToken)
        {

            DynamicParameters dp = new DynamicParameters();
            AccountFleetRebate fleetRebate = new AccountFleetRebate();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var query = @"SELECT " + "ac.id, ac.rebate, ac.fmc_bill_to,default_bill_to_id" +
                    " from account ac " +
                    " left join  default_bill_to db on db.id = ac.default_bill_to_id " +
                    " where ac.id =@fmcId ";
                dp.Add("@fmcId", request.fmcId);
                fleetRebate = (AccountFleetRebate)await connection.QueryFirstOrDefaultAsyncWithRetry<AccountFleetRebate>(query, dp, commandType: CommandType.Text);
            }
            return fleetRebate;
        }
    }
}
