﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class HubDto
    {
        public string zips { get; set; }
        public string country { get; set; }
        public decimal latitude { get; set; }
        public decimal longitude { get; set; }
    }
}
