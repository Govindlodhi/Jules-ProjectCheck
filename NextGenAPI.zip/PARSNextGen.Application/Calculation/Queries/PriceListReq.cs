﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class PriceListReq
    {
        public long id { get; set; }
        public long tarrif_calculation_type_ev { get; set; }
        public long tarrif_calculation_type_nev { get; set; }
        //public long default_bill_to_id { get; set; }
    }
}
