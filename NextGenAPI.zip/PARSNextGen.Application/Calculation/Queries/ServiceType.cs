﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class ServiceType
    {
        public int id { get; set; }
        public long price_list_id { get; set; }
        public long service_id { get; set; }
        public decimal amount { get; set; }
        public long rate_type_id { get; set; }
        public decimal sur_charge { get; set; }
        public decimal markup_number { get; set; }
        public long markup_type { get; set; }
        public decimal discount { get; set; }
        public long discount_type { get; set; }
        public decimal rebate { get; set; }
        public long rebate_type { get; set; }
        //public string name { get; set; }
        //public string rate_type { get; set; }
        ////public decimal price { get; set; }
        //public decimal percenatge { get; set; }
        //public decimal minimum_amount { get; set; }
        //public decimal surcharge { get; set; }
        //public int markup_number { get; set; }
        //public string markup_type { get; set; }
        //public int discount { get; set; }
        //public string discount_type { get; set; }
        //public int rebate { get; set; }
        //public string rebate_type { get; set; }
    }
}
