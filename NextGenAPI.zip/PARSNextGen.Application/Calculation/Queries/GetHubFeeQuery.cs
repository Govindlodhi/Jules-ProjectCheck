﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class GetHubFeeQuery : IRequest<HubDto>
    {
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string Country { get; set; }
    }
    public class GetHubFeeQueryHandler : IRequestHandler<GetHubFeeQuery, HubDto>
    {
        private readonly ISqlContext _dbCntx;
        public GetHubFeeQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<HubDto> Handle(GetHubFeeQuery request, CancellationToken cancellationToken)
        {

            DynamicParameters dp = new DynamicParameters();
            HubDto hubDto = new HubDto();
            var procedure = "sp_hub_distance";
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@lat", request.latitude);
                dp.Add("@lon", request.longitude);
                dp.Add("@country", request.Country);
                hubDto = (HubDto)await connection.QueryFirstOrDefaultAsyncWithRetry<HubDto>(procedure, dp, commandType: CommandType.StoredProcedure);
            }
            return hubDto;
        }
    }
}
