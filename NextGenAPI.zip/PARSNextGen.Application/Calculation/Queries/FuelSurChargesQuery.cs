﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.Vehicle.VehicleDetail.Queries;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class FuelSurChargesQuery : IRequest<FuelSurChargesDto>
    {
        public string columnName { get; set; }
        public long? currencyId { get; set; }
    }
    public class FuelSurChargesQueryHandler : IRequestHandler<FuelSurChargesQuery, FuelSurChargesDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;

        public FuelSurChargesQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<FuelSurChargesDto> Handle(FuelSurChargesQuery request, CancellationToken cancellationToken)
        {

            DynamicParameters dp = new DynamicParameters();
            FuelSurChargesDto fuelSurcharges = new FuelSurChargesDto();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                //var query = @"SELECT " +
                //"passenger_car,suv_van,truck_10000_and_less,truck_van_10001_to_14000,truck_van_14001_to_16000,truck_van_16001_to_19500" +
                //",truck_van_19501_to_26000,truck_bus_26001_to_33000,truck_bus_33001_and_more,other_powered,other_unpowered,unknown" +
                // " from fuel_sur_charges where currency_id =@currencyId";
                //fuelSurcharges = (List<FuelSurChargesDto>)await connection.QueryAsyncWithRetry<FuelSurChargesDto>(query, dp, commandType: CommandType.Text);

                var sp = "sp_get_fuel_sur_charges_by_currency_id";
                    dp.Add("@column_name", request.columnName);
                    dp.Add("@currency_Id", request.currencyId);
                    fuelSurcharges = (FuelSurChargesDto)await connection.QueryFirstOrDefaultAsyncWithRetry<FuelSurChargesDto>(sp, dp, commandType: CommandType.StoredProcedure);                            
            }
            return fuelSurcharges;
        }
    }
}
