﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class HubLocationQuery : IRequest<HubLocationDto>
    {
        public string zips { get; set; }
    }
    public class HubLocationQueryHandler : IRequestHandler<HubLocationQuery, HubLocationDto>
    {
        private readonly ISqlContext _dbCntx;
        public HubLocationQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<HubLocationDto> Handle(HubLocationQuery request, CancellationToken cancellationToken)
        {

            DynamicParameters dp = new DynamicParameters();
            HubLocationDto hubLocationDto = new HubLocationDto();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var query = @"SELECT " +
                    "zip_code,rate,additional_hub_fee, currency_id from hub_location where zip_code = @zip_code";
                dp.Add("@zip_code", request.zips);
                hubLocationDto = (HubLocationDto)await connection.QueryFirstOrDefaultAsyncWithRetry<HubLocationDto>(query, dp, commandType: CommandType.Text);
            }
            return hubLocationDto;
        }
    }
}
