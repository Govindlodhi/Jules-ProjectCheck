﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Calculation.Queries
{
    public class CalculateServicePriceRangeDto
    {
        public ulong id { get; set; }
        public ulong currency_id { get; set; }
        public string range { get; set; }
        public int range_number { get; set; }
        public decimal pl { get; set; }
        public decimal suv { get; set; }
        public decimal tr1 { get; set; }
        public decimal tr2 { get; set; }
        public decimal tr3 { get; set; }
        public decimal tr4 { get; set; }
        public decimal tr5 { get; set; }
        public decimal tr6 { get; set; }
        public decimal tr7 { get; set; }
        public decimal tr8 { get; set; }
        public decimal attributeName { get; set; }
        public long fuel_type { get; set; }
    }
}
