﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.ContactPars.Command
{
    public class ContactParsReq
    {
        public Guid service_request_crm_id { get; set; }
        public string service_request_number { get; set; }
        public long? service_request_id { get; set; }
        public long subject_id { get; set; }
        public string note { get; set; }
    }
}
