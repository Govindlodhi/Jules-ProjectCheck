﻿using MediatR;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.ContactPars.Command
{
    public class CreateContactParsCommand : IRequest<bool>
    {
        public List<ContactParsReq> contactParsReq;
    }
    public class CreateContactParsCommandHandler : IRequestHandler<CreateContactParsCommand, bool>
    {
        private readonly IQuoteRepository _quoteRepository;

        public CreateContactParsCommandHandler(IQuoteRepository quoteRepository)
        {
            _quoteRepository = quoteRepository;
        }
        public async Task<bool> Handle(CreateContactParsCommand request, CancellationToken cancellationToken)
        {
            bool result = false;
            #region Task_Fields
            List<contact_pars> serviceTask = new List<contact_pars>();

            if (request.contactParsReq.Count > 0)
            {
                foreach (var item in request.contactParsReq)
                {
                    contact_pars serviceTask1 = new contact_pars();
                    serviceTask1.service_request_crm_id = item.service_request_crm_id;
                    serviceTask1.service_request_number = item.service_request_number;
                    serviceTask1.service_request_id = item.service_request_id;
                    serviceTask1.subject_id = item.subject_id;
                    serviceTask1.note = item.note;
                    serviceTask.Add(serviceTask1);
                }
                result = await _quoteRepository.CreateContactPARS(serviceTask);
            }

            return result;

            #endregion End_Task_Fields

        }
    }
}
