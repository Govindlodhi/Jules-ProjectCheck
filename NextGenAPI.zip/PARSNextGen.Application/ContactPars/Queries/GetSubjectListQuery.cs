﻿using Amazon.Runtime.Internal;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.ContactPars.Queries
{
    public class GetSubjectListQuery : IRequest<List<SubjectContactParsDto>>
    {
    }
    public class GetSubjectListQueryHandler : IRequestHandler<GetSubjectListQuery, List<SubjectContactParsDto>>
    {
        private readonly ISqlContext _dbCntx;

        public GetSubjectListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<SubjectContactParsDto>> Handle(GetSubjectListQuery request, CancellationToken cancellationToken)
        {
            List<SubjectContactParsDto> subjectList = null;

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @" select id, name from subject_contact_pars where status = 1 ";
                subjectList = (List<SubjectContactParsDto>)await connection.QueryAsyncWithRetry<SubjectContactParsDto>(query, commandType: CommandType.Text);
            }
            return subjectList;
        }
    }

}
