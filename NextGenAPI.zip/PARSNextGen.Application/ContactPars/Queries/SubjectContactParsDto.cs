﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.ContactPars.Queries
{
    public class SubjectContactParsDto
    {
        public long? id { get; set; }
        public string name { get; set; }
        public Guid? crm_id { get; set; }
    }
}
