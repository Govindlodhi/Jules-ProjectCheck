﻿using MediatR;
using PARSNextGen.Application.Utility.Preference;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.IcInstructions.Command
{
    public class UpdateIcPreferenceRulesCommand : IRequest<bool>
    {
        public UpdateIcPreferenceRuleReq updateIcPreferenceRuleReq;
    }
    public class UpdateIcPreferenceRulesCommandHandler : IRequestHandler<UpdateIcPreferenceRulesCommand, bool>
    {
        private readonly IPreferenceRepository _preferenceRepo;

        public UpdateIcPreferenceRulesCommandHandler(IPreferenceRepository preferenceRepo)
        {
            _preferenceRepo = preferenceRepo;
        }
        public async Task<bool> Handle(UpdateIcPreferenceRulesCommand request, CancellationToken cancellationToken)
        {
            bool result = false;
            IcPreferenceRule icPreferenceRule = new IcPreferenceRule();




            if (!string.IsNullOrEmpty(request.updateIcPreferenceRuleReq.instruction_rule))
            {
                GetRuleEditor getRuleEditor = new GetRuleEditor();
                long category_id = 1;//Service Request = 1

                var editor = getRuleEditor.GetRuleEditorData(category_id, request.updateIcPreferenceRuleReq.rule_type_id, "divruleeditor");

                editor.LoadClientData(request.updateIcPreferenceRuleReq.instruction_rule);

                icPreferenceRule.human_readable_rule = editor.ToString();

                if (!editor.Rule.IsValid(LoadRuleXml))
                {

                    var ClientInvalidData = editor.GetClientInvalidData();
                }
                request.updateIcPreferenceRuleReq.instruction_rule = editor.Rule.GetRuleXml();
            }


            icPreferenceRule.id = request.updateIcPreferenceRuleReq.id;
            icPreferenceRule.agreement_id = request.updateIcPreferenceRuleReq.agreement_id;
            icPreferenceRule.agreement_type_id = request.updateIcPreferenceRuleReq.agreement_type_id;
            icPreferenceRule.service_id = request.updateIcPreferenceRuleReq.service_id;
            icPreferenceRule.event_type_id = request.updateIcPreferenceRuleReq.event_type_id;
            icPreferenceRule.instruction = request.updateIcPreferenceRuleReq.instruction;           
            icPreferenceRule.can_modify = request.updateIcPreferenceRuleReq.can_modify;
            icPreferenceRule.can_override = request.updateIcPreferenceRuleReq.can_override;
            icPreferenceRule.instruction_rule = request.updateIcPreferenceRuleReq.instruction_rule;
            icPreferenceRule.inclusion_type_id = request.updateIcPreferenceRuleReq.preference_type_id;
            icPreferenceRule.rule_type_id = request.updateIcPreferenceRuleReq.rule_type_id;
            icPreferenceRule.currency_id = request.updateIcPreferenceRuleReq.currency_id;
            icPreferenceRule.sequence_number = request.updateIcPreferenceRuleReq.sequence_number;

            result = await _preferenceRepo.UpdateIcPreferenceRule(icPreferenceRule);
            return result;
        }
        public string LoadRuleXml(string ruleId)
        {
            return "";
        }
    }
}
