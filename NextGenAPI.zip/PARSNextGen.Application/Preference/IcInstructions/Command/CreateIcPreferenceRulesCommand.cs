﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility.Preference;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.IcInstructions.Command
{
    public class CreateIcPreferenceRulesCommand : IRequest<bool>
    {
        public CreateIcPreferenceRuleReq createIcPreferenceRuleReq { get; set; }
    }
    public class CreateIcInstructionsCommandHandler : IRequestHandler<CreateIcPreferenceRulesCommand, bool>
    {
        private readonly IPreferenceRepository _preferenceRepo;

        public CreateIcInstructionsCommandHandler(IPreferenceRepository preferenceRepo)
        {
            _preferenceRepo = preferenceRepo;
        }
        public async Task<bool> Handle(CreateIcPreferenceRulesCommand request, CancellationToken cancellationToken)
        {
            bool result = false;
            IcPreferenceRule icPreferenceRule = new IcPreferenceRule();





            if (!string.IsNullOrEmpty(request.createIcPreferenceRuleReq.instruction_rule))
            {
                GetRuleEditor getRuleEditor = new GetRuleEditor();

                long category_id = 1;//Service Request = 1
                var editor = getRuleEditor.GetRuleEditorData(category_id, request.createIcPreferenceRuleReq.rule_type_id, "divRuleEditor");

                editor.LoadClientData(request.createIcPreferenceRuleReq.instruction_rule);

                icPreferenceRule.human_readable_rule = editor.ToString();

                if (!editor.Rule.IsValid(LoadRuleXml))
                {

                    var ClientInvalidData = editor.GetClientInvalidData();
                }
                request.createIcPreferenceRuleReq.instruction_rule = editor.Rule.GetRuleXml();
            }





            icPreferenceRule.agreement_id = request.createIcPreferenceRuleReq.agreement_id;
            icPreferenceRule.parent_ic_preference_id = request.createIcPreferenceRuleReq.parent_ic_preference_id;
            icPreferenceRule.agreement_type_id = request.createIcPreferenceRuleReq.agreement_type_id;
            icPreferenceRule.service_id = request.createIcPreferenceRuleReq.service_id;
            icPreferenceRule.event_type_id = request.createIcPreferenceRuleReq.event_type_id;
            icPreferenceRule.instruction = request.createIcPreferenceRuleReq.instruction;
            icPreferenceRule.can_modify = true;//request.createIcPreferenceRuleReq.can_modify;
            icPreferenceRule.can_override = request.createIcPreferenceRuleReq.can_override;
            icPreferenceRule.is_overridden = request.createIcPreferenceRuleReq.is_overridden;
            icPreferenceRule.instruction_rule = request.createIcPreferenceRuleReq.instruction_rule;
            icPreferenceRule.inclusion_type_id = request.createIcPreferenceRuleReq.preference_type_id;
            icPreferenceRule.rule_type_id = request.createIcPreferenceRuleReq.rule_type_id;
            icPreferenceRule.currency_id = request.createIcPreferenceRuleReq.currency_id;
            icPreferenceRule.sequence_number = request.createIcPreferenceRuleReq.sequence_number;

            result = await _preferenceRepo.CreateIcPreferenceRule(icPreferenceRule);
            return result;
                
        }
        public string LoadRuleXml(string ruleId)
        {
            return "";
        }
    }
}
