﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.IcInstructions.Command
{
    public class UpdateIcPreferenceRuleStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class UpdateIcPreferenceRuleStatusCommandHandler : IRequestHandler<UpdateIcPreferenceRuleStatusCommand,bool>
    {
        private readonly IPreferenceRepository _preferenceRepo;

        public UpdateIcPreferenceRuleStatusCommandHandler(IPreferenceRepository preferenceRepo)
        {
            _preferenceRepo = preferenceRepo;
        }
        public async Task<bool> Handle(UpdateIcPreferenceRuleStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _preferenceRepo.UpdateIcPreferenceRuleStatus(request.id, request.is_active);
            return result;
        }
    }
}
