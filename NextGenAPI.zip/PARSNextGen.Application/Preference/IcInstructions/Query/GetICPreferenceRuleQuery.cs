﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.Utility.Preference;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.IcInstructions.Query
{
    public class GetICPreferenceRuleQuery : IRequest<GetICPreferenceRuleDto>
    {
        public long id { get; set; }
    }
    public class GetICPreferenceRuleQueryHandler : IRequestHandler<GetICPreferenceRuleQuery, GetICPreferenceRuleDto>
    {
        private readonly ISqlContext _dbCntx;

        public GetICPreferenceRuleQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<GetICPreferenceRuleDto> Handle(GetICPreferenceRuleQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            GetICPreferenceRuleDto getICPreferenceRule = new GetICPreferenceRuleDto();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@Id", request.id);
                
                string query = "select ic.id,ic.agreement_id,ag.name agreement ,ic.agreement_type_id,at.name agreement_type,ic.service_id,sr.name service,ic.event_type_id,et.name event_type," +
                                   "ic.instruction, ic.can_modify,ic.can_override,ic.instruction_rule,ic.is_active,ic.created_on,ic.updated_on,ic.currency_id, cr.name as currency, " +
                                   "ic.inclusion_type_id,it.name as inclusion_type,ic.rule_type_id,rt.name as rule_type,ic.human_readable_rule,ic.sequence_number,ic.created_by from ic_preference_rule ic " +
                                   "left join agreement ag on ic.agreement_id = ag.id " +
                                   "left join agreement_type at on ic.agreement_type_id = at.id " +
                                   "left join service sr on ic.service_id = sr.id " +
                                   "left join event_type et on ic.event_type_id = et.id " +
                                   "left join currency cr on ic.currency_id = cr.id " +
                                   "left join inclusion_type it on ic.inclusion_type_id = it.id " +
                                   "left join rule_type rt on ic.rule_type_id = rt.id " +
                                   " where ic.id = @Id ";


                getICPreferenceRule = await connection.QueryFirstOrDefaultAsyncWithRetry<GetICPreferenceRuleDto>(query, dp, commandType: CommandType.Text);





                

                if (getICPreferenceRule != null && !string.IsNullOrWhiteSpace(getICPreferenceRule.instruction_rule))
                {
                    GetRuleEditor getRuleEditor = new GetRuleEditor();

                    long category_id = 1;


                    var editor = getRuleEditor.GetRuleEditorData(category_id, getICPreferenceRule.rule_type_id, "divruleeditor");

                    //ClientSettingsDto settings = new ClientSettingsDto
                    //{
                    //    EditorData = editor.GetInitialSettings(),
                    //    SourceData = editor.GetClientSettings(),
                    //};

                    //preference.clientSettingsDto = new ClientSettingsDto();

                    //preference.clientSettingsDto = settings;

                    editor.LoadRuleXml(getICPreferenceRule.instruction_rule);

                    string ruleJson = editor.GetClientRuleData();

                    getICPreferenceRule.instruction_rule = ruleJson;

                    // return preference;
                }







            }
            return getICPreferenceRule;
        }
    }
}
