﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.IcInstructions.Query
{
    public class GetAllICPreferenceRuleDto
    {
        public long? id { get; set; }
        public long? agreement_id { get; set; }
        public string agreement { get; set; }
        public long? agreement_type_id { get; set; }
        public long? parent_ic_preference_id { get; set; }
        public string agreement_type { get; set; }
        public long? service_id { get; set; }
        public string service { get; set; }
        public long event_type_id { get; set; }
        public string event_type { get; set; }
        public long? preference_type_id { get; set; }
        public string preference_type { get; set; }
        public string instruction { get; set; }
        public bool can_modify { get; set; }
        public bool can_override { get; set; }
        public string is_overriden { get; set; }
        public bool is_overridden { get; set; }
        public string is_inherited { get; set; }
        public string instruction_rule { get; set; }
        public long? inclusion_type_id { get; set; }
        public string inclusion_type { get; set; }
        public long? rule_type_id { get; set; }
        public string rule_type { get; set; }
        public long currency_id { get; set; }
        public string currency { get; set; }
        public string human_readable_rule { get; set; }
        public string category { get; set; }
        public int? sequence_number { get; set; }
        public bool is_active { get; set; }
        public DateTime created_on { get; set; }
        public DateTime updated_on { get; set; }
    }
}
