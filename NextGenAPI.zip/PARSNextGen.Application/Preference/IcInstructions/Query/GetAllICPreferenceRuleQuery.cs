﻿using Dapper;
using MassTransit.Util;
using MediatR;
using Newtonsoft.Json.Linq;
using PARSNextGen.Application.Preference.Preference.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.Xml;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.IcInstructions.Query
{
    public class GetAllICPreferenceRuleQuery : IRequest<List<GetAllICPreferenceRuleDto>>
    {
        public GetICPreferenceRuleListReq preferenceRuleListReq { get; set; }
    }
    public class GetAllICPreferenceRuleQueryHandler : IRequestHandler<GetAllICPreferenceRuleQuery, List<GetAllICPreferenceRuleDto>>
    {
        private readonly ISqlContext _dbCntx;

        public GetAllICPreferenceRuleQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<GetAllICPreferenceRuleDto>> Handle(GetAllICPreferenceRuleQuery request, CancellationToken cancellationToken)
        {
            try
            {

                DynamicParameters dp = new DynamicParameters();
                List<GetAllICPreferenceRuleDto> getAllICPreferenceRuleDto = new List<GetAllICPreferenceRuleDto>();
                using (var connection = _dbCntx.GetOpenConnection())
                {
                    string where = string.Empty;
                    List<string> servicelist = new List<string>();

                    #region Service from current agreement
                    dp.Add("@AgreementId", request.preferenceRuleListReq.agreement_id);
                    dp.Add("@event_type_id", EnumTypes.Event_Type.new_service_request);
                    where = string.Empty;

                    where = " where p.agreement_id = @AgreementId and p.event_type_id =@event_type_id order by p.created_on desc";
                    //else
                    //    where = " where p.agreement_id = @AgreementId  order by p.created_on desc";
                    string query = @"SELECT " +
                                    " p.id,p.name[name],p.agreement_id,ag.name agreement " +
                                    " , p.human_readable_rule,p.preference_type_id,p.preference_type " +
                                    " ,p.category_id, p.category,p.subcategory_id, p.subcategory " +
                                    " ,p.service_id, p.service,p.service_amount,p.event_type_id, p.event_type " +
                                    " ,p.inclusion_type_id,p.inclusion_type,p.rule_type_id, p.rule_type,p.rule_json,p.is_active " +
                                    " from vw_preferences p " +
                                    " left join agreement ag on p.agreement_id = ag.id " +
                                      where;
                    // " where p.agreement_id = @AgreementId and p.event_type_id =@event_type_id order by p.created_on desc";
                    List<PreferenceDto> preferencesList = (List<PreferenceDto>)await connection.QueryAsyncWithRetry<PreferenceDto>(query, dp, commandType: CommandType.Text);




                    #endregion END

                    where = string.Empty;



                    if (request.preferenceRuleListReq.agreement_id != null)
                    {
                        where = " where (ic.agreement_id = @agreementId or (ic.agreement_type_id = @agreementTypeId and ic.agreement_id is null)) and ic.currency_id = @currency_id order by ic.created_on desc ";
                        dp.Add("@agreementId", request.preferenceRuleListReq.agreement_id);
                        dp.Add("@agreementTypeId", request.preferenceRuleListReq.agreement_type_id);
                        dp.Add("@currency_id", request.preferenceRuleListReq.currency_id);
                    }
                    else
                    {
                        where = " where (ic.agreement_id is null and ic.agreement_type_id = @agreementTypeId ) and ic.currency_id = @currency_id order by ic.created_on desc ";
                        dp.Add("@agreementTypeId", request.preferenceRuleListReq.agreement_type_id);
                        dp.Add("@currency_id", request.preferenceRuleListReq.currency_id);
                    }


                    query = "select ic.id,ic.parent_ic_preference_id," +
                        "CASE WHEN parent_ic_preference_id IS NULL THEN 'No' ELSE 'Yes' END AS is_inherited ," +
                        "Case when is_overridden =1 then 'Yes' else 'No' end as is_overriden," +
                        "CASE WHEN ic.parent_ic_preference_id IS NULL AND ic.agreement_id IS NULL THEN 'Standard' " +
                        "WHEN ic.parent_ic_preference_id IS NULL AND ic.agreement_id IS NOT NULL THEN 'Custom' " +
                        "WHEN ic.parent_ic_preference_id IS NOT NULL AND ic.is_overridden = 1 THEN 'Overridden' " +
                        "END AS category ," +
                        "ic.agreement_id,ag.name agreement ,ic.agreement_type_id,at.name agreement_type,ic.service_id,sr.name service,ic.event_type_id,et.name event_type," +
                                       " ic.is_overridden,ic.instruction, ic.can_modify,ic.can_override,ic.instruction_rule,ic.currency_id, cr.name as currency, " +
                                       " ic.inclusion_type_id,it.name as inclusion_type,ic.rule_type_id,rt.name as rule_type,ic.human_readable_rule,ic.sequence_number,ic.is_active,ic.created_on,ic.updated_on " +
                                       "from ic_preference_rule ic " +
                                       "left join agreement ag on ic.agreement_id = ag.id " +
                                       "left join agreement_type at on ic.agreement_type_id = at.id " +
                                       "left join service sr on ic.service_id = sr.id " +
                                       "left join event_type et on ic.event_type_id = et.id " +
                                       "left join currency cr on ic.currency_id = cr.id " +
                                       "left join inclusion_type it on ic.inclusion_type_id = it.id " +
                                       "left join rule_type rt on ic.rule_type_id = rt.id " +
                                       where;


                    getAllICPreferenceRuleDto = (List<GetAllICPreferenceRuleDto>)await connection.QueryAsyncWithRetry<GetAllICPreferenceRuleDto>(query, dp, commandType: CommandType.Text);

                    List<long?> default_ic_instruction_ids = new List<long?>();
                    default_ic_instruction_ids = getAllICPreferenceRuleDto.Where(x => x.parent_ic_preference_id != null).Select(y => y.parent_ic_preference_id).ToList();
                    if (default_ic_instruction_ids.Count > 0)
                    {
                        foreach (long id in default_ic_instruction_ids)
                            getAllICPreferenceRuleDto.RemoveAll(y => y.id == id);
                    }



                    List<GetAllICPreferenceRuleDto> getAllICPreferenceRuleObj1 = new List<GetAllICPreferenceRuleDto>();
                    getAllICPreferenceRuleObj1.AddRange(getAllICPreferenceRuleDto);

                    if (preferencesList.Count > 0)
                    {
                        //foreach (var item in getAllICPreferenceRuleObj1)
                        //{
                        //    if (item.service_id != null)
                        //    {
                        //        var obj = preferencesList.Where(x => x.service_id == item.service_id).FirstOrDefault();

                        //        if (obj == null)
                        //        {
                        //            int? index = getAllICPreferenceRuleDto.FindIndex(x => x.id == item.id);
                        //            if (index != null && index != -1)
                        //            {
                        //                getAllICPreferenceRuleDto.RemoveAt((int)index);
                        //            }
                        //        }
                        //    }

                        //}
                    }



                }
                return getAllICPreferenceRuleDto;
            }
            catch(Exception ex) { }
            return null;
        }
    }
}
