﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.IcInstructions.Query
{
    public class GetICPreferenceRuleListReq
    {
        public long? agreement_id { get; set; }
        public long agreement_type_id { get; set; }
        public long currency_id { get; set; }
    }
}
