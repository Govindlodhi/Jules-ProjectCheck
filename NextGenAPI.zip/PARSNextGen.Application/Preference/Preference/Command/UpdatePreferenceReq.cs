﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Preference.Command
{
    public class UpdatePreferenceReq
    {
        public long id { get; set; }
        public string name { get; set; }
        public long? agreement_id { get; set; }
        //public long? preference_type_id { get; set; }
        public long? event_type_id { get; set; }
        public long? category_id { get; set; }
       
        //public long? subcategory_id { get; set; }
        public long? service_id { get; set; }
        public decimal? service_amount { get; set; }
        public long? inclusion_type_id { get; set; }
        public long? rule_type_id { get; set; }
        public string rule_json { get; set; }
        public bool can_override { get; set; }
        public bool can_modify { get; set; }
        public bool is_overridden { get; set; }
    }
}
