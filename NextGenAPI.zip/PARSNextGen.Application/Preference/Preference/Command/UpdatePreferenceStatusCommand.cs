﻿using MediatR;
using PARSNextGen.Domain.Interface;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace PARSNextGen.Application.Preference.Preference.Command
{
    public class UpdatePreferenceStatusCommand : IRequest<bool>
    {
        public UpdatePreferenceStatusReq updatePreferenceStatusReq { get; set; }
    }

    public class UpdatePreferenceStatusCommandHandler : IRequestHandler<UpdatePreferenceStatusCommand, bool>
    {
        private readonly IPreferenceRepository _preferenceRepo;
        public UpdatePreferenceStatusCommandHandler(IPreferenceRepository preferenceRepo)
        {
            _preferenceRepo = preferenceRepo;
        }



        public async Task<bool> Handle(UpdatePreferenceStatusCommand request, CancellationToken cancellationToken)
        {
            preference preference = new preference();

            #region preference_field

            preference.id = request.updatePreferenceStatusReq.id;
            preference.is_active = request.updatePreferenceStatusReq.is_active;

            #endregion

            bool status = await _preferenceRepo.UpdatePreferenceStatus(preference);

            return status;
        }
    }
}
