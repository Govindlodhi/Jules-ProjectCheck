﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using PARSNextGen.Domain.Interface;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Application.Utility.Preference;
using PARSNextGen.Application.Preference.RuleEditor.Queries;

namespace PARSNextGen.Application.Preference.Preference.Command
{
    public class CreatePreferenceCommand : IRequest<string>
    {
        public CreatePreferenceReq createPreferenceReq { get; set; }
    }
    public class CreatePreferenceCommandHandler : IRequestHandler<CreatePreferenceCommand, string>
    {

        private readonly IPreferenceRepository _preferenceRepo;
        public CreatePreferenceCommandHandler(IPreferenceRepository preferenceRepo)
        {
            _preferenceRepo = preferenceRepo;
        }
        public async Task<string> Handle(CreatePreferenceCommand request, CancellationToken cancellationToken)
        {
            preference preference = new preference();

            //request.createPreferenceReq.rule_json = "{'Elements':[{'Type':0,'Name':'_divruleeditor0','Oper':16,'FuncType':4,'InpType':2,'CalType':9,'Value':'if'},{'Type':1,'Name':'_divruleeditor1','Oper':0,'FuncType':4,'InpType':2,'CalType':9,'Value':'gvwr','IsRule':false,'Max':200},{'Type':3,'Name':'_divruleeditor2','Oper':0,'FuncType':4,'InpType':2,'CalType':9,'Value':'contains'},{'Type':4,'Name':'_divruleeditor4','Oper':0,'FuncType':4,'InpType':1,'CalType':9,'Value':'123'}],'IsLoadedRuleOfEvalType':true,'Command':'ceExtract','Mode':0,'Name':'name','Desc':'desc','SkipNameValidation':false}";


            if (!string.IsNullOrEmpty(request.createPreferenceReq.rule_json))
            {
                //GetRuleEditor getRuleEditor = new GetRuleEditor();

                //var editor = getRuleEditor.GetRuleEditorData(request.createPreferenceReq.category_id, request.createPreferenceReq.rule_type_id, "divRuleEditor");

                //editor.LoadClientData(request.createPreferenceReq.rule_json);

                //preference.human_readable_rule = editor.ToString();

                //if (!editor.Rule.IsValid(LoadRuleXml))
                //{

                //    var ClientInvalidData = editor.GetClientInvalidData();
                //}
                //request.createPreferenceReq.rule_json = editor.Rule.GetRuleXml();


                GetRuleEditor getRuleEditor = new GetRuleEditor();

                long category_id = 1;//Service Request = 1
                var editor = getRuleEditor.GetRuleEditorData(category_id, request.createPreferenceReq.rule_type_id, "divruleeditor");

                editor.LoadClientData(request.createPreferenceReq.rule_json);

                preference.human_readable_rule = editor.ToString();

                if (!editor.Rule.IsValid(LoadRuleXml))
                {

                    var ClientInvalidData = editor.GetClientInvalidData();
                }
                request.createPreferenceReq.rule_json = editor.Rule.GetRuleXml();



            }


            #region preference_field
            preference.agreement_id = request.createPreferenceReq.agreement_id;
            preference.name = request.createPreferenceReq.name;
            //preference.preference_type_id = request.createPreferenceReq.preference_type_id;
            preference.event_type_id = request.createPreferenceReq.event_type_id;
            preference.category_id = request.createPreferenceReq.category_id;
            
            //preference.subcategory_id = request.createPreferenceReq.subcategory_id;
            preference.service_id = request.createPreferenceReq.service_id;
            preference.service_amount = request.createPreferenceReq.service_amount;
            preference.inclusion_type_id = request.createPreferenceReq.inclusion_type_id;
            preference.rule_type_id = request.createPreferenceReq.rule_type_id;
            preference.rule_json = request.createPreferenceReq.rule_json;
            preference.can_override = request.createPreferenceReq.can_override;
            preference.can_modify = request.createPreferenceReq.can_modify;
            preference.is_overridden = request.createPreferenceReq.is_overridden;

            #endregion

            string status = await _preferenceRepo.CreatePreference(preference);
            return status;
        }
        public string LoadRuleXml(string ruleId)
        {
            return "";
        }
    }
}
