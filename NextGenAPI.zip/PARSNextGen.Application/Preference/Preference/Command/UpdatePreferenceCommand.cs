﻿using MediatR;
using PARSNextGen.Application.Utility.Preference;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Preference.Command
{
    public class UpdatePreferenceCommand : IRequest<bool>
    {
        public UpdatePreferenceReq updatePreferenceReq { get; set; }
    }
    public class UpdatePreferenceCommandHandler : IRequestHandler<UpdatePreferenceCommand, bool>
    {
        private readonly IPreferenceRepository _preferenceRepo;
        public UpdatePreferenceCommandHandler(IPreferenceRepository preferenceRepo)
        {
            _preferenceRepo = preferenceRepo;
        }



        public async Task<bool> Handle(UpdatePreferenceCommand request, CancellationToken cancellationToken)
        {
            preference preference = new preference();

            if (!string.IsNullOrEmpty(request.updatePreferenceReq.rule_json))
            {
                GetRuleEditor getRuleEditor = new GetRuleEditor();

                long category_id = 1;//Service Request = 1
                var editor = getRuleEditor.GetRuleEditorData(category_id, request.updatePreferenceReq.rule_type_id, "divruleeditor");

                editor.LoadClientData(request.updatePreferenceReq.rule_json);

                preference.human_readable_rule = editor.ToString();

                if (!editor.Rule.IsValid(LoadRuleXml))
                {

                    var ClientInvalidData = editor.GetClientInvalidData();
                }
                request.updatePreferenceReq.rule_json = editor.Rule.GetRuleXml();
            }
            

            #region preference_field
            preference.id = request.updatePreferenceReq.id;
            preference.agreement_id = request.updatePreferenceReq.agreement_id;
            preference.name = request.updatePreferenceReq.name;
            //preference.preference_type_id = request.updatePreferenceReq.preference_type_id;
            preference.event_type_id = request.updatePreferenceReq.event_type_id;
            preference.category_id = request.updatePreferenceReq.category_id;
            //preference.subcategory_id = request.updatePreferenceReq.subcategory_id;
            preference.service_id = request.updatePreferenceReq.service_id;
            preference.service_amount = request.updatePreferenceReq.service_amount;
            preference.inclusion_type_id = request.updatePreferenceReq.inclusion_type_id;
            preference.rule_type_id = request.updatePreferenceReq.rule_type_id;
            preference.rule_json = request.updatePreferenceReq.rule_json;
            preference.can_override = request.updatePreferenceReq.can_override;
            preference.can_modify = request.updatePreferenceReq.can_modify;
            preference.is_overridden = request.updatePreferenceReq.is_overridden;

            #endregion

            bool status = await _preferenceRepo.UpdatePreference(preference);

            return status;
        }
        public string LoadRuleXml(string ruleId)
        {
            return "";
        }
    }
}
