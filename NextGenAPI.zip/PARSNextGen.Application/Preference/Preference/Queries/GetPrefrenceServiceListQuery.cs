﻿using Dapper;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using Scriban.Syntax;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Preference.Queries
{
    public class GetPrefrenceServiceListQuery : IRequest<List<PrefrenceServiceDto>>
    {
        public long currency_id { get; set; }
    }
    public class GetPrefrenceServiceListQueryHandler : IRequestHandler<GetPrefrenceServiceListQuery, List<PrefrenceServiceDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        private readonly IConfiguration _config;
        public GetPrefrenceServiceListQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService, IConfiguration configuration)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
            _config = configuration;
        }
        public async Task<List<PrefrenceServiceDto>> Handle(GetPrefrenceServiceListQuery request, CancellationToken cancellationToken)
        {
            List<PrefrenceServiceDto> prefrenceServiceDto = new List<PrefrenceServiceDto>();            

            using (var connection = _dbCntx.GetOpenConnection())
            {
                /*
                //DynamicParameters dp = new DynamicParameters();
                //dp.Add("@AgreementId", request.agreement_id);
                //string queryAgreement = @"select fleet_id,fmc_id from agreement where id=@AgreementId;";
                //var agreement = await connection.QueryFirstOrDefaultAsyncWithRetry<Object>(queryAgreement, dp, commandType: CommandType.Text);
                //long? fmc_id = null, fleet_id = null;
                //string quesrydefaultpricelist = "";
                //long? default_price_list_id = null;
                //if (agreement != null)
                //{
                //    var attribute = ((IDictionary<String, Object>)agreement);


                //    var fmcId = attribute["fmc_id"];
                //    if (fmcId != null)
                //    {
                //        fmc_id = Convert.ToInt64(attribute["fmc_id"].ToString());
                //    }
                //    var fleetId = attribute["fleet_id"];
                //    if (fleetId != null)
                //    {
                //        fleet_id = Convert.ToInt64(attribute["fleet_id"].ToString());
                //    }

                //    //If Agreement between FMC and Fleet than get Fleet Pricelist.
                //    if (fmc_id != null && fleet_id != null)
                //    {
                //        dp = new DynamicParameters();
                //        dp.Add("@fleet_id", request.agreement_id);
                //        quesrydefaultpricelist = @"select default_price_list_id from account a where id=@fleet_id;";
                //    }
                //    //If Agreement of FMC  then get Pricelist accordingly.
                //    if (fmc_id != null && fleet_id == null)
                //    {
                //        dp = new DynamicParameters();
                //        dp.Add("@fmc_id", request.agreement_id);
                //        quesrydefaultpricelist = @"select default_price_list_id from account a where id=@fmc_id;";
                //    }
                //}
                ////If Agreement of Fleet  then get Pricelist accordingly.
                //if (fmc_id == null && fleet_id != null)
                //{
                //    dp = new DynamicParameters();
                //    dp.Add("@fleet_id", request.agreement_id);
                //    quesrydefaultpricelist = @"select default_price_list_id from account a where id=@fleet_id;";
                //}

                //var defaultPriceList = await connection.QueryFirstOrDefaultAsyncWithRetry<Object>(quesrydefaultpricelist, dp, commandType: CommandType.Text);
                //var defaultPriceListattribute = ((IDictionary<String, Object>)defaultPriceList);

                //var defaultPriceListId = defaultPriceListattribute["default_price_list_id"];

                //if (defaultPriceListId != null)
                //{
                //    default_price_list_id = Convert.ToInt64(defaultPriceListattribute["default_price_list_id"].ToString());
                //} */

                string priceListId = string.Empty;
                if (request.currency_id == (long)EnumTypes.CurrencyType.CA)
                {
                    priceListId = _config["appSettings:DefaultPriceListIdCA"];
                }
                else if (request.currency_id == (long)EnumTypes.CurrencyType.US)
                {
                    priceListId = _config["appSettings:DefaultPriceListIdUS"];
                }
                else
                {
                    return prefrenceServiceDto;
                }

                DynamicParameters dp = new DynamicParameters();
                dp.Add("@pricelistId", priceListId);
                string priceListItem = @"SELECT distinct pitem.service_id id,s.name FROM price_list_item pitem " +
                                        " INNER JOIN service s ON pitem.service_id=s.id " +
                                        " INNER JOIN price_list plist on pitem.price_list_id=plist.id"+                                        
                                        " WHERE plist.id=@pricelistId and pitem.is_active=1 order by s.name";
                prefrenceServiceDto = (List<PrefrenceServiceDto>)await connection.QueryAsyncWithRetry<PrefrenceServiceDto>(priceListItem, dp, commandType: CommandType.Text);
            }
            return prefrenceServiceDto;
        }
    }
}
