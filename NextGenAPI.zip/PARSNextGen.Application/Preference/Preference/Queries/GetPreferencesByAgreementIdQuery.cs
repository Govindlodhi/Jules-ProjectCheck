﻿                   using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Preference.Queries
{
    public class GetPreferencesByAgreementIdQuery:IRequest<List<PreferenceDto>>
    {
        public long? agreementId { get;set; }
        public long? eventTypeId { get;set; }
    }
    public class GetPreferencesByAgreementIdQueryHandler : IRequestHandler<GetPreferencesByAgreementIdQuery, List<PreferenceDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetPreferencesByAgreementIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<List<PreferenceDto>> Handle(GetPreferencesByAgreementIdQuery request, CancellationToken cancellationToken )
        {
            List<PreferenceDto> preferencesList = new List<PreferenceDto>();
            DynamicParameters dp = new DynamicParameters();
            List<AgreementDetails> agreementDetails = new List<AgreementDetails>();
            if (request.agreementId != null)
            {
                using (var connection = _dbCntx.GetOpenConnection())
                {
                    dp.Add("@AgreementId", request.agreementId);
                    dp.Add("@event_type_id", request.eventTypeId);
                    string where = string.Empty;
                    where = " where p.agreement_id = @AgreementId  order by p.created_on desc";
                    if (request.eventTypeId != null)
                    {
                        if(request.eventTypeId == 1)
                        where = " where p.agreement_id = @AgreementId and p.event_type_id =@event_type_id  or p.event_type_id = 2 order by p.created_on desc";
                        else
                        where = " where p.agreement_id = @AgreementId and p.event_type_id =@event_type_id order by p.created_on desc";

                    }
                    else
                        where = " where p.agreement_id = @AgreementId  order by p.created_on desc";
                    string query = @"SELECT " +
                                   " p.id,p.name[name],p.agreement_id,ag.name agreement " +
                                   " ,CASE WHEN parent_preference_id IS NULL THEN 'No' ELSE 'Yes' END AS is_inherited "+
                                   " , p.human_readable_rule,p.preference_type_id,p.preference_type " +
                                   " ,p.category_id, p.category,p.subcategory_id, p.subcategory " +
                                   " ,p.service_id, p.service,case when p.service_amount is null then s.average_cost else p.service_amount end as service_amount," +
                                   "p.event_type_id, p.event_type " +
                                   " ,p.inclusion_type_id,p.inclusion_type,p.rule_type_id, p.rule_type,p.rule_json,p.is_active,p.created_on,p.updated_on " +
                                   " from vw_preferences p " +
                                   " left join agreement ag on p.agreement_id = ag.id " +
                                   " left join service s on p.service_id = s.id " +
                                     where;
                    // " where p.agreement_id = @AgreementId and p.event_type_id =@event_type_id order by p.created_on desc";
                    preferencesList = (List<PreferenceDto>)await connection.QueryAsyncWithRetry<PreferenceDto>(query, dp, commandType: CommandType.Text);
                }
            }
            else
            {
                preferencesList = null;
            }

           
            return preferencesList;
        }

       
    }
}
