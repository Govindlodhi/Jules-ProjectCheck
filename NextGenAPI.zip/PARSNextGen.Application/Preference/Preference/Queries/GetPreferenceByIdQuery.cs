﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Preference.RuleEditor.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.Utility.Preference;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Preference.Queries
{
    public class GetPreferenceByIdQuery : IRequest<PreferenceDto>
    {
        public long? preferenceId { get; set; }
    }
    public class GetPreferenceByIdQueryHandler : IRequestHandler<GetPreferenceByIdQuery, PreferenceDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetPreferenceByIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<PreferenceDto> Handle(GetPreferenceByIdQuery request, CancellationToken cancellationToken)
        {
            PreferenceDto preference = new PreferenceDto();
            DynamicParameters dp = new DynamicParameters();

            if (request.preferenceId != null)
            {
                using (var connection = _dbCntx.GetOpenConnection())
                {
                    string query = @"SELECT "+
                        " p.id, p.name,agreement_id, event_type_id,human_readable_rule, event_type, category_id, " +
                        " category, subcategory_id, subcategory, service_id , service , service_amount, inclusion_type_id, inclusion_type, " +
                        " rule_code, rule_type_id, rule_type , rule_json, can_override, can_modify, is_overridden, p.is_active, p.created_on" +
                        " ,created_by ,p.created_by_name , updated_on, updated_by, p.updated_by_name,parent_preference_id" +
                        " FROM vw_preferences p inner join vw_agreements vag on p.agreement_id=vag.id where p.id = @PreferenceId";

                    dp.Add("@PreferenceId", request.preferenceId);

                    preference = (PreferenceDto)await connection.QueryFirstOrDefaultAsyncWithRetry<PreferenceDto>(query, dp, commandType: CommandType.Text);

                    if (preference.parent_preference_id != null && preference.can_override == false)
                        preference.is_readOnly = true;

                    if (preference != null && !string.IsNullOrWhiteSpace(preference.rule_json))
                    {
                        GetRuleEditor getRuleEditor = new GetRuleEditor();

                        var editor = getRuleEditor.GetRuleEditorData(preference.category_id, preference.rule_type_id, "divruleeditor");

                        //ClientSettingsDto settings = new ClientSettingsDto
                        //{
                        //    EditorData = editor.GetInitialSettings(),
                        //    SourceData = editor.GetClientSettings(),
                        //};

                        //preference.clientSettingsDto = new ClientSettingsDto();

                        //preference.clientSettingsDto = settings;

                        editor.LoadRuleXml(preference.rule_json);

                        string ruleJson = editor.GetClientRuleData();

                        preference.rule_json = ruleJson;

                        // return preference;
                    }
                }
            }

            return preference;
        }


    }
}
