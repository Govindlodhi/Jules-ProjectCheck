﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Preference.Queries
{
    public class GetPreferenceMasterQuery : IRequest<PreferenceMasterDto>
    {

    }
    public class GetPreferenceMasterQueryHandler : IRequestHandler<GetPreferenceMasterQuery, PreferenceMasterDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetPreferenceMasterQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<PreferenceMasterDto> Handle(GetPreferenceMasterQuery request, CancellationToken cancellationToken)
        {
            PreferenceMasterDto preferenceMasterDto = new PreferenceMasterDto();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string preferenceType = @"select id,name  from preference_type where is_active = 1;";
                string eventType = @"select id,name from event_type where is_public=1 and is_active = 1;";
                string category = @"select id,name from category where is_active = 1;";
                string inclusionType = @"select id,name from inclusion_type where is_active = 1;";
                string ruleType = @"select id,name from rule_type where is_active = 1;";
                string inspectionType = @"select id,name from inspection_type where is_active = 1 ;";
                string stateName = @"select id,name from state where is_active = 1 order by name;";

                string multiSQLQry = preferenceType + eventType + category  + inclusionType + ruleType+inspectionType+ stateName;

                using (var multiResultSet = await connection.QueryMultipleAsync(multiSQLQry))
                {
                    preferenceMasterDto.preference_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    preferenceMasterDto.event_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    preferenceMasterDto.category = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    preferenceMasterDto.inclusion_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    preferenceMasterDto.rule_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    preferenceMasterDto.inspection_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    preferenceMasterDto.state_name = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                }
            }
            return preferenceMasterDto;
        }

    }
}
