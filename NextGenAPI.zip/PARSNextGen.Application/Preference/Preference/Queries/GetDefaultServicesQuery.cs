﻿using Dapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PARSNextGen.Application.Calculation.Queries;
using PARSNextGen.Application.Quotes.QuickQuote.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.Utility.Preference;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Security.Cryptography.Xml;
using System.Threading;
using System.Threading.Tasks;
using static PARSNextGen.Domain.Common.EnumTypes;

namespace PARSNextGen.Application.Preference.Preference.Queries
{
    public class GetDefaultServicesQuery : IRequest<List<ApplicableServiceDto>>
    {
        public List<JsonResult> jsonResults { get; set; }
        public long? price_list_id { get; set; }
        public long? service_id { get; set; }
        public long? agreement_id { get; set; }
        public long? rule_type_id { get; set; }
        public long? event_type_id { get; set; }
        public long? service_standard { get; set; }
        public List<ApplicableServiceDto>? applicableServiceDto { get; set; }


    }
    public class GetDefaultServicesQueryHandler : IRequestHandler<GetDefaultServicesQuery, List<ApplicableServiceDto>>
    {
        private readonly IMediator _mediator;
        private readonly ISqlContext _dbCntx;
        private readonly IConfiguration _config;
        public GetDefaultServicesQueryHandler(IMediator mediator, ISqlContext dbCntx, IConfiguration config)
        {
            _dbCntx = dbCntx;
            _mediator = mediator;
            _config = config;
        }

        public async Task<List<ApplicableServiceDto>> Handle(GetDefaultServicesQuery request, CancellationToken cancellationToken)
        {
            List<ApplicableServiceDto> applicableServiceDtos = new List<ApplicableServiceDto>();

            List<string> service_idList = new List<string>();

            List<ActionResponse> actionResponsesList = new List<ActionResponse>();
            List<ApplicableServiceDto> applicableServiceList = new List<ApplicableServiceDto>();
            var message = _config["appSettings:ActualService"];
            if (request.service_id == null)
            {
                foreach (var item in request.jsonResults)
                {
                    //

                    var response = (IDictionary<String, Object>)(item.Value);

                    if (response != null)
                    {
                        PreferencesListDto preferencesListDto = new PreferencesListDto();

                        if (response.ContainsKey("Preference") && response["Preference"] != null)
                        {
                            preferencesListDto = (PreferencesListDto)response["Preference"];

                            if (response.ContainsKey("isInclusionType"))
                            {
                                bool isInclusionType = bool.Parse(response["isInclusionType"].ToString());
                                if (isInclusionType)
                                {
                                    service_idList.Add(preferencesListDto.service_id.ToString());
                                    continue;
                                }

                            }

                            if (preferencesListDto.rule_type_id == (long)EnumTypes.Rule_Type.Evaluation)
                            {

                                if (response["Output"] != null && !string.IsNullOrWhiteSpace(response["Output"].ToString()) && preferencesListDto.service_id != null)
                                {
                                    bool evaluationResult = false;
                                    if (Boolean.TryParse(response["Output"].ToString(), out evaluationResult))
                                    {
                                        if (evaluationResult)
                                        {
                                            service_idList.Add(preferencesListDto.service_id.ToString());
                                        }
                                    }

                                }
                            }
                            else
                            {
                                // Deserialize action response json



                                if (response["Output"] != null && !string.IsNullOrWhiteSpace(response["Output"].ToString()) && preferencesListDto.service_id != null)
                                {
                                    string responseOut = response["Output"].ToString();
                                    if (responseOut != "False")
                                    {

                                        ActionResponse actionResponse = JsonConvert.DeserializeObject<ActionResponse>(responseOut);


                                        //bool evaluationResult = false;
                                        // if (Boolean.TryParse(response["Output"].ToString(), out evaluationResult))
                                        if (actionResponse.success)
                                        {
                                            //if (evaluationResult)
                                            //{
                                            service_idList.Add(preferencesListDto.service_id.ToString());
                                            // }
                                            ActionResponse actionResponsItem = new ActionResponse();
                                            actionResponsItem.service_id = (long)preferencesListDto.service_id;
                                            actionResponsItem.action_type = actionResponse.action_type;
                                            actionResponsItem.message = actionResponse.message;

                                            actionResponsesList.Add(actionResponsItem);
                                        }
                                    }

                                }
                            }
                        }
                    }

                }
            }
            else
            {
                service_idList.Add(request.service_id.ToString());
            }

            if (service_idList.Count > 0)
            {
                var serviceIds = string.Join(",", service_idList.ToArray());
                
                serviceIds = string.Join(",", service_idList.ToArray());

                DynamicParameters dp = new DynamicParameters();
                List<ApplicableServiceDto> applicableServiceDto = new List<ApplicableServiceDto>();
                string query = string.Empty;
                string TNRquery = string.Empty;
                List<ApplicableServiceDto> TNRapplicableServiceDto = new List<ApplicableServiceDto>();
                using (var connection = _dbCntx.GetOpenConnection())
                {
                    ApplicableServiceDto serviceObj = null;
                    string where = string.Empty;
                    if (request.rule_type_id != null)
                    {
                        if (request.rule_type_id == (long)EnumTypes.Rule_Type.Evaluation && request.event_type_id != (long)EnumTypes.Event_Type.t_n_r_preferences)
                        {
                            where = " and (pr.rule_type_id=@rule_type_id or inclusion_type_id=@inclusion_type_id)";
                        }
                        else if (request.rule_type_id == (long)EnumTypes.Rule_Type.Evaluation && request.event_type_id == (long)EnumTypes.Event_Type.t_n_r_preferences)
                        {
                            //where = " and (pr.rule_type_id=@rule_type_id or inclusion_type_id=@inclusion_type_id)";
                        }
                        else
                        {
                            where = " and pr.rule_type_id=@rule_type_id  ";
                        }

                    }
                    dp.Add("@serviceId", serviceIds);
                    dp.Add("@PriceListId", request.price_list_id);
                    dp.Add("@AgreementId", request.agreement_id);
                    dp.Add("@rule_type_id", request.rule_type_id);
                    dp.Add("@inclusion_type_id", (long)EnumTypes.Preference_Type.Include);

                    if (request.rule_type_id != null)
                    {
                        if (request.event_type_id == (long)EnumTypes.Event_Type.t_n_r_preferences)
                        {
                            query = @"select priceListItem.id ,priceListItem.service_id,sr.crm_id,sr.unit_crm_id, sr.service_order_type_id,priceListItem.price_list_id,sr.name as service,sr.description,
                                      sr.impacts_timeline,sr.have_more_info,sr.is_major_service,  
                                      priceListItem.rate_type_id, priceListItem.sur_charge, priceListItem.markup_number, priceListItem.markup_type, priceListItem.discount, 
                                      priceListItem.discount_type as discount_type_id, priceListItem.rebate, priceListItem.rebate_type, priceListItem.is_active,
                                      sr.is_public,
                                      0 as can_modify,
                                      priceListItem.amount amount,
                                      sr.is_ic_instruction,sr.sub_category_id,subCat.name sub_category,subCat.description sub_category_description ,
                                      rt.name rate_type
                                      from price_list_item priceListItem 
                                      inner join rate_type rt on priceListItem.rate_type_id=rt.id
                                      inner join  service sr on priceListItem.service_id = sr.id  
                                      inner join  sub_category subCat on sr.sub_category_id = subCat.id 
                                      where priceListItem.service_id in ((select value from FnSpliteParameterVals(@serviceId,',')))
                                      and price_list_id=@PriceListId ";



                        }
                        else
                        {

                            query = @"select priceListItem.id" +
                                            " ,priceListItem.service_id,sr.crm_id,sr.unit_crm_id,sr.service_order_type_id,priceListItem.price_list_id,sr.name as service,sr.description,sr.impacts_timeline,sr.have_more_info,sr.is_major_service," +
                                            //" case when pr.service_amount is null then priceListItem.amount else pr.service_amount end amount," +
                                            "priceListItem.amount as amount,pr.service_amount authorized_amount," +
                                            " priceListItem.rate_type_id, priceListItem.sur_charge, priceListItem.markup_number, priceListItem.markup_type, priceListItem.discount," +
                                            " priceListItem.discount_type as discount_type_id, priceListItem.rebate, priceListItem.rebate_type, priceListItem.is_active ,pr.can_modify,sr.is_public,pr.rule_type_id, " +
                                            " sr.is_ic_instruction,sr.sub_category_id,subCat.name sub_category,subCat.description sub_category_description , rt.name rate_type" +
                                            " from price_list_item priceListItem " +
                                            " inner join  service sr on priceListItem.service_id = sr.id " +
                                            " inner join rate_type rt on priceListItem.rate_type_id=rt.id" +
                                            " inner join  sub_category subCat on sr.sub_category_id = subCat.id" +
                                            " inner join preference pr on  pr.service_id=priceListItem.service_id " +
                                            " where priceListItem.service_id in ((select value from FnSpliteParameterVals(@serviceId,','))) " +
                                            " and price_list_id=@PriceListId and pr.agreement_id=@AgreementId " + where + "";
                        }

                        applicableServiceDto = (List<ApplicableServiceDto>)await connection.QueryAsyncWithRetry<ApplicableServiceDto>(query, dp, commandType: CommandType.Text);
                    }
                    if (applicableServiceDto.Count == 0)
                    {
                        // If service not exsit in preference
                        query = @"select priceListItem.id" +
                                         ",priceListItem.service_id,sr.crm_id,sr.unit_crm_id, sr.service_order_type_id," +
                                         " priceListItem.price_list_id,sr.name as service,sr.description,sr.impacts_timeline,sr.have_more_info,sr.is_major_service," +
                                         " priceListItem.amount amount," +
                                         " priceListItem.rate_type_id, priceListItem.sur_charge, priceListItem.markup_number, priceListItem.markup_type, priceListItem.discount," +
                                         " priceListItem.discount_type as discount_type_id, priceListItem.rebate, priceListItem.rebate_type, priceListItem.is_active,1 as can_modify,sr.is_public,null as rule_type_id, " +
                                         " sr.is_ic_instruction,sr.sub_category_id,subCat.name sub_category,subCat.description sub_category_description , rt.name rate_type" +
                                         " from price_list_item priceListItem " +
                                         " inner join rate_type rt on priceListItem.rate_type_id=rt.id" +
                                         " left join  service sr on priceListItem.service_id = sr.id " +
                                         " inner join  sub_category subCat on sr.sub_category_id = subCat.id" +
                                         " inner join  price_list pl on priceListItem.price_list_id = pl.id " +
                                         " where priceListItem.service_id in ((select value from FnSpliteParameterVals(@serviceId,','))) " +
                                         " and price_list_id=@PriceListId ";
                        applicableServiceDto = (List<ApplicableServiceDto>)await connection.QueryAsyncWithRetry<ApplicableServiceDto>(query, dp, commandType: CommandType.Text);

                    }

                    #region GET SHIPPING AND HANDLING SERVICES
                    if (applicableServiceDto.Count > 0)
                    {
                        TNRquery = @"select plm.id,ds.id service_id,s.id dependent_service_id,ds.service_order_type_id,plm.price_list_id
                                    ,ds.name service
                                    ,concat('(for ',s.name,') ',ds.description ) description
                                    ,ds.impacts_timeline
                                    ,ds.have_more_info,ds.is_major_service
                                    ,plm.amount  amount
                                    ,plm.rate_type_id, rt.name rate_type, plm.sur_charge, plm.markup_number, plm.markup_type, plm.discount
                                    ,plm.discount_type as discount_type_id, plm.rebate, plm.rebate_type, plm.is_active,1 as can_modify,ds.is_public,null as rule_type_id
                                    , ds.is_ic_instruction,ds.sub_category_id
                                    ,sb.name sub_category,sb.description sub_category_description
                                    from service s
                                    inner JOin service ds ON s.dependent_service_id = ds.id
                                    inner join price_list_item plm on plm.service_id=ds.id
                                    inner join rate_type rt on plm.rate_type_id=rt.id
                                    inner join sub_category sb on ds.sub_category_id=sb.id
                                    where s.id in ((select value from FnSpliteParameterVals(@serviceId,','))) and plm.price_list_id=@PriceListId";

                        TNRapplicableServiceDto = (List<ApplicableServiceDto>)await connection.QueryAsyncWithRetry<ApplicableServiceDto>(TNRquery, dp, commandType: CommandType.Text);
                    }
                    #endregion END



                    if (applicableServiceDto.Count > 0)
                    {
                        if (request.event_type_id == (long)EnumTypes.Event_Type.t_n_r_preferences)
                        {
                            applicableServiceList = request.applicableServiceDto;

                            foreach (var serviceItem in applicableServiceDto)
                            {
                                serviceObj = new ApplicableServiceDto();

                                serviceObj.id = serviceItem.id;
                                serviceObj.is_ic_instruction = serviceItem.is_ic_instruction;
                                serviceObj.sub_category_id = serviceItem.sub_category_id;
                                serviceObj.sub_category = serviceItem.sub_category;
                                serviceObj.sub_category_description = serviceItem.sub_category_description;
                                serviceObj.service_id = serviceItem.service_id;
                                serviceObj.crm_id = serviceItem.crm_id;
                                serviceObj.unit_crm_id = serviceItem.unit_crm_id;
                                serviceObj.service_order_type_id = serviceItem.service_order_type_id;
                                serviceObj.service = serviceItem.service;
                                serviceObj.description = serviceItem.description;
                                serviceObj.impacts_timeline = serviceItem.impacts_timeline;
                                serviceObj.rate_type_id = serviceItem.rate_type_id;
                                if (serviceItem.rate_type_id == (int)Rate_Type.Actual)
                                {
                                    serviceObj.actual_service = message;
                                }
                                serviceObj.rate_type = serviceItem.rate_type;
                                serviceObj.is_price_modifiable = serviceItem.is_price_modifiable;

                                serviceObj.amount = serviceItem.amount;
                                serviceObj.authorized_amount = serviceItem.authorized_amount;
                                serviceObj.actual_amount = serviceItem.actual_amount;

                                serviceObj.amount_modified_reason = serviceItem.amount_modified_reason;
                                serviceObj.per_mile_rate = serviceItem.per_mile_rate;
                                serviceObj.distance = serviceItem.distance;
                                serviceObj.fuel_surcharge_rate = serviceItem.fuel_surcharge_rate;
                                serviceObj.fuel_surcharge_amount = serviceItem.fuel_surcharge_amount;
                                serviceObj.pickup_hub_fee = serviceItem.pickup_hub_fee;
                                serviceObj.delivery_hub_fee = serviceItem.delivery_hub_fee;
                                serviceObj.admin_fee = serviceItem.admin_fee;
                                serviceObj.surcharge_type_id = serviceItem.surcharge_type_id;
                                serviceObj.surcharge_rate = serviceItem.surcharge_rate;
                                serviceObj.surcharge_amount = serviceItem.surcharge_amount;
                                serviceObj.markup_number = serviceItem.markup_number;
                                serviceObj.markup_type_id = serviceItem.markup_type_id;
                                serviceObj.markup_amount = serviceItem.markup_amount;
                                serviceObj.discount_rate = serviceItem.discount_rate;
                                serviceObj.discount_type_id = serviceItem.discount_type_id;
                                serviceObj.discount_amount = serviceItem.discount_amount;
                                serviceObj.rebate_rate = serviceItem.rebate_rate;
                                serviceObj.rebate_type_id = serviceItem.rebate_type_id;
                                serviceObj.rebate_amount = serviceItem.rebate_amount;
                                serviceObj.total_amount = serviceItem.total_amount;

                                //if ((actionResponsItem.action_type == (long)EnumTypes.Action_Type.Alert_Message) || (serviceObj.impacts_timeline == true))
                                //{
                                //    serviceObj.is_alert_message = true;
                                //    serviceObj.service_notification_icon = (int)EnumTypes.Service_Notification_Icon.Warning;
                                //}
                                //else
                                //{
                                serviceObj.is_alert_message = false;
                                serviceObj.is_major_service = serviceItem.is_major_service;
                                //}
                                if (serviceObj.service_notification_icon == null)
                                {
                                    if (request.service_standard == (long)EnumTypes.Service_Standard.New)
                                    {
                                        serviceObj.service_notification_icon = null;
                                    }
                                    else
                                    {
                                        serviceObj.service_notification_icon = (int)EnumTypes.Service_Notification_Icon.Standard;
                                    }
                                }

                                serviceObj.have_more_info = serviceItem.have_more_info;
                                //serviceObj.additional_info = serviceItem.additional_info;

                                //serviceObj.message = actionResponsItem.message;

                                serviceObj.is_read_only = true;
                                serviceObj.service_standard = (int?)request.service_standard;
                                serviceObj.can_modify = false;
                                applicableServiceList.Add(serviceObj);



                            }

                        }
                        else
                        {
                            if (actionResponsesList.Count > 0)
                            {
                                //Add action service 


                                foreach (var serviceItem in applicableServiceDto)
                                {
                                    serviceObj = new ApplicableServiceDto();
                                    foreach (var actionResponsItem in actionResponsesList)
                                    {
                                        if (actionResponsItem.service_id == serviceItem.service_id)
                                        {
                                            serviceObj.id = serviceItem.id;
                                            serviceObj.is_ic_instruction = serviceItem.is_ic_instruction;
                                            serviceObj.sub_category_id = serviceItem.sub_category_id;
                                            serviceObj.sub_category = serviceItem.sub_category;
                                            serviceObj.sub_category_description = serviceItem.sub_category_description;
                                            serviceObj.service_id = serviceItem.service_id;
                                            serviceObj.crm_id = serviceItem.crm_id;
                                            serviceObj.unit_crm_id = serviceItem.unit_crm_id;
                                            serviceObj.service_order_type_id = serviceItem.service_order_type_id;
                                            serviceObj.service = serviceItem.service;
                                            serviceObj.description = serviceItem.description;
                                            serviceObj.impacts_timeline = serviceItem.impacts_timeline;
                                            serviceObj.rate_type_id = serviceItem.rate_type_id;
                                            if (serviceItem.rate_type_id == (int)Rate_Type.Actual)
                                            {
                                                serviceObj.actual_service = message;
                                            }
                                            serviceObj.rate_type = serviceItem.rate_type;
                                            serviceObj.is_price_modifiable = serviceItem.is_price_modifiable;
                                            serviceObj.amount = serviceItem.amount;
                                            serviceObj.authorized_amount = serviceItem.authorized_amount;
                                            serviceObj.amount_modified_reason = serviceItem.amount_modified_reason;
                                            serviceObj.per_mile_rate = serviceItem.per_mile_rate;
                                            serviceObj.distance = serviceItem.distance;
                                            serviceObj.fuel_surcharge_rate = serviceItem.fuel_surcharge_rate;
                                            serviceObj.fuel_surcharge_amount = serviceItem.fuel_surcharge_amount;
                                            serviceObj.pickup_hub_fee = serviceItem.pickup_hub_fee;
                                            serviceObj.delivery_hub_fee = serviceItem.delivery_hub_fee;
                                            serviceObj.admin_fee = serviceItem.admin_fee;
                                            serviceObj.surcharge_type_id = serviceItem.surcharge_type_id;
                                            serviceObj.surcharge_rate = serviceItem.surcharge_rate;
                                            serviceObj.surcharge_amount = serviceItem.surcharge_amount;
                                            serviceObj.markup_number = serviceItem.markup_number;
                                            serviceObj.markup_type_id = serviceItem.markup_type_id;
                                            serviceObj.markup_amount = serviceItem.markup_amount;
                                            serviceObj.discount_rate = serviceItem.discount_rate;
                                            serviceObj.discount_type_id = serviceItem.discount_type_id;
                                            serviceObj.discount_amount = serviceItem.discount_amount;
                                            serviceObj.rebate_rate = serviceItem.rebate_rate;
                                            serviceObj.rebate_type_id = serviceItem.rebate_type_id;
                                            serviceObj.rebate_amount = serviceItem.rebate_amount;
                                            serviceObj.total_amount = serviceItem.total_amount;

                                            serviceObj.can_modify = serviceItem.can_modify;

                                            if ((actionResponsItem.action_type == (long)EnumTypes.Action_Type.Alert_Message) || (serviceObj.impacts_timeline == true))
                                            {
                                                serviceObj.is_alert_message = true;
                                                serviceObj.service_notification_icon = (int)EnumTypes.Service_Notification_Icon.Warning;
                                            }
                                            else
                                            {
                                                serviceObj.is_alert_message = false;
                                            }
                                            if (serviceObj.service_notification_icon == null)
                                            {
                                                if (request.service_standard == (long)EnumTypes.Service_Standard.New)
                                                {
                                                    serviceObj.service_notification_icon = null;
                                                }
                                                else
                                                {
                                                    serviceObj.service_notification_icon = (int)EnumTypes.Service_Notification_Icon.Standard;
                                                }
                                            }

                                            serviceObj.have_more_info = serviceItem.have_more_info;
                                            //serviceObj.additional_info = serviceItem.additional_info;

                                            serviceObj.message = actionResponsItem.message;

                                            serviceObj.is_read_only = true;
                                            serviceObj.service_standard = (int?)request.service_standard;
                                            applicableServiceList.Add(serviceObj);
                                        }

                                    }
                                }
                            }

                            //Add evaluation service 

                            foreach (var serviceItem in applicableServiceDto)
                            {
                                bool isExist = false;
                                if (applicableServiceList.Count > 0)
                                {
                                    isExist = applicableServiceList.Exists(x => x.service_id == serviceItem.service_id);
                                }
                                if (!isExist)
                                {
                                    serviceObj = new ApplicableServiceDto();
                                    serviceObj.id = serviceItem.id;
                                    serviceObj.is_ic_instruction = serviceItem.is_ic_instruction;
                                    serviceObj.sub_category_id = serviceItem.sub_category_id;
                                    serviceObj.sub_category = serviceItem.sub_category;
                                    serviceObj.sub_category_description = serviceItem.sub_category_description;
                                    serviceObj.service_id = serviceItem.service_id;
                                    serviceObj.crm_id = serviceItem.crm_id;
                                    serviceObj.unit_crm_id = serviceItem.unit_crm_id;
                                    serviceObj.service_order_type_id = serviceItem.service_order_type_id;
                                    serviceObj.service = serviceItem.service;
                                    serviceObj.description = serviceItem.description;
                                    serviceObj.impacts_timeline = serviceItem.impacts_timeline;
                                    if (serviceObj.impacts_timeline == true)
                                    {
                                        serviceObj.is_alert_message = true;
                                        serviceObj.service_notification_icon = (int)EnumTypes.Service_Notification_Icon.Warning;
                                    }

                                    serviceObj.rate_type_id = serviceItem.rate_type_id;
                                    if (serviceItem.rate_type_id == (int)Rate_Type.Actual)
                                    {
                                        serviceObj.actual_service = message;
                                    }
                                    serviceObj.rate_type = serviceItem.rate_type;
                                    serviceObj.is_price_modifiable = serviceItem.is_price_modifiable;
                                    serviceObj.amount = serviceItem.amount;
                                    serviceObj.authorized_amount = serviceItem.authorized_amount;
                                    serviceObj.amount_modified_reason = serviceItem.amount_modified_reason;
                                    serviceObj.per_mile_rate = serviceItem.per_mile_rate;
                                    serviceObj.distance = serviceItem.distance;
                                    serviceObj.fuel_surcharge_rate = serviceItem.fuel_surcharge_rate;
                                    serviceObj.fuel_surcharge_amount = serviceItem.fuel_surcharge_amount;
                                    serviceObj.pickup_hub_fee = serviceItem.pickup_hub_fee;
                                    serviceObj.delivery_hub_fee = serviceItem.delivery_hub_fee;
                                    serviceObj.admin_fee = serviceItem.admin_fee;
                                    serviceObj.surcharge_type_id = serviceItem.surcharge_type_id;
                                    serviceObj.surcharge_rate = serviceItem.surcharge_rate;
                                    serviceObj.surcharge_amount = serviceItem.surcharge_amount;
                                    serviceObj.markup_number = serviceItem.markup_number;
                                    serviceObj.markup_type_id = serviceItem.markup_type_id;
                                    serviceObj.markup_amount = serviceItem.markup_amount;
                                    serviceObj.discount_rate = serviceItem.discount_rate;
                                    serviceObj.discount_type_id = serviceItem.discount_type_id;
                                    serviceObj.discount_amount = serviceItem.discount_amount;
                                    serviceObj.rebate_rate = serviceItem.rebate_rate;
                                    serviceObj.rebate_type_id = serviceItem.rebate_type_id;
                                    serviceObj.rebate_amount = serviceItem.rebate_amount;
                                    serviceObj.total_amount = serviceItem.total_amount;
                                    serviceObj.can_modify = serviceItem.can_modify;
                                    if (serviceObj.service_notification_icon == null)
                                    {
                                        if (request.service_standard == (long)EnumTypes.Service_Standard.New)
                                        {
                                            serviceObj.service_notification_icon = null;
                                        }
                                        else
                                        {
                                            serviceObj.service_notification_icon = (int)EnumTypes.Service_Notification_Icon.Standard;
                                        }
                                    }
                                    serviceObj.is_read_only = true;
                                    serviceObj.service_standard = (int?)request.service_standard;

                                    serviceObj.have_more_info = serviceItem.have_more_info;
                                    serviceObj.is_major_service = serviceItem.is_major_service;
                                    //serviceObj.additional_info = serviceItem.additional_info;

                                    applicableServiceList.Add(serviceObj);

                                }
                            }
                        }

                        #region ADD SHIPPING AND HANDLING
                        if (TNRapplicableServiceDto.Count > 0)
                        {
                            foreach (var serviceItem in TNRapplicableServiceDto)
                            {
                                serviceObj = new ApplicableServiceDto();

                                serviceObj.id = serviceItem.id;
                                serviceObj.is_ic_instruction = serviceItem.is_ic_instruction;
                                serviceObj.sub_category_id = serviceItem.sub_category_id;
                                serviceObj.sub_category = serviceItem.sub_category;
                                serviceObj.sub_category_description = serviceItem.sub_category_description;
                                serviceObj.service_id = serviceItem.service_id;
                                serviceObj.crm_id = serviceItem.crm_id;
                                serviceObj.unit_crm_id = serviceItem.unit_crm_id;
                                serviceObj.dependent_service_id = serviceItem.dependent_service_id;                                
                                serviceObj.service_order_type_id = serviceItem.service_order_type_id;
                                serviceObj.service = serviceItem.service;
                                serviceObj.description = serviceItem.description;
                                serviceObj.impacts_timeline = serviceItem.impacts_timeline;
                                serviceObj.rate_type_id = serviceItem.rate_type_id;
                                if (serviceItem.rate_type_id == (int)Rate_Type.Actual)
                                {
                                    serviceObj.actual_service = message;
                                }
                                serviceObj.rate_type = serviceItem.rate_type;
                                serviceObj.is_price_modifiable = serviceItem.is_price_modifiable;
                                serviceObj.amount = serviceItem.amount;
                                serviceObj.authorized_amount = serviceItem.authorized_amount;
                                serviceObj.amount_modified_reason = serviceItem.amount_modified_reason;
                                serviceObj.per_mile_rate = serviceItem.per_mile_rate;
                                serviceObj.distance = serviceItem.distance;
                                serviceObj.fuel_surcharge_rate = serviceItem.fuel_surcharge_rate;
                                serviceObj.fuel_surcharge_amount = serviceItem.fuel_surcharge_amount;
                                serviceObj.pickup_hub_fee = serviceItem.pickup_hub_fee;
                                serviceObj.delivery_hub_fee = serviceItem.delivery_hub_fee;
                                serviceObj.admin_fee = serviceItem.admin_fee;
                                serviceObj.surcharge_type_id = serviceItem.surcharge_type_id;
                                serviceObj.surcharge_rate = serviceItem.surcharge_rate;
                                serviceObj.surcharge_amount = serviceItem.surcharge_amount;
                                serviceObj.markup_number = serviceItem.markup_number;
                                serviceObj.markup_type_id = serviceItem.markup_type_id;
                                serviceObj.markup_amount = serviceItem.markup_amount;
                                serviceObj.discount_rate = serviceItem.discount_rate;
                                serviceObj.discount_type_id = serviceItem.discount_type_id;
                                serviceObj.discount_amount = serviceItem.discount_amount;
                                serviceObj.rebate_rate = serviceItem.rebate_rate;
                                serviceObj.rebate_type_id = serviceItem.rebate_type_id;
                                serviceObj.rebate_amount = serviceItem.rebate_amount;
                                serviceObj.total_amount = serviceItem.total_amount;

                                //if ((actionResponsItem.action_type == (long)EnumTypes.Action_Type.Alert_Message) || (serviceObj.impacts_timeline == true))
                                //{
                                //    serviceObj.is_alert_message = true;
                                //    serviceObj.service_notification_icon = (int)EnumTypes.Service_Notification_Icon.Warning;
                                //}
                                //else
                                //{
                                serviceObj.is_alert_message = false;
                                //}
                                if (serviceObj.service_notification_icon == null)
                                {
                                    if (request.service_standard == (long)EnumTypes.Service_Standard.New)
                                    {
                                        serviceObj.service_notification_icon = null;
                                    }
                                    else
                                    {
                                        serviceObj.service_notification_icon = (int)EnumTypes.Service_Notification_Icon.Standard;
                                    }
                                }

                                serviceObj.have_more_info = serviceItem.have_more_info;
                                //serviceObj.additional_info = serviceItem.additional_info;

                                //serviceObj.message = actionResponsItem.message;

                                serviceObj.is_read_only = true;
                                serviceObj.service_standard = (int?)request.service_standard;
                                serviceObj.can_modify = false;
                                applicableServiceList.Add(serviceObj);
                            }
                        }

                        #endregion END


                    }

                }
            }
            else
            {
                if (request.applicableServiceDto != null)
                    applicableServiceList = request.applicableServiceDto;
            }

            return applicableServiceList;
        }
    }


}
