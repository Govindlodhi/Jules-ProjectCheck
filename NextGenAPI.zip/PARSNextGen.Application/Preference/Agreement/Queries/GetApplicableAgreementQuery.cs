﻿using Dapper;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class GetApplicableAgreementQuery : IRequest<ApplicableAgreementDto>
    {
        public long? fmc_id { get; set; }
        public long? customer_account_id { get; set; }
        public long? fleet_id { get; set; }       
    }
    public class GetApplicableAgreementQueryHandler : IRequestHandler<GetApplicableAgreementQuery, ApplicableAgreementDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        private readonly IConfiguration _config;
        public GetApplicableAgreementQueryHandler(ISqlContext sqlContext, ICurrentUserService currentUserService, IConfiguration configuration)
        {
            _dbCntx = sqlContext;
            _currentUserService = currentUserService;
            _config = configuration;
        }
        public async Task<ApplicableAgreementDto> Handle(GetApplicableAgreementQuery request, CancellationToken cancellationToken)
        {
            ApplicableAgreementDto applicableAgreementDto = null;

            long? fmcId = request.fmc_id;
            long? fleetId = request.fleet_id;
            long? customerAccountId = request.customer_account_id;
            long parsStandardAgreementId = Convert.ToInt64(_config["appSettings:PARSStandardAgreementUSD"]);

            if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
            {
                if (fleetId.HasValue)
                {
                    applicableAgreementDto = await getAgreement(fleetId);

                    if (applicableAgreementDto == null)
                        applicableAgreementDto = await getAgreement(fmcId);
                }

                if (applicableAgreementDto == null && fmcId.HasValue)
                    applicableAgreementDto = await getAgreement(fmcId);

                if (applicableAgreementDto == null)
                    applicableAgreementDto = await getDefaultAgreement(parsStandardAgreementId);
            }
            else if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.Account)
            {
                applicableAgreementDto = await getAgreement(customerAccountId);

                if (applicableAgreementDto == null)
                    applicableAgreementDto = await getDefaultAgreement(parsStandardAgreementId);
            }

            return applicableAgreementDto;

        }

        /**
        public async Task<ApplicableAgreementDto> Handle(GetApplicableAgreementQuery request, CancellationToken cancellationToken)
        {
            ApplicableAgreementDto applicableAgreementDto = null;

            long? fmc_id = request.fmc_id;
            long? fleet_id = request.fleet_id;
            long? customer_account_id = request.customer_account_id;            
            long parsStandardAgreementId = Convert.ToInt64(_config["appSettings:PARSStandardAgreementUSD"]);

            if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
            {
                applicableAgreementDto = await getAgreement(fleet_id);
                if (applicableAgreementDto == null)
                    applicableAgreementDto = await getAgreement(fmc_id);
                if (applicableAgreementDto == null)
                    applicableAgreementDto = await getDefaultAgreement(parsStandardAgreementId);
            }
            else if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.Account)
            {
                applicableAgreementDto = await getAgreement(customer_account_id);
                if (applicableAgreementDto == null)
                    applicableAgreementDto = await getAgreement(fleet_id);
                if (applicableAgreementDto == null)
                    applicableAgreementDto = await getAgreement(fmc_id);
                if (applicableAgreementDto == null)
                    applicableAgreementDto = await getDefaultAgreement(parsStandardAgreementId);
            }
            return applicableAgreementDto;
        }

        **/
        public async Task<ApplicableAgreementDto> getAgreement(long? id)
        {
            ApplicableAgreementDto applicableAgreementDto = null;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dpcurrency = new DynamicParameters();
                dpcurrency.Add("@accountId", id);
                string query = @"select 
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then a.preferred_agreement_id else a.fallback_agreement_id end agreement_id,  
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                         				then preferredAg.name else fallbackAg.name end agreement, 
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then preferredAg.agreement_type_id else fallbackAg.agreement_type_id end agreement_type_id,  
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                         				then a.preferred_price_list_id else a.fallback_price_list_id end price_list_id,
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                         				then pl.name else preferredpl.name end price_list, 
                         case when(preferredAg.end_date >= convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL)  
                         				then preferredAg.transportation_preference_type_id else fallbackAg.transportation_preference_type_id end transportation_preference_type_id,
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then preferredAg.default_bill_to_id else fallbackAg.default_bill_to_id end default_bill_to_id,
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then case when preferredAg.pars_perform_inspection is null then '0' else preferredAg.pars_perform_inspection end 
										else case when fallbackAg.pars_perform_inspection  is null then  '0' else fallbackAg.pars_perform_inspection end
										   end pars_perform_inspection,
                         preferredBillto.name default_bill_to, preferredAg.fmc_id,fmc.account_name fmc_name,preferredAg.fleet_id,
                         fleet.account_name fleet_name,preferredAg.currency_id  from account a  
                         inner join agreement preferredAg on a.preferred_agreement_id = preferredAg.id  
                         inner join agreement fallbackAg on a.fallback_agreement_id = fallbackAg.id  
                         left join account fmc on preferredAg.fmc_id = fmc.id  
                         left join account fleet on preferredAg.fleet_id = fleet.id  
                         inner join price_list pl on a.preferred_price_list_id = pl.id  
                         inner join price_list preferredpl on a.preferred_price_list_id = preferredpl.id  
                         inner join default_bill_to preferredBillto on preferredAg.default_bill_to_id = preferredBillto.id                            
                         inner join default_bill_to fallbackBillto on fallbackAg.default_bill_to_id = fallbackBillto.id 
                         where a.id =@accountId ";
                applicableAgreementDto = await connection.QueryFirstOrDefaultAsyncWithRetry<ApplicableAgreementDto>(query, dpcurrency, commandType: CommandType.Text);
                return applicableAgreementDto;
            }
        }
        public async Task<ApplicableAgreementDto> getDefaultAgreement(long? id)
        {
            ApplicableAgreementDto applicableAgreementDto = null;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dpcurrency = new DynamicParameters();
                dpcurrency.Add("@agreement_id", id);
                string query = @"select 
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then a.preferred_agreement_id else a.fallback_agreement_id end agreement_id,  
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                         				then preferredAg.name else fallbackAg.name end agreement, 
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then preferredAg.agreement_type_id else fallbackAg.agreement_type_id end agreement_type_id,  
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                         				then a.preferred_price_list_id else a.fallback_price_list_id end price_list_id,
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                         				then pl.name else preferredpl.name end price_list, 
                         case when(preferredAg.end_date >= convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL)  
                         				then preferredAg.transportation_preference_type_id else fallbackAg.transportation_preference_type_id end transportation_preference_type_id,
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then preferredAg.default_bill_to_id else fallbackAg.default_bill_to_id end default_bill_to_id,
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then case when preferredAg.pars_perform_inspection is null then '0' else preferredAg.pars_perform_inspection end 
										else case when fallbackAg.pars_perform_inspection  is null then  '0' else fallbackAg.pars_perform_inspection end
										   end pars_perform_inspection,
                         preferredBillto.name default_bill_to, preferredAg.fmc_id,fmc.account_name fmc_name,preferredAg.fleet_id,
                         fleet.account_name fleet_name,preferredAg.currency_id  from account a  
                         inner join agreement preferredAg on a.preferred_agreement_id = preferredAg.id  
                         inner join agreement fallbackAg on a.fallback_agreement_id = fallbackAg.id  
                         left join account fmc on preferredAg.fmc_id = fmc.id  
                         left join account fleet on preferredAg.fleet_id = fleet.id  
                         inner join price_list pl on a.preferred_price_list_id = pl.id  
                         inner join price_list preferredpl on a.preferred_price_list_id = preferredpl.id  
                         inner join default_bill_to preferredBillto on preferredAg.default_bill_to_id = preferredBillto.id                            
                         inner join default_bill_to fallbackBillto on fallbackAg.default_bill_to_id = fallbackBillto.id 
                         where  preferredAg.id = @agreement_id ";
                applicableAgreementDto = await connection.QueryFirstOrDefaultAsyncWithRetry<ApplicableAgreementDto>(query, dpcurrency, commandType: CommandType.Text);
                return applicableAgreementDto;
            }
        }
    }
}
