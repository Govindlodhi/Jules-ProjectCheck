﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class GetAgreementMasterDataQuery : IRequest<AgreementMasterDataDto>
    {

    }
    public class GetAccountMasterDataQueryHandler : IRequestHandler<GetAgreementMasterDataQuery, AgreementMasterDataDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetAccountMasterDataQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<AgreementMasterDataDto> Handle(GetAgreementMasterDataQuery request, CancellationToken cancellationToken)
        {
            AgreementMasterDataDto agreementMasterDataDto = new AgreementMasterDataDto();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@account_type_id", _currentUserService.AccountTypeId);
                dp.Add("@account_id", _currentUserService.AccountId);

                string queryFleet = "";
                string queryFMC = "";
                string querycurrency = @"select id ,name from currency where is_active = 1;";



                if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.Fleet)
                    queryFleet = @"select id,account_name from account where id =" + _currentUserService.AccountId + " and is_active = 1 " + ";";
                else if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
                    queryFleet = @"select distinct id,account_name from account where fmc_id = " + _currentUserService.AccountId + " and is_active = 1 " + ";";
                else
                    queryFleet = @"select distinct id,account_name,account_type_id from account where account_type_id = 4 and linked_account_id is null  and parent_account_id is  null and is_active = 1 ;";


                if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
                    queryFMC = @"select distinct id,account_name from account where id =" + _currentUserService.AccountId + " and is_active = 1 " +  ";";
                else if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.Fleet)
                    queryFMC = @"select distinct account.id,account.account_name from account inner join account Fmc on account.id= Fmc.fmc_id where fmc.linked_account_id =" + _currentUserService.AccountId + " and is_active = 1 " +  ";";
                else
                    queryFMC = @"select distinct id,account_name, account_type_id from account where account_type_id = 2 and is_active = 1 ";

                string queryDefaultBillTo = @"select id,name from default_bill_to where is_active = 1;";

                string transportationPreference = "select id,name from transportation_preference_type where is_active = 1";

                string multiSQLQry = queryFleet + queryFMC + querycurrency+ queryDefaultBillTo + transportationPreference;

                using (var multiResultSet = await connection.QueryMultipleAsync(multiSQLQry))
                {
                    //data.States = statesList;
                    agreementMasterDataDto.fleet = (List<EntityReferenceAccount>)await multiResultSet.ReadAsync<EntityReferenceAccount>();
                    agreementMasterDataDto.fmc = (List<EntityReferenceAccount>)await multiResultSet.ReadAsync<EntityReferenceAccount>();
                    agreementMasterDataDto.currency = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    agreementMasterDataDto.default_bill_to = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    agreementMasterDataDto.transportation_preference_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                }
            }
            return agreementMasterDataDto;
        }
    }
}
