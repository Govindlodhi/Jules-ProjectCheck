﻿using PARSNextGen.Application.ServiceRequest.Queries;
using System.Collections.Generic;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class ApplicableAgreementDto
    {
        public long fmc_id { get; set; }
        public string fmc_name { get; set; }

        public long fleet_id { get; set; }
        public string fleet_name { get; set; }

        public long agreement_id { get; set; }
        public long agreement_type_id { get; set; }
        public string agreement { get; set; }
        public long price_list_id { get; set; }
        public string price_list { get; set; }
        public long default_bill_to_id { get; set; }

        public string default_bill_to { get; set; }
        public long currency_id { get; set; }
        public long transportation_preference_type_id { get; set; }
        public string transportation_preference { get; set; }
        public bool? pars_perform_inspection { get; set; }
        public long service_id { get; set; }

        public List<SupportContactsOnServiceRequestDto> supportContactLists { get; set; }
    }
}
