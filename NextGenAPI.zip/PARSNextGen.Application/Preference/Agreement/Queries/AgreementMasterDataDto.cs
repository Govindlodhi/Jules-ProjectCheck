﻿using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class AgreementMasterDataDto
    {
        public List<EntityReferenceAccount> fleet { get; set; }
        public List<EntityReferenceAccount> fmc { get; set; }
        public List<EntityReference> transportation_preference_type { get; set; }
        public List<EntityReference> currency { get; set; }
        public List<EntityReference> default_bill_to { get; set; }
    }
}
