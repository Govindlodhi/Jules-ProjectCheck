﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class CheckDuplicateAgreementQuery : IRequest<bool>
    {
        public long? fmc_id { get; set; }
        public long? fleet_id { get; set; }
        public DateTime start_date { get; set; }
        public DateTime? end_date { get; set; }
        public long? currency_id { get; set; }
    }

    public class CheckDuplicateAgreementQueryHandler : IRequestHandler<CheckDuplicateAgreementQuery, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;

        public CheckDuplicateAgreementQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<bool> Handle(CheckDuplicateAgreementQuery request, CancellationToken cancellationToken)
        {
            List<AgreementDto> agreementDtos = new List<AgreementDto>();
            bool isDuplicate = false;
           
            using (var connection = _dbCntx.GetOpenConnection())
            {

                DynamicParameters dp = new DynamicParameters();
                dp.Add("@fmcId", request.fmc_id);
                dp.Add("@fleetId", request.fleet_id);
                dp.Add("@currencyId", request.currency_id);
                dp.Add("@startDate", request.start_date.ToString("MM-dd-yyyy"));
                if (request.end_date.HasValue)
                {
                    dp.Add("@endDate", request.end_date.Value.ToString("MM-dd-yyyy"));
                }
               
                dp.Add("@agreementStatusId", (long)EnumTypes.Agreement_Status.Active);
               //request.start_date.ToString("MM-dd-yyyy")

                var query = string.Empty;

                if (request.fmc_id != null && request.fleet_id != null)
                {
                    query = @"select * from agreement where fmc_id = @fmcId and fleet_id = @fleetId and agreement_status_id=@agreementStatusId and currency_id=@currencyId and (end_date>=@startDate or end_date IS NULL) ";
                }
                else if (request.fmc_id != null && request.fleet_id == null)
                {
                    query = @"select * from agreement where fmc_id=@fmcId and fleet_id IS NULL and agreement_status_id=@agreementStatusId and currency_id=@currencyId and (end_date>=@startDate or end_date IS NULL) ";
                }
                else if (request.fmc_id == null && request.fleet_id != null)
                {
                    query = @"select * from agreement where fmc_id IS NULL and fleet_id = @fleetId and agreement_status_id=@agreementStatusId and currency_id=@currencyId and (end_date>=@startDate or end_date IS NULL) ";
                }
                else if (request.fmc_id == null && request.fleet_id == null)
                {
                    query = @"select * from agreement where fmc_id IS NULL and fleet_id = @fleetId and agreement_status_id=@agreementStatusId and currency_id=@currencyId and (end_date>=@startDate or end_date IS NULL) ";
                }



                if (!string.IsNullOrEmpty(query))
                {
                    agreementDtos = (List<AgreementDto>)await connection.QueryAsync<AgreementDto>(query, dp, commandType: CommandType.Text);
                }

            }

            if (agreementDtos.Count > 0)
            {
                isDuplicate = true;
            }

            return isDuplicate;
        }
    }
}
