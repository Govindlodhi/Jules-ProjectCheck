﻿/* Created By: Anand Singh
 * Created On: 19-Sep-2022
 * Company   : Soluzione IT Services
 * Description: Agreement Data Table For Agreement Level Operation.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class AllAgreementsDto
    {
        public long id { get; set; }
        public long agreement_type_id { get; set; }
        public string agreement_type { get; set; }

        public string name { get; set; }
        public string account_name { get; set; }
        public long? fmc_id { get; set; }
        public string fmc_name { get; set; }
        public long? fleet_id { get; set; }
        public string fleet_name { get; set; }
        public long? agreement_status_id { get; set; }
        public string agreement_status_name { get; set; }

        public string agreement_status_reason_name { get; set; }
        public DateTime? start_date { get; set; }
        public DateTime? end_date { get; set; }
        public string created_by_name { get; set; }
        public DateTime? created_on { get; set; }
        public long? currency_id { get; set; }
        public string currency { get; set; }
        public long default_bill_to_id { get; set; }
        public string default_bill_to_name { get; set; }
        public bool is_default { get; set; }
        public long? parent_agreement_id { get; set; }
        public string parent_agreement_name { get; set; }

        public long? transportation_preference_type_id { get; set; }
        public string transportation_preference_type { get; set; }
    }
}
