﻿using Dapper;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.Master.SupportContact.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.ServiceRequest.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class GetApplicableAgreementForCRMQuery : IRequest<ApplicableAgreementDto>
    {
        public long? fmc_id { get; set; }
        public long? fleet_id { get; set; }
        public string? fleet_number { get; set; }
        public long currency_id { get; set; }
    }
    public class GetApplicableAgreementForCRMQueryHandler : IRequestHandler<GetApplicableAgreementForCRMQuery, ApplicableAgreementDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        private readonly IConfiguration _config;
        private readonly IMediator _mediator;

        public GetApplicableAgreementForCRMQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService, IConfiguration config, IMediator mediator)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
            _config = config;
            _mediator = mediator;
        }
        public async Task<ApplicableAgreementDto> Handle(GetApplicableAgreementForCRMQuery request, CancellationToken cancellationToken)
        {
            ApplicableAgreementDto applicableAgreementDto = null;
            DynamicParameters dp = new DynamicParameters();

            long? fmc_id = null;
            long? fleet_id = null;
            if (request.fmc_id != (long)EnumTypes.Account.Not_Available)
            {
                fmc_id = request.fmc_id;
            }

            if (request.fleet_id != (long)EnumTypes.Account.Not_Available)
            {
                fleet_id = request.fleet_id;
            }

            string fleet_number = request.fleet_number;

            using (var connection = _dbCntx.GetOpenConnection())
            {

                // If Fleet number not null.
                if (!string.IsNullOrEmpty(fleet_number))
                {

                    string fleetAccQuery = @"Select id from account Where fleet_no = '" + fleet_number + "' and linked_account_id=" + fleet_id + "  and fmc_id=" + fmc_id + "";
                    var data = await connection.QueryFirstOrDefaultAsyncWithRetry<Object>(fleetAccQuery, commandType: CommandType.Text);
                    if (data != null)
                    {
                        var attribute = ((IDictionary<String, Object>)data);
                        var fleeetAccountID = attribute["id"];
                        if (fleeetAccountID != null)
                            fleet_id = Convert.ToInt64(attribute["id"].ToString());
                    }
                }
                else
                {
                    string fleetAccQuery = @"Select id from account Where linked_account_id=" + fleet_id + "  and fmc_id=" + fmc_id + "";
                    var data1 = await connection.QueryFirstOrDefaultAsyncWithRetry<Object>(fleetAccQuery, commandType: CommandType.Text);
                    if (data1 != null)
                    {
                        var attribute1 = ((IDictionary<String, Object>)data1);
                        var fleeetAccountID1 = attribute1["id"];
                        if (fleeetAccountID1 != null)
                            fleet_id = Convert.ToInt64(attribute1["id"].ToString());
                    }
                }
            }
            DynamicParameters dpcurrency = new DynamicParameters();

            // Getting Fleet's agreement
            if (fmc_id != null && fleet_id != null)
            {
                dpcurrency.Add("@accountId", fleet_id);
                applicableAgreementDto = await getAgreement(fleet_id);

                // if Fleet's agreement doesn't exist then FMC agreement will be applied

                if (applicableAgreementDto == null && fmc_id != null)
                {
                    applicableAgreementDto = await getAgreement(fmc_id);
                }


            }

            // Getting FMC's agreement
            if (applicableAgreementDto == null && fmc_id != null && fleet_id == null)
            {
                applicableAgreementDto = await getAgreement(fmc_id);
            }

            // Getting Account's agreement
            if (applicableAgreementDto == null && fmc_id == null && fleet_id != null)
            {
                dpcurrency.Add("@accountId", fleet_id);
                applicableAgreementDto = await getAgreement(fmc_id);
            }

            if (applicableAgreementDto == null)
            {
                applicableAgreementDto = new ApplicableAgreementDto();
                if (request.currency_id == (long)EnumTypes.CurrencyType.CA)
                {
                    applicableAgreementDto.agreement_id = Convert.ToInt64(_config["appSettings:PARSStandardAgreementCAD"]);
                    applicableAgreementDto.price_list_id = Convert.ToInt64(_config["appSettings:DefaultPriceListIdCA"]);
                }
                else if (request.currency_id == (long)EnumTypes.CurrencyType.US)
                {
                    applicableAgreementDto.agreement_id = Convert.ToInt64(_config["appSettings:PARSStandardAgreementUSD"]);
                    applicableAgreementDto.price_list_id = Convert.ToInt64(_config["appSettings:DefaultPriceListIdUS"]);
                }
            }

            var result = await _mediator.Send(new GetSupportContactsOnRequestQuery { fmc_id = fmc_id, fleet_id = fleet_id });

            applicableAgreementDto.supportContactLists = new List<SupportContactsOnServiceRequestDto>(result);

            return applicableAgreementDto;
        }
        public async Task<ApplicableAgreementDto> getAgreement(long? id)
        {
            ApplicableAgreementDto applicableAgreementDto = null;

            using (var connection = _dbCntx.GetOpenConnection())
            {

                string query = "";
                DynamicParameters dpcurrency = new DynamicParameters();
                dpcurrency.Add("@accountId", id);
                query = @"select 
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then a.preferred_agreement_id else a.fallback_agreement_id end agreement_id,  
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                         				then preferredAg.name else fallbackAg.name end agreement, 
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then preferredAg.agreement_type_id else fallbackAg.agreement_type_id end agreement_type_id,  
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                         				then a.preferred_price_list_id else a.fallback_price_list_id end price_list_id,
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                         				then pl.name else preferredpl.name end price_list, 
                         case when(preferredAg.end_date >= convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL)  
                         				then preferredAg.transportation_preference_type_id else fallbackAg.transportation_preference_type_id end transportation_preference_type_id,
                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then preferredAg.default_bill_to_id else fallbackAg.default_bill_to_id end default_bill_to_id,

                         case when (preferredAg.end_date>=convert(varchar, getutcdate(), 23) or preferredAg.end_date IS NULL ) 
                                        then 
										   case when preferredAg.pars_perform_inspection is null then '0' else preferredAg.pars_perform_inspection end 
										   else 
										   case when fallbackAg.pars_perform_inspection  is null then  '0' else fallbackAg.pars_perform_inspection end
										   end pars_perform_inspection,


                         preferredBillto.name default_bill_to,
                         preferredAg.fmc_id,fmc.account_name fmc_name,preferredAg.fleet_id,
                         fleet.account_name fleet_name,preferredAg.currency_id  from account a  
                         inner join agreement preferredAg on a.preferred_agreement_id = preferredAg.id  
                         inner join agreement fallbackAg on a.fallback_agreement_id = fallbackAg.id  
                         left join account fmc on preferredAg.fmc_id = fmc.id  
                         left join account fleet on preferredAg.fleet_id = fleet.id  
                         inner join price_list pl on a.preferred_price_list_id = pl.id  
                         inner join price_list preferredpl on a.preferred_price_list_id = preferredpl.id  
                         inner join default_bill_to preferredBillto on preferredAg.default_bill_to_id = preferredBillto.id   
                         
                         inner join default_bill_to fallbackBillto on fallbackAg.default_bill_to_id = fallbackBillto.id 
                            where a.id =@accountId ";

                applicableAgreementDto = await connection.QueryFirstOrDefaultAsyncWithRetry<ApplicableAgreementDto>(query, dpcurrency, commandType: CommandType.Text);

                return applicableAgreementDto;

            }
        }
    }
}
