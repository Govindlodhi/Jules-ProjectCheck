﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class ApplicableAgreementReq
    {
        public long? customer_account_id {  get; set; } 
        public long? fleet_id { get; set; }
        public long? fmc_id { get; set; }
    }
}
