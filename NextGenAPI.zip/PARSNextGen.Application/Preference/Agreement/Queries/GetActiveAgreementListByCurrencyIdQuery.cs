﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Quotes.ServiceMasterDetails.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static PARSNextGen.Domain.Common.EnumTypes;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class GetActiveAgreementListByCurrencyIdQuery : IRequest<List<AgreementsByCurrencyDto>>
    {
        public long? currencyId { get; set; }
    }
    public class GetActiveAgreementListByCurrencyIdQueryHandler : IRequestHandler<GetActiveAgreementListByCurrencyIdQuery, List<AgreementsByCurrencyDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;

        public GetActiveAgreementListByCurrencyIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<List<AgreementsByCurrencyDto>> Handle(GetActiveAgreementListByCurrencyIdQuery request, CancellationToken cancellationToken)
        {
            List<AgreementAndRelatedPriceList> agreementAndRelatedPriceList = new List<AgreementAndRelatedPriceList>();
            List<AgreementsByCurrencyDto> agreementsByCurrencyDto = new List<AgreementsByCurrencyDto>();

            if (request.currencyId != null)
            {
                using (var connection = _dbCntx.GetOpenConnection())
                {
                    DynamicParameters dp = new DynamicParameters();
                    dp.Add("@currencyId", request.currencyId);
                    dp.Add("@agreement_status_id", Agreement_Status.Active);
                    dp.Add("@price_list_status_id", Price_List_Status.Active);
                    var query = @"SELECT a.id AS agreement_id, a.name AS agreement, pl.id AS price_list_id, pl.name AS      
                                   price_list 
                                 FROM agreement a
                                 LEFT OUTER JOIN price_list pl ON pl.agreement_id = a.id
                                 WHERE a.currency_id = @currencyId AND a.agreement_status_id = @agreement_status_id
                                    AND pl.price_list_status_id = @price_list_status_id";

                    agreementAndRelatedPriceList = (List<AgreementAndRelatedPriceList>)await connection.QueryAsyncWithRetry<AgreementAndRelatedPriceList>(query, dp, commandType: CommandType.Text);

                    // Grouping By agreements
                    var distinctAgreements = agreementAndRelatedPriceList.Select(u => new { u.agreement_id,u.agreement }).Distinct();
                    foreach (var item in distinctAgreements)
                    {
                        AgreementsByCurrencyDto agmt = new AgreementsByCurrencyDto();
                        agmt.agreement = item.agreement;
                        agmt.agreement_id = item.agreement_id;
                        agmt.priceLists = new List<AgreementRelatedPriceList>();
                        var agreementRelatedPriceLists = agreementAndRelatedPriceList.Where(x => x.agreement_id == agmt.agreement_id).ToList();
                        
                        foreach (var itemService in agreementRelatedPriceLists)
                        {
                            AgreementRelatedPriceList priceList = new AgreementRelatedPriceList();
                            priceList.price_list_id = itemService.price_list_id;
                            priceList.price_list = itemService.price_list;


                            agmt.priceLists.Add(priceList);
                        }

                        agreementsByCurrencyDto.Add(agmt);

                    }
                    
                }
            }
            return agreementsByCurrencyDto;
        }
    }
}
