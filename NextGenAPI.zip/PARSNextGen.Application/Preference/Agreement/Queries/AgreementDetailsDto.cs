﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class AgreementDetailsDto
    {
        public long? fmc_id { get; set; }

        public long? fleet_id { get; set; }

        public long agreement_id { get; set; }
        public string agreement { get; set; }
        public long price_list_id { get; set; }
        public long agreement_status_id { get; set; }
        public long currency_id { get; set; }
    }
}
