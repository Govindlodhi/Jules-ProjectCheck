﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Account.Accounts.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class GetAllAgreementsQuery : IRequest<List<AllAgreementsDto>>
    {

    }
    public class GetAllAgreementsQueryHandler : IRequestHandler<GetAllAgreementsQuery, List<AllAgreementsDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;

        public GetAllAgreementsQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<List<AllAgreementsDto>> Handle(GetAllAgreementsQuery request, CancellationToken cancellationToken)
        {
            List<AllAgreementsDto> allAgreementsDto = new List<AllAgreementsDto>();

            string condition = string.Empty;

            bool isAccountTypeMatched = false;

            if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.Account)
            {
                condition = "inner join account fleet on ag.fleet_id=fleet.id where (fleet.linked_account_id=" + _currentUserService.AccountId+ " or fleet.id=" + _currentUserService.AccountId + ")";
                isAccountTypeMatched = true;
            }
            else if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
            {
                condition = "where ag.fmc_id=" + _currentUserService.AccountId;
                isAccountTypeMatched = true;
            }
            else if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.PARS)
            {
                condition = string.Empty;
                isAccountTypeMatched = true;
            }

            if (isAccountTypeMatched)
            {
                using (var connection = _dbCntx.GetOpenConnection())
                {

                    var query = @"select ag.id ,name,ag.account_name, ag.fmc_id,fmc_name,ag.default_bill_to_id,default_bill_to_name,parent_agreement_id
                            ,parent_agreement_name,fleet_id, fleet_name, agreement_status_id,agreement_status_name, end_date
                            ,start_date,created_by_name  updated_by_name,ag.created_on,currency_id,currency,agreement_type_id,ag.transportation_preference_type_id,ag.transportation_preference_type
                            ,agreement_type,case when agreement_type_id is null Then 0 else 1 end is_default  
                            from vw_agreements ag " + condition;
                    try
                    {
                        allAgreementsDto = (List<AllAgreementsDto>)await connection.QueryAsync<AllAgreementsDto>(query, null, commandType: CommandType.Text);
                    }
                    catch (Exception ex) 
                    { 
                    }
                }
            }

            return allAgreementsDto;
        }
    }
}
