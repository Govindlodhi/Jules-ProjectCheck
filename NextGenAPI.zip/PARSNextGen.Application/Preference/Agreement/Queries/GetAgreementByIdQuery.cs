﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class GetAgreementByIdQuery : IRequest<AgreementDto>
    {
        public long? id { get; set; }
    }
    public class GetAgreementByIdQueryHandler : IRequestHandler<GetAgreementByIdQuery, AgreementDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;

        public GetAgreementByIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<AgreementDto> Handle(GetAgreementByIdQuery request, CancellationToken cancellationToken)
        {
            AgreementDto agreementDto =null;

            if (request.id != null)
            {
                using (var connection = _dbCntx.GetOpenConnection())
                {
                    DynamicParameters dp = new DynamicParameters();
                    dp.Add("@Id", request.id);
                    
                    var query = @"select id, name, account_name," +
                                " case when fmc_id is null then 999999999 else fmc_id end fmc_id, fmc_name, default_bill_to_id " +
                                " ,default_bill_to_name,parent_agreement_id,parent_agreement_name," +
                                " case when fleet_id is null then 999999999 else fleet_id end fleet_id, fleet_name," +
                                " agreement_status_id,agreement_status_name, end_date,start_date, created_by_name" +
                                " updated_by_name, created_on, currency_id, currency ,transportation_preference_type_id,transportation_preference_type,pars_perform_inspection  from vw_agreements where id=@Id";

                    agreementDto = (AgreementDto)await connection.QueryFirstOrDefaultAsyncWithRetry<AgreementDto>(query, dp, commandType: CommandType.Text);

                   

                }
            }
            return agreementDto;
        }
    }
}
