﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class GetCurrencyByAccountIdQuery : IRequest<CurrencyByAccountIdDto>
    {
        public long fmc_id { get; set; }
        public long fleet_id { get; set; }
    }
    public class GetCurrencyByAccountIdQueryHandler : IRequestHandler<GetCurrencyByAccountIdQuery, CurrencyByAccountIdDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;

        public GetCurrencyByAccountIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<CurrencyByAccountIdDto> Handle(GetCurrencyByAccountIdQuery request, CancellationToken cancellationToken)
        {
            CurrencyByAccountIdDto currencyByAccountIdDto = new CurrencyByAccountIdDto();
            var query = @"";
            if (request.fmc_id > 0 && request.fleet_id > 0)
            {
                query = "SELECT  a.default_currency_id id ,c.name as name  FROM account a "+
                        "inner join currency c on a.default_currency_id = c.id " +
                        "WHERE a.id = @fleetId";

            }
            else if (request.fmc_id > 0 && request.fleet_id == 0)
            {
                query = "SELECT  a.default_currency_id id ,c.name as name  FROM account a " +
                       "inner join currency c on a.default_currency_id = c.id " +
                       "WHERE a.id = @fmcId";
            }
            else if (request.fmc_id == 0 && request.fleet_id > 0)
            {
                query = "SELECT  a.default_currency_id id ,c.name as name  FROM account a " +
                      "inner join currency c on a.default_currency_id = c.id " +
                      "WHERE a.id = @fleetId";
            }
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@fmcId", request.fmc_id);
                dp.Add("@fleetId", request.fleet_id);

                currencyByAccountIdDto = (CurrencyByAccountIdDto)await connection.QueryFirstOrDefaultAsyncWithRetry<CurrencyByAccountIdDto>(query, dp, commandType: CommandType.Text);
            }

            return currencyByAccountIdDto;
        }
    }
}
