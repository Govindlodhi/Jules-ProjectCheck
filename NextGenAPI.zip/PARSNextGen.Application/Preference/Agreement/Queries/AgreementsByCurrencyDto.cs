﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class AgreementsByCurrencyDto
    {
        public long? agreement_id { get; set; }
        public string agreement { get; set; }
        public List<AgreementRelatedPriceList> priceLists { get; set; }
    }
    public class AgreementRelatedPriceList
    {
        public long? price_list_id { get; set; }
        public string price_list { get; set; }
    }
    public class AgreementAndRelatedPriceList
    {
        public long? agreement_id { get; set; }
        public string agreement { get; set; }
        public long? price_list_id { get; set; }
        public string price_list { get; set; }
    }

}
