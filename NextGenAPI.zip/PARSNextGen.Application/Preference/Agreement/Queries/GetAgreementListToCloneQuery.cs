﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Queries
{
    public class GetAgreementListToCloneQuery : IRequest<List<GetAgreementListToCloneDto>>
    {
        public long currency_id { get; set; }
    }

    public class GetAgreementListToCloneQueryHandler : IRequestHandler<GetAgreementListToCloneQuery, List<GetAgreementListToCloneDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;

        public GetAgreementListToCloneQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<List<GetAgreementListToCloneDto>> Handle(GetAgreementListToCloneQuery request, CancellationToken cancellationToken)
        {
            List<GetAgreementListToCloneDto> result = null;
            if (request != null)
            {
                if (request.currency_id != 0)
                {
                    using (var connection = _dbCntx.GetOpenConnection())
                    {
                        DynamicParameters dp = new DynamicParameters();

                        dp.Add("@currencyid", request.currency_id);

                        string query = "select ag.id,ag.name,ag.currency_id from agreement ag where ag.agreement_status_id in(1,3) and ag.currency_id=@currencyid";

                        result = (List<GetAgreementListToCloneDto>)await connection.QueryAsyncWithRetry<GetAgreementListToCloneDto>(query, dp, commandType: CommandType.Text);
                    }
                }
            }
           return result;
        }
    }
}
