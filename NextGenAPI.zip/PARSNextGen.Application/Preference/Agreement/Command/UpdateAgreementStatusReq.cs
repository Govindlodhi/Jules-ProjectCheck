﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Command
{
    public class UpdateAgreementStatusReq
    {
        public long id { get; set; }
        public long? agreement_status_id { get; set; }
        public long? fleet_id { get; set; }
        public long? fmc_id { get; set; }
        public DateTime start_date { get; set; }
        public DateTime? end_date { get; set; }
        public long? currency_id { get; set; }
    }
}
