﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Command
{
    public class UpdateAgreementReq
    {
        public long id { get; set; }
        public string name { get; set; }
        public long? fmc_id { get; set; }
        public long? fleet_id { get; set; }
        public DateTime? start_date { get; set; }
        public DateTime? end_date { get; set; }
        public long? currency_id { get; set; }
        public long default_bill_to_id { get; set; }
        public long? transportation_preference_type_id { get; set; }
        public bool? pars_perform_inspection { get; set; }
    }
}
