﻿using Dapper;
using MassTransit;
using MediatR;
using Microsoft.Extensions.Configuration;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using IMediator = MediatR.IMediator;

namespace PARSNextGen.Application.Preference.Agreement.Command.UpdateAGServicesAndICFromCRM
{
    public class UpdateServicesAndICFromCRMCommand : IRequest<bool>
    {
        public UpdateServicesAndICFromCRMReq requestParameters { get; set; }
    }
    public class UpdateServicesAndICFromCRMCommandHandler : IRequestHandler<UpdateServicesAndICFromCRMCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        public List<ICPrefrenceListDto> iCPrefrenceListDtos = new List<ICPrefrenceListDto>();
        public int? agreement_id;
        public int? account_id;
        public IDbConnection dbConnection;
        public IMediator _mediator;
        private readonly IConfiguration _config;
        public UpdateServicesAndICFromCRMCommandHandler(ISqlContext dbCntx, IMediator mediator, IConfiguration config)
        {
            _dbCntx = dbCntx;
            _mediator = mediator;
            _config = config;
        }
        public async Task<bool> Handle(UpdateServicesAndICFromCRMCommand request, CancellationToken cancellationToken)
        {

            using (var conn = _dbCntx.GetOpenConnection())
            {
                try
                {
                    long? detail_optionset = request.requestParameters.solzit_detail_optionset;
                    dbConnection = conn;

                    string agreementQuery = "Select ag.id as AgreementId from agreement ag where ag.parameter_crm_id = '" + request.requestParameters.parameter_id + "';";

                    var result = await dbConnection.QuerySingleOrDefaultAsync<dynamic>(agreementQuery);
                    if (result != null)
                        agreement_id = result.AgreementId != null ? (int)result.AgreementId : null;

                    if (agreement_id == null)
                    {
                        var agreementId = await _mediator.Send(new CloneAgreementForCustomerParameterSetCommand { agreement_id = Convert.ToInt64(_config["appSettings:PARSStandardAgreementUSD"]), name = request.requestParameters.parameter_name, parameter_set_id = Guid.Parse(request.requestParameters.parameter_id) });
                        if (agreementId != 0)
                            agreement_id = (int)agreementId;
                        if (dbConnection.State != System.Data.ConnectionState.Open)
                            dbConnection = _dbCntx.GetOpenConnection();
                    }

                    if (agreement_id != null)
                    {
                        string preferenceQuery = "select id, instruction, is_active, sort_code from ic_preference_rule where agreement_id = " + agreement_id;
                        List<ICPrefrenceListDto> availableICList = (List<ICPrefrenceListDto>)await dbConnection.QueryAsyncWithRetry<ICPrefrenceListDto>(preferenceQuery);

                        iCPrefrenceListDtos = availableICList;
                        CheckICInstruction("Key_Flap", request.requestParameters.solzit_keyflapping, null);
                        CheckICInstruction("Telematics", request.requestParameters.solzit_telematics, null);
                        CheckICInstruction("KeyFob", request.requestParameters.solzit_keyfob, null);
                        CheckICInstruction("ContentsMaterials", request.requestParameters.solzit_contentsmaterials, null);
                        CheckICInstruction("AddressChange", request.requestParameters.solzit_addresschange, null);
                        CheckICInstruction("ServiceLights", request.requestParameters.solzit_servicelights, null);

                        if (!string.IsNullOrEmpty(request.requestParameters.solzit_lastservice))
                        {
                            string[] icParts = request.requestParameters.solzit_lastservice.Split('/');
                            string lastServiceRule = "<?xml version=\"1.0\" encoding=\"utf-8\"?><codeeffects xmlns=\"https://codeeffects.com/schemas/rule/41\" xmlns:ui=\"https://codeeffects.com/schemas/ui/4\"><rule id=\"94b8e15b-f04b-4633-acc3-95b914f8abca\" webrule=\"5.0.52.4\" utc=\"2024-09-23T11:10:50.7021\" type=\"PARSNextGen.Application.Utility.Preference.Models.service_request, PARSNextGen.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null\" eval=\"true\"><name>name</name><description>desc</description><definition><and ui:block=\"true\"><condition type=\"equal\"><property name=\"transportation_type_id\" /><value type=\"numeric\">1</value></condition><condition type=\"equal\"><property name=\"is_electric_vehicle\" /><value type=\"System.Boolean\">false</value></condition><and ui:block=\"true\"><condition type=\"notEqual\"><property name=\"delivery_address_type\" /><value type=\"numeric\">4</value></condition><condition type=\"notEqual\"><property name=\"delivery_address_type\" /><value type=\"numeric\">8</value></condition></and></and></definition><format><lines /></format></rule></codeeffects>";
                            string lastServiceHumanReadbleRule = "Check if (Transportation Type is equal to 1 and Is Electric Vehicle is False and (Delivery Address Type is not equal to 4 and Delivery Address Type is not equal to 8))";
                            await CheckICInstructionAsync(icParts[0], null, (long)EnumTypes.default_services_for_crm.Last_Service, "Last Service", lastServiceRule, lastServiceHumanReadbleRule, null);

                            string lastServiceEVRule = "<?xml version=\"1.0\" encoding=\"utf-8\"?><codeeffects xmlns=\"https://codeeffects.com/schemas/rule/41\" xmlns:ui=\"https://codeeffects.com/schemas/ui/4\"><rule id=\"31bc52f3-024b-4b9b-bb28-3fed2a01d5b4\" webrule=\"5.0.52.4\" utc=\"2024-09-25T04:56:37.5735\" type=\"PARSNextGen.Application.Utility.Preference.Models.service_request, PARSNextGen.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null\" eval=\"true\"><name>name</name><description>desc</description><definition><and><condition type=\"equal\"><property name=\"transportation_type_id\" /><value type=\"numeric\">1</value></condition><condition type=\"equal\"><property name=\"is_electric_vehicle\" /><value type=\"System.Boolean\">true</value></condition><and ui:block=\"true\"><condition type=\"notEqual\"><property name=\"delivery_address_type\" /><value type=\"numeric\">4</value></condition><condition type=\"notEqual\"><property name=\"delivery_address_type\" /><value type=\"numeric\">8</value></condition></and></and></definition><format><lines /></format></rule></codeeffects>";
                            string lastServiceEVHumanReadbleRule = "Check if Transportation Type is equal to 1 and Is Electric Vehicle is True and (Delivery Address Type is not equal to 4 and Delivery Address Type is not equal to 8)";
                            await CheckICInstructionAsync(icParts[1], null, (long)EnumTypes.default_services_for_crm.Last_Service_EV, "Last Service(EV)", lastServiceEVRule, lastServiceEVHumanReadbleRule, null);
                        }
                        else
                        {
                            await CheckICInstructionAsync(null, null, (long)EnumTypes.default_services_for_crm.Last_Service_EV, "Last Service(EV)", null, null, null);
                            await CheckICInstructionAsync(null, null, (long)EnumTypes.default_services_for_crm.Last_Service, "Last Service", null, null, null);
                        }
                        string fullDetailServiceRule = "<?xml version=\"1.0\" encoding=\"utf-8\"?><codeeffects xmlns=\"https://codeeffects.com/schemas/rule/41\" xmlns:ui=\"https://codeeffects.com/schemas/ui/4\"><rule id=\"37060b44-f617-4c13-aa26-8344c276a7c9\" webrule=\"5.0.52.4\" utc=\"2024-09-23T11:05:53.6385\" type=\"PARSNextGen.Application.Utility.Preference.Models.service_request, PARSNextGen.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null\" eval=\"true\"><name>name</name><description>desc</description><definition><and ui:block=\"true\"><condition type=\"equal\"><property name=\"transportation_type_id\" /><value type=\"numeric\">1</value></condition><and ui:block=\"true\"><condition type=\"notEqual\"><property name=\"delivery_address_type\" /><value type=\"numeric\">4</value></condition><condition type=\"notEqual\"><property name=\"delivery_address_type\" /><value type=\"numeric\">8</value></condition></and></and></definition><format><lines /></format></rule></codeeffects>";
                        string fullDetaileHumanReadbleRule = "Check if (Transportation Type is equal to 1 and (Delivery Address Type is not equal to 4 and Delivery Address Type is not equal to 8))";
                        await CheckICInstructionAsync(request.requestParameters.solzit_detail, request.requestParameters.solzit_detailmax, (long)EnumTypes.default_services_for_crm.Full_Detail, "Full Detail", fullDetailServiceRule, fullDetaileHumanReadbleRule, detail_optionset);

                        string mEServiceRule = "<?xml version=\"1.0\" encoding=\"utf-8\"?><codeeffects xmlns=\"https://codeeffects.com/schemas/rule/41\" xmlns:ui=\"https://codeeffects.com/schemas/ui/4\"><rule id=\"15971095-03e8-42aa-a48a-ef50a92a71a8\" webrule=\"5.0.52.4\" utc=\"2025-01-16T06:47:39.7171\" type=\"PARSNextGen.Application.Utility.Preference.Models.service_request, PARSNextGen.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null\" eval=\"true\"><name>name</name><description>desc</description><definition><and ui:block=\"true\"><condition type=\"notEqual\"><property name=\"pickup_address_type\" /><value type=\"numeric\">4</value></condition><condition type=\"equal\"><property name=\"delivery_address_type\" /><value type=\"numeric\">4</value></condition></and></definition><format><lines /></format></rule></codeeffects>";
                        string mEHumanReadbleRule = "Check if (Pickup Address Type is not equal to 4 and Delivery Address Type is equal to 4)";
                        await CheckICInstructionAsync(request.requestParameters.solzit_maintenanceinquiry is true ? "Maintenance Inquiry" : null, null, (long)EnumTypes.default_services_for_crm.Maintenance_Inquiry, "Maintenance Inquiry", mEServiceRule, mEHumanReadbleRule, null);
                    }

                    #region CREATE AND UPDATE MAINTENANCE CONTACTs
                    //if (request.requestParameters.fmcId1 != null && (!string.IsNullOrEmpty(request.requestParameters.contact1) || !string.IsNullOrEmpty(request.requestParameters.instruction1)))
                    //    CreateMaintenanceContact(request.requestParameters.fmcId1, request.requestParameters.contact1, request.requestParameters.instruction1, "SELECTEDFMC1");
                    //if (request.requestParameters.fmcId2 != null && (!string.IsNullOrEmpty(request.requestParameters.contact2) || !string.IsNullOrEmpty(request.requestParameters.instruction2)))
                    //    CreateMaintenanceContact(request.requestParameters.fmcId2, request.requestParameters.contact2, request.requestParameters.instruction2, "SELECTEDFMC2");
                    //if (request.requestParameters.fmcId3 != null && (!string.IsNullOrEmpty(request.requestParameters.contact3) || !string.IsNullOrEmpty(request.requestParameters.instruction3)))
                    //    CreateMaintenanceContact(request.requestParameters.fmcId3, request.requestParameters.contact3, request.requestParameters.instruction3, "SELECTEDFMC3");
                    #endregion
                }
                catch (Exception ex)
                {
                    string syncLogQuery = "sp_create_sync_log";
                    DynamicParameters dpSync = new DynamicParameters();
                    dpSync.Add("@entity_name", "Customer Parameter Set Sync");
                    dpSync.Add("@operation", EnumTypes.operation.Update.ToString());
                    dpSync.Add("@priority", 4);
                    dpSync.Add("@nextgen_id", null);
                    dpSync.Add("@remark", request.requestParameters.parameter_name + " " + request.requestParameters.parameter_id + " " + ex.Message);
                    dpSync.Add("@sync_log_status_id", (long)EnumTypes.sync_log_status.Failed);
                    dpSync.Add("@created_by", 1);
                    var syncLogEntry = await conn.ExecuteAsyncWithRetry(syncLogQuery, dpSync, commandType: CommandType.StoredProcedure);
                    throw new Exception(ex.Message);
                }
            }
            return true;

        }
        public void CheckICInstruction(string icSortCode, string availableIns, long? detail_optionset)
        {
            ICPrefrenceListDto ICPrefrenceDto = iCPrefrenceListDtos?.FirstOrDefault(x => x.sort_code != null && x.sort_code.Contains(icSortCode));
            string rulejson = string.Empty;
            string humanReadbleRule = string.Empty;

            if (icSortCode != null && (icSortCode == "Telematics" || icSortCode == "ContentsMaterials"))
            {
                rulejson = "<?xml version=\"1.0\" encoding=\"utf-8\"?><codeeffects xmlns=\"https://codeeffects.com/schemas/rule/41\" xmlns:ui=\"https://codeeffects.com/schemas/ui/4\"><rule id=\"76ba83d6-1996-4c6a-a9dc-70ec8f30d386\" webrule=\"5.0.52.4\" utc=\"2024-09-27T10:15:38.8703\" type=\"PARSNextGen.Application.Utility.Preference.Models.service_request, PARSNextGen.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null\" eval=\"true\"><name>name</name><description>desc</description><definition><condition type=\"equal\"><property name=\"transportation_type_id\" /><value type=\"numeric\">1</value></condition></definition><format><lines /></format></rule></codeeffects>";
                humanReadbleRule = "Check if (Transportation Type is equal to 1)";

            }
            else
            {
                rulejson = "<?xml version=\"1.0\" encoding=\"utf-8\"?><codeeffects xmlns=\"https://codeeffects.com/schemas/rule/41\" xmlns:ui=\"https://codeeffects.com/schemas/ui/4\"><rule id=\"37060b44-f617-4c13-aa26-8344c276a7c9\" webrule=\"5.0.52.4\" utc=\"2024-09-23T11:05:53.6385\" type=\"PARSNextGen.Application.Utility.Preference.Models.service_request, PARSNextGen.Application, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null\" eval=\"true\"><name>name</name><description>desc</description><definition><and ui:block=\"true\"><condition type=\"equal\"><property name=\"transportation_type_id\" /><value type=\"numeric\">1</value></condition><and ui:block=\"true\"><condition type=\"notEqual\"><property name=\"delivery_address_type\" /><value type=\"numeric\">4</value></condition><condition type=\"notEqual\"><property name=\"delivery_address_type\" /><value type=\"numeric\">8</value></condition></and></and></definition><format><lines /></format></rule></codeeffects>";
                humanReadbleRule = "Check if (Transportation Type is equal to 1 and (Delivery Address Type is not equal to 4 and Delivery Address Type is not equal to 8))";
            }

            if (ICPrefrenceDto is null && availableIns is not null)
            {
                //if ((long)EnumTypes.detail_product_option_set.Detail_Deliver_as_is_no_detail != detail_optionset)
                //{
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@agreement_id", agreement_id);
                dp.Add("@agreement_type_id", 1);
                dp.Add("@event_type_id", EnumTypes.Event_Type.new_service_request);
                dp.Add("@instruction", availableIns);
                dp.Add("@inclusion_type_id", EnumTypes.Inclusion_Type.ConditionBased);
                dp.Add("@rule_type_id", EnumTypes.Rule_Type.Evaluation);
                dp.Add("@rule_json", rulejson);
                dp.Add("@human_readable_rule", humanReadbleRule);
                dp.Add("@can_modify", 1);
                dp.Add("@can_override", 0);
                dp.Add("@currency_id", EnumTypes.CurrencyType.US);
                dp.Add("@is_active", 1);
                dp.Add("@sort_code", icSortCode);
                dp.Add("@created_on", DateTime.Now);
                dp.Add("@created_by", 1);
                string query = @"insert into ic_preference_rule(agreement_id,agreement_type_id,event_type_id,instruction,inclusion_type_id,rule_type_id,instruction_rule,human_readable_rule,can_modify,can_override,currency_id,is_active,sort_code,created_on,created_by,updated_on) 
                                Values(@agreement_id,@agreement_type_id ,@event_type_id,@instruction,@inclusion_type_id,@rule_type_id,@rule_json,@human_readable_rule,@can_modify,@can_override,@currency_id,@is_active,@sort_code,@created_on,@created_by,@created_on)";
                var data = dbConnection.Execute(query, dp, commandType: CommandType.Text);
                //}
            }
            else if ((ICPrefrenceDto is not null) && (availableIns is null))
            {
                string query = @"Update ic_preference_rule set is_active=0 ,updated_on = GETUTCDATE() where id = " + ICPrefrenceDto.id;
                var data = dbConnection.Execute(query, commandType: CommandType.Text);
            }
            else if ((ICPrefrenceDto is not null) && (ICPrefrenceDto.is_active == false) && availableIns.Contains(ICPrefrenceDto.instruction))
            {
                string query = @"Update ic_preference_rule set is_active=1 ,updated_on = GETUTCDATE() where id = " + ICPrefrenceDto.id;
                var data = dbConnection.Execute(query, commandType: CommandType.Text);
            }
            else if (!string.IsNullOrEmpty(availableIns))
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@instruction", availableIns);
                string query = @"Update ic_preference_rule set is_active = 1,instruction = @instruction ,updated_on = GETUTCDATE() where id = " + ICPrefrenceDto.id;
                var data = dbConnection.Execute(query, dp, commandType: CommandType.Text);
            }
        }
        public async Task CheckICInstructionAsync(string availableIns, float? amount, long? serviceId, string service_name, string rulejson, string humanReadbleJson, long? detail_optionset)
        {
            string preferenceQuery = "select id, is_active, service_id from preference where agreement_id = " + agreement_id;
            List<ICPrefrenceListDto> availableICList = (List<ICPrefrenceListDto>)await dbConnection.QueryAsyncWithRetry<ICPrefrenceListDto>(preferenceQuery);

            bool isActivate = false;

            ICPrefrenceListDto ICPrefrenceDto = availableICList?.Where(x => x.service_id == serviceId).FirstOrDefault();

            if (ICPrefrenceDto is null && availableIns is not null)
            {
                if ((long)EnumTypes.detail_product_option_set.Detail_Deliver_as_is_no_detail != detail_optionset &&
                    (long)EnumTypes.detail_product_option_set.Detail_If_needed_contact_FO_for_instruction != detail_optionset)
                {
                    DynamicParameters dp1 = new DynamicParameters();
                    dp1.Add("@name", service_name);
                    dp1.Add("@agreement_id", agreement_id);
                    dp1.Add("@event_type_id", EnumTypes.Event_Type.new_service_request);
                    dp1.Add("@category_id", EnumTypes.Category_Types.service_request);
                    dp1.Add("@service_id", serviceId);
                    dp1.Add("@service_amount", amount);
                    dp1.Add("@inclusion_type_id", EnumTypes.Inclusion_Type.ConditionBased);
                    dp1.Add("@rule_type_id", EnumTypes.Rule_Type.Evaluation);
                    dp1.Add("@rule_json", rulejson);
                    dp1.Add("@human_readable_rule", humanReadbleJson);
                    dp1.Add("@can_override", 1);
                    dp1.Add("@can_modify", 1);
                    dp1.Add("@is_overridden", 1);
                    dp1.Add("@is_active", 1);
                    dp1.Add("@created_on", DateTime.UtcNow);
                    dp1.Add("@created_by", 1);
                    string query = @"insert into preference(name,agreement_id,event_type_id,category_id,service_id,service_amount,inclusion_type_id,rule_type_id,rule_json,human_readable_rule,can_override,can_modify,is_overridden,is_active,created_on,created_by,updated_on)
                                values(@name,@agreement_id,@event_type_id,@category_id,@service_id,@service_amount,@inclusion_type_id,@rule_type_id,@rule_json,@human_readable_rule,@can_override,@can_modify,@is_overridden,@is_active,@created_on,@created_by,@created_on)";
                    var data1 = await dbConnection.ExecuteAsyncWithRetry(query, dp1, commandType: CommandType.Text);
                }
            }
            else if (ICPrefrenceDto is not null && availableIns is null)
            {
                string query2 = @"update preference set is_active = 0 ,updated_on = GETUTCDATE()  where id = " + ICPrefrenceDto.id;
                var data = await dbConnection.ExecuteAsyncWithRetry(query2, commandType: CommandType.Text);
            }
            else if (ICPrefrenceDto is not null && availableIns is not null)
            {
                if (((long)EnumTypes.detail_product_option_set.Detail_Deliver_as_is_no_detail == detail_optionset || (long)EnumTypes.detail_product_option_set.Detail_If_needed_contact_FO_for_instruction == detail_optionset) && serviceId == (long)EnumTypes.default_services_for_crm.Full_Detail)
                    isActivate = false;
                else
                    isActivate = true;

                DynamicParameters dp = new DynamicParameters();
                dp.Add("@amount", amount);
                dp.Add("@isActivate", isActivate);
                string query = @"Update preference set is_active=@isActivate, service_amount = @amount ,updated_on = GETUTCDATE() where id = " + ICPrefrenceDto.id;
                var data = dbConnection.Execute(query, dp, commandType: CommandType.Text);
            }
            else if (ICPrefrenceDto != null)
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@amount", amount);
                string query2 = @"update preference set service_amount = @amount ,updated_on = GETUTCDATE() where id = " + ICPrefrenceDto.id;
                var data = await dbConnection.ExecuteAsyncWithRetry(query2, dp, commandType: CommandType.Text);
            }

            string icPreferenceQuery = "select id, is_active, service_id,instruction from ic_preference_rule where agreement_id = " + agreement_id;
            List<ICPrefrenceListDto> availableIC = (List<ICPrefrenceListDto>)await dbConnection.QueryAsyncWithRetry<ICPrefrenceListDto>(icPreferenceQuery);

            ICPrefrenceListDto ICPrefrenceDto1 = availableIC?.Where(x => x.service_id == serviceId).FirstOrDefault();

            if (serviceId == (long)EnumTypes.default_services_for_crm.Maintenance_Inquiry)
                availableIns = null;

            string parent_preference_query = string.Empty;
            int? parent_preference_id = null;
            if (serviceId != null) // Check if serviceId is not null
            {
                parent_preference_query = "SELECT * FROM ic_preference_rule WHERE agreement_id IS NULL AND currency_id = 2 AND service_id = " + serviceId;
                var parameters = new { CurrencyId = (long)EnumTypes.CurrencyType.US, ServiceId = serviceId.Value }; // Use Value if serviceId is nullable
                parent_preference_id = await dbConnection.QueryFirstOrDefaultAsyncWithRetry<int?>(parent_preference_query);
            }

            if (ICPrefrenceDto1 is null && availableIns is not null)
            {
                //if ((long)EnumTypes.detail_product_option_set.Detail_Deliver_as_is_no_detail != detail_optionset)
                //{
                DynamicParameters dp = new DynamicParameters();
                //if ((long)EnumTypes.detail_product_option_set.if_detail_needed_contact_FO_for_instruction == detail_optionset)
                //{
                //    dp.Add("@instruction_rule", null);
                //    dp.Add("@human_readable_rule", null);
                //    dp.Add("@inclusion_type_id", EnumTypes.Inclusion_Type.Include);

                //}
                //else
                //{
                //    dp.Add("@instruction_rule", rulejson);
                //    dp.Add("@human_readable_rule", humanReadbleJson);
                //    dp.Add("@inclusion_type_id", EnumTypes.Inclusion_Type.ConditionBased);

                //}
                dp.Add("@instruction_rule", rulejson);
                dp.Add("@human_readable_rule", humanReadbleJson);
                dp.Add("@inclusion_type_id", EnumTypes.Inclusion_Type.ConditionBased);

                dp.Add("@agreement_id", agreement_id);
                dp.Add("@parent_preference_id", parent_preference_id);
                dp.Add("@agreement_type_id", 1);
                dp.Add("@service_id", serviceId);
                dp.Add("@event_type_id", EnumTypes.Event_Type.new_service_request);
                dp.Add("@instruction", availableIns);
                dp.Add("@rule_type_id", EnumTypes.Rule_Type.Evaluation);
                dp.Add("@can_modify", 1);
                dp.Add("@can_override", 1);
                dp.Add("@is_overridden", 1);
                dp.Add("@currency_id", (long)EnumTypes.CurrencyType.US);
                dp.Add("@is_active", 1);
                dp.Add("@sort_code", "");
                dp.Add("@created_on", DateTime.UtcNow);
                dp.Add("@created_by", 1);
                string query2 = @"insert into ic_preference_rule(agreement_id,parent_ic_preference_id,agreement_type_id,service_id,instruction_rule,human_readable_rule,event_type_id,instruction,can_modify,can_override,is_overridden,currency_id,inclusion_type_id,rule_type_id,is_active,sort_code,created_on,created_by,updated_on) "
                               + "Values(@agreement_id,@parent_preference_id,@agreement_type_id ,@service_id,@instruction_rule,@human_readable_rule,@event_type_id,@instruction,@can_modify,@can_override,@is_overridden,@currency_id,@inclusion_type_id,@rule_type_id,@is_active,@sort_code,@created_on,@created_by,@created_on)";

                var data = await dbConnection.ExecuteAsyncWithRetry(query2, dp, commandType: CommandType.Text);
                //}
            }
            else if (ICPrefrenceDto1 is not null && availableIns is null)
            {
                string query2 = @"update ic_preference_rule set is_active = 0 ,updated_on = GETUTCDATE() where id = " + ICPrefrenceDto1.id;
                var data = await dbConnection.ExecuteAsyncWithRetry(query2, commandType: CommandType.Text);
            }
            else if ((availableIns is not null) && ICPrefrenceDto1 is not null)
            {
                if (serviceId == (long)EnumTypes.default_services_for_crm.Full_Detail)
                {
                    //if ((long)EnumTypes.detail_product_option_set.deliver_as_is_no_detail == detail_optionset)
                    //    isActivate = false;
                    //else
                    isActivate = true;

                }
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@isActivate", isActivate);
                dp.Add("@instruction_rule", rulejson);
                dp.Add("@human_readable_rule", humanReadbleJson);
                dp.Add("@instruction", availableIns);
                string query2 = @"update ic_preference_rule set is_active = @isActivate ,instruction_rule=@instruction_rule,human_readable_rule=@human_readable_rule,instruction=@instruction,updated_on = GETUTCDATE() where id = " + ICPrefrenceDto1.id;
                var data = await dbConnection.ExecuteAsyncWithRetry(query2, dp, commandType: CommandType.Text);
            }
            else if (availableIns is not null && ICPrefrenceDto1.instruction != null && !availableIns.Contains(ICPrefrenceDto1?.instruction))
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@instruction", availableIns);
                string query2 = @"update ic_preference_rule set instruction = @instruction ,is_active=1,updated_on = GETUTCDATE() where id = " + ICPrefrenceDto1.id;
                var data = await dbConnection.ExecuteAsyncWithRetry(query2, dp, commandType: CommandType.Text);
            }
        }
        public void CreateMaintenanceContact(long? fmcId, string contact, string instruction, string sortCode)
        {
            DynamicParameters cDP = new DynamicParameters();
            cDP.Add("@fmcId", fmcId);
            cDP.Add("@description", contact + " " + instruction);
            cDP.Add("@created_on", DateTime.UtcNow);
            cDP.Add("@created_by", (int)EnumTypes.Account.PARS);
            cDP.Add("@sortCode", sortCode);

            string query = @"Select id from account where preferred_agreement_id =" + agreement_id + " and fmc_id = " + fmcId;
            List<int> ids = (List<int>)dbConnection.Query<int>(query, cDP);
            foreach (int id in ids)
            {
                cDP.Add("@fleet_id", fmcId == id ? null : id);
                string selectIdQuery = "Select id FROM support_contact where sort_code = @sortCode AND account_id = @fleet_id and fmc_id = @fmcId ";
                int supportContactId = dbConnection.QuerySingleOrDefault<int>(selectIdQuery, cDP);
                if (supportContactId < 1)
                {
                    string createContactQuery = @"INSERT INTO SUPPORT_CONTACT(fmc_id,account_id,description,created_by,created_on,sort_code,is_active) OUTPUT INSERTED.id VALUES ( @fmcId, @fleet_id, @description, @created_by, @created_on, @sortCode,1)";
                    var data = dbConnection.ExecuteScalar(createContactQuery, cDP, commandType: CommandType.Text);
                    cDP.Add("@support_contact_id", data);
                    string query3 = @"Insert into trns_accounts_support_contact_types(support_contact_id, support_contact_type_id)values(@support_contact_id,4)";
                    _ = dbConnection.ExecuteScalar(query3, cDP, commandType: CommandType.Text);
                }
                else if (!string.IsNullOrEmpty(contact) || !string.IsNullOrEmpty(instruction))
                {
                    string updateContactQuery = @"Update support_contact SET description=@description, updated_by=@created_by, updated_on = @created_on where id = " + supportContactId;
                    var data = dbConnection.Execute(updateContactQuery, cDP, commandType: CommandType.Text);
                }
                else
                {
                    string updateContactQuery = @"Update support_contact SET is_active = 0 where id = " + supportContactId;
                    var data = dbConnection.Execute(updateContactQuery, cDP, commandType: CommandType.Text);
                }
            }
        }
    }
}