﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Command.UpdateAGServicesAndICFromCRM
{
    public class UpdateServicesAndICFromCRMReq
    {
        public string parameter_id { get; set; }
        public string parameter_name { get; set; }
        public string solzit_keyflapping { get; set; }
        public string solzit_telematics { get; set; }
        public string solzit_keyfob { get; set; }
        public string solzit_contentsmaterials { get; set; }
        public string solzit_addresschange { get; set; }
        public string solzit_servicelights { get; set; }
        public string solzit_lastservice { get; set; }
        public string solzit_detail { get; set; }
        public long solzit_detail_optionset { get; set; }
        public float? solzit_detailmax { get; set; }
        public bool? solzit_maintenanceinquiry { get; set; }
        public long? fmcId1 { get; set; }
        public string contact1 { get; set; }
        public string instruction1 { get; set; }
        public long? fmcId2 { get; set; }
        public string contact2 { get; set; }
        public string instruction2 { get; set; }
        public long? fmcId3 { get; set; }
        public string contact3 { get; set; }
        public string instruction3 { get; set; }
    }
    public class ICPrefrenceListDto
    {
        public long id { get; set; }
        public long? service_id { get; set; }
        public string instruction { get; set; }
        public string sort_code { get; set; }
        public bool is_active { get; set; }
    }
}
