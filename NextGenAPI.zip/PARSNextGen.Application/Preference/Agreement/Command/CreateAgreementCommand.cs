﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using PARSNextGen.Domain.Interface;
using PARSNextGen.Application.SQL;
using System.Data;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.Master.Roles.Queries.RoleDetail;
using PARSNextGen.Domain.Entities;
using System.Collections;
using System.Collections.Generic;
using System;
using PARSNextGen.Domain.Common;
using System.Linq;
using PARSNextGen.Application.Preference.IcInstructions.Query;

namespace PARSNextGen.Application.Preference.Agreement.Command
{
    public class CreateAgreementCommand : IRequest<bool>
    {
        public CreateAgreementReq createAgreementReqs { get; set; }
    }
    public class CreateAgreementCommandHandler : IRequestHandler<CreateAgreementCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAgreementRepository _AgreementRepo;
        private readonly IMediator _mediator;
        public CreateAgreementCommandHandler(ISqlContext dbCntx, IAgreementRepository AgreementRepo, MediatR.IMediator mediator)
        {
            _dbCntx = dbCntx;
            _AgreementRepo = AgreementRepo;
            _mediator = mediator;
        }

        public async Task<bool> Handle(CreateAgreementCommand request, CancellationToken cancellationToken)
        {
            Agreements agreementObj = new Agreements();

            #region Agreement_Field

            string agreementname = string.Empty;
            if (string.IsNullOrWhiteSpace(request.createAgreementReqs.name))
            {
                string fmc_name = string.Empty;
                string fleet_name = string.Empty;
                string fleet_no = string.Empty;
                string fmc_query = string.Empty;
                string fleet_query = string.Empty;

                //fmc condition
                if (request.createAgreementReqs.fmc_id != null)
                {
                    fmc_query = "where fmc.id= " + request.createAgreementReqs.fmc_id;
                }
                else
                {
                    fmc_query = "where fmc.id IS NULL";
                }

                //fleet condition
                if (request.createAgreementReqs.fleet_id != null)
                {
                    fleet_query = "where fleet.id= " + request.createAgreementReqs.fleet_id;
                }
                else
                {
                    fleet_query = "where fleet.id IS NULL";
                }

                //Get fmc and fleet
                using (var connection = _dbCntx.GetOpenConnection())
                {
                    string query = @"select fmc.account_type_id,fmc.account_name,fmc.id,fmc.fleet_no from account fmc " + fmc_query +
                                     " Union all " +
                                     "select fleet.account_type_id,fleet.account_name,fleet.id,fleet.fleet_no from account fleet " + fleet_query;
                    dynamic obj = (List<dynamic>)await connection.QueryAsyncWithRetry<dynamic>(query, null, commandType: CommandType.Text);

                    if (obj != null)
                    {
                        foreach (var item in obj)
                        {
                            var attribute = ((IDictionary<String, Object>)item);

                            var account_type_id = long.Parse(attribute["account_type_id"].ToString());
                            if(attribute["fleet_no"] != null)
                                fleet_no = attribute["fleet_no"].ToString();

                            if (account_type_id == (long)EnumTypes.AccountTypes.FMC)
                            {
                                fmc_name = attribute["account_name"].ToString();
                            }
                            else if (account_type_id == (long)EnumTypes.AccountTypes.Fleet)
                            {
                                fleet_name= attribute["account_name"].ToString();
                            }
                            else if (account_type_id == (long)EnumTypes.AccountTypes.Account)
                            {
                                fleet_name = attribute["account_name"].ToString();
                            }
                        }
                    }

                }

                if (!string.IsNullOrWhiteSpace(fmc_name) && !string.IsNullOrWhiteSpace(fleet_name))
                {
                    agreementname = fmc_name + " | " + fleet_no + " " + fleet_name;
                }
                else if (!string.IsNullOrWhiteSpace(fmc_name))
                {
                    agreementname = fmc_name;
                }
                else if (!string.IsNullOrWhiteSpace(fleet_name))
                {
                    agreementname = fleet_name;
                }

                if (request.createAgreementReqs.end_date == null)
                {
                    agreementname = agreementname + " | " + request.createAgreementReqs.start_date.Value.Year;
                }
                else
                {
                    agreementname = agreementname + " | " + request.createAgreementReqs.end_date.Value.Year;
                }
            }
            else
            {
                agreementname = request.createAgreementReqs.name;
            }

            agreementObj.name = agreementname;
            agreementObj.fleet_id = request.createAgreementReqs.fleet_id;
            agreementObj.fmc_id = request.createAgreementReqs.fmc_id;
            agreementObj.start_date = request.createAgreementReqs.start_date;
            agreementObj.end_date = request.createAgreementReqs.end_date;
            agreementObj.currency_id = request.createAgreementReqs.currency_id;
            agreementObj.parent_agreement_id = request.createAgreementReqs.parent_agreement_id;
            agreementObj.default_bill_to_id = request.createAgreementReqs.default_bill_to_id;
            agreementObj.transportation_preference_type_id = request.createAgreementReqs.transportation_preference_type_id;
            agreementObj.agreement_status_id = request.createAgreementReqs.agreement_status_id;
            agreementObj.pars_perform_inspection = request.createAgreementReqs.pars_perform_inspection;
            #endregion






            #region Get IC_Preference_Rule
            long agreementTypeId = 0;
            #region agreement_type
            if (request.createAgreementReqs.fmc_id != null && request.createAgreementReqs.fleet_id != null)
                agreementTypeId = (long)EnumTypes.Agreement_Type.FMC_Fleet;

            if (request.createAgreementReqs.fmc_id != null && request.createAgreementReqs.fleet_id == null)
                agreementTypeId = (long)EnumTypes.Agreement_Type.FMC;

            if (request.createAgreementReqs.fmc_id == null && request.createAgreementReqs.fleet_id != null)
                agreementTypeId = (long)EnumTypes.Agreement_Type.Fleet;

            #endregion

            GetICPreferenceRuleListReq icPreference = new GetICPreferenceRuleListReq();
            icPreference.agreement_id = request.createAgreementReqs.parent_agreement_id;
            icPreference.agreement_type_id = agreementTypeId;
            icPreference.currency_id = (long)request.createAgreementReqs.currency_id;

            //var icPreferenceRule = await _mediator.Send(new GetAllICPreferenceRuleQuery { agreement_id = request.cloneAgreementReq.agreement_id, agreement_type_id = agreementTypeId });
            var icPreferenceRule = await _mediator.Send(new GetAllICPreferenceRuleQuery { preferenceRuleListReq = icPreference });
            List<IcPreferenceRule> ICPreferenceRuleList = new List<IcPreferenceRule>();
            IcPreferenceRule ic_preference = null;
            if (icPreferenceRule!=null)
            {
                foreach (var item in icPreferenceRule)
                {
                    ic_preference = new IcPreferenceRule();
                    ic_preference.agreement_id = item.agreement_id;
                    ic_preference.agreement_type_id = item.agreement_type_id;
                    ic_preference.service_id = item.service_id;
                    ic_preference.event_type_id = item.event_type_id;
                    ic_preference.preference_type_id = item.preference_type_id;
                    ic_preference.instruction = item.instruction;
                    ic_preference.can_modify = item.can_modify;
                    ic_preference.can_override = item.can_override;
                    //ic_preference.is_overridden = item.is_overridden;
                    ic_preference.instruction_rule = item.instruction_rule;
                    ic_preference.inclusion_type_id = item.inclusion_type_id;
                    ic_preference.rule_type_id = item.rule_type_id;
                    ic_preference.human_readable_rule = item.human_readable_rule;
                    ic_preference.currency_id = item.currency_id;
                    ic_preference.sequence_number = item.sequence_number;
                    ICPreferenceRuleList.Add(ic_preference);
                }
            }

            #endregion




            bool status = await _AgreementRepo.CreateAgreement(agreementObj, ICPreferenceRuleList);

            return status;
        }
    }
}

