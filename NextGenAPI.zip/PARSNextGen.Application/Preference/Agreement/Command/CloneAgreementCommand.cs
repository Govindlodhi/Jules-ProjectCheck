﻿using Dapper;
using MassTransit.Caching.Internals;
using MediatR;
using PARSNextGen.Application.Preference.Agreement.Queries;
using PARSNextGen.Application.Preference.IcInstructions.Query;
using PARSNextGen.Application.Preference.Preference.Queries;
using PARSNextGen.Application.Preference.PriceList.Queries;
using PARSNextGen.Application.Preference.PriceListItem.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static MassTransit.Logging.OperationName;

namespace PARSNextGen.Application.Preference.Agreement.Command
{
    public class CloneAgreementCommand : IRequest<long>
    {
        public CloneAgreementReq cloneAgreementReq { get; set; }
    }
    public class CloneAgreementCommandHandler : IRequestHandler<CloneAgreementCommand, long>
    {
        private readonly IMediator _mediator;
        private readonly IAgreementRepository _AgreementRepo;
        private readonly ISqlContext _dbCntx;

        public CloneAgreementCommandHandler(IMediator mediator, IAgreementRepository AgreementRepo, ISqlContext dbCntx)
        {
            _mediator = mediator;
            _AgreementRepo = AgreementRepo;
            _dbCntx = dbCntx;
        }

        public async Task<long> Handle(CloneAgreementCommand request, CancellationToken cancellationToken)
        {
            long agreementid = 0;
            //List<PriceLists> lstpriceList = new List<PriceLists>();

            if (request != null)
            {
                /*
                    var pricelistDetails = await _mediator.Send(new GetPriceListByAgreementIdQuery
                    { agreementId = request.cloneAgreementReq.agreement_id });

                    if (pricelistDetails != null)
                    {
                        foreach (var item in pricelistDetails)
                        {
                            #region PriceList_Field

                            PriceLists priceLists = new PriceLists();
                            priceLists.id = item.id;
                            priceLists.price_list_name = item.price_list_name;
                            priceLists.agreement_id = item.agreement_id;
                            priceLists.price_list_type_id = item.price_list_type_id;
                            priceLists.default_bill_to_id = item.default_bill_to_id;
                            priceLists.tarrif_calculation_type_ev_id = item.tarrif_calculation_type_ev_id;
                            priceLists.tarrif_calculation_type_nev_id = item.tarrif_calculation_type_nev_id;
                            priceLists.price_list_status_id = item.price_list_status_id;
                        
                            priceLists.currency_id = item.currency_id;

                        #endregion

                        priceLists.PriceListItemsList = new List<PriceListItems>();

                        var pricelistItemDetails = await _mediator.Send(new GetPriceListItemByPriceListIdQuery
                        {
                            priceListId = item.id
                        });

                        foreach (var i in pricelistItemDetails)
                        {
                            PriceListItems priceListItems = new PriceListItems();
                            priceListItems.price_list_id = i.price_list_id;
                            priceListItems.service_id = i.service_id;
                            priceListItems.amount = i.amount;
                            priceListItems.rate_type_id = i.rate_type;
                            priceListItems.sur_charge = i.sur_charge;
                            priceListItems.markup_number = i.markup_number;
                            priceListItems.markup_type = i.markup_type;
                            priceListItems.discount = i.discount;
                            priceListItems.discount_type = i.discount_type;
                            priceListItems.rebate = i.rebate;
                            priceListItems.rebate_type = i.rebate_type;
                            priceListItems.is_active = i.price_list_item_is_active;

                            priceLists.PriceListItemsList.Add(priceListItems);
                        }

                        lstpriceList.Add(priceLists);
                        }
                    }
                    */

                #region Get Preference to related agreement
                long? eventTypeId = null;
                List<PreferenceDto> preferencesList = await _mediator.Send(new GetPreferencesByAgreementIdQuery
                {
                    agreementId = request.cloneAgreementReq.agreement_id,
                    eventTypeId = eventTypeId,

                });
                List<preference> preferencesLst = new List<preference>();
                preference preference = null;
                if (preferencesList.Count > 0)
                {
                    foreach (var item in preferencesList)
                    {
                        if (request.cloneAgreementReq.transportation_preference_type_id == (long)EnumTypes.Transportation_Preference_Type.Always_Use_Drive_Away ||
                            request.cloneAgreementReq.transportation_preference_type_id == (long)EnumTypes.Transportation_Preference_Type.Always_Use_Auto_Carrier)
                        {

                            preference = new preference();
                            preference.agreement_id = item.agreement_id;
                            preference.name = item.name;
                            preference.preference_id = item.id;
                            //preference.preference_type_id = request.createPreferenceReq.preference_type_id;
                            preference.event_type_id = item.event_type_id;
                            preference.category_id = item.category_id;
                            //preference.subcategory_id = request.createPreferenceReq.subcategory_id;
                            preference.service_id = item.service_id;
                            preference.service_amount = item.service_amount;
                            preference.inclusion_type_id = item.inclusion_type_id;
                            preference.rule_type_id = item.rule_type_id;
                            preference.rule_json = item.rule_json;

                            if(item.can_override==null)
                            preference.can_override = false;
                            else
                            preference.can_override = item.can_override;

                            if (item.can_modify == null)
                                preference.can_modify = false;
                            else
                                preference.can_modify = item.can_modify;

                            if (item.is_overridden == null)
                                preference.is_overridden = false;
                            else
                                preference.is_overridden = item.is_overridden;

                            preference.human_readable_rule = item.human_readable_rule;
                            preferencesLst.Add(preference);

                            var AutoCarrierTariff = preferencesLst.Find(x => x.service_id == (long)EnumTypes.Transport_service.Auto_Carrier_Tariff);
                            if (AutoCarrierTariff != null)
                                preferencesLst.Remove(preference);

                            var DriveAway = preferencesLst.Find(x => x.service_id == (long)EnumTypes.Transport_service.Drive_Away_Tariff);
                            if (DriveAway != null)
                                preferencesLst.Remove(preference);

                        }
                        else
                        {
                            preference = new preference();
                            preference.agreement_id = item.agreement_id;
                            preference.name = item.name;
                            preference.preference_id = item.id;
                            //preference.preference_type_id = request.createPreferenceReq.preference_type_id;
                            preference.event_type_id = item.event_type_id;
                            preference.category_id = item.category_id;
                            //preference.subcategory_id = request.createPreferenceReq.subcategory_id;
                            preference.service_id = item.service_id;
                            preference.service_amount = item.service_amount;
                            preference.inclusion_type_id = item.inclusion_type_id;
                            preference.rule_type_id = item.rule_type_id;
                            preference.rule_json = item.rule_json;

                            if (item.can_override == null)
                                preference.can_override = false;
                            else
                                preference.can_override = item.can_override;

                            if (item.can_modify == null)
                                preference.can_modify = false;
                            else
                                preference.can_modify = item.can_modify;

                            if (item.is_overridden == null)
                                preference.is_overridden = false;
                            else
                                preference.is_overridden = item.is_overridden;

                            preference.human_readable_rule = item.human_readable_rule;
                            preferencesLst.Add(preference);
                        }
                    }
                }
                #endregion END


                #region Get IC_Preference_Rule
                long agreementTypeId = 0;
                #region agreement_type
                if (request.cloneAgreementReq.fmc_id != null && request.cloneAgreementReq.fleet_id != null)
                    agreementTypeId = (long)EnumTypes.Agreement_Type.FMC_Fleet;

                if (request.cloneAgreementReq.fmc_id != null && request.cloneAgreementReq.fleet_id == null)
                    agreementTypeId = (long)EnumTypes.Agreement_Type.FMC;

                if (request.cloneAgreementReq.fmc_id == null && request.cloneAgreementReq.fleet_id != null)
                    agreementTypeId = (long)EnumTypes.Agreement_Type.Fleet;

                #endregion

                GetICPreferenceRuleListReq icPreference = new GetICPreferenceRuleListReq();
                icPreference.agreement_id = request.cloneAgreementReq.agreement_id;
                icPreference.agreement_type_id = agreementTypeId;
                icPreference.currency_id = (long)request.cloneAgreementReq.currency_id;

                //var icPreferenceRule = await _mediator.Send(new GetAllICPreferenceRuleQuery { agreement_id = request.cloneAgreementReq.agreement_id, agreement_type_id = agreementTypeId });
                var icPreferenceRule = await _mediator.Send(new GetAllICPreferenceRuleQuery { preferenceRuleListReq = icPreference });
                List<IcPreferenceRule> ICPreferenceRuleList = new List<IcPreferenceRule>();
                IcPreferenceRule ic_preference = null;
                if (icPreferenceRule.Count > 0)
                {
                    foreach (var item in icPreferenceRule)
                    {
                        ic_preference = new IcPreferenceRule();
                        ic_preference.agreement_id = item.agreement_id;
                        ic_preference.agreement_type_id = (long)item.agreement_type_id;
                        ic_preference.service_id = item.service_id;
                        ic_preference.event_type_id = item.event_type_id;
                        ic_preference.preference_type_id = item.preference_type_id;
                        ic_preference.instruction = item.instruction;
                        ic_preference.can_modify = item.can_modify;
                        ic_preference.can_override = item.can_override;
                        ic_preference.is_overridden = item.is_overridden;
                        ic_preference.instruction_rule = item.instruction_rule;
                        ic_preference.is_active = item.is_active;

                        ICPreferenceRuleList.Add(ic_preference);
                    }
                }

                #endregion

                Agreements agreementObj = new Agreements();

                #region Agreement_Field

                agreementObj.id = request.cloneAgreementReq.agreement_id;
                agreementObj.name = request.cloneAgreementReq.name;
                agreementObj.fleet_id = request.cloneAgreementReq.fleet_id;
                agreementObj.fmc_id = request.cloneAgreementReq.fmc_id;
                agreementObj.start_date = request.cloneAgreementReq.start_date;
                agreementObj.end_date = request.cloneAgreementReq.end_date;
                agreementObj.currency_id = request.cloneAgreementReq.currency_id;
                agreementObj.default_bill_to_id = request.cloneAgreementReq.default_bill_to_id;
                agreementObj.transportation_preference_type_id = request.cloneAgreementReq.transportation_preference_type_id;
                agreementObj.pars_perform_inspection = request.cloneAgreementReq.pars_perform_inspection;


                //agreementObj.agreement_status_id = request.cloneAgreementReq.agreement_status_id;

                #endregion

                agreementid = await _AgreementRepo.CloneAgreement(agreementObj, preferencesLst, ICPreferenceRuleList);

            }

            return agreementid;
        }
    }
}
