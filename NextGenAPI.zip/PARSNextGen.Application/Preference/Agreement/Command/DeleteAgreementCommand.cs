﻿using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Command
{
    public class DeleteAgreementCommand : IRequest<bool>
    {
        public long Id { get; set; }
    }
    public class DeleteAgreementCommandHandler : IRequestHandler<DeleteAgreementCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IAgreementRepository _AgreementRepo;

        public DeleteAgreementCommandHandler(ISqlContext dbCntx, IAgreementRepository AgreementRepo)
        {
            _dbCntx = dbCntx;
            _AgreementRepo = AgreementRepo;
        }

        public async Task<bool> Handle(DeleteAgreementCommand request, CancellationToken cancellationToken)
        {
        
            bool status = await _AgreementRepo.DeleteAgreement(request.Id);

            return status;
        }
    }
}
