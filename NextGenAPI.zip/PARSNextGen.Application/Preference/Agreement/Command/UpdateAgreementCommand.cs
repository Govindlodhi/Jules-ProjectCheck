﻿using MediatR;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Command
{
    public class UpdateAgreementCommand : IRequest<bool>
    {
        public UpdateAgreementReq updateAgreementReq { get; set; }
    }

    public class UpdateAgreementCommandHandler : IRequestHandler<UpdateAgreementCommand, bool>
    {
        private readonly IAgreementRepository _AgreementRepo;

        public UpdateAgreementCommandHandler(IAgreementRepository AgreementRepo)
        {
            _AgreementRepo = AgreementRepo;
        }

        public async Task<bool> Handle(UpdateAgreementCommand request, CancellationToken cancellationToken)
        {
            Agreements agreementObj = new Agreements();

            #region Agreement_Field

            agreementObj.id = request.updateAgreementReq.id;
            agreementObj.name = request.updateAgreementReq.name;
            agreementObj.fleet_id = request.updateAgreementReq.fleet_id;
            agreementObj.fmc_id = request.updateAgreementReq.fmc_id;
            agreementObj.start_date = request.updateAgreementReq.start_date;
            agreementObj.end_date = request.updateAgreementReq.end_date;
            agreementObj.currency_id = request.updateAgreementReq.currency_id;
            agreementObj.default_bill_to_id = request.updateAgreementReq.default_bill_to_id;
            agreementObj.transportation_preference_type_id = request.updateAgreementReq.transportation_preference_type_id;
            agreementObj.pars_perform_inspection = request.updateAgreementReq.pars_perform_inspection;

            #endregion

            bool status = await _AgreementRepo.UpdateAgreement(agreementObj);

            return status;
        }
    }
}
