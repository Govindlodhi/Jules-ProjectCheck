﻿using Dapper;
using MassTransit.Caching.Internals;
using MediatR;
using PARSNextGen.Application.Preference.Agreement.Queries;
using PARSNextGen.Application.Preference.IcInstructions.Query;
using PARSNextGen.Application.Preference.Preference.Queries;
using PARSNextGen.Application.Preference.PriceList.Queries;
using PARSNextGen.Application.Preference.PriceListItem.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static MassTransit.Logging.OperationName;

namespace PARSNextGen.Application.Preference.Agreement.Command
{
    public class CloneAgreementForCustomerParameterSetCommand : IRequest<long>
    {
        public long agreement_id { get; set; }
        public string name { get; set; }
        public Guid parameter_set_id { get; set; }
    }
    public class CloneAgreementForCustomerParameterSetCommandHandler : IRequestHandler<CloneAgreementForCustomerParameterSetCommand, long>
    {
        private readonly IMediator _mediator;
        private readonly IAgreementRepository _AgreementRepo;
        private readonly ISqlContext _dbCntx;
        public CloneAgreementForCustomerParameterSetCommandHandler(IMediator mediator, IAgreementRepository AgreementRepo, ISqlContext dbCntx)
        {
            _mediator = mediator;
            _AgreementRepo = AgreementRepo;
            _dbCntx = dbCntx;
        }
        public async Task<long> Handle(CloneAgreementForCustomerParameterSetCommand request, CancellationToken cancellationToken)
        {
            long agreementid = 0;           
            if (request != null)
            {
                #region Get Preference to related agreement
                long? eventTypeId = null;
                List<PreferenceDto> preferencesList = await _mediator.Send(new GetPreferencesByAgreementIdQuery
                {
                    agreementId = request.agreement_id,
                    eventTypeId = eventTypeId,

                });
                List<preference> preferencesLst = new List<preference>();
                preference preference = null;
                if (preferencesList.Count > 0)
                {
                    foreach (var item in preferencesList)
                    {
                        preference = new preference();
                        preference.agreement_id = item.agreement_id;
                        preference.name = item.name;
                        preference.preference_id = item.id;
                        preference.event_type_id = item.event_type_id;
                        preference.category_id = item.category_id;
                        preference.service_id = item.service_id;
                        preference.service_amount = item.service_amount;
                        preference.inclusion_type_id = item.inclusion_type_id;
                        preference.rule_type_id = item.rule_type_id;
                        preference.rule_json = item.rule_json;

                        if (item.can_override == null)
                            preference.can_override = false;
                        else
                            preference.can_override = item.can_override;

                        if (item.can_modify == null)
                            preference.can_modify = false;
                        else
                            preference.can_modify = item.can_modify;

                        if (item.is_overridden == null)
                            preference.is_overridden = false;
                        else
                            preference.is_overridden = item.is_overridden;

                        preference.human_readable_rule = item.human_readable_rule;
                        preferencesLst.Add(preference);                       
                    }
                }
                #endregion END

                #region Get IC_Preference_Rule
                long agreementTypeId = 0;
                GetICPreferenceRuleListReq icPreference = new GetICPreferenceRuleListReq();
                icPreference.agreement_id = request.agreement_id;
                icPreference.agreement_type_id = agreementTypeId;
                var icPreferenceRule = await _mediator.Send(new GetAllICPreferenceRuleQuery { preferenceRuleListReq = icPreference });
                List<IcPreferenceRule> ICPreferenceRuleList = new List<IcPreferenceRule>();
                IcPreferenceRule ic_preference = null;
                if (icPreferenceRule.Count > 0)
                {
                    foreach (var item in icPreferenceRule)
                    {
                        ic_preference = new IcPreferenceRule();
                        ic_preference.agreement_id = item.agreement_id;
                        ic_preference.agreement_type_id = (long)item.agreement_type_id;
                        ic_preference.service_id = item.service_id;
                        ic_preference.event_type_id = item.event_type_id;
                        ic_preference.preference_type_id = item.preference_type_id;
                        ic_preference.instruction = item.instruction;
                        ic_preference.can_modify = item.can_modify;
                        ic_preference.can_override = item.can_override;
                        ic_preference.is_overridden = item.is_overridden;
                        ic_preference.instruction_rule = item.instruction_rule;
                        ic_preference.is_active = item.is_active;
                        ICPreferenceRuleList.Add(ic_preference);
                    }
                }
                #endregion

                agreementid = await _AgreementRepo.CloneAgreementForCrmCustomerParameterSet(request.name, request.parameter_set_id, preferencesLst, ICPreferenceRuleList);
            }
            return agreementid;
        }
    }
}
