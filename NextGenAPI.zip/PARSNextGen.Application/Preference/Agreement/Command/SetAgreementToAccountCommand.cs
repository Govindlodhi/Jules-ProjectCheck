﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Command
{
    public class SetAgreementToAccountCommand : IRequest<bool>
    {
        public SetAgreementReq req { get; set; }
    }
    public class SetAgreementToAccountCommandHandler : IRequestHandler<SetAgreementToAccountCommand, bool>
    {
        private readonly IAgreementRepository _AgreementRepo;
        public SetAgreementToAccountCommandHandler(IAgreementRepository agreementRepository)
        {
            _AgreementRepo = agreementRepository;
        }
        public async Task<bool> Handle(SetAgreementToAccountCommand request, CancellationToken cancellationToken)
        {
            bool status = false;
            if (request.req.accountType == "fleet")
                status = await _AgreementRepo.SetAgreementToFleet(request.req.Ids);
            else if (request.req.accountType == "account")
                status = await _AgreementRepo.SetAgreementToAccount(request.req.Ids);
            return status;
        }
    }

    public class SetAgreementReq
    {
        public System.Collections.Generic.List<long> Ids { get; set; }
        public string accountType { get; set; }
    }
}
