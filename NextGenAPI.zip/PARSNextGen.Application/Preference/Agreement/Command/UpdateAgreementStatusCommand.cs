﻿using MediatR;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Preference.Agreement.Command
{
    public class UpdateAgreementStatusCommand : IRequest<bool>
    {
        public UpdateAgreementStatusReq updateAgreementStatusReq { get; set; }
    }
    public class UpdateAgreementStatusCommandHandler : IRequestHandler<UpdateAgreementStatusCommand, bool>
    {
        private readonly IAgreementRepository _AgreementRepo;

        public UpdateAgreementStatusCommandHandler(IAgreementRepository AgreementRepo)
        {
            _AgreementRepo = AgreementRepo;
        }

        public async Task<bool> Handle(UpdateAgreementStatusCommand request, CancellationToken cancellationToken)
        {
            Agreements agreementObj = new Agreements();

            #region Agreement_Field

            agreementObj.id = request.updateAgreementStatusReq.id;
            agreementObj.agreement_status_id = request.updateAgreementStatusReq.agreement_status_id;
           // agreementObj.agreement_status_reason_id = request.updateAgreementStatusReq.agreement_status_reason_id;

            #endregion

            bool status = await _AgreementRepo.UpdateAgreementStatus(agreementObj);

            return status;
        }
    }
}

