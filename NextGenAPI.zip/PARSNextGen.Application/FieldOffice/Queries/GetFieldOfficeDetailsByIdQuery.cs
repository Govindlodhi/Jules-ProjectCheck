﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.FieldOffice.Queries
{
    public class GetFieldOfficeDetailsByIdQuery : IRequest<FieldOfficeDto>
    {
        public long id { get; set; }
    }
    public class GetFieldOfficeDetailsByIdQueryHandler : IRequestHandler<GetFieldOfficeDetailsByIdQuery, FieldOfficeDto>
    {
        private readonly ISqlContext _context;
        public GetFieldOfficeDetailsByIdQueryHandler(ISqlContext context)
        {
            _context = context;
        }
        public async Task<FieldOfficeDto> Handle(GetFieldOfficeDetailsByIdQuery request, CancellationToken cancellationToken)
        {
            FieldOfficeDto fieldOffice = new();

            using (var connection = _context.GetOpenConnection())
            {
                string query = $@"select fo.id , fo.name as fieldOffice, fo.division, fo.parent_business, fo.website, fo.number, fo.ns_location_id,
                                fo.main_phone, fo.other_phone, fo.fax, fo.email, fo.latitude, fo.longitude,fo.address_line_1, fo.address_line_2, 
                                fo.address_line_3, fo.address_line_4,fo.city, fo.state_id,s.name as state, fo.postal_code, fo.country_id , c.name as country, 
                                fo.is_active, fo.crm_id,fo.created_by, fo.created_on, fo.updated_by, fo.updated_on
			                    from field_office fo
			                    left join state s on fo.state_id= s.id
			                    left join country c on fo.country_id=c.id where fo.id={request.id}";
                fieldOffice = await connection.QuerySingleOrDefaultAsync<FieldOfficeDto>(query, commandType: CommandType.Text);
            }
            return fieldOffice;
        }
    }
}
