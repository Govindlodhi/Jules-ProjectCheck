﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.FieldOffice.Queries
{
    public class FieldOfficeDto
    {
        public long id { get; set; }
        public string fieldOffice { get; set; }// Will change fieldOffice = name
        public string division { get; set; }
        public long parent_business_id { get; set; }
        public string parent_business { get; set; }
        public string website { get; set; }
        public string number { get; set; }
        public string ns_location_id { get; set; }
        public string main_phone { get; set; }
        public string other_phone { get; set; }
        public string fax { get; set; }
        public string email { get; set; }
        public decimal latitude { get; set; }
        public decimal longitude { get; set; }
        public string address_line_1 { get; set; }
        public string address_line_2 { get; set; }
        public string address_line_3 { get; set; }
        public string address_line_4 { get; set; }
        public string city { get; set; }
        public long state_id { get; set; }
        public string state { get; set; }
        public string postal_code { get; set; }
        public long country_id { get; set; }
        public string country { get; set; }
        public bool is_active { get; set; }
        public Guid crm_id { get; set; }
        public string created_by { get; set; }
        public DateTime created_on { get; set; }
        public long updated_by { get; set; }
        public DateTime updated_on { get; set; }
    }
}
