﻿using MediatR;
using PARSNextGen.Application.ServiceRequest.Queries;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.FieldOffice.Queries
{
    public class FieldOfficeListQuery : IRequest<List<FieldOfficeDto>>
    {
    }
    public class FieldOfficeListQueryHandler : IRequestHandler<FieldOfficeListQuery, List<FieldOfficeDto>>
    {
        private readonly ISqlContext _dbCntx;

        public FieldOfficeListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<FieldOfficeDto>> Handle(FieldOfficeListQuery request, CancellationToken cancellationToken)
        {
            List<FieldOfficeDto> fieldOfficeList = null;

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select fos.id,fos.name as fieldOffice,fos.division,fos.parent_business parent_business_id,
                                fo.name parent_business,fos.website,fos.number, fos.ns_location_id,fos.main_phone,fos.other_phone,fos.fax,
                                fos.email,fos.latitude,fos.longitude,fos.address_line_1,fos.address_line_2,fos.address_line_3,fos.address_line_4,
                                fos.city,fos.state_id,fos.postal_code,fos.country_id,fos.is_active,fos.crm_id,CONCAT(ct.first_name,' ',ct.last_name) created_by,fos.created_on 
                                from field_office fos
                                left join field_office fo on fos.parent_business = fo.id
                                left join user_auth ua on fos.created_by = ua.id
                                left join contact ct on ua.contact_id = ct.id
                                where fos.is_active=1 order by fos.created_on desc;";
                fieldOfficeList = (List<FieldOfficeDto>)await connection.QueryAsyncWithRetry<FieldOfficeDto>(query, commandType: CommandType.Text);
            }
            return fieldOfficeList;
        }
    }
}
