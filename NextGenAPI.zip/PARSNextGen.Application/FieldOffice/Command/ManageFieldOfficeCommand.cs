﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.FieldOffice.Command
{
    public class ManageFieldOfficeCommand : IRequest<long>
    {
        public FieldOfficeReq officeReq { get; set; }
    }
    public class ManageFieldOfficeCommandHandler : IRequestHandler<ManageFieldOfficeCommand, long>
    {
        private readonly ISqlContext _sqlContext;
        private readonly ICurrentUserService _currentUserService;
        public ManageFieldOfficeCommandHandler(ISqlContext sqlContext, ICurrentUserService currentUserService)
        {
            _sqlContext = sqlContext;
            _currentUserService = currentUserService;
        }
        public async Task<long> Handle(ManageFieldOfficeCommand request, CancellationToken cancellationToken)
        {
            long result = 0;
            long duplicate_record_id = 0;

            using (var con = _sqlContext.GetOpenConnection())
            {
                if (request.officeReq.id == 0)
                {
                    var query = $@"select id from field_office where name = '{request.officeReq.name}' and is_active=1";
                    duplicate_record_id = await con.QueryFirstOrDefaultAsync<long>(query, commandType: CommandType.Text);
                }
                else
                {
                    var query = $@"select id from field_office where name = '{request.officeReq.name}' and id != {request.officeReq.id} and is_active=1";
                    duplicate_record_id = await con.QueryFirstOrDefaultAsync<long>(query, commandType: CommandType.Text);
                }

                if (duplicate_record_id > 0)
                    return -1;
                else
                {
                    var stored_procedure = @"sp_create_field_office";

                    var param = new DynamicParameters();
                    param.Add("@id", request.officeReq.id);
                    param.Add("@name", request.officeReq.name);
                    param.Add("@division", request.officeReq.division);
                    param.Add("@parent_business", request.officeReq.parent_business);
                    param.Add("@website", request.officeReq.website);
                    param.Add("@number", request.officeReq.number);
                    param.Add("@ns_location_id", request.officeReq.ns_location_id);
                    param.Add("@main_phone", request.officeReq.main_phone);
                    param.Add("@other_phone", request.officeReq.other_phone);
                    param.Add("@fax", request.officeReq.fax);
                    param.Add("@email", request.officeReq.email);
                    param.Add("@latitude", request.officeReq.latitude);
                    param.Add("@longitude", request.officeReq.longitude);
                    param.Add("@address_line_1", request.officeReq.address_line_1);
                    param.Add("@address_line_2", request.officeReq.address_line_2);
                    param.Add("@address_line_3", request.officeReq.address_line_3);
                    param.Add("@address_line_4", request.officeReq.address_line_4);
                    param.Add("@city", request.officeReq.city);
                    param.Add("@state_id", request.officeReq.state_id);
                    param.Add("@postal_code", request.officeReq.postal_code);
                    param.Add("@country_id", request.officeReq.country_id);
                    param.Add("@is_active", request.officeReq.is_active);
                    param.Add("@crm_id", request.officeReq.crm_id);
                    param.Add("@user_id", _currentUserService.LoggedInUserId);

                    result = await con.ExecuteScalarAsync<long>(stored_procedure, param, commandType: CommandType.StoredProcedure);

                }
            }

            return result;
        }
    }
}
