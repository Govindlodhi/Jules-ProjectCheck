﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.FieldOffice.Command
{
    public class ChangeFieldOfficeStatusCommand : IRequest<long>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class ChangeFieldOfficeStatusCommandHandler : IRequestHandler<ChangeFieldOfficeStatusCommand, long>
    {
        private readonly ISqlContext _sql;
        private readonly ICurrentUserService _currentUserService;
        public ChangeFieldOfficeStatusCommandHandler(ISqlContext sql, ICurrentUserService currentUserService)
        {
            _sql = sql;
            _currentUserService = currentUserService;
        }
        public async Task<long> Handle(ChangeFieldOfficeStatusCommand request, CancellationToken cancellationToken)
        {
            long result = 0;

            using (var con = _sql.GetOpenConnection())
            {
                var stored_procedure = @"sp_change_field_office_status";
                var param = new DynamicParameters();
                param.Add("@id", request.id);
                param.Add("@is_active", request.is_active);
                param.Add("@user_id", _currentUserService.LoggedInUserId);

                result = await con.ExecuteScalarAsync<long>(stored_procedure, param, commandType: CommandType.StoredProcedure);
            }
            return result;
        }
    }
}
