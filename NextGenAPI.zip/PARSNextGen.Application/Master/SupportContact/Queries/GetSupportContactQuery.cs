﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static PARSNextGen.Domain.Common.EnumTypes;

namespace PARSNextGen.Application.Master.SupportContact.Queries
{
    public class GetSupportContactQuery : IRequest<List<SupportContactListDto>>
    {
        public SupportContactListReq supportContactListReq { get; set; }
    }
    public class GetSupportContactQueryHandler : IRequestHandler<GetSupportContactQuery, List<SupportContactListDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetSupportContactQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<SupportContactListDto>> Handle(GetSupportContactQuery request, CancellationToken cancellationToken)
        {
            List<SupportContactListDto> supportContactList = new List<SupportContactListDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                if (request.supportContactListReq.accountType == 0)
                    return supportContactList;

                string whereAccountId = string.Empty;
                if (request.supportContactListReq.accountType == (long)AccountTypes.Account)
                {
                    if (request.supportContactListReq.fmcId != null && request.supportContactListReq.fleetId != null)
                        whereAccountId = " where (clientAccount.linked_account_id = @accountId or clientAccount.id=@accountId and sc.fmc_id = @fmcId )";
                    else if (request.supportContactListReq.fmcId == null && request.supportContactListReq.fleetId != null)
                        whereAccountId = " where ((clientAccount.linked_account_id = @accountId or clientAccount.id=@accountId) and sc.fmc_id is null)";
                }

                if (request.supportContactListReq.accountType == (long)AccountTypes.PARS)
                    whereAccountId = " where sc.fmc_id = @fmcId ";

                else if (request.supportContactListReq.accountType == (long)AccountTypes.FMC && request.supportContactListReq.fmcId != null)
                    whereAccountId = "where sc.fmc_id = @fmcId and sc.account_id is null ";

                else if (request.supportContactListReq.accountType == (long)AccountTypes.Fleet && request.supportContactListReq.fleetId != null)
                    whereAccountId = "where sc.fmc_id= @fmcId and sc.account_id = @accountId ";

                var dp = new DynamicParameters();
                dp.Add("@fmcId", request.supportContactListReq.fmcId);
                dp.Add("@accountId", request.supportContactListReq.fleetId);

                string query = @"SELECT  " +
                                         "sc.id " +
                                         ",sc.first_name," +
                                         "sc.last_name  " +
                                         ",sc.fmc_id  ,fmc.account_name  fmc_name" +
                                         ",CASE WHEN clientAccount.fleet_no IS NULL THEN clientAccount.account_name ELSE clientAccount.fleet_no +' | '+clientAccount.account_name END  fleet_name " +
                                         ",sc.phone_1  ,sc.phone_2 ,sc.organization_name ,sc.emails  ,sc.description  " +
                                         ",sc.address_line_1,sc.address_line_2,sc.address_line_3 " +
                                         ",sc.state_id,state.name state_name " +
                                         ",sc.country_id, country.name country_name " +
                                         ",sc.created_on  ,sc.is_active   " +
                                 ", STUFF((SELECT distinct ', ' + sct.name " +
                                 " FROM trns_accounts_support_contact_types t1 " +
                                 " INNER JOIN support_contact_type sct ON t1.support_contact_type_id = sct.id " +
                                 " WHERE sc.id = t1.support_contact_id " +
                                         " FOR XML PATH(''), TYPE " +
                                         " ).value('.', 'NVARCHAR(MAX)') ,1,2,'') contact_type" +
                                " FROM support_contact sc " +
                                " LEFT JOIN account fmc ON sc.fmc_id=fmc.id " +
                                " LEFT JOIN account clientAccount ON sc.account_id = clientAccount.id " +
                                " LEFT JOIN state ON sc.state_id = state.id " +
                                " LEFT JOIN country ON sc.country_id = country.id " + whereAccountId +
                                " ORDER BY created_on DESC";
                supportContactList = (List<SupportContactListDto>)await connection.QueryAsync<SupportContactListDto>(query, dp, commandType: CommandType.Text);
            }
            return supportContactList;
        }
    }
}
