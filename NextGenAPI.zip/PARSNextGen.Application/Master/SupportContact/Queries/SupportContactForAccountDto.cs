﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.SupportContact.Queries
{
    public class SupportContactForAccountDto
    {
        public long id { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string emails { get; set; }
        public string phone_1 { get; set; }
        public string support_contact_type { get; set; }

    }
}
