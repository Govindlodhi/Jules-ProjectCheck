﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Account.Accounts.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.SupportContact.Queries
{
    public class GetSupportContactMasterDataQuery : IRequest<SupportContactMasterDataDto>
    {
    }
    public class GetSupportContactMasterDataQueryHandler : IRequestHandler<GetSupportContactMasterDataQuery, SupportContactMasterDataDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetSupportContactMasterDataQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<SupportContactMasterDataDto> Handle(GetSupportContactMasterDataQuery request, CancellationToken cancellationToken)
        {
            SupportContactMasterDataDto supportContactMasterDataDto = new SupportContactMasterDataDto();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                dp.Add("@account_type_id", _currentUserService.AccountTypeId);
                dp.Add("@account_id", _currentUserService.AccountId);

                string queryFleet = "";
                string queryFMC = "";
                string querySupportContactType = @"select id, name from support_contact_type where is_active = 1 order by name;";
                string querystate = @"select s.id As id,s.name As name,s.country_id As country_id ,c.name as country_name  from state s inner join country c on s.country_id = c.id;";
                string queryCountry = @"select c.id,c.name from country c inner join state s on c.id = s.id;";
                if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.Fleet)
                    queryFleet = @"select id,account_name from account where id =" + _currentUserService.AccountId + " order by account_name;";
                else if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
                    queryFleet = @"select distinct id,account_name from account where fmc_id = " + _currentUserService.AccountId + " order by account_name;";
                else
                    queryFleet = @"select distinct id,account_name,account_type_id from account where account_type_id = " + (long)EnumTypes.AccountTypes.Account + " and linked_account_id is null  and parent_account_id is  null  order by account_name;";

                if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
                    queryFMC = @"select distinct id,account_name from account where id =" + _currentUserService.AccountId + " order by account_name;";
                else if (_currentUserService.AccountTypeId == (long)EnumTypes.AccountTypes.Fleet)
                    queryFMC = @"select distinct account.id,account.account_name from account inner join account Fmc on account.id= Fmc.fmc_id where fmc.linked_account_id =" + _currentUserService.AccountId + " order by account_name;";
                else
                    queryFMC = @"select distinct id,account_name, account_type_id from account where account_type_id = " + (long)EnumTypes.AccountTypes.FMC + "  order by account_name";


                string multiSQLQry = querySupportContactType + queryFleet + queryFMC;
                //First get  country list
                var states = (List<State>)await connection.QueryAsync<State>(queryCountry, null, null, 300, null);

                List<EntityReference> countryList = new List<EntityReference>();

                foreach (var item in states)
                {
                    EntityReference countryDM = new EntityReference();
                    countryDM.id = item.id;
                    countryDM.name = item.name;
                    countryList.Add(countryDM);
                }

                var states1 = (List<State>)await connection.QueryAsync<State>(querystate, null, null, 300, null);
                List<Country> Countries = new List<Country>();
                foreach (var countryItem in countryList)
                {
                    var countryDM = new Country();
                    var stateList = new List<State>();
                    foreach (var stateItem in states1)
                    {
                        if (countryItem.name == stateItem.country_name)
                        {
                            var stateDM = new State()
                            {
                                id = stateItem.id,
                                name = stateItem.name,
                                country_id = stateItem.country_id,
                                country_name = stateItem.country_name,
                            };
                            stateList.Add(stateDM);
                        }
                        countryDM.Country_Name = countryItem.name;
                        countryDM.Country_Id = countryItem.id;
                        countryDM.States = stateList;
                    }
                    Countries.Add(countryDM);
                }
                using (var multiResultSet = await connection.QueryMultipleAsync(multiSQLQry))
                {
                    supportContactMasterDataDto.support_contact_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    supportContactMasterDataDto.fleet = (List<EntityReferenceAccount>)await multiResultSet.ReadAsync<EntityReferenceAccount>();
                    supportContactMasterDataDto.fmc = (List<EntityReferenceAccount>)await multiResultSet.ReadAsync<EntityReferenceAccount>();
                    supportContactMasterDataDto.country = Countries;
                }
            }
            return supportContactMasterDataDto;
        }
    }
}
