﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.SupportContact.Queries
{
    public class SupportContactListReq
    {
        public long accountType { get; set; }
        public long? fmcId { get; set; }
        public long? fleetId { get; set; }
    }
}
