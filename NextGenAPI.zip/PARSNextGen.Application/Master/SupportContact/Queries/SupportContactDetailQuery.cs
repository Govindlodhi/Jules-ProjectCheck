﻿using System.Data;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using Dapper;
using PARSNextGen.Application.Service;
using System.Collections.Generic;
using System.Linq;

namespace PARSNextGen.Application.Master.SupportContact.Queries
{
    public class SupportContactDetailQuery : IRequest<SupportContactDetailDto>
    {
        public long id { get; set; }
    }
    public class SupportContactDetailQueryHandler : IRequestHandler<SupportContactDetailQuery, SupportContactDetailDto>
    {
        private readonly ISqlContext _dbCntx;
        public SupportContactDetailQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<SupportContactDetailDto> Handle(SupportContactDetailQuery request, CancellationToken cancellationToken)
        {
            SupportContactDetailDto supportContactDetail = null;
            DynamicParameters dp = new DynamicParameters();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"
            SELECT 
                sc.id, sc.first_name,sc.last_name,concat(sc.first_name,' ',sc.last_name) full_name,sc.fmc_id,fmc.account_name AS fmc_name,sc.account_id,clientAccount.account_name AS fleet_name,
                sc.phone_1,sc.phone_2,sc.emails,sc.alternate_email,sc.description,sc.organization_name,sc.address_line_1,sc.address_line_2,
                sc.address_line_3,sc.state_id,state.name AS state_name,sc.city,sc.zip_code,sc.country_id,country.name AS country_name,sc.created_on,sc.is_active
            FROM support_contact sc
            LEFT JOIN account fmc ON sc.fmc_id = fmc.id
            LEFT JOIN account clientAccount ON sc.account_id = clientAccount.id
            LEFT JOIN state ON sc.state_id = state.id
            LEFT JOIN country ON sc.country_id = country.id
            WHERE sc.id = @id
            ORDER BY sc.created_on";

                dp.Add("@id", request.id);
                supportContactDetail = await connection.QueryFirstOrDefaultAsync<SupportContactDetailDto>(query, dp, commandType: CommandType.Text);

                if (supportContactDetail != null)
                {
                    // Define the query to get support contact types
                    string queryContactTypes = @"
                                                 SELECT 
                                                     sc.support_contact_type_id,sct.name AS support_contact_type
                                                 FROM trns_accounts_support_contact_types sc
                                                 INNER JOIN support_contact_type sct ON sc.support_contact_type_id = sct.id
                                                 WHERE sc.support_contact_id = @id";

                    // Execute the query to get the support contact types
                    dp = new DynamicParameters();
                    dp.Add("@id", request.id);
                    var contactTypes = (List<AccountSupportContactTypes>)await connection.QueryAsync<AccountSupportContactTypes>(queryContactTypes, dp, commandType: CommandType.Text);
                    supportContactDetail.supportContactType = contactTypes;
                }
            }
            return supportContactDetail;
        }
    }
}
