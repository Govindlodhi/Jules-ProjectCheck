﻿using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.SupportContact.Queries
{
    public class SupportContactMasterDataDto
    {
       public List<EntityReference> support_contact_type { get; set; }
        public List<EntityReferenceAccount> fleet { get; set; }
        public List<EntityReferenceAccount> fmc { get; set; }
        public List<Country> country { get; set; }
    }
}
