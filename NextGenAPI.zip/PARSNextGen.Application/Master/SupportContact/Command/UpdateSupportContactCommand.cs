﻿
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using PARSNextGen.Domain.Interface;
using PARSNextGen.Application.SQL;
using FluentValidation;
using Dapper;
using PARSNextGen.Application.Service;
using System.Data;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Entities;
namespace PARSNextGen.Application.Master.SupportContact.Command
{
  
    public class UpdateSupportContactCommand : IRequest<bool>
    {
        public UpdateSupportContactReq updateSupportContactReq { get; set; }
    }

    public class UpdateSupportContactCommandHandler : IRequestHandler<UpdateSupportContactCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IServiceMasterRepository _masterRepo;
        private readonly ICurrentUserService _currentUserService;

        public UpdateSupportContactCommandHandler(IServiceMasterRepository masterRepo, ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _masterRepo = masterRepo;
            _currentUserService = currentUserService;
        }

        public async Task<bool> Handle(UpdateSupportContactCommand request, CancellationToken cancellationToken)
        {
            DynamicParameters parameters = new DynamicParameters();
            support_contact supportContact = new support_contact();
            supportContact.id = request.updateSupportContactReq.id;
            supportContact.first_name = request.updateSupportContactReq.first_name;
            supportContact.last_name = request.updateSupportContactReq.last_name;
            supportContact.fmc_id = request.updateSupportContactReq.fmc_id;
            supportContact.account_id = request.updateSupportContactReq.account_id;
            supportContact.phone_1 = request.updateSupportContactReq.phone_1;
            supportContact.phone_2 = request.updateSupportContactReq.phone_2;
            supportContact.emails = request.updateSupportContactReq.emails;
            supportContact.alternate_email = request.updateSupportContactReq.alternate_email;
            supportContact.organization_name = request.updateSupportContactReq.organization_name;
            supportContact.description = request.updateSupportContactReq.description;
            supportContact.address_line_1 = request.updateSupportContactReq.address_line_1;
            supportContact.address_line_2 = request.updateSupportContactReq.address_line_2;
            supportContact.address_line_3 = request.updateSupportContactReq.address_line_3;
            supportContact.city = request.updateSupportContactReq.city;
            supportContact.state_id = request.updateSupportContactReq.state_id;
            supportContact.zip_code = request.updateSupportContactReq.zip_code;
            supportContact.country_id = request.updateSupportContactReq.country_id;
            supportContact.support_contact_types = string.Join(",", request.updateSupportContactReq.support_contact_types.ToArray());
            bool flag = await _masterRepo.UpdateSupportContact(supportContact);
            return flag;
        }


    }
}
