﻿
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using PARSNextGen.Domain.Interface;
using PARSNextGen.Application.SQL;
using FluentValidation;
using Dapper;
using PARSNextGen.Application.Service;
using System.Data;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Entities;

namespace PARSNextGen.Application.Master.SupportContact.Command
{
   

    public class CreateSupportContactCommand : IRequest<bool>
    {
       public CreateSupportContactReq createSupportContactReq { get; set; }
    }

    public class CreateSupportContactCommandHandler : IRequestHandler<CreateSupportContactCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IServiceMasterRepository _masterRepo;
        private readonly ICurrentUserService _currentUserService;

        public CreateSupportContactCommandHandler(IServiceMasterRepository masterRepo, ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _masterRepo = masterRepo;
            _currentUserService = currentUserService;
        }

        public async Task<bool> Handle(CreateSupportContactCommand request, CancellationToken cancellationToken)
        {
           
             DynamicParameters parameters = new DynamicParameters();
            support_contact supportContact  =  new support_contact();
            supportContact.first_name =request.createSupportContactReq.first_name;
            supportContact.last_name = request.createSupportContactReq.last_name;
            supportContact.fmc_id = request.createSupportContactReq.fmc_id;
            supportContact.account_id = request.createSupportContactReq.account_id;
            supportContact.phone_1 = request.createSupportContactReq.phone_1;
            supportContact.phone_2 = request.createSupportContactReq.phone_2;
            supportContact.emails = request.createSupportContactReq.emails;
            supportContact.alternate_email = request.createSupportContactReq.alternate_email;
            supportContact.organization_name = request.createSupportContactReq.organization_name;
            supportContact.description = request.createSupportContactReq.description;
            supportContact.address_line_1 = request.createSupportContactReq.address_line_1;
            supportContact.address_line_2 = request.createSupportContactReq.address_line_2;
            supportContact.address_line_3 = request.createSupportContactReq.address_line_3;
            supportContact.city = request.createSupportContactReq.city;
            supportContact.state_id = request.createSupportContactReq.state_id;
            supportContact.zip_code = request.createSupportContactReq.zip_code;
            supportContact.country_id = request.createSupportContactReq.country_id;
            supportContact.support_contact_types =  string.Join(",", request.createSupportContactReq.support_contact_types.ToArray()); 

            bool role = await _masterRepo.CreateSupportContact(supportContact);
            return role;
        }


    }
}
