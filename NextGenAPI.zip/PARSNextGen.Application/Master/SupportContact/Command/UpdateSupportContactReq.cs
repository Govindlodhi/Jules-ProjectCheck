﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.SupportContact.Command
{
    public class UpdateSupportContactReq
    {
        public long? id { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public long? fmc_id { get; set; }
        public long? account_id { get; set; }
        public string phone_1 { get; set; }
        public string phone_2 { get; set; }
        public string emails { get; set; }
        public string alternate_email { get; set; }
        public string organization_name { get; set; }
        public string description { get; set; }
        public string address_line_1 { get; set; }
        public string address_line_2 { get; set; }
        public string address_line_3 { get; set; }
        public string city { get; set; }
        public long? state_id { get; set; }
        public string zip_code { get; set; }
        public long? country_id { get; set; }

        public List<long> support_contact_types { get; set; }
    }
}
