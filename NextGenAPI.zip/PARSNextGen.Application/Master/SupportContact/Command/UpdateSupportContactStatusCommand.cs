﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using PARSNextGen.Domain.Interface;
using PARSNextGen.Application.SQL;
using FluentValidation;
using Dapper;
using PARSNextGen.Application.Service;
using System.Data;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Entities;

namespace PARSNextGen.Application.Master.SupportContact.Command
{
    public class UpdateSupportContactStatusCommand : IRequest<bool>
    {
        public UpdateSupportContactStatusReq updateSupportContactStatusReq { get; set; }
    }
    public class UpdateSupportContactStatusCommandHandler : IRequestHandler<UpdateSupportContactStatusCommand, bool>
    {
        private readonly IServiceMasterRepository _masterRepo;
        public UpdateSupportContactStatusCommandHandler(IServiceMasterRepository masterRepo)
        {
            _masterRepo = masterRepo;
        }
        public async Task<bool> Handle(UpdateSupportContactStatusCommand request, CancellationToken cancellationToken)
        {
            bool flage = await _masterRepo.UpdateSupportContactStatus(request.updateSupportContactStatusReq.id, request.updateSupportContactStatusReq.is_active);
            return flage;
        }
    }
}
