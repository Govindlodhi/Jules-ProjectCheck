﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Category.Command
{
    public class UpdateCategoryStatusReq
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
}
