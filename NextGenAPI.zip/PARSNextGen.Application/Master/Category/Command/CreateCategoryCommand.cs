﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Master.AccountType.Command;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Category.Command
{
    public class CreateCategoryCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateCategoryReq createCategory { get; set; }
    }
    public class CreateCategoryCommandHandler : IRequestHandler<CreateCategoryCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IMasterRepository _masterRepo;
        public CreateCategoryCommandHandler(ISqlContext dbCntx, IMasterRepository masterRepository)
        {
            _dbCntx = dbCntx;
            _masterRepo = masterRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateCategoryCommand request, CancellationToken cancellationToken)
        {
            Tuple<bool, bool> responseT = null;
            Categories ctgs = new Categories
            {
                name = request.createCategory.name,
                description = request.createCategory.description,
                is_active = request.createCategory.is_active
            };

            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                string query = @"select id from category where name =@name";
                dp.Add("@name", request.createCategory.name);
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);
                isDulicateData = recordExists > 0;
            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _masterRepo.CreateCategory(ctgs);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }
        }
    }
}
