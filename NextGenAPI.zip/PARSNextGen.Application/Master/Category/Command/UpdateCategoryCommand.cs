﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Master.AccountType.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Category.Command
{
    public class UpdateCategoryCommand : IRequest<bool>
    {
        public UpdateCategoryReq Req { get; set; }
    }
    public class UpdateCategoryCommandHandler : IRequestHandler<UpdateCategoryCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IMasterRepository _masterRepo;

        public UpdateCategoryCommandHandler(ISqlContext dbCntx, IMasterRepository masterRepo)
        {
            _dbCntx = dbCntx;
            _masterRepo = masterRepo;
        }
        public async Task<bool> Handle(UpdateCategoryCommand request, CancellationToken cancellationToken)
        {
            bool result = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var dp = new DynamicParameters();
                var querycolumns = @"SELECT id,name,description 
                                     FROM category 
                                     WHERE name=@name AND id!=@id";
                dp.Add("@id", request.Req.id);
                dp.Add("@name", request.Req.name);
                int output = await connection.ExecuteScalarAsync<int>(querycolumns, dp, commandType: CommandType.Text);
                if (output > 0)
                    result = false;
                else
                    result = await _masterRepo.UpdateCategory(request.Req.id, request.Req.name, request.Req.description);

                return result;
            }
        }
    }
}
