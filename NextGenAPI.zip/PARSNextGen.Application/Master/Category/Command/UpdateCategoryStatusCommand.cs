﻿using AutoMapper;
using MediatR;
using PARSNextGen.Application.Master.AccountType.Command;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Category.Command
{
    public class UpdateCategoryStatusCommand : IRequest<bool>
    {
        public UpdateCategoryStatusReq UpdateCategory { get; set; }
    }
    public class UpdateCategoryStatusCommandHandler : IRequestHandler<UpdateCategoryStatusCommand, bool>
    {
        private readonly IMasterRepository _masterRepo;
        public UpdateCategoryStatusCommandHandler(IMasterRepository masterRepo)
        {
            _masterRepo = masterRepo;
        }
        public async Task<bool> Handle(UpdateCategoryStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _masterRepo.UpdateCategoryStatus(request.UpdateCategory.id, request.UpdateCategory.is_active);
            return result;
        }
    }
}
