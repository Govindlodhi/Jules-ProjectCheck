﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Master.Queue.Query;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Category.Query
{
    public class GetCategoryByIdQuery : IRequest<GetCategoryByIdDto>
    {
        public long id { get; set; }
    }
    public class GetCategoryByIdQueryHandler : IRequestHandler<GetCategoryByIdQuery, GetCategoryByIdDto>
    {
        private readonly ISqlContext _dbCntx;
        public GetCategoryByIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
        }
        public async Task<GetCategoryByIdDto> Handle(GetCategoryByIdQuery request, CancellationToken cancellationToken)
        {
            GetCategoryByIdDto category = new GetCategoryByIdDto();
           
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var dp = new DynamicParameters();
                string query = @"SELECT c.id as id,c.name as name,c.description as description,c.is_active as is_active 
                                 FROM category AS c 
                                 WHERE c.id =@id";
                dp.Add("@id", request.id);
                category = await connection.QueryFirstOrDefaultAsync<GetCategoryByIdDto>(query, dp, commandType: CommandType.Text);
            }
            return category;
        }
    }
}