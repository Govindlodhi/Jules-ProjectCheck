﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Category.Query
{
    public class GetAllCategoryQuery : IRequest<List<GetAllCategoryDto>>
    {
    }
    public class GetAllCategoryQueryHandler : IRequestHandler<GetAllCategoryQuery, List<GetAllCategoryDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetAllCategoryQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<GetAllCategoryDto>> Handle(GetAllCategoryQuery request, CancellationToken cancellationToken)
        {
            List<GetAllCategoryDto> category = new List<GetAllCategoryDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"SELECT c.id as id,c.name as name,c.description as description,c.is_active as is_active 
                                 FROM category as c";
                category = (List<GetAllCategoryDto>)await connection.QueryAsyncWithRetry<GetAllCategoryDto>(query, commandType: CommandType.Text);
            }
            return category;
        }
    }
}
