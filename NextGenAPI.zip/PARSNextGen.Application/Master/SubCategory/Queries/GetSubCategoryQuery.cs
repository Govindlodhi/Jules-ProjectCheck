﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.SubCategory.Queries
{
    public class GetSubCategoryQuery : IRequest<List<SubCategoryDto>>
    {
        public long category_id { get; set; }
    }
    public class GetSubCategoryQueryHandler : IRequestHandler<GetSubCategoryQuery, List<SubCategoryDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetSubCategoryQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<SubCategoryDto>> Handle(GetSubCategoryQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            List<SubCategoryDto> statedata = new List<SubCategoryDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string StateList = @"select id,name from sub_category  where is_active = 1 and category_id=@categoryId order by name asc";
                dp.Add("@categoryId", request.category_id);
                statedata = (List<SubCategoryDto>)await connection.QueryAsync<SubCategoryDto>(StateList, dp, null, commandType: CommandType.Text);
            }
            return statedata;
        }
    }
}
