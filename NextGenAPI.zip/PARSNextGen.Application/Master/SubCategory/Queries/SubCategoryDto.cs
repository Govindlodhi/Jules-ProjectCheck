﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.SubCategory.Queries
{
    public class SubCategoryDto
    {
        public long id { get; set; }
        public string name { get; set; }
    }
}
