﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Master.Category.Query;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.DocumentType.Query
{
    public class GetDocumentTypeQuery : IRequest<GetDocumentTypeDtos>
    {
        public long id { get; set; }
    }
    public class GetDocumentTypeQueryHandler : IRequestHandler<GetDocumentTypeQuery, GetDocumentTypeDtos>
    {
        private readonly ISqlContext _dbCntx;
        public GetDocumentTypeQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
        }
        public async Task<GetDocumentTypeDtos> Handle(GetDocumentTypeQuery request, CancellationToken cancellationToken)
        {
            GetDocumentTypeDtos result = new GetDocumentTypeDtos();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var dp = new DynamicParameters();
                string query = @"SELECT dt.id as id,dt.name as name,dt.description as description,dt.is_active as is_active
                                 FROM document_type AS dt
                                 WHERE id =@id";
                dp.Add("@id", request.id);
                result = await connection.QueryFirstOrDefaultAsync<GetDocumentTypeDtos>(query, dp, commandType: CommandType.Text);
            }
            return result;
        }
    }
}
