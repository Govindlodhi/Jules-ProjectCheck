﻿using MediatR;
using PARSNextGen.Application.Master.Category.Query;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.DocumentType.Query
{
    public class GetAllDocumentTypeQuery : IRequest<List<GetAllDocumentTypeDto>>
    {
    }
    public class GetAllDocumentTypeQueryHandler : IRequestHandler<GetAllDocumentTypeQuery, List<GetAllDocumentTypeDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetAllDocumentTypeQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<GetAllDocumentTypeDto>> Handle(GetAllDocumentTypeQuery request, CancellationToken cancellationToken)
        {
            List<GetAllDocumentTypeDto> docType = new List<GetAllDocumentTypeDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"SELECT dt.id as id,dt.name as name,dt.description as description,dt.is_active as is_active
                                 FROM document_type AS dt";
                docType = (List<GetAllDocumentTypeDto>)await connection.QueryAsyncWithRetry<GetAllDocumentTypeDto>(query, commandType: CommandType.Text);
            }
            return docType;
        }
    }
}
