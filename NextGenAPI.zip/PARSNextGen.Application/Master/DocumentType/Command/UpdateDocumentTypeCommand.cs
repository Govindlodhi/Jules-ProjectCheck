﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Master.Category.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.DocumentType.Command
{
    public class UpdateDocumentTypeCommand : IRequest<bool>
    {
        public UpdateDocumentTypeReq typeReq { get; set; }
    }
    public class UpdateDocumentTypeCommandHandler : IRequestHandler<UpdateDocumentTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IMasterRepository _masterRepo;
        public UpdateDocumentTypeCommandHandler(ISqlContext dbCntx, IMasterRepository masterRepo)
        {
            _dbCntx = dbCntx;
            _masterRepo = masterRepo;
        }
        public async Task<bool> Handle(UpdateDocumentTypeCommand request, CancellationToken cancellationToken)
        {
            bool result = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"SELECT id,name,description FROM document_type WHERE name=@name and id!=@id";
                var dp = new DynamicParameters();
                dp.Add("@id", request.typeReq.id);
                dp.Add("@name", request.typeReq.name);
                int output = await connection.ExecuteScalarAsync<int>(querycolumns, dp, commandType: CommandType.Text);
                if (output > 0)
                    result = false;
                else
                    result = await _masterRepo.UpdateDocumentType(request.typeReq.id, request.typeReq.name, request.typeReq.description);

                return result;
            }
        }
    }
}
