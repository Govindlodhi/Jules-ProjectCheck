﻿using AutoMapper;
using MediatR;
using PARSNextGen.Application.Master.Category.Command;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.DocumentType.Command
{
    public class UpdateDocumentTypeStatusCommand : IRequest<bool>
    {
        public UpdateDocumentTypeStatusReq statusReq { get; set; }
    }
    public class UpdateDocumentTypeStatusCommandHandler : IRequestHandler<UpdateDocumentTypeStatusCommand, bool>
    {
        private readonly IMasterRepository _masterRepo;
        public UpdateDocumentTypeStatusCommandHandler(IMasterRepository masterRepo)
        {
            _masterRepo = masterRepo;
        }
        public async Task<bool> Handle(UpdateDocumentTypeStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _masterRepo.UpdateDocumentTypeStatus(request.statusReq.id, request.statusReq.is_active);
            return result;
        }
    }
}
