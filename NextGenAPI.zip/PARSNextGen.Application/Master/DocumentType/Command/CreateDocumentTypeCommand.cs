﻿using Dapper;
using MediatR;
using Nancy.Validation;
using PARSNextGen.Application.Master.AccountType.Command;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.DocumentType.Command
{
    public class CreateDocumentTypeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateDocumentTypeReq createDocTypeReq { get; set; }
    }
    public class CreateDocumentTypeCommandHandler : IRequestHandler<CreateDocumentTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IMasterRepository _masterRepo;
        public CreateDocumentTypeCommandHandler(ISqlContext dbCntx, IMasterRepository masterRepository)
        {
            _dbCntx = dbCntx;
            _masterRepo = masterRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateDocumentTypeCommand request, CancellationToken cancellationToken)
        {
            bool isDulicateData = false;
            Tuple<bool, bool> responseT = null;

            DocType docType = new DocType
            {
                name = request.createDocTypeReq.name,
                description = request.createDocTypeReq.description,
                is_active = request.createDocTypeReq.is_active,
            };
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var dp = new DynamicParameters();
                string query = @"SELECT id FROM document_type WHERE name =@name";
                dp.Add("@name", request.createDocTypeReq.name);
                int queueExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);
                isDulicateData = queueExists > 0;
            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _masterRepo.CreateDocumentType(docType);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }
        }
    }
}
