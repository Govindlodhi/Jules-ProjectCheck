﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.StateMaster.Queries
{
    public class GetStateQuery : IRequest<List<stateDto>>
    {
        public long country_id { get; set; }
    }
    public class GetStateQueryHandler : IRequestHandler<GetStateQuery, List<stateDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetStateQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<stateDto>> Handle(GetStateQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            List<stateDto> statedata = new List<stateDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string StateList = @"select id,name,code as state_code from state where country_id = @countryId";
                dp.Add("@countryId", request.country_id);
                statedata = (List<stateDto>)await connection.QueryAsync<stateDto>(StateList, dp, null, commandType: CommandType.Text);
            }
            return statedata;
        }
    }
}
