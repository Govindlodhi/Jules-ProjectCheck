﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.StateMaster.Queries
{
    public class stateDto
    {
        public long id { get; set; }
        public string name { get; set; }
        public string state_code { get; set; }
    }
}
