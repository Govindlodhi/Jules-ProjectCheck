﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Service.Command
{
    public class UpdateServiceReq
    {
        public long id { get; set; }
        public string name { get; set; }
        public long? category_id { get; set; }
        public long? sub_category_id { get; set; }
        public long? rate_type_id { get; set; }
        public string net_suite_id { get; set; }
        public bool have_more_info { get; set; }
        public string description { get; set; }
    }
}
