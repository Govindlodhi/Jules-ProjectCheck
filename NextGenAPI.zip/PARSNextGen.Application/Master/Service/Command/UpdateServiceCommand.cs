﻿using Amazon.Runtime.Internal;
using Dapper;
using MediatR;
using PARSNextGen.Application.Preference.PriceList.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Service.Command
{
    public class UpdateServiceCommand : IRequest<bool>
    {
        public UpdateServiceReq updateServiceReq { get; set; }
    }
    public class UpdateServiceListCommandHandler : IRequestHandler<UpdateServiceCommand, bool>
    {
        private readonly IServiceMasterRepository _serviceListRepo;
        private readonly ISqlContext _dbCntx;
        public UpdateServiceListCommandHandler(IServiceMasterRepository serviceListRepo, ISqlContext dbCntx)
        {
            _serviceListRepo = serviceListRepo;
            _dbCntx = dbCntx;
        }

        public async Task<bool> Handle(UpdateServiceCommand request, CancellationToken cancellationToken)
        {
            service_master serviceMaster = new service_master();
            DynamicParameters parameters = new DynamicParameters();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description,is_active from service where name=@name AND id <> @id ";
                parameters.Add("@id", request.updateServiceReq.id);
                parameters.Add("@name", request.updateServiceReq.name);
                serviceMaster = await connection.QueryFirstOrDefaultAsyncWithRetry<service_master>(querycolumns, parameters, commandType: CommandType.Text);
            }
            if (serviceMaster != null)
                throw new Exception("PARS_SERVICE_EXIST_WITH_SAME_NAME");
            else
            {
                service_master serviceListObj = new service_master();

                #region ServiceList_Field
                serviceListObj.id = request.updateServiceReq.id;
                serviceListObj.name = request.updateServiceReq.name;
                serviceListObj.category_id = request.updateServiceReq.category_id;
                serviceListObj.sub_category_id = request.updateServiceReq.sub_category_id;
                serviceListObj.rate_type_id = request.updateServiceReq.rate_type_id;
                serviceListObj.net_suite_id = request.updateServiceReq.net_suite_id;
                serviceListObj.have_more_info = request.updateServiceReq.have_more_info;
                serviceListObj.description = request.updateServiceReq.description;
                #endregion

                bool status = await _serviceListRepo.UpdateService(serviceListObj);
                return status;
            }
        }
    }
}
