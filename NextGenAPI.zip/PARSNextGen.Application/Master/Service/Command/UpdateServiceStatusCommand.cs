﻿using MediatR;
using PARSNextGen.Application.Master.Roles.Command.UpdateRoleStatus;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Service.Command
{
    public class UpdateServiceStatusCommand : IRequest<bool>
    {
        public long service_id { get; set; }
        public bool service_status { get; set; }
    }
    public class UpdateServiceStatusCommandHandler : IRequestHandler<UpdateServiceStatusCommand, bool>
    {
        private readonly IServiceMasterRepository _serviceRepository;
        public UpdateServiceStatusCommandHandler(IServiceMasterRepository serviceRepository)
        {
            _serviceRepository = serviceRepository;
        }
        public async Task<bool> Handle(UpdateServiceStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _serviceRepository.UpdateServiceStatus(request.service_id, request.service_status);
            return result;
        }
    }
}
