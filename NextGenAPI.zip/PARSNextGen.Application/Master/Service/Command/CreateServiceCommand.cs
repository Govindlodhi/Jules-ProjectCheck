﻿using Amazon.Runtime.Internal;
using Dapper;
using MediatR;
using PARSNextGen.Application.Preference.PriceList.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Service.Command
{
    public class CreateServiceCommand : IRequest<bool>
    {
        public CreateServiceReq createServiceReq { get; set; }
    }
    public class CreateServiceListCommandHandler : IRequestHandler<CreateServiceCommand, bool>
    {
        private readonly IServiceMasterRepository _serviceListRepository;
        private readonly ISqlContext _dbCntx;
        public CreateServiceListCommandHandler(IServiceMasterRepository serviceListRepository, ISqlContext dbCntx)
        {
            _serviceListRepository = serviceListRepository;
            _dbCntx = dbCntx;
        }

        public async Task<bool> Handle(CreateServiceCommand request, CancellationToken cancellationToken)
        {
            service_master serviceDetails = new service_master();
            DynamicParameters parameters = new DynamicParameters();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description,is_active from service where name=@name";
                parameters.Add("@name", request.createServiceReq.name);
                serviceDetails = await connection.QueryFirstOrDefaultAsyncWithRetry<service_master>(querycolumns, parameters, commandType: CommandType.Text);
            }

            if (serviceDetails != null)
                return false;
            else
            {
                service_master serviceListObj = new service_master();

                #region ServiceList_Field

                serviceListObj.name = request.createServiceReq.name;
                serviceListObj.category_id = request.createServiceReq.category_id;
                serviceListObj.sub_category_id = request.createServiceReq.sub_category_id;
                serviceListObj.rate_type_id = request.createServiceReq.rate_type_id;
                serviceListObj.net_suite_id = request.createServiceReq.net_suite_id;
                serviceListObj.have_more_info = (bool)request.createServiceReq.have_more_info;
                serviceListObj.description = request.createServiceReq.description;

                #endregion

                bool status = await _serviceListRepository.CreateService(serviceListObj);
                return status;
            }
        }
    }
}
