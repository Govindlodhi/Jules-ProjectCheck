﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Service.Queries
{
    public class GetServiceByIdQuery : IRequest<ServiceDto>
    {
        public long id { get; set; }
    }
    public class GetServiceByIdQueryHandler : IRequestHandler<GetServiceByIdQuery, ServiceDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetServiceByIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }
        public async Task<ServiceDto> Handle(GetServiceByIdQuery request, CancellationToken cancellationToken)
        {
            ServiceDto services = new ServiceDto();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = $@"SELECT
                                     sv.id as service_id ,sv.name as service,sv.category_id,ct.name as category,sv.sub_category_id,st.name as sub_category ,
                                     sv. rate_type_id,rt.name as rate_type,sv.net_suite_id,sv.have_more_info , sv.description, sv.is_active as status, sv.average_cost
                                 FROM service sv 
                                 LEFT JOIN category ct ON ct.id = sv.category_id
                                 LEFT JOIN sub_category st ON st.id = sv.sub_category_id
                                 LEFT JOIN rate_type rt ON rt.id = sv.rate_type_id
                                 WHERE sv.id = @id";
                services = await connection.QueryFirstOrDefaultAsync<ServiceDto>(query, new { request.id }, commandType: CommandType.Text);
            }
            return services;
        }
    }
}
