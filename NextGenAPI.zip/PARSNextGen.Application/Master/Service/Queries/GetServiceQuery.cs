﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Service.Queries
{
    public class GetServiceQuery : IRequest<List<ServiceDto>>
    {
    }
    public class GetServiceQueryHandler : IRequestHandler<GetServiceQuery, List<ServiceDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetServiceQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<ServiceDto>> Handle(GetServiceQuery request, CancellationToken cancellationToken)
        {
            List<ServiceDto> services = new List<ServiceDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"SELECT
                                     sv.id as service_id ,sv.name as service,sv.category_id,ct.name as category,sv.sub_category_id,st.name as sub_category ,
                                     sv. rate_type_id,rt.name as rate_type, sv.description,sv.have_more_info, sv.is_active as status, sv.average_cost
                                FROM service sv
                                LEFT JOIN category ct ON ct.id = sv.category_id
                                LEFT JOIN sub_category st ON st.id = sv.sub_category_id
                                LEFT JOIN rate_type rt ON rt.id = sv.rate_type_id 
                                ORDER BY service";
                services = (List<ServiceDto>)await connection.QueryAsync<ServiceDto>(query, null, commandType: CommandType.Text);
            }
            return services;
        }
    }
}

