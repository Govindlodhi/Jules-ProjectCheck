﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Account.Accounts.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Service.Queries
{
    public class GetServiceMasterQuery : IRequest<ServiceMasterDto>
    {
    }
    public class GetServiceMasterQueryHandler : IRequestHandler<GetServiceMasterQuery, ServiceMasterDto>
    {
        private readonly ISqlContext _dbCntx;
        public GetServiceMasterQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<ServiceMasterDto> Handle(GetServiceMasterQuery request, CancellationToken cancellationToken)
        {
            ServiceMasterDto serviceRelatedMasterdata = new ServiceMasterDto();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string queryCategorytype = @"select id, name from category where is_active = 1";
                string querySubCategorytype = @"select id, name from sub_category where is_active = 1";
                string queryRateType = @"select id, name from rate_type where is_active = 1 and is_applicable_for_default=1";

                string multiSQLQry = queryCategorytype + querySubCategorytype + queryRateType;

                using (var multiResultSet = await connection.QueryMultipleAsync(multiSQLQry))
                {
                    serviceRelatedMasterdata.category_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    serviceRelatedMasterdata.sub_category_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                    serviceRelatedMasterdata.rate_type = (List<EntityReference>)await multiResultSet.ReadAsync<EntityReference>();
                }
            }
            return serviceRelatedMasterdata;
        }
    }
}
