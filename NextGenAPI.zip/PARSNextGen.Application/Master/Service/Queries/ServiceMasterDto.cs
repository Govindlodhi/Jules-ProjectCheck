﻿using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Service.Queries
{
    public class ServiceMasterDto
    {
        public List<EntityReference> category_type { get; set; }
        public List<EntityReference> sub_category_type { get; set; }
        public List<EntityReference> rate_type { get; set; }
    }
}
