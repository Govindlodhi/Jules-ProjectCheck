﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Service.Queries
{
    public class ServiceDto
    {
        public long service_id { get; set; }
        public string service { get; set; }
        public long category_id { get; set; }
        public string category { get; set; }
        public long sub_category_id { get; set; }
        public string sub_category { get; set; }
        public long rate_type_id { get; set; }
        public string rate_type { get; set; }
        public string net_suite_id { get; set; }
        public bool have_more_info { get; set; }
        public decimal average_cost { get; set; }
        public string description { get; set; }
        public bool status { get; set; }
    }
}
