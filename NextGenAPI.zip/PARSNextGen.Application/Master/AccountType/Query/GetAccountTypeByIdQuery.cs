﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AccountType.Query
{
    public class GetAccountTypeByIdQuery : IRequest<GetAccountTypeByIdDto>
    {
        public long id { get; set; }
    }
    public class GetAccountTypeByIdQueryHandler : IRequestHandler<GetAccountTypeByIdQuery, GetAccountTypeByIdDto>
    {
        private readonly ISqlContext _dbCntx;
        public GetAccountTypeByIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
        }
        public async Task<GetAccountTypeByIdDto> Handle(GetAccountTypeByIdQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            GetAccountTypeByIdDto result = new GetAccountTypeByIdDto();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"SELECT at.id as id,at.name as name,at.description as description,at.is_active as is_active
                                 FROM account_type AS at 
                                 WHERE id=@id";
                dp.Add("@id", request.id);
                result = await connection.QueryFirstOrDefaultAsync<GetAccountTypeByIdDto>(query, dp, commandType: CommandType.Text);
            }
            return result;
        }
    }
}
