﻿using MediatR;
using PARSNextGen.Application.Master.Queue.Query;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AccountType.Query
{
    public class GetAllAccountTypeQuery : IRequest<List<GetAllAccountTypeDto>>
    {
    }
    public class GetAllAccountTypeQueryHandler : IRequestHandler<GetAllAccountTypeQuery, List<GetAllAccountTypeDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetAllAccountTypeQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<GetAllAccountTypeDto>> Handle(GetAllAccountTypeQuery request, CancellationToken cancellationToken)
        {
            List<GetAllAccountTypeDto> result = new List<GetAllAccountTypeDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"SELECT at.id as id,at.name as name,at.description as description,at.is_active as is_active
                                 FROM account_type AS at";
                result = (List<GetAllAccountTypeDto>)await connection.QueryAsyncWithRetry<GetAllAccountTypeDto>(query, commandType: CommandType.Text);
            }
            return result;
        }
    }
}
