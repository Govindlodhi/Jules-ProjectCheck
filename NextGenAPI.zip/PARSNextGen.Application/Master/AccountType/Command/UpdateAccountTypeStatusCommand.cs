﻿using Amazon.Runtime.Internal;
using AutoMapper;
using MediatR;
using PARSNextGen.Application.Master.Queue.Command;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AccountType.Command
{
    public class UpdateAccountTypeStatusCommand : IRequest<bool>
    {
        public UpdateAccountTypeStatusReq typeStatusReq { get; set; }
    }
    public class UpdateAccountTypeStatusCommandHandler : IRequestHandler<UpdateAccountTypeStatusCommand, bool>
    {
        private readonly IMasterRepository _masterRepo;
        public UpdateAccountTypeStatusCommandHandler(IMasterRepository masterRepo)
        {
            _masterRepo = masterRepo;
        }
        public async Task<bool> Handle(UpdateAccountTypeStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _masterRepo.UpdateAccountTypeStatus(request.typeStatusReq.id, request.typeStatusReq.is_active);
            return result;
        }
    }
}
