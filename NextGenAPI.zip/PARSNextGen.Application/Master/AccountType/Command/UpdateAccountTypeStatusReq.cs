﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AccountType.Command
{
    public class UpdateAccountTypeStatusReq
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
}
