﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Master.Queue.Command;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AccountType.Command
{
    public class CreateAccountTypeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateAccountTypeReq createAccountTypeReq { get; set; }
    }
    public class CreateAccountTypeCommandHandler : IRequestHandler<CreateAccountTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IMasterRepository _masterRepo;
        public CreateAccountTypeCommandHandler(ISqlContext dbCntx, IMasterRepository masterRepository)
        {
            _dbCntx = dbCntx;
            _masterRepo = masterRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateAccountTypeCommand request, CancellationToken cancellationToken)
        {
            bool isDulicateData = false;
            Tuple<bool, bool> responseT = null;

            AccountTypes ats = new AccountTypes
            {
                name = request.createAccountTypeReq.name,
                description = request.createAccountTypeReq.description,
                is_active = request.createAccountTypeReq.is_active
            };
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var dp = new DynamicParameters();

                dp.Add("@name", request.createAccountTypeReq.name);
                string query = @"select id from account_type where name like '%'+@name+'%'";
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);
                isDulicateData = recordExists > 0;
            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _masterRepo.CreateAccountType(ats);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }
        }
    }
}
