﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Master.Queue.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AccountType.Command
{
    public class UpdateAccountTypeCommand : IRequest<bool>
    {
        public UpdateAccountTypeReq updateAccountTypeReq { get; set; }
    }
    public class UpdateAccountTypeCommandHandler : IRequestHandler<UpdateAccountTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IMasterRepository _masterRepo;

        public UpdateAccountTypeCommandHandler(ISqlContext dbCntx, IMasterRepository masterRepo)
        {
            _dbCntx = dbCntx;
            _masterRepo = masterRepo;
        }
        public async Task<bool> Handle(UpdateAccountTypeCommand request, CancellationToken cancellationToken)
        {
            bool result = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var dp = new DynamicParameters();
                var querycolumns = @"Select id,name,description from account_type where name=@name and id!=@id";
                dp.Add("@id", request.updateAccountTypeReq.id);
                dp.Add("@name", request.updateAccountTypeReq.name);
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, dp, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;
                else
                    result = await _masterRepo.UpdateAccountType(request.updateAccountTypeReq.id, request.updateAccountTypeReq.name, request.updateAccountTypeReq.description);

                return result;
            }
        }
    }
}