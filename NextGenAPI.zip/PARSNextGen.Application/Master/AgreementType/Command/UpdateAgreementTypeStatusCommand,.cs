﻿using AutoMapper;
using MediatR;
using PARSNextGen.Application.Master.AccountType.Command;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AgreementType.Command
{
    public class UpdateAgreementTypeStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class UpdateAgreementTypeStatusCommandHandler : IRequestHandler<UpdateAgreementTypeStatusCommand, bool>
    {
        private readonly IMasterRepository _masterRepo;
        private readonly IMapper _mapper;
        public UpdateAgreementTypeStatusCommandHandler(IMasterRepository masterRepo, IMapper mapper)
        {
            _masterRepo = masterRepo;
            _mapper = mapper;
        }
        public async Task<bool> Handle(UpdateAgreementTypeStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _masterRepo.UpdateAgreementTypeStatus(request.id, request.is_active);
            return result;
        }
    }
}
