﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Master.AccountType.Command;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AgreementType.Command
{
    public class UpdateAgreementTypeCommand : IRequest<bool>
    {
        public long id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
    }
    public class UpdateAgreementTypeCommandHandler : IRequestHandler<UpdateAgreementTypeCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IMasterRepository _masterRepo;

        public UpdateAgreementTypeCommandHandler(ISqlContext dbCntx, IMasterRepository masterRepo)
        {
            _dbCntx = dbCntx;
            _masterRepo = masterRepo;
        }
        public async Task<bool> Handle(UpdateAgreementTypeCommand request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from agreement_type where name=@name and id!=@id";
                dp.Add("@id", request.id);
                dp.Add("@name", request.name);
                int recordExists = await connection.ExecuteScalarAsync<int>(querycolumns, dp, commandType: CommandType.Text);
                if (recordExists > 0)
                    return false;

                bool result = await _masterRepo.UpdateAgreementType(request.id, request.name, request.description);
                return result;
            }
        }
    }
}
