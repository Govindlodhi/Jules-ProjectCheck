﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Master.Queue.Command;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AgreementType.Command
{
    public class CreateAgreementTypeCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateAgreementTypeReq CreateAgreementTypeReq { get; set; }
    }
    public class CreateAgreementTypeCommandHanler : IRequestHandler<CreateAgreementTypeCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IMasterRepository _masterRepo;
        private readonly IMediator _mediator;

        public CreateAgreementTypeCommandHanler(ISqlContext dbCntx, ICurrentUserService currentUserService, IMasterRepository queueRepository, IIdentityService identityService, IMediator mediator)
        {
            _dbCntx = dbCntx;
            _masterRepo = queueRepository;
            _mediator = mediator;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateAgreementTypeCommand request, CancellationToken cancellationToken)
        {
            Agreement data = new Agreement();
            Tuple<bool, bool> responseT = null;
            data.name = request.CreateAgreementTypeReq.name;
            data.description = request.CreateAgreementTypeReq.description;
            data.is_active = request.CreateAgreementTypeReq.is_active;

            bool isDulicateData = false;
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                string query = @"select id from agreement_type where name = @name";
                dp.Add("@name", request.CreateAgreementTypeReq.name);
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);

                if (recordExists > 0)
                {
                    isDulicateData = true;
                }
            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _masterRepo.CreateAgreementType(data);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }
        }
    }
}
