﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Master.AccountType.Query;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AgreementType.Query
{
    public class GetAgreementTypeByIdQuery : IRequest<List<GetAgreementTypeByIdDto>>
    {
        public long id { get; set; }
    }
    public class GetAgreementTypeByIdQueryHandler : IRequestHandler<GetAgreementTypeByIdQuery, List<GetAgreementTypeByIdDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetAgreementTypeByIdQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<GetAgreementTypeByIdDto>> Handle(GetAgreementTypeByIdQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            List<GetAgreementTypeByIdDto> result = new List<GetAgreementTypeByIdDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select at.id as id,at.name as name,at.description as description,at.is_active as is_active from agreement_type as at where id=@id";
                dp.Add("@id", request.id);
                result = (List<GetAgreementTypeByIdDto>)await connection.QueryAsyncWithRetry<GetAgreementTypeByIdDto>(query, dp, commandType: CommandType.Text);
            }
            return result;
        }
    }
}
