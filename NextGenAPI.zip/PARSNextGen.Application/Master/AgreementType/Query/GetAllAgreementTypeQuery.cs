﻿using MediatR;
using PARSNextGen.Application.Master.Queue.Query;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.AgreementType.Query
{
    public class GetAllAgreementTypeQuery : IRequest<List<GetAllAgreementTypeReq>>
    {

    }
    public class GetAllAgreementQueryHandler : IRequestHandler<GetAllAgreementTypeQuery, List<GetAllAgreementTypeReq>>
    {
        private readonly ISqlContext _dbCntx;
        public GetAllAgreementQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<GetAllAgreementTypeReq>> Handle(GetAllAgreementTypeQuery request, CancellationToken cancellationToken)
        {      
                List<GetAllAgreementTypeReq> record = new List<GetAllAgreementTypeReq>();
                using (var connection = _dbCntx.GetOpenConnection())
                {
                    string query = @"select at.id as id,at.name as name,at.description as description,at.is_active as is_active from agreement_type at";
                    record = (List<GetAllAgreementTypeReq>)await connection.QueryAsyncWithRetry<GetAllAgreementTypeReq>(query, commandType: CommandType.Text);
                }
                return record;                
        }
    }
}
