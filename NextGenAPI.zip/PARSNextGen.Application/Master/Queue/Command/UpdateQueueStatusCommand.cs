﻿using AutoMapper;
using MediatR;
using PARSNextGen.Application.Master.Service.Command;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Queue.Command
{
    public class UpdateQueueStatusCommand : IRequest<bool>
    {
        public long id { get; set; }
        public bool is_active { get; set; }
    }
    public class UpdateQueueStatusCommandHandler : IRequestHandler<UpdateQueueStatusCommand, bool>
    {
        private readonly IMasterRepository _masterRepository;
        public UpdateQueueStatusCommandHandler(IMasterRepository masterRepository)
        {
            _masterRepository = masterRepository;
        }
        public async Task<bool> Handle(UpdateQueueStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _masterRepository.UpdateQueueStatus(request.id, request.is_active);
            return result;
        }
    }
}