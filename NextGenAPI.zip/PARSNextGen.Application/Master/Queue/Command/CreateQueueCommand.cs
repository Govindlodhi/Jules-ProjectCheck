﻿using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Queue.Command
{
    public class CreateQueueCommand : IRequest<Tuple<bool, bool>>
    {
        public CreateQueueReq createQueueReq { get; set; }
    }
    public class CreateQueueCommandHandler : IRequestHandler<CreateQueueCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IMasterRepository _masterRepo;
        public CreateQueueCommandHandler(ISqlContext dbCntx, IMasterRepository queueRepository)
        {
            _dbCntx = dbCntx;
            _masterRepo = queueRepository;
        }
        public async Task<Tuple<bool, bool>> Handle(CreateQueueCommand request, CancellationToken cancellationToken)
        {
            bool isDulicateData = false;
            Tuple<bool, bool> responseT = null;

            Queues q = new Queues
            {
                name = request.createQueueReq.name,
                description = request.createQueueReq.description,
                is_active = request.createQueueReq.is_active
            };
            using (var connection = _dbCntx.GetOpenConnection())
            {
                DynamicParameters dp = new DynamicParameters();
                string query = @"select id from queue where name like '%'+@name+'%'";
                dp.Add("@name", request.createQueueReq.name);
                int recordExists = await connection.ExecuteScalarAsync<int>(query, dp, commandType: CommandType.Text);
                isDulicateData = recordExists > 0;
            }
            if (isDulicateData)
            {
                responseT = Tuple.Create(false, isDulicateData);
                return responseT;
            }
            else
            {
                bool contactUser = await _masterRepo.CreateQueue(q);
                responseT = Tuple.Create(contactUser, false);
                return responseT;
            }
        }
    }
}
