﻿using Amazon.Runtime.Internal;
using AutoMapper;
using Dapper;
using MediatR;
using PARSNextGen.Application.Account.Accounts.Command;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.User.Users.Command;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Queue.Command
{
    public class UpdateQueueCommand : IRequest<bool>
    {
        public UpdateQueueReq updateQueueReq { get; set; }
    }
    public class UpdateQueueCommandHandler : IRequestHandler<UpdateQueueCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IMasterRepository _masterRepo;

        public UpdateQueueCommandHandler(ISqlContext dbCntx, IMasterRepository masterRepository)
        {
            _dbCntx = dbCntx;
            _masterRepo = masterRepository;
        }
        public async Task<bool> Handle(UpdateQueueCommand request, CancellationToken cancellationToken)
        {
            DynamicParameters parameters = new DynamicParameters();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description from queue where name=@name and id!=@id";
                parameters.Add("@id", request.updateQueueReq.id);
                parameters.Add("@name", request.updateQueueReq.name);
                int queueExist = await connection.ExecuteScalarAsync<int>(querycolumns, parameters, commandType: CommandType.Text);
                if (queueExist > 0)
                    return false;

                bool result = await _masterRepo.UpdateQueue(request.updateQueueReq.id, request.updateQueueReq.name, request.updateQueueReq.description);
                return result;
            }
        }
    }
}

