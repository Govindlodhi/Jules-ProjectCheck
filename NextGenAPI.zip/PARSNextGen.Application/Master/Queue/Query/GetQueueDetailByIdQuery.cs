﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Account.Accounts.Queries;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Queue.Query
{
    public class GetQueueDetailByIdQuery : IRequest<GetQueueDetailByIdDto>
    {
        public long id { get; set; }
    }
    public class GetQueueDetailByIdQueryHandler : IRequestHandler<GetQueueDetailByIdQuery, GetQueueDetailByIdDto>
    {
        private readonly ISqlContext _dbCntx;
        public GetQueueDetailByIdQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<GetQueueDetailByIdDto> Handle(GetQueueDetailByIdQuery request, CancellationToken cancellationToken)
        {
            var dp = new DynamicParameters();
            GetQueueDetailByIdDto result = new GetQueueDetailByIdDto();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select q.id as id,q.name as name,q.description as description,q.is_active as is_active from Queue as q  where id=@id";
                dp.Add("@id", request.id);
                result = await connection.QueryFirstOrDefaultAsync<GetQueueDetailByIdDto>(query, dp, commandType: CommandType.Text);
            }
            return result;
        }
    }
}
