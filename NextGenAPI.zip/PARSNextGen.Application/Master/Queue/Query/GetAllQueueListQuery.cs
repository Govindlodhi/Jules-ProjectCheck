﻿using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Queue.Query
{
    public class GetAllQueueListQuery : IRequest<List<GetAllQueueListDto>>
    {
    }
    public class GetAllQueueListQueryHandler : IRequestHandler<GetAllQueueListQuery, List<GetAllQueueListDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetAllQueueListQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<GetAllQueueListDto>> Handle(GetAllQueueListQuery request, CancellationToken cancellationToken)
        {
            List<GetAllQueueListDto> queueList = new List<GetAllQueueListDto>();
            using (var connection = _dbCntx.GetOpenConnection())
            {
                string query = @"select q.id as id,q.name as name,q.description as description,q.is_active as is_active from Queue as q";
                queueList = (List<GetAllQueueListDto>)await connection.QueryAsyncWithRetry<GetAllQueueListDto>(query, commandType: CommandType.Text);
            }
            return queueList;
        }
    }
}