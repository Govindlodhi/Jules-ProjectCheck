﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using PARSNextGen.Domain.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Permission.Queries
{
    public class GetRolePermissionQuery : IRequest<PermissionDto>
    {
        public long id { get; set; }
        public long account_type_id { get; set; }
    }
    public class GetPermissionForRoleQueryHandler : IRequestHandler<GetRolePermissionQuery, PermissionDto>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserContext;
        public GetPermissionForRoleQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserContext)
        {
            _dbCntx = dbCntx;
            _currentUserContext = currentUserContext;
        }

        public async Task<PermissionDto> Handle(GetRolePermissionQuery request, CancellationToken cancellationToken)
        {
            List<RolePermissionDto> userPermissions = null;
            DynamicParameters parameters = new DynamicParameters();
            var procedure = "sp_get_permissions_for_role";
            using (var connection = _dbCntx.GetOpenConnection())
            {
                parameters.Add("@pId", request.id);
                userPermissions = (List<RolePermissionDto>)await connection.QueryAsyncWithRetry<RolePermissionDto>(procedure, parameters, commandType: CommandType.StoredProcedure);
            }

            //filter user permission by applicable to FMC or applicable to Fleet or applicable to PARS

            ////if Account Type- Fleet
            //if (_currentUserContext.AccountTypeId ==(long) EnumTypes.AccountTypes.Fleet)
            //    userPermissions = userPermissions.Where(x => x.applicable_to_fleet == true).ToList();

            ////if Account Type- Cutomer Account
            //if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.Account)
            //    userPermissions = userPermissions.Where(x => x.applicable_to_fleet == true).ToList();

            ////if Account Type- FMC
            //if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.FMC)
            //    userPermissions = userPermissions.Where(x => x.applicable_to_fmc == true).ToList();

            ////if Account Type- PARS
            //if (_currentUserContext.AccountTypeId == (long)EnumTypes.AccountTypes.PARS)
            //    userPermissions = userPermissions.Where(x => x.applicable_to_pars == true).ToList();




            //if Account Type- Fleet
            if (request.account_type_id == (long)EnumTypes.AccountTypes.Fleet)
                userPermissions = userPermissions.Where(x => x.applicable_to_fleet == true).ToList();

            //if Account Type- Cutomer Account
            if (request.account_type_id == (long)EnumTypes.AccountTypes.Account)
                userPermissions = userPermissions.Where(x => x.applicable_to_fleet == true).ToList();

            //if Account Type- FMC
            if (request.account_type_id == (long)EnumTypes.AccountTypes.FMC)
                userPermissions = userPermissions.Where(x => x.applicable_to_fmc == true).ToList();

            //if Account Type- PARS
            if (request.account_type_id == (long)EnumTypes.AccountTypes.PARS)
                userPermissions = userPermissions.Where(x => x.applicable_to_pars == true).ToList();


            PermissionDto permissionsDto = new PermissionDto();

            permissionsDto.role_id = userPermissions[0].role_id;
            permissionsDto.role_name = userPermissions[0].role_name;
            permissionsDto.is_read_only = userPermissions[0].is_read_only;

            var uniquePermissionSet = userPermissions.Select(u => new { u.permission_set, u.permission_set_id }).Distinct();

            permissionsDto.permissionSets = new List<PermissionSet>();

            foreach (var per in uniquePermissionSet)
            {
                PermissionSet permissionSet = new PermissionSet();
                permissionSet.permissions = new List<Permissions>();

                permissionSet.permission_set = per.permission_set;
                permissionSet.permission_set_id = per.permission_set_id;
                var setPer = userPermissions.Where(x => x.permission_set == permissionSet.permission_set).ToList();

                foreach (var item in setPer)
                {
                    Permissions p = new Permissions();

                    p.permission_id = item.permission_id;
                    p.permission_name = item.permission_name;
                    p.dependent_permission_id = item.dependent_permission_id;
                    p.description = item.description;
                    p.is_assigned = item.is_assigned;
                   
                    permissionSet.permissions.Add(p);
                }

                permissionsDto.permissionSets.Add(permissionSet);
            }

            return permissionsDto;
        }
    }
}
