﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Permission.Queries
{
    public class RolePermissionDto
    {
        public bool is_assigned { get; set; }
        public long permission_id { get; set; }
        public string permission_name { get; set; }
        public string description { get; set; }
        public long dependent_permission_id { get; set; }
        public long role_id { get; set; }
        public string role_name { get; set; }
        public string permission_set { get; set; }
        public long permission_set_id { get; set; }
        public bool? applicable_to_fmc { get; set; }
        public bool? applicable_to_fleet { get; set; }
        public bool? applicable_to_pars { get; set; }
        public bool is_read_only { get; set; }

    }

    public class PermissionDto
    {
        public long role_id { get; set; }
        public string role_name { get; set; }
        public bool is_read_only { get; set; }
        public List<PermissionSet> permissionSets { get; set; }
    }

    public class Permissions
    {
        public long permission_id { get; set; }
        public string permission_name { get; set; }
        public string description { get; set; }
        public bool is_assigned { get; set; }
        public long dependent_permission_id { get; set; }
    }

    public class PermissionSet
    {
        public string permission_set { get; set; }
        public long permission_set_id { get; set; }
        public List<Permissions> permissions { get; set; }
    }

}



