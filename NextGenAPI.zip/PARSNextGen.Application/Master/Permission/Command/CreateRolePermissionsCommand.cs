﻿using MediatR;
using PARSNextGen.Domain.Interface;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PARSNextGen.Application.Master.Permission.Command
{
    public class CreateRolePermissionsCommand : IRequest<bool>
    {
        public long role_id { get; set; }
        public List<long> permission_ids { get; set; }
    }
    public class AddUserRoleCommandHandler : IRequestHandler<CreateRolePermissionsCommand, bool>
    {
        private readonly IRoleRepository _roleRepo;
        public AddUserRoleCommandHandler(IRoleRepository roleRepo)
        {
            _roleRepo = roleRepo;
        }
        public async Task<bool> Handle(CreateRolePermissionsCommand request, CancellationToken cancellationToken)
        {
            bool status = await _roleRepo.CreateRolePermission(request.role_id,request.permission_ids);
            return status;
        }
    }
}
