﻿using System.Data;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using Dapper;

namespace PARSNextGen.Application.Master.Roles.Queries.RoleDetail
{
    public class RoleDetailQuery : IRequest<RoleDetailDto>
    {
        public int role_id { get; set; }
    }

    public class GetRoleByIdQueryHandler : IRequestHandler<RoleDetailQuery, RoleDetailDto>
    {
        private readonly ISqlContext _dbCntx;
        public GetRoleByIdQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }

        public async Task<RoleDetailDto> Handle(RoleDetailQuery request, CancellationToken cancellationToken)
        {
            RoleDetailDto userRoles = new RoleDetailDto();
            DynamicParameters dp = new DynamicParameters();
            var procedure = "sp_get_role_by_role_id";
            using (var connection = _dbCntx.GetOpenConnection())
            {
                dp.Add("@pRoleId", request.role_id);
                userRoles = await connection.QueryFirstOrDefaultAsyncWithRetry<RoleDetailDto>(procedure, dp, commandType: CommandType.StoredProcedure);
            }
            return userRoles;
        }
    }

}

