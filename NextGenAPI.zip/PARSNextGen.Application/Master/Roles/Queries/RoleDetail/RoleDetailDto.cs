﻿using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace PARSNextGen.Application.Master.Roles.Queries.RoleDetail
{
    public class RoleDetailDto 
    {
        public int id { get; set; }
        public string name { get; set; }
        public bool is_active { get; set; }
        public bool is_read_only { get; set; }
        public string description { get; set; }
    }
}
