﻿using PARSNextGen.Domain.Common;
using PARSNextGen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace PARSNextGen.Application.Master.Roles.Queries.AccountRoles
{
    public class RolesDto
    {
        public int id { get; set; } 
        public string name { get; set; }
        public int is_active { get; set; }
        public int is_read_only { get; set; }
        public string description { get; set; }
        public bool is_assigned { get; set; }

        public long account_type_id { get; set; }



    }
}
