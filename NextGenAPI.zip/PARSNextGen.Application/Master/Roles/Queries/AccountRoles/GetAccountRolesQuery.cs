﻿using System.Data;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Application.Utility;
using Dapper;
using PARSNextGen.Application.Service;

namespace PARSNextGen.Application.Master.Roles.Queries.AccountRoles
{
    public class GetAccountRolesQuery : IRequest<List<RolesDto>>
    {
        public long accountId { get; set; }
    }

    public class GetAllRolesQueryHandler : IRequestHandler<GetAccountRolesQuery, List<RolesDto>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public GetAllRolesQueryHandler(ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _currentUserService = currentUserService;
        }

        public async Task<List<RolesDto>> Handle(GetAccountRolesQuery request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            List<RolesDto> userRoles = new List<RolesDto>();
            var procedure = "sp_get_account_roles";

            dp.Add("@accountId", request.accountId);
            
            using (var connection = _dbCntx.GetOpenConnection())
            {
                userRoles = (List<RolesDto>)await connection.QueryAsyncWithRetry<RolesDto>(procedure, dp,commandType: CommandType.StoredProcedure);
            }
            return userRoles;
        }
    }

}

