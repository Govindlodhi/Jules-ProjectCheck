﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using PARSNextGen.Domain.Interface;
using PARSNextGen.Application.SQL;
using FluentValidation;
using Dapper;
using PARSNextGen.Application.Service;
using System.Data;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.Master.Roles.Queries.RoleDetail;

namespace PARSNextGen.Application.Master.Roles.Command.CreateRole
{
    public class CreateRoleCommand : IRequest<bool>
    {
        public string role_name { get; set; }
        public string role_description { get; set; }
    }

    public class CreateRoleCommandHandler : IRequestHandler<CreateRoleCommand, bool>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IRoleRepository _roleRepo;
        private readonly ICurrentUserService _currentUserService;

        public CreateRoleCommandHandler(IRoleRepository roleRepo, ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _roleRepo = roleRepo;
            _currentUserService = currentUserService;
        }

        public async Task<bool> Handle(CreateRoleCommand request, CancellationToken cancellationToken)
        {
            DynamicParameters parameters = new DynamicParameters();
            RoleDetailDto roleDetailDto = null;

            // Check if record is already exist or not
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description,is_active,is_read_only from role where name=@name and account_id=@accountId";
                parameters.Add("@name", request.role_name);
                parameters.Add("@accountId", _currentUserService.AccountId);
                roleDetailDto = await connection.QueryFirstOrDefaultAsyncWithRetry<RoleDetailDto>(querycolumns, parameters, commandType: CommandType.Text);
            }

            if (roleDetailDto != null)
                return false;
            // Create Role
            bool role =  await _roleRepo.CreateRole(request.role_name, request.role_description);
            return role;
        }


    }

}

