﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using PARSNextGen.Domain.Interface;

namespace PARSNextGen.Application.Master.Roles.Command.UpdateRoleStatus
{
    public class UpdateRoleStatusCommand : IRequest<bool>
    {
        public int role_id { get; set; }
        public bool role_status { get; set; }
    }

    public class UpdateRoleStatusCommandHandler : IRequestHandler<UpdateRoleStatusCommand, bool>
    {
        private readonly IRoleRepository _roleRepo;
        public UpdateRoleStatusCommandHandler(IRoleRepository roleRepo)
        {
            _roleRepo = roleRepo;
        }

        public async Task<bool> Handle(UpdateRoleStatusCommand request, CancellationToken cancellationToken)
        {
            bool result = await _roleRepo.UpdateRoleStatus(request.role_id, request.role_status);
            return result;
        }
    }
}
