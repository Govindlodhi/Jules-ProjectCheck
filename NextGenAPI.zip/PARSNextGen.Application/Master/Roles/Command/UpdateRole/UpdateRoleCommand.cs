﻿
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using PARSNextGen.Domain.Interface;
using PARSNextGen.Application.SQL;
using Dapper;
using PARSNextGen.Application.Service;
using System.Data;
using PARSNextGen.Application.Utility;
using PARSNextGen.Application.Master.Roles.Queries.RoleDetail;

namespace PARSNextGen.Application.Master.Roles.Command.UpdateRole
{
    public class UpdateRoleCommand : IRequest<bool>
    {
        public int role_id { get; set; }
        public string role_name { get; set; }
        public string role_description { get; set; }
    }

    public class UpdateRoleCommandHandler : IRequestHandler<UpdateRoleCommand, bool>
    {
        private readonly IRoleRepository _roleRepo;
        private readonly ISqlContext _dbCntx;
        private readonly ICurrentUserService _currentUserService;
        public UpdateRoleCommandHandler(IRoleRepository roleRepo, ISqlContext dbCntx, ICurrentUserService currentUserService)
        {
            _dbCntx = dbCntx;
            _roleRepo = roleRepo;
            _currentUserService = currentUserService;
        }

        public async Task<bool> Handle(UpdateRoleCommand request, CancellationToken cancellationToken)
        {
            DynamicParameters parameters = new DynamicParameters();
            RoleDetailDto roleDetailDto = null;

            // Check if record is already exist or not
            using (var connection = _dbCntx.GetOpenConnection())
            {
                var querycolumns = @"Select id,name,description,is_active,is_read_only from role where name=@name and account_id=@accountId and id!=@roleId";
                parameters.Add("@name", request.role_name);
                parameters.Add("@roleId", request.role_id);
                parameters.Add("@accountId", _currentUserService.AccountId);
                
                roleDetailDto = await connection.QueryFirstOrDefaultAsyncWithRetry<RoleDetailDto>(querycolumns, parameters, commandType: CommandType.Text);
            }

            if (roleDetailDto != null)
                return false;

            bool result = await _roleRepo.UpdateRoleById(request.role_id, request.role_name, request.role_description);
            return result;
        }
    }
}
