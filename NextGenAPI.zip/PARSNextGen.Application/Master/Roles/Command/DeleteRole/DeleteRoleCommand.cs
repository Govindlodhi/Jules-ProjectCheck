﻿using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;
using Dapper;
using MediatR;
using PARSNextGen.Application.SQL;
using PARSNextGen.Domain.Interface;

namespace PARSNextGen.Application.Master.Roles.Command.DeleteRole
{
    public class DeleteRoleCommand : IRequest<Tuple<bool,bool>>
    {
        public int role_id { get; set; }
    }

    public class DeleteRoleCommandHandler : IRequestHandler<DeleteRoleCommand, Tuple<bool, bool>>
    {
        private readonly ISqlContext _dbCntx;
        private readonly IRoleRepository _roleRepo;
        public DeleteRoleCommandHandler(ISqlContext dbCntx, IRoleRepository roleRepo)
        {
            _dbCntx = dbCntx;
            _roleRepo = roleRepo;
        }

        public async Task<Tuple<bool, bool>> Handle(DeleteRoleCommand request, CancellationToken cancellationToken)
        {
            DynamicParameters dp = new DynamicParameters();
            var query = "sp_check_assigned_role";
            long count = 0;
            Tuple<bool, bool> responseT = null;
            using (var con = _dbCntx.GetOpenConnection())
            {
                dp.Add("@pRoleId", request.role_id);
                dp.Add("@pCount", dbType: DbType.Int32, direction: ParameterDirection.Output);
                await con.QueryAsync(query, dp, commandType: CommandType.StoredProcedure);

                count = dp.Get<int>("@pCount");

                if (count > 0)
                {
                    responseT = Tuple.Create(true, false);
                    return responseT;
                }
                else
                {
                    bool res = await _roleRepo.DeleteRoleById(request.role_id);
                    responseT = Tuple.Create(false, res);
                    return responseT;
                }
            }

        }
    }
}
