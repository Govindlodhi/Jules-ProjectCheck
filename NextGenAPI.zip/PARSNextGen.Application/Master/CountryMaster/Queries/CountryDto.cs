﻿using System.Collections.Generic;
using PARSNextGen.Domain.Entities;
using PARSNextGen.Domain.Common;

namespace PARSNextGen.Application.Master.CountryMaster.Queries
{
    public class CountryDto
    {
        public long id { get; set; }
        public string name { get; set; }
    }
}
