﻿using Dapper;
using MediatR;
using PARSNextGen.Application.Service;
using PARSNextGen.Application.SQL;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace PARSNextGen.Application.Master.CountryMaster.Queries
{
    public class GetCountryQuery : IRequest<List<CountryDto>>
    {
    }
    public class GetCountryQueryHandler : IRequestHandler<GetCountryQuery, List<CountryDto>>
    {
        private readonly ISqlContext _dbCntx;
        public GetCountryQueryHandler(ISqlContext dbCntx)
        {
            _dbCntx = dbCntx;
        }
        public async Task<List<CountryDto>> Handle(GetCountryQuery request, CancellationToken cancellationToken)
        {
            List<CountryDto> countries = new List<CountryDto>();

            using (var connection = _dbCntx.GetOpenConnection())
            {
                string CountryList = @"select id,name from country  where is_active = 1";
                countries = (List<CountryDto>)await connection.QueryAsync<CountryDto>(CountryList, null, commandType: CommandType.Text);
            }
            return countries;
        }
    }
}
